package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class VideoTrack (
	var id: String? = null,
	var videoId: Int? = null,
	var isocode: String? = null,
	var roleFlags: Int? = null,
	var label: String? = null,
	var isSelected: Boolean? = null,
	var mimeType: String? = null,
	var origId: String? = null
)
