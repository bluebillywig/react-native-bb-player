package com.bluebillywig.bbnativeshared.controller

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.EmbedObject

/**
 * @suppress
 */
class MasterController (eventBus: EventBusInterface?): EventListenerInterface {
    companion object {
        const val TAG = "MasterController"
    }

    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_embed_loaded -> {
                if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
            }
            else -> { return }
        }
        // Logger.d(TAG, "Processed event: $eventType data: $data")
    }
    // resources
    private var _eventBus: EventBusInterface? = eventBus

    // settings
    private var _autoMute: Boolean = false
    // private var _autoMuteIfNeededForAutoPlay: Boolean = false

    // state
    private var _muted: Boolean = false
    private var _volume: Double = 1.0

    init {
        _eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
    }

    fun __destruct() {
        _eventBus?.removeEventlistener(this)
        _eventBus = null
    }

    var muted: Boolean // masterMuted
        get() = _muted
        set(value) {
            val muted = _muted
            _muted = value
            if (_muted != muted) {
                if (_muted) {
                    _eventBus?.trigger(EventName.bb_master_mute)
                } else {
                    _eventBus?.trigger(EventName.bb_master_unmute)
                }
            }
        }

    var volume: Double // masterVolume
        get() = _volume
        set(value) {
            val volume = _volume
            _volume = value
            if (_volume != volume) {
                _eventBus?.trigger(EventName.bb_master_volume, mapOf("volume" to _volume))
            }
        }

    private fun _ingestOpts(opts: EmbedObject?) {
        if (opts != null) {
            // playout settings
            if (opts.playoutData != null) {
                if (opts.playoutData.autoMute != null) _autoMute = opts.playoutData.autoMute == "true"
                // if (opts.playoutData.autoMuteIfNeededForAutoPlay != null) _autoMuteIfNeededForAutoPlay = opts.playoutData.autoMuteIfNeededForAutoPlay == "true"

                if (_autoMute) this.muted = true // NB using public setter!
            }
        }
    }
}
