package com.bluebillywig.bbnativeshared.controller

import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.EmbedObject

/**
 * @suppress
 */
open class InViewController (eventBus: EventBusInterface?, pc: ProgramController?, mc: MasterController? = null): EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				// check options dict and override values (here, because can't add options argument to _ingestOpts)
				val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
				if (options != null && options["autoPlay"] != null) {
					if (options["autoPlay"] is String) _autoPlay_override = (options["autoPlay"] as String == "true")
					if (options["autoPlay"] is Boolean) _autoPlay_override = options["autoPlay"] as Boolean
				}
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_inview -> {
				_onInView(eventType)
			}
			EventName.bb_outview -> {
				_onOutView(eventType)
			}
			EventName.bb_adunit_initialized -> {
				if (data != null && data["adUnitSettings"] is MutableMap<*,*>) {
					val adUnitSettings = data["adUnitSettings"] as MutableMap<String, String?>
					var inViewMarginString = ""
					if (adUnitSettings["inviewMargin"] != null) inViewMarginString = adUnitSettings["inviewMargin"] as String
					inViewMarginString = inViewMarginString.replace("%", "")
					if ( inViewMarginString != "" ) {
						try {
							_inViewMargin = inViewMarginString.toInt()
						} catch (e: Exception) {}
					}
				}
			}
			else -> { return }
		}
		Logger.d("[InViewController] onEvent", "Processed event: $eventType")
	}
	// resources
	protected var _eventBus: EventBusInterface? = eventBus
	private var _pc: ProgramController? = pc
	private var _mc: MasterController? = mc

	// settings
	protected var _inViewAction: String = ""
	protected var _outViewAction: String = ""
	protected var _inViewMargin: Int = 0
	protected var _autoPlay: Boolean = false
	protected var _autoPlay_override: Boolean = false

	// state
	protected var _inView: Boolean = false
	protected var _inView_forced: Boolean? = null
	protected var _outViewOnce: Boolean = false

	init {
		_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
	}

	open fun __destruct() {
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}
	/**
	 * Set inView (forced)
	 *
	 * @param mixed inView TRUE, FALSE, or NULL (meaning unforced)
	 */
	public fun setInView(inView: Boolean?) {
		_inView_forced = inView
		if (_inView_forced != _inView) {
			if (_inView_forced ?: _inView) { // NB!
				_eventBus?.trigger(EventName.bb_inview)
			} else {
				_eventBus?.trigger(EventName.bb_outview)
			}
		}
	}

	/**
	 * Get inView
	 */
	public fun getInView(): Boolean {
		return _inView_forced ?: _inView
	}

	private fun _onInView(eventType: EventName?) {
		if (_inView_forced == false) return // bail out
		Logger.d("[InViewController] _onInView", "")
		_inView = true

		when (_inViewAction.toUpperCase()) {
			"PLAY" -> {
				_pc?.play(userAction = false)
			}
			"UNMUTE" -> {
				val mc = _mc
				if (mc != null) mc.muted = false else _eventBus?.trigger(EventName.bb_master_unmute)
			}
			"PLAY AND UNMUTE" -> {
				val mc = _mc
				if (mc != null) mc.muted = false else _eventBus?.trigger(EventName.bb_master_unmute)
				_pc?.play(userAction = false)
			}
			else -> {
			} // "NONE"
		}
	}

	private fun _onOutView(eventType: EventName?) {
		if (_inView_forced == true) return // bail out
		Logger.d("[InViewController] _onOutView", "")
		_inView = false

		when (_outViewAction.toUpperCase()) {
			"PAUSE" -> {
				if ((_autoPlay || _autoPlay_override) && !_outViewOnce) {
					_outViewOnce = true
					return // avoid pausing
				}
				_pc?.pause()
			}
			"MUTE" -> {
				val mc = _mc
				if (mc != null) mc.muted = true else _eventBus?.trigger(EventName.bb_master_mute)
			}
			"PAUSE AND MUTE" -> {
				val mc = _mc
				if (mc != null) mc.muted = true else _eventBus?.trigger(EventName.bb_master_mute)
				if ((_autoPlay || _autoPlay_override) && !_outViewOnce) {
					_outViewOnce = true
					return // avoid pausing
				}
				_pc?.pause()
			}
			else -> {
			} // "NONE"
		}
	}

	protected open fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			// playout settings
			if (opts.playoutData != null) {
				if (opts.playoutData.interactivityInView != null) _inViewAction = opts.playoutData.interactivityInView
				if (opts.playoutData.interactivityOutView != null) _outViewAction = opts.playoutData.interactivityOutView
				if (opts.playoutData.autoPlay != null) _autoPlay = (opts.playoutData.autoPlay == "true")

				if (_inView) { // NB!
					_onInView(null)
				} else {
					_onOutView(null)
				}
			}
		}
	}
}
