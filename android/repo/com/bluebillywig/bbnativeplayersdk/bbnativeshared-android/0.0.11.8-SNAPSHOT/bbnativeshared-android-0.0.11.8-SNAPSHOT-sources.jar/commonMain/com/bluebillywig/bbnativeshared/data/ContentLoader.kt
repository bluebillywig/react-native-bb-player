package com.bluebillywig.bbnativeshared.data

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import kotlinx.coroutines.*
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlin.coroutines.CoroutineContext



class ContentLoader : CoroutineScope {
    var network: NetworkInterface? = null

    private val job = SupervisorJob()
    // Use Dispatchers.IO instead of Main thread
    override val coroutineContext: CoroutineContext = job + Dispatchers.IO

    // Static methods for parsing Media Objects, mostly build for use in iOS
    companion object { // this is Kotlin's way to support static class methods; don't ask...

        // reusable Json parser instance
        val optimizedJsonParser: Json = Json {
            ignoreUnknownKeys = true
            isLenient = true
            serializersModule = contentItemSerializersModule
        }

        fun parsePlayout(jsonString: String): Playout? {
            try {
                val responseText = fixDataInconsistencies(jsonString)
                val returnObject = optimizedJsonParser.decodeFromString<Playout>(responseText)
                // returnObject.rawJsonString = responseText
                return returnObject
            } catch (e: Exception) {
                Logger.d("ContentLoader.parsePlayout", "Error parsing Data: ${e}")
                return null
            }
        }

        fun parseMediaClip(jsonString: String): MediaClip? {
            try {
                val responseText = fixDataInconsistencies(jsonString)
                val typedObject = optimizedJsonParser.decodeFromString<TypedObject>(responseText)
                if ( typedObject.type != "MediaClip" ) {
                    return null
                }
                val returnObject = optimizedJsonParser.decodeFromString<MediaClip>(responseText)
                returnObject.rawJsonString = responseText
                return returnObject
            } catch (e: Exception) {
                Logger.d("ContentLoader.parseMediaClip", "Error parsing Data: ${e}")
                return null
            }
        }

        fun parseProject(jsonString: String): Project? {
            try {
                val responseText = fixDataInconsistencies(jsonString)
                val typedObject = optimizedJsonParser.decodeFromString<TypedObject>(responseText)
                if ( typedObject.type != "Project" ) {
                    return null
                }
                val returnObject:Project = optimizedJsonParser.decodeFromString<Project>(responseText)
                returnObject.rawJsonString = responseText
                return returnObject
            } catch (e: Exception) {
                Logger.d("ContentLoader.parseProject", "Error parsing Data: ${e}")
                return null
            }
        }

        fun parseMediaClipList(jsonString: String): MediaClipList? {
            try {
                val responseText = fixDataInconsistencies(jsonString)
                val typedObject = optimizedJsonParser.decodeFromString<TypedObject>(responseText)
                if ( typedObject.type != "MediaClipList" ) {
                    return null
                }
                val returnObject = optimizedJsonParser.decodeFromString<MediaClipList>(responseText)
                returnObject.rawJsonString = responseText
                return returnObject
            } catch (e: Exception) {
                Logger.d("ContentLoader.parseMediaClipList", "Error parsing Data: ${e}")
                return null
            }
        }

        fun fixDataInconsistencies( dataString: String ): String  {
            var s1 = "\"fitmode\":\"\""
            var s2 = "\"fitmode\":\"FIT_BOTH\""
            var ret = dataString.replace(s1,s2)

            s1 = "\"isPrefetch\":\"1\""
            s2 = "\"isPrefetch\":\"true\""
            ret = ret.replace(s1,s2)
            s1 = "\"isPrefetch\":\"0\""
            s2 = "\"isPrefetch\":\"false\""
            ret = ret.replace(s1,s2)

            s1 = "\"allowDatasource\":true"
            s2 = "\"allowDatasource\":\"true\""
            ret = ret.replace(s1,s2)
            s1 = "\"allowDatasource\":false"
            s2 = "\"allowDatasource\":\"false\""
            ret = ret.replace(s1,s2)

            val r1 = Regex(""""skipOffset":([^",}]+)""") // non-String value
            val t2 = { mr: MatchResult -> "\"skipOffset\":\"${mr.groupValues[1]}\"" }
            ret = r1.replace(ret,t2)

            // PHP object - array mixup
            ret = ret.replace("\"customfields\":[]", "\"customfields\":{}")

            // from Solr
            ret = ret.replace("\"deeplink_string\":", "\"deeplink\":")
            ret = ret.replace("\"gendeeplink_string\":", "\"gendeeplink\":")
            ret = ret.replace("\"src_string\":", "\"src\":")
            ret = ret.replace("\"length_int\":", "\"length\":")
            ret = ret.replace("\"width_int\":", "\"width\":")
            ret = ret.replace("\"height_int\":", "\"height\":")

            ret = ret.replace("\"assets\":\"", "\"assets_json\":\"")
            ret = ret.replace("\"thumbnails\":\"", "\"thumbnails_json\":\"")

            // strip bare timeline id's (strings); we expect [{"id":"<id>"}] instead of ["<id>"]
            ret = Regex(""""timelines":\s*\[\s*"[^]]*"\s*\]""").replace(ret, "\"timelines\":[]")

            return ret
        }
    }

    inline fun <reified T>getObjectFromJsonUrl(jsonUrl: String, crossinline onSuccess: (retObject: T) -> Unit, crossinline onFailure: (error: Exception) -> Unit) {
        Logger.d("ContentLoader", "getObjectFromJsonUrl: ${jsonUrl}")

        this.network?.getJsonStringAndHeaders(jsonUrl, { responseJson, responseHeaders ->
            Logger.d("ContentLoader", "Data loaded. Moving to background thread for parsing")

            // moved processing to background thread
            launch {
                try {
                    val responseText = fixDataInconsistencies(responseJson)
                    val returnObject = optimizedJsonParser.decodeFromString<T>(responseText)

                    if (returnObject is BBModel) {
                        returnObject.rawJsonString = responseText

                        val cookieStrings: List<String> = responseHeaders.get("set-cookie") ?: listOf()
                        val bbCpJwtCookieString = cookieStrings.find({ it.startsWith("BB_CP_JWT=") }) // NB first found!
                        if (!bbCpJwtCookieString.isNullOrEmpty()) {
                            returnObject.bbCpJwtCookieString = bbCpJwtCookieString
                        }
                    }
                    Logger.d("ContentLoader", "Data parsed successfully on background thread")

                    withContext(Dispatchers.Main) {
                        onSuccess(returnObject)
                    }
                } catch (e: Exception) {
                    Logger.d("ContentLoader", "Parsing failed: ${e.message}")
                    // Switch to Main thread for error callback
                    withContext(Dispatchers.Main) {
                        onFailure(Exception("PARSE_ERROR: ${e.message}"))
                    }
                } catch (ce: CancellationException) {
                    Logger.d("ContentLoader", "JSON parsing cancelled")
                    throw ce // Re-throw cancellation to properly handle coroutine cancellation
                }
            }
        }, {
            Logger.d("ContentLoader", "Json load using network failed")
            // switch to Main thread
            launch(Dispatchers.Main) {
                onFailure(Exception("NETWORK_ERROR: failed to load json url"))
            }
        })
    }

    fun getContentFromJsonUrl(jsonUrl: String, onSuccess: (contentItem: ContentItemInterface) -> Unit, onFailure: (error: Exception) -> Unit) {

        Logger.d("ContentLoader", "getContentFromJsonUrl: ${jsonUrl}")
        this.network?.getJsonString(jsonUrl, { responseJson ->
            Logger.d("ContentLoader", "Data loaded. Moving to background thread for parsing")

            // moved processing to background thread
            launch {
                try {
                    val responseText = fixDataInconsistencies(responseJson)

                    val typedObject = optimizedJsonParser.decodeFromString<TypedObject>(responseText)

                    val contentType = typedObject.type
                    if (contentType != null) {
                        Logger.d("ContentLoader", "Found contenttype in json: $contentType")

                        val returnObject: ContentItemInterface = when (contentType) {
                            "MediaClip" -> {
                                val mediaClip = optimizedJsonParser.decodeFromString<MediaClip>(responseText)
                                mediaClip.rawJsonString = responseText
                                Logger.d("ContentLoader", "Data parsed for type MediaClip on background thread")
                                mediaClip
                            }
                            "Project" -> {
                                val project = optimizedJsonParser.decodeFromString<Project>(responseText)
                                project.rawJsonString = responseText
                                Logger.d("ContentLoader", "Data parsed for type Project on background thread")
                                project
                            }
                            "MediaClipList" -> {
                                val mediaClipList = optimizedJsonParser.decodeFromString<MediaClipList>(responseText)
                                mediaClipList.rawJsonString = responseText
                                Logger.d("ContentLoader", "Data parsed for type MediaClipList on background thread")
                                mediaClipList
                            }
                            else -> {
                                Logger.e("ContentLoader", "Unsupported content type: $contentType")
                                throw IllegalArgumentException("PARSE_ERROR: No Compatible Content Type Found in JSON")
                            }
                        }
                        // Switch to Main thread
                        withContext(Dispatchers.Main) {
                            onSuccess(returnObject)
                        }
                    } else {
                        Logger.e("ContentLoader", "No content type found in JSON")
                        // Switch to Main thread
                        withContext(Dispatchers.Main) {
                            onFailure(Exception("PARSE_ERROR: No Compatible Content Type Found in JSON"))
                        }
                    }
                } catch (e: Exception) {
                    Logger.e("ContentLoader", "Data parsing failed: ${e.message}")
                    // Switch to Main thread
                    withContext(Dispatchers.Main) {
                        onFailure(Exception("PARSE_ERROR: ${e.message}"))
                    }
                } catch (ce: CancellationException) {
                    Logger.d("ContentLoader", "Content parsing cancelled")
                    throw ce // Re-throw cancellation to maintain proper coroutine behavior
                }
            }
        }, {
            Logger.d("ContentLoader", "Json load using network failed")
            // Switch to Main thread
            launch(Dispatchers.Main) {
                onFailure(Exception("NETWORK_ERROR: failed to load json url"))
            }
        })
    }


    fun getJsonStringFromUrl(jsonUrl: String, onSuccess: (jsonString: String) -> Unit, onFailure: (error: Exception) -> Unit) {
        Logger.d("ContentLoader", "getJsonStringFromUrl: ${jsonUrl}")
        this.network?.getJsonString(jsonUrl, { responseJson ->
            Logger.d("ContentLoader", "Data loaded. Moving to background thread for processing")

            launch {
                try {
                    val responseText = fixDataInconsistencies(responseJson)
                    Logger.d("ContentLoader", "Data processed on background thread")

                    // Switch to Main thread
                    withContext(Dispatchers.Main) {
                        onSuccess(responseText)
                    }
                } catch (e: Exception) {
                    Logger.d("ContentLoader", "String processing failed: ${e.message}")
                    // Switch to Main thread
                    withContext(Dispatchers.Main) {
                        onFailure(Exception("PROCESSING_ERROR: ${e.message}"))
                    }
                } catch (ce: CancellationException) {
                    Logger.d("ContentLoader", "String processing cancelled")
                    throw ce // Re-throw cancellation to maintain coroutine contract
                }
            }
        }, {
            Logger.d("ContentLoader", "Json load using network failed")
            // Switch to Main thread
            launch(Dispatchers.Main) {
                onFailure(Exception("NETWORK_ERROR: failed to load json url"))
            }
        })
    }

    fun __destruct() {
        // Cancel coroutine to prevent crashes and memory leaks, this stops all background JSON parsing immediately
        job.cancel()
        this.network?.__destruct()
        this.network = null
    }
}
