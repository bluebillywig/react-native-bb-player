package com.bluebillywig.bbnativeshared.interfaces


import com.bluebillywig.bbnativeshared.model.Subtitle

/**
 * @suppress
 */
interface MediaControllerInterface {
    fun set(propertyName: String, propertyValue: Any?): Boolean

    fun get(propertyName: String): Any?

    fun load(mediaUrl: String?, seekPosition: Number?, metadata: Map<String, String?>? = null): Boolean

    fun play(userAction: Boolean = true, requested: Boolean = false): Boolean

    fun pause(requested: Boolean = false): Boolean

    fun setSubtitle(id: String): Boolean

    fun setAudiotrack(id: String): Boolean

    fun setQuality(index: Int): Boolean

    fun setVideoTrack(videoTrackId: String): Boolean

    fun subtitlesOff()

    fun subtitlesOn()
}
