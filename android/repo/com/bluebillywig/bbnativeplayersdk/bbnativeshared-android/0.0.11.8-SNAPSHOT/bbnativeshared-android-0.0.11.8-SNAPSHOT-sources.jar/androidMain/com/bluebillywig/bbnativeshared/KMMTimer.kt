package com.bluebillywig.bbnativeshared

import java.util.*
import kotlin.concurrent.fixedRateTimer

/**
 * @suppress
 */
actual class KMMTimer actual constructor(
    actual val name: String?,
    actual val interval: Long,
    actual val delay: Long,
    action: () -> Unit
) {
    private var _timer: Timer? = null
    private val _action = action

    actual fun start() {
        if (!isRunning()) {
            _timer = fixedRateTimer(
                name = name,
                initialDelay = delay,
                period = interval
            ) {
                _action()
            }
        }
    }

    actual fun cancel() {
        _timer?.cancel()
        _timer = null
    }

    actual fun isRunning(): Boolean {
        return _timer != null
    }
}
