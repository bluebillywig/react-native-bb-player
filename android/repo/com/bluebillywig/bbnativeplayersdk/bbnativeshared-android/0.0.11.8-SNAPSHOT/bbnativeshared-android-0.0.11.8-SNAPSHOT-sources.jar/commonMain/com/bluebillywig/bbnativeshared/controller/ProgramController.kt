package com.bluebillywig.bbnativeshared.controller

import io.ktor.http.*

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.State
import com.bluebillywig.bbnativeshared.data.ContentLoader

import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.model.MediaClipList
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.Project
import com.bluebillywig.bbnativeshared.model.MediaAsset
import com.bluebillywig.bbnativeshared.model.Subtitle
import com.bluebillywig.bbnativeshared.model.Thumbnail
import com.bluebillywig.bbnativeshared.model.contentItemSerializersModule
import com.bluebillywig.bbnativeshared.model.Chapter
import com.bluebillywig.bbnativeshared.model.Highlight
import com.bluebillywig.bbnativeshared.model.Quality

import com.bluebillywig.bbnativeshared.AutoPlayNextTimer
import com.bluebillywig.bbnativeshared.SoftEmbargoTimer
import com.bluebillywig.bbnativeshared.Capabilities
import com.bluebillywig.bbnativeshared.RelatedItemsHelper
import com.bluebillywig.bbnativeshared.InstantFactory
import com.bluebillywig.bbnativeshared.ShortsEngine

import com.bluebillywig.bbnativeshared.interfaces.*
import com.bluebillywig.bbnativeshared.loggers.BlueBillywigLogger
import com.bluebillywig.bbnativeshared.loggers.BlueBillywigLogger.Companion.getFromJsonObject
import com.bluebillywig.bbnativeshared.model.AdUnit
import com.bluebillywig.bbnativeshared.model.ContentItem
import com.bluebillywig.bbnativeshared.model.ContentItemFactory
import com.bluebillywig.bbnativeshared.model.ContextFrame
import com.bluebillywig.bbnativeshared.model.Playout

import kotlinx.datetime.Instant
import kotlinx.datetime.Clock
import kotlinx.serialization.SerialName
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

import kotlin.math.* // ceil, abs

//import io.ktor.util.*
//import com.soywiz.krypto.encoding.Base64

/**
 * @suppress
 */
class ProgramController (eventBus: EventBusInterface?): EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["url"] is String) {
					_playerId = data["url"] as String // Base64.encode(sha1((data["url"] as String).toByteArray()))
				}
				val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
			}
			EventName.bb_media_duration_change -> {
				val duration = if (data != null && data["duration"] is Double) data["duration"] as Double else 0.0
				_eventBus?.trigger(EventName.durationchange, mapOf("duration" to duration))
			}
			EventName.bb_media_canplay -> {
				if (_phase != Phase.EXIT) { // weird but happens on Android
					_onCanPlay()
				}
			}
			EventName.bb_media_playing -> {
				if (_phase != Phase.EXIT) { // weird but happens on Android
					_playing_med = true
					_onPlaying()
				}
			}
			EventName.bb_media_paused -> {
				_playing_med = false
				_onPause()
			}
			EventName.bb_media_finished -> {
				_playing_med = false
				_onPause() // NB!?!
				_onMediaFinished(eventType)
			}
			EventName.bb_media_failed -> {
				_playing_med = false
				_onMediaFailed()
			}
			EventName.qualityTracksChanged -> { // MediaController event, don't ask...
				if (data?.get("assets") is MutableList<*>) {
					_qualities = data?.get("assets") as MutableList<Quality>
				}
			}
//            EventName.bb_adsystem_loaded -> {
//                val adProperties = if (data != null && data["adProperties"] is Map<*, *>) data["adProperties"] as Map<String, Any?> else null
//                val duration = if (adProperties != null && adProperties["duration"] is Double) adProperties["duration"] as Double else 0.0
//                _eventBus?.trigger(EventName.durationchange, mapOf("duration" to duration))
//            }
			EventName.bb_adsystem_canplay, EventName.bb_as_item_canplay -> {
				_onCanPlay()
			}
			EventName.bb_adsystem_started -> { // bb_commercial_playing
				_playing_com = true
				_onPlaying()
			}
			EventName.bb_adsystem_finished, // bb_commercial_finished
			EventName.bb_adsystem_skipped, EventName.bb_as_item_skipped,
			EventName.bb_adsystem_failed, EventName.bb_as_item_failed -> {
				_playing_com = false
				_onPause() // NB!?!
			}
			EventName.bb_as_ad_quartile -> {
				val quartile = data?.get("quartile") as String?
				if (quartile == "0") { // started
					_playing_com = true
					_onPlaying()
				} else if (quartile == "4") { // complete
					_playing_com = false
					_onPause() // NB!?!
				}
			}
			EventName.bb_msas_pre_finished, EventName.bb_as_pre_finished -> {
				_onCommercialPreFinished(eventType)
			}
			EventName.bb_msas_main_finished, EventName.bb_as_main_finished -> {
				_onCommercialMainFinished(eventType)
			}
			EventName.bb_msas_post_finished, EventName.bb_as_post_finished -> {
				_onCommercialPostFinished(eventType)
			}
			EventName.adContentPauseReq -> {
				_onAdContentPauseReq()
			}
			EventName.adContentResumeReq -> {
				_onAdContentResumeReq()
			}
			EventName.adResumed -> {
				_playing_com = true
				_onPlaying()
			}
			EventName.adPaused -> {
				_playing_com = false
				_onPause()
			}
			EventName.bb_playout_changed -> {
				_onPlayoutChanged(data)
			}
			EventName.bb_related_clips_changed -> {
				_onRelatedClipsChanged(eventType, data)
			}
			EventName.bb_phase_change -> {
				if ((_autoPlayNext && _phase == Phase.MAIN) ||
					(!_autoPlayNext && _phase == Phase.EXIT) ||
					(_showRelatedItemsOnPause && _phase == Phase.MAIN)) {
					_relatedItemsHelper?.load()
				}
			}
			EventName.bb_asset_selected -> {
				val asset: MediaAsset? = if (data != null && data["asset"] is MediaAsset) data["asset"] as MediaAsset else null
				if (asset == null && _contentIndicator != "a") { // not an "inArticle" ad
					// _setState(State.ERROR, "No Asset")
				}
			}
			EventName.bb_softembargotimer_finished -> {
				_onSoftEmbargoTimerFinished()
			}
			else -> { return }
		}
		// Logger.d(TAG, "Processed event: $eventType data: $data")
	}
	private var _eventBus: EventBusInterface? = eventBus

	// settings
	private var _baseUrl: String = ""
	private var _defaultMediaAssetPath: String = ""
	private var _mobileMediaAssetPath: String = ""
	private var _ignoreSingleMediaResource: Boolean = false
	private var _ignoreProjectMetadata: Boolean = false
	private var _noPosterInExitPhase: Boolean = false
	private var _softEmbargoCustomPosterClipId: String? = null
	private var _autoPlayNext: Boolean = false
	private var _autoPlay: Boolean = false
	private var _autoLoop: Boolean = false
	private var _autoLoopClip: Boolean = false
	private var _initiator: String? = null
	private var _seekPosition: Number? = null
	private var _autoPlayOnlyWithPrerollAd: Boolean = false
	private var _showOnlyWhenPrerollAvailable: Boolean = false
	private var _dynamicMode: Boolean = false // IMPLEMENT ME
	private var _dvid: String? = null // IMPLEMENT ME
	private var _usingSuggest: Boolean = false
	private var _showRelatedItemsOnPause: Boolean = false
	private var _useThumbsFromMetadata: Boolean = false
	private var _startCollapsed: Boolean = false
	private var _hidePlayerOnEnd: Boolean = false
	private var _playerId: String? = null
	private var _forceSSL = true
	private var _listOffset: Int? = null

	// state
	private var _userAction: Boolean = true
	private var _session_started: Boolean = false
	private var _view_started: Boolean = false
	private var _phase: Phase = Phase.INIT
	private var _phase_started: Boolean = false
	private var _mediaMainFinished: Boolean = false
	private var _msasMainFinished: Boolean = false
	private var _mediaController_preloaded: Boolean = false
	private var _pauseRequested: Boolean = false
	private var _pendingPlay: Boolean = false
	private var _playing: Boolean = false
	private var _playing_med: Boolean = false
	private var _playing_com: Boolean = false
	private var _state: State = State.IDLE
	private var _mode: String = ""
	private var _playBackRate:Float = 1f
	private var _softEmbargoActive: Boolean = false
	private var _keepPosterShowingOnPlaying:Boolean = false
	private var _isAutoAdvance: Boolean = false
	private var _contextStack: MutableList<ContextFrame> = mutableListOf()
	private var _nestingLevel: Int = 0 // always equal to _contextStack count

	// data
	private var _content: ContentItemInterface? = null
	private var _contentId: String? = null
	private var _contentIndicator: String? = null
	private var _contentList: MutableList<ContentItemInterface> = mutableListOf()
	private var _contentListIndex: Int = -1
	private var _failedMediaContentIndex: Int = -1
	private var _projectClipList: MutableList<MediaClip> = mutableListOf()
	private var _projectClipListIndex: Int = -1
	private var _playlist: MutableList<ContentItemInterface> = mutableListOf()
	private var _projectId: String? = null
	private var _clipId: String? = null
	private var _clipSoftEmbargo: String? = null
	private var _clip: MediaClip? = null
	private var _prev: MediaClip? = null
	private var _autoPlayNext_items: MutableList<ContentItemInterface> = mutableListOf()
	private var _autoPlayNext_excludeIds: MutableList<String> = mutableListOf()
	private var _clipListPrefetchedItem: ContentItemInterface? = null
	private var _rawJsonString: String? = null
	private var _contextCollectionType: String? = null
	private var _contextCollectionId: String? = null
	private var _contextEntityType: String? = null
	private var _contextEntityId: String? = null
	private var _clipListId: String? = null
	private var _cliplistEntryPointId: String? = null

	private var _qualities: MutableList<Quality>? = null

	private var _network: NetworkInterface? = null

	var network: NetworkInterface?
		get() = _network
		set(value) {
			_network = value
			_contentLoader?.network = value
			_relatedItemsHelper?.network = value
		}

	// resources
	private var _contentLoader: ContentLoader? = null
	private var _adSchedulingController: AdSchedulingController? = null
	private var _msasController: MsasController? = null
	private var _autoPlayNext_timer: AutoPlayNextTimer? = null
	private var _softEmbargoTimer: SoftEmbargoTimer? = null
	private var _relatedItemsHelper: RelatedItemsHelper? = null
	private var _posterController: PosterControllerInterface? = null
	private var _mediaController: MediaControllerInterface? = null
	private var _adController: AdControllerInterface? = null
	private var _shortsEngine: ShortsEngine? = null

	companion object { // this is Kotlin's way to support static class methods; don't ask...
		const val TAG = "ProgramController"

		fun assetIsExcluded(asset: MediaAsset?): Boolean {
			if (asset === null) return true

			val assetMediaType = asset.mediatype ?: "unknown"
			if (assetMediaType.startsWith("MPEG2", true)) return true
			if (assetMediaType.startsWith("MP4_TIMELINE", true)) return true
			if (assetMediaType.startsWith("MP4_PREVIEW", true)) return true
			if (assetMediaType.startsWith("TEASER", true)) return true
			if (assetMediaType.startsWith("thumbnailset", true)) return true
			if (assetMediaType.startsWith("fMP4", true)) return true
			if (assetMediaType.contains("WMV", true)) return true
			if (assetMediaType.contains("3GP", true)) return true
			if (!Capabilities.canPlayType(assetMediaType)) return true

			return false
		}

		fun assetCompareAudio(assetA: MediaAsset?, assetB: MediaAsset?): Int {
			if (Capabilities.canPlayType("MPD")) {
				if (assetA?.mediatype?.startsWith("MPD") == true) return -1; // prefer A
				if (assetB?.mediatype?.startsWith("MPD") == true) return 1; // prefer B
			}
			if (Capabilities.canPlayType("MP4_HLS")) {
				if (assetA?.mediatype?.startsWith("MP4_HLS") == true) return -1; // prefer A
				if (assetB?.mediatype?.startsWith("MP4_HLS") == true) return 1; // prefer B
			}
			val assetAScore = (assetA?.bandwidth ?: "-1").toIntOrNull() ?: -1
			val assetBScore = (assetB?.bandwidth ?: "-1").toIntOrNull() ?: -1
			return if (assetBScore <= 384) assetBScore - assetAScore else -1
		}

		fun assetCompareVisual(assetA: MediaAsset?, assetB: MediaAsset?): Int {
			if (Capabilities.canPlayType("MPD")) {
				if (assetA?.mediatype?.startsWith("MPD") == true) return -1; // prefer A
				if (assetB?.mediatype?.startsWith("MPD") == true) return 1; // prefer B
			}
			if (Capabilities.canPlayType("MP4_HLS")) {
				if (assetA?.mediatype?.startsWith("MP4_HLS") == true) return -1; // prefer A
				if (assetB?.mediatype?.startsWith("MP4_HLS") == true) return 1; // prefer B
			}
			val assetAScore = (assetA?.height ?: "-1").toIntOrNull() ?: -1
			val assetBScore = (assetB?.height ?: "-1").toIntOrNull() ?: -1
			return if (assetBScore <= 1080) assetBScore - assetAScore else -1
		}

		fun fakeMode(clip: MediaClip?): String {
			if (clip != null) {
				if (clip.mediatype == "mainroll") return "commercial"
			}

			return "video" // default
		}

		fun listSplice (target: MutableList<ContentItemInterface>, position: Int = 0, remove: Int = 0, items: List<ContentItemInterface> = listOf()): MutableList<ContentItemInterface> {
			// return target.subList(0, position) + items.toMutableList() + target.subList(position + remove, target.count())
			val ret: MutableList<ContentItemInterface> = mutableListOf()

			// first part
			var fromIncl = 0 // max(0, 0)
			var tillExcl = min(position, target.count())
			if (tillExcl > fromIncl) {
				for (item in target.subList(fromIncl, tillExcl)) {
					ret.add(item)
				}
			}
			// middle part
			for (item in items) {
				ret.add(item)
			}
			// last part
			fromIncl = max(0, position + remove)
			tillExcl = target.count() // min(target.count(), target.count())
			if (tillExcl > fromIncl) {
				for (item in target.subList(fromIncl, tillExcl)) {
					ret.add(item)
				}
			}

			return ret
		}
	}

	init {
		_contentLoader = ContentLoader()

		_autoPlayNext_timer = AutoPlayNextTimer(_eventBus, this)
		_softEmbargoTimer = SoftEmbargoTimer(_eventBus, this)
		_relatedItemsHelper = RelatedItemsHelper(_eventBus, this)

		_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
	}

	fun __destruct() {
		if (_view_started) {
			_view_started = false
			_eventBus?.trigger(EventName.bb_view_finished)
		}

		_network?.__destruct()
		_network = null

		_contentLoader?.__destruct()
		_contentLoader  = null

		_eventBus?.removeEventlistener(this)
		_autoPlayNext_timer?.__destruct()
		_autoPlayNext_timer = null
		_softEmbargoTimer?.__destruct()
		_softEmbargoTimer = null
		_relatedItemsHelper?.__destruct()
		_relatedItemsHelper = null
		_msasController?.__destruct()
		_msasController = null
		_adSchedulingController?.__destruct()
		_adSchedulingController = null

		_eventBus = null
		_posterController = null
		_mediaController = null
		_adController = null
	}

	fun skipAd() {
		this._adController?.skipAd()
	}

	private fun _setState(state: State, reason: String = "") {
		val savedState = _state
		_state = state
		if (_state != savedState) { // changed
			_eventBus?.trigger(EventName.bb_state_change, mapOf("state" to _state, "reason" to reason))
		}
	}

	fun getState(): State {
		return _state
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value

			_adSchedulingController?.eventBus = _eventBus
			_msasController?.eventBus = _eventBus
			_autoPlayNext_timer?.__destruct()
			_autoPlayNext_timer = AutoPlayNextTimer(_eventBus, this)
			_softEmbargoTimer?.__destruct()
			_softEmbargoTimer = SoftEmbargoTimer(_eventBus, this)
			_relatedItemsHelper?.__destruct()
			_relatedItemsHelper = RelatedItemsHelper(_eventBus, this)
			_relatedItemsHelper?.network = network

			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var posterController: PosterControllerInterface?
		get() = _posterController
		set(value) { _posterController = value }

	var mediaController: MediaControllerInterface?
		get() = _mediaController
		set(value) { _mediaController = value }

	var adController: AdControllerInterface?
		get() = _adController
		set(value) {
			_adController = value
			_adSchedulingController?.adController = _adController  // AdSchedulingController needs to get this adController
			_msasController?.adController = _adController  // MsasController needs to get this adController
		}

	var contentId: String? = null
		get() = _contentId

	var clipData: MediaClip? = null
		get() = _clip

	var relatedItems: List<ContentItemInterface>? = null
		set(value) {
			_relatedItemsHelper?.setItems(value)
		}

	/**
	 * load content data
	 */
	fun loadContent(content: ContentItemInterface, initiator: String?, autoPlay: Boolean?, seekPosition: Number?, context: Map<String,String?>? = null, listOffset: Int? = null) { //, shouldPlayInline, token, useSession) {
		Logger.d(TAG, "loadContent")
		this.pause()

		_reset() // state
		_adSchedulingController?.resetAdCounter_load()
		_msasController?.resetAdCounter_load()
		_clip = null
		_playlist.clear()
		_cliplistEntryPointId = null

		if (initiator !== null) _initiator = initiator
		if (autoPlay !== null) _pendingPlay = autoPlay
		if (seekPosition !== null) _seekPosition = seekPosition
		if (listOffset != null) _listOffset = listOffset

		// Clip-in-cliplist-context swap for pre-loaded data (matches web loadData).
		// When a clip/project is loaded with a cliplist context, save its ID as the
		// entry point and switch to loading the cliplist by ID instead.
		var content_: ContentItemInterface? = content
		var contentId_: String? = null
		var contentIndicator_: String? = null
		val contextCollectionType: String? = context?.get("contextCollectionType")
		val contextCollectionId: String? = context?.get("contextCollectionId")
		val contextEntityType: String? = context?.get("contextEntityType")
		val contextEntityId: String? = context?.get("contextEntityId")
		if (contextEntityType != _contextEntityType || contextEntityId != _contextEntityId) { // && content !is MediaClipList
			val cliplistId = if (contextEntityType == "MediaClipList" && !contextEntityId.isNullOrEmpty()) contextEntityId
				else if (contextCollectionType == "MediaClipList" && !contextCollectionId.isNullOrEmpty()) contextCollectionId
				else null
			if (cliplistId != null && (content as? ContentItem)?.id != null) {
				_cliplistEntryPointId = (content as ContentItem).id
				content_ = null
				contentId_ = cliplistId
				contentIndicator_ = "l"
			}
		}

		// handle context stack
		val contentItem: ContentItem? = when (contentIndicator_) {
			"l", "q" -> ContentItemFactory.createMediaClipList(contentId_ ?: "")
			"p" -> ContentItemFactory.createProject(contentId_ ?: "")
			"c" -> ContentItemFactory.createMediaClip(contentId_ ?: "")
			else -> content_ as? ContentItem
		}
		if (contentItem != null) _updateContentListIndex(contentItem as ContentItemInterface)
		if (contentItem is MediaClipList) {
			_contentListIndex++
			_pushContext()
		}

		if (context != null) {
			_contextCollectionType = contextCollectionType
			_contextCollectionId = contextCollectionId
			_contextEntityType = contextEntityType
			_contextEntityId = contextEntityId
		}
		_contentId = contentId_
		_contentIndicator = contentIndicator_
		_content = content_

		_eventBus?.trigger(EventName.loadstart)

		return _loadContent()
	}

	/**
	 * load content
	 */
	fun loadContentById(contentId: String, contentIndicator: String?, initiator: String?, autoPlay: Boolean?, seekPosition: Number?, context: Map<String,String?>? = null, listOffset: Int? = null) { //, shouldPlayInline, token, useSession) {
		Logger.d(TAG, "loadContentById $contentId, $contentIndicator")
		this.pause()

		_reset() // state
		_adSchedulingController?.resetAdCounter_load()
		_msasController?.resetAdCounter_load()
		_clip = null
		_playlist.clear()
		_cliplistEntryPointId = null

		if (initiator !== null) _initiator = initiator
		if (autoPlay !== null) _pendingPlay = autoPlay
		if (seekPosition !== null) _seekPosition = seekPosition
		if (listOffset != null) _listOffset = listOffset

		// Clip-in-cliplist-context swap: when loading a clip that has a cliplist context,
		// save the clip ID as the entry point and switch to loading the cliplist instead.
		// Matches web standardplayer pattern (ProgramController.js lines 451-457).
		var contentId_ = contentId
		var contentIndicator_ = if (!contentIndicator.isNullOrEmpty()) contentIndicator else "c"
		val contextCollectionType: String? = context?.get("contextCollectionType")
		val contextCollectionId: String? = context?.get("contextCollectionId")
		val contextEntityType: String? = context?.get("contextEntityType")
		val contextEntityId: String? = context?.get("contextEntityId")
		if (contextEntityType != _contextEntityType || contextEntityId != _contextEntityId) { //  && contentIndicator_ == "c"
			val cliplistId = if (contextEntityType == "MediaClipList" && !contextEntityId.isNullOrEmpty()) contextEntityId
				else if (contextCollectionType == "MediaClipList" && !contextCollectionId.isNullOrEmpty()) contextCollectionId
				else null
			if (cliplistId != null) {
				_cliplistEntryPointId = contentId
				contentId_ = cliplistId
				contentIndicator_ = "l"
			}
		}

		// handle context stack
		val contentItem: ContentItem? = when (contentIndicator_) {
			"l", "q" -> ContentItemFactory.createMediaClipList(contentId_)
			"p" -> ContentItemFactory.createProject(contentId_)
			"c" -> ContentItemFactory.createMediaClip(contentId_)
			else -> null
		}
		if (contentItem != null) _updateContentListIndex(contentItem as ContentItemInterface)
		if (contentItem is MediaClipList) {
			_contentListIndex++
			_pushContext()
		}

		if (context != null) {
			_contextCollectionType = contextCollectionType
			_contextCollectionId = contextCollectionId
			_contextEntityType = contextEntityType
			_contextEntityId = contextEntityId
		}
		_contentId = contentId_
		_contentIndicator = contentIndicator_
		_content = null

		_eventBus?.trigger(EventName.loadstart)

		return _loadContent()
	}

	/**
	 * load ad services data
	 */
	fun loadAdServicesData(adServicesData: List<AdUnit>, initiator: String?, autoPlay: Boolean?, seekPosition: Number?, context: Map<String,String?>?) { //, shouldPlayInline, token, useSession) {
		Logger.d(TAG, "loadAdServicesData")
		this.pause()

		_reset() // state
		_adSchedulingController?.resetAdCounter_load()
		_msasController?.resetAdCounter_load()

		_msasController?.loadContent(adServicesData)

		if (initiator !== null) _initiator = initiator
		if (autoPlay !== null) _pendingPlay = autoPlay
		if (seekPosition !== null) _seekPosition = seekPosition
		if (context != null) {
			_contextCollectionType = context.get("contextCollectionType")
			_contextCollectionId = context.get("contextCollectionId")
			_contextEntityType = context.get("contextEntityType")
			_contextEntityId = context.get("contextEntityId")
		}
		_contentId = null
		_contentIndicator = null
		if (adServicesData.find { item -> item.positionType == "inarticle" && item.status == "published" } != null) {
			_content = MediaClip("0", "", null, null, null, null, "mainroll", "commercial")
		} else {
			_content = null
			return // NB!
		}

		_eventBus?.trigger(EventName.loadstart)

		return _loadContent()
	}

	fun play(userAction: Boolean = true) {
		_userAction = userAction
		Logger.d(TAG, "play in phase: ${_phase}")
		_eventBus?.trigger(EventName.bb_program_play)

		_play()
	}

	fun setPlaybackRate(rate: Float) {
		_playBackRate = rate
		_eventBus?.trigger(EventName.playbackSpeedChanged,  mapOf("speed" to rate))
	}

	fun getPlaybackRate(): Float {
		return _playBackRate
	}

	private fun _play() { // userAction?: Boolean) {
		Logger.d(TAG, "_play in phase: ${_phase}")
		_autoPlayNext_timer?.cancel()
		_autoPlayNext_excludeIds.add(_clipId ?: "")

		// view
		if (!_view_started) {
			_view_started = true
			_eventBus?.trigger(EventName.bb_view_started, mapOf("initiator" to _initiator))
		}

		when (_phase) {
			Phase.INIT -> {
				// reposition
				_phase = Phase.PRE
				_phase_started = false
				_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to true))
				_updateMode()
				_play()
			}

			Phase.PRE -> {
				_keepPosterShowingOnPlaying = false // _posterController?.hide()
				if (_autoPlayOnlyWithPrerollAd && !_userAction) {
//                    _keepPosterShowingOnPlaying = true
					_posterController?.show()
				}
				if (!_phase_started) {
					_phase_started = true
					if (_adSchedulingController != null) {
						if (_adSchedulingController?.play(_phase) != true) { // no systems for this position
							_onCommercialPreFinished(null) // call event handler directly
						}
					} else if (_msasController != null) {
						if (_msasController?.play(_phase) != true) { // no systems for this position
							_onCommercialPreFinished(null) // call event handler directly
						}
					} else {
						_onCommercialPreFinished(null) // call event handler directly
					}
				} else { // phase started
					if (_adSchedulingController != null) {
						_adSchedulingController?.resume() // userAction?
					} else if (_msasController != null) {
						_msasController?.resume() // userAction?
					}
				}
			}

			Phase.MAIN -> {
				_keepPosterShowingOnPlaying = false
				if (_clip != null && _clip?.mediatype == "audio") {
					_keepPosterShowingOnPlaying = true
					_posterController?.show()
				}
				if (!_phase_started) {
					_phase_started = true
					if (_mediaController != null) {
						if (!_mediaController_preloaded) {
							val mediaUrl = _getMediaUrl(_clip)
							var chaptersJsonString = "{"
							_clip?.chapters?.forEach {
									it: Chapter -> chaptersJsonString += "\"${it.timeOffset}\":\"${("${it.title}").replace("\\", "\\\\").replace("\"", "\\\"")}\","
							}
							chaptersJsonString = chaptersJsonString.replace(Regex(""",$"""), "") + "}" // fixes last comma
							var highlightsJsonString = "{"
							_clip?.highlights?.forEach {
									it: Highlight -> highlightsJsonString += "\"${it.timeOffset}\":\"${("${it.title}").replace("\\", "\\\\").replace("\"", "\\\"")}\","
							}
							highlightsJsonString = highlightsJsonString.replace(Regex(""",$"""), "") + "}" // fixes last comma
							val metadata: Map<String, String?> = mapOf(
								"playerId" to _playerId,
								"title" to (_clip?.title ?: "<untitled>"),
								"thumbnailUrl" to _getPosterUrl(_clip),
								"description" to (_clip?.description ?: ""),
								"contentType" to _inferContentType(mediaUrl),
								"duration" to (_clip?.length ?: 0).toString(),
								"isLive" to if (_clip?.sourcetype == "live") "true" else "false",
								"chaptersJson" to chaptersJsonString,
								"highlightsJson" to highlightsJsonString
							)
							_mediaController?.load(mediaUrl, _seekPosition, metadata)
						}
						if (_seekPosition != null) {
							var seekPosition = _seekPosition
							_seekPosition = null
							_mediaController?.set("currentTime", seekPosition) // html5 head will use #t=[time] to seek.
						}
						if (!_pauseRequested) {
							_mediaController?.play(_userAction)
							_userAction = true // reset
						}
					}
					if (_adSchedulingController != null) {
						if (_adSchedulingController?.play(_phase) != true) { // no systems for this position
							_onCommercialMainFinished(null) // call event handler directly
						}
					} else if (_msasController != null) {
						if (_msasController?.play(_phase) != true) { // no systems for this position
							_onCommercialMainFinished(null) // call event handler directly
						}
					} else {
						_onCommercialMainFinished(null) // call event handler directly
					}
				} else { // phase started
					if (_mediaController != null) {
						if (_seekPosition != null) {
							var seekPosition = _seekPosition
							_seekPosition = null
							_mediaController?.set("currentTime", seekPosition) // html5 head will use #t=[time] to seek.
						}
						if (!_pauseRequested) {
							_mediaController?.play(_userAction)
							_userAction = true // reset
						}
					}
					if (_adSchedulingController != null) {
						_adSchedulingController?.resume() // userAction?
					} else if (_msasController != null) {
						_msasController?.resume() // userAction?
					}
				}
			}

			Phase.POST -> {
				_keepPosterShowingOnPlaying = false // _posterController?.hide()
				if (!_phase_started) {
					_phase_started = true
					if (_msasController != null) {
						if (_msasController?.play(_phase) != true) { // no systems for this position
							_onCommercialPostFinished(null) // call event handler directly
						}
					} else {
						_onCommercialPostFinished(null) // call event handler directly
					}
				} else { // phase started
					if (_msasController != null) {
						_msasController?.resume() // userAction?
					}
				}
			}

			Phase.EXIT -> {
				// resposition
				_mediaMainFinished = false; _msasMainFinished = false
				_phase = Phase.MAIN
				_phase_started = false
				_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to true))
				_updateMode()
				_mediaController_preloaded = false // force reload
				_seekPosition = 0
				_play()
			}
		}
	}

	fun pause() {
		Logger.d(TAG, "pause in phase: ${_phase}")
		when (_phase) {
			Phase.INIT -> {
			}

			Phase.PRE -> {
				if (_adSchedulingController != null) {
					_adSchedulingController?.pause()
				} else if (_msasController != null) {
					_msasController?.pause()
				}
			}

			Phase.MAIN -> {
				if (!_pauseRequested) {
					_mediaController?.pause()
				}
				if (_adSchedulingController != null) {
					_adSchedulingController?.pause()
				} else if (_msasController != null) {
					_msasController?.pause()
				}
			}

			Phase.POST -> {
				_msasController?.pause()
			}

			Phase.EXIT -> {
			}
		}
	}

	fun seek(positionInSeconds: Number, relativeToCurrentTime: Boolean = false) {
		Logger.d(TAG, "seek with positionInSeconds: $positionInSeconds in phase: ${_phase}")
		if (relativeToCurrentTime) {
			_eventBus?.trigger(EventName.bb_api_called, mapOf(
				"method" to "seek_relative",
				"offsetInSeconds" to positionInSeconds,
				"userAction" to true)
			) // NB pretend this was a user-action api call!
		}
		when (_phase) {
			Phase.INIT -> {
			}

			Phase.PRE -> {
			}

			Phase.MAIN -> {
				var newPosition = positionInSeconds.toDouble()
				if (relativeToCurrentTime) {
					newPosition += (_mediaController?.get("currentTime") as Double?) ?: 0.0
				}
				_mediaController?.set("currentTime", newPosition)
			}

			Phase.POST -> {
			}

			Phase.EXIT -> {
				var newPosition = positionInSeconds.toDouble()
				if (relativeToCurrentTime) {
					newPosition += (_mediaController?.get("currentTime") as Double?) ?: 0.0
				}
				if (newPosition >= 0.0) {
					// resposition
					_mediaMainFinished = false; _msasMainFinished = false
					_phase = Phase.MAIN
					_phase_started = false
					_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to true))
					_updateMode()
					// _mediaController_preloaded = true // DON'T force reload OR _seekPosition = 0
					_mediaController?.set("currentTime", newPosition)
					_play()
				}
			}
		}
	}

	fun setSubtitle(id: String) {
		_mediaController?.setSubtitle(id)
	}

	fun setAudiotrack(id: String) {
		_mediaController?.setAudiotrack(id)
	}

	fun setQuality(index: Int) {
		val quality: Quality? = _qualities?.getOrNull(index)
		_eventBus?.trigger(EventName.bb_api_called, mapOf(
			"method" to "setAsset",
			"userAction" to true,
			"quality" to "${quality?.label}"
		)) // NB pretend this was a user-action api call!
		_mediaController?.setQuality(index)
	}

	fun setVideoTrack(videoTrackId: String) {
		_mediaController?.setVideoTrack(videoTrackId)
	}

	fun autoPlayNextPause() {
		if (_autoPlayNext) {
			_autoPlayNext_timer?.pause()
		}
	}

	fun autoPlayNextResume() {
		if (_autoPlayNext) {
			_autoPlayNext_timer?.resume()
		}
	}

	fun autoPlayNextProceed() {
		_autoPlayNext_timer?.cancel()

		if (_phase == Phase.EXIT) {
			_initiator = "autoPlayNext" // used in _playlistNextItem & _play

			if (_playlistNextItem()) {
				_phase = Phase.INIT
				_phase_started = false
				_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to true))
				_updateMode()

				_play()
			} else {
				_eventBus?.trigger(EventName.ended)
				if (_hidePlayerOnEnd) {
					_eventBus?.trigger(EventName.bb_request_collapse)
				}
			}
		}
	}

	fun autoPlayNextCancel(): Boolean {
		_autoPlayNext_timer?.cancel()

		if (_phase == Phase.EXIT) {
			_playlist.clear()
			_eventBus?.trigger(EventName.ended)
			if (_hidePlayerOnEnd) {
				_eventBus?.trigger(EventName.bb_request_collapse)
			}
		}

		return true
	}

	fun getPosterUrl(content: ContentItemInterface?): String? {
		return _getPosterUrl(content)
	}

	fun getFirstFrameUrl(content: ContentItemInterface?): String? {
		return _getPosterUrl(content, true)
	}

	fun getContentList(): List<ContentItemInterface> {
		return _contentList
	}

	fun getContentListIndex(): Int {
		return _contentListIndex
	}

	fun getRawJsonString (): String? {
		return _rawJsonString
	}

	fun spliceIntoContentList (splicePosition: Int, items: List<ContentItemInterface>) {
		if (splicePosition < 0) return

		// Keep track of where we are pointing
		val indexedItem = _contentList.elementAtOrNull(_contentListIndex)

		// If the item is being placed further in the list than the current content index,
		// we should add it to the playlist too
		if (_contentListIndex >= 0) {
			val playlistSplicePosition = splicePosition - _contentListIndex // NB!
			if (playlistSplicePosition >= 0) {
				_playlist = listSplice(_playlist, playlistSplicePosition, 0, items)
			}
		}

		_contentList = listSplice(_contentList, splicePosition, 0, items)

		// Make sure index still points to current item
		if (indexedItem != null) {
			val contentListIndex = _contentList.indexOf(indexedItem)
			if (contentListIndex > -1) _contentListIndex = contentListIndex
		} else if (_contentListIndex >= 0) {
			_contentListIndex++;
		}

		_eventBus?.trigger(EventName.bb_cliplist_changed, mapOf("clipListItems" to _contentList)) // NB not clipListData!
	}

	fun spliceOutoffContentList (splicePosition: Int) {
		if (splicePosition < 0) return

		// Keep track of where we are pointing
		val indexedItem = _contentList.elementAtOrNull(_contentListIndex)

		// If the item is being placed further in the list than the current content index,
		// we should add it to the playlist too
		if (_contentListIndex >= 0) {
			val playlistSplicePosition = splicePosition - _contentListIndex // NB!
			if (playlistSplicePosition >= 0) {
				_playlist = listSplice(_playlist, playlistSplicePosition, 1)
			}
		}

		_contentList = listSplice(_contentList, splicePosition, 1)

		// Make sure index still points to current item
		if (indexedItem != null) {
			val contentListIndex = _contentList.indexOf(indexedItem)
			if (contentListIndex > -1) _contentListIndex = contentListIndex
		} else if (_contentListIndex >= 0) {
			_contentListIndex--;
		}

		_eventBus?.trigger(EventName.bb_cliplist_changed, mapOf("clipListItems" to _contentList)) // NB not clipListData!
	}

	private fun _reset() {
		_softEmbargoTimer?.cancel()

		_isAutoAdvance = false

		// state
		_view_started = false
		_phase = Phase.INIT
		_phase_started = false
		_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to _pendingPlay))
		_updateMode()
	}

	// private
	private fun _pushContext () {
		val frame = ContextFrame(
			_contentList.toMutableList(),
			_contentListIndex,
			_contextCollectionType,
			_contextCollectionId,
			_contextEntityType,
			_contextEntityId,
			_contentIndicator,
			_contentId,
			_clipListId,
			_nestingLevel
		)

		_contextStack.add(frame)
		_nestingLevel++;
	}

	// private
	private fun _popContext (): Boolean {
		if (_contextStack.count() == 0) {
			// debug('ProgramController._popContext', 'stack is empty, cannot pop');
			return false
		}

		val frame = _contextStack.removeAt(_contextStack.count() - 1)
		if (frame != null) {
			// Restore parent context
			_contentList = frame.contentList
			_contentListIndex = frame.contentListIndex
			_contextCollectionType = frame.contextCollectionType
			_contextCollectionId = frame.contextCollectionId
			_contextEntityType = frame.contextEntityType
			_contextEntityId = frame.contextEntityId
			_contentIndicator = frame.contentIndicator
			_contentId = frame.contentId
			_clipListId = frame.clipListId
			_nestingLevel = frame.nestingLevel

			return true;
		}

		return false
	}

	private fun _isAtRootContext (): Boolean {
		return (_contextStack.isEmpty() || _nestingLevel == 0)
	}

	private fun _handlePlaylistDepletion () {
		var popped = false
		while ((_contentListIndex >= _contentList.count()) && !_isAtRootContext()) {
			_popContext()
			popped = true
		}
		if (popped) {
			if (_contentListIndex < 0) _contentListIndex = 0 // just in case
			val iter = _contentList.listIterator(_contentListIndex)
			iter.forEach {
				_playlist.add(it)
			}
		}
	}

	private fun _loadContent() {
		if (_content == null) {
			val contentUrl = _getContentUrl()
			if (contentUrl !== null) {
				_setState(State.LOADING)
				_contentLoader?.getContentFromJsonUrl(contentUrl, { _loadContentSuccess(it) }, { _loadContentFailure(it) }) // fetchJsonData
			} else {
				_loadContentFailure(Exception("Could not compose url"));
			}
		} else {
			_loadContentSuccess(_content)
		}
	}

	private fun _getContentUrl(): String? {
		var url: String? = null

		if (_contentIndicator == "q") { // Query
			url = _baseUrl + "/json/search?query=" + _contentId?.encodeURLParameter()
		} else if (_contentIndicator == "l") { // List
			url = _baseUrl + "/papi/search?cliplistid=" + _contentId?.encodeURLParameter() + "&allowCache=true"
		} else if (_contentIndicator == "p") { // Project
			url = _baseUrl + "/papi/project/" + _contentId?.encodeURLParameter() + "?allowCache=true"
		} else if (_contentIndicator == "c" || true) { // Clip
			if (_dynamicMode && _dvid !== null) {
				url = _baseUrl + "/json/dynamicmediaclip/" + _contentId?.encodeURLParameter() + "?dvid=" + _dvid?.encodeURLParameter()
			} else {
				url = _baseUrl + "/json/mediaclip/"+_contentId?.encodeURLParameter()
			}
		}

		return url
	}

	private fun _contentListFindIndex(item: ContentItemInterface): Int {
		var idx = _contentList.count()
		while (idx >= 0) {
			val contentItem = _contentList.elementAtOrNull(idx)
			if (contentItem is MediaClipList && item is MediaClipList && contentItem.id == item.id) break
			if (contentItem is MediaClip && item is MediaClip && contentItem.id == item.id) break
			if (contentItem is Project && item is Project && contentItem.id == item.id) break
			idx--
		}
		return idx
	}

	private fun _updateContentListIndex (item: ContentItemInterface) {
		var idx = _contentList.indexOfFirst { it.id == item.id } // _contentListFindIndex(item)
		while (idx < 0 && !_isAtRootContext()) {
			this._popContext()
			idx = _contentList.indexOfFirst { it.id == item.id } // _contentListFindIndex(item)
		}

		if (idx >= 0) { // found
			// update _contentList
			if ((item is MediaClip && !item.assets.isNullOrEmpty()) ||
				(item is Project && !item.chapters.isNullOrEmpty()) ||
				(item is MediaClipList && !item.items.isNullOrEmpty())
			) _contentList[idx] = item
			_contentListIndex = idx
		} else { // not found
			// Clear context stack
			_contextStack = mutableListOf()
			_nestingLevel = 0
			// re-create _contentList
			_contentList = mutableListOf(item)
			_contentListIndex = 0
		}
	}

	private fun _loadContentSuccess(data: ContentItemInterface?): Unit {
		if (data !== null) {
			//if (_content["items"]) _content["type"] = "MediaClipList" // hack missing type
			if (data is MediaClipList) {
				data.isPrefetch = true
				_content = data // _sanitizeContent?
				if (!data.rawJsonString.isNullOrEmpty()) _rawJsonString = data.rawJsonString // NB!
				_clipListId = data.id ?: _contentId
				_projectClipListIndex = -1
				_contentListIndex = -1
				_contentList.clear()

				var selectedAssetsForPreload: MutableList<String?> = arrayListOf()

				if (data.items !== null) {
					for (item in data.items) {
						if (item.id == _clipListPrefetchedItem?.id) { // item type clash unlikely
							_contentList.add(_clipListPrefetchedItem!!)
						} else {
							if (item is MediaClip) {
								item.isPrefetch = item.assets != null // NB!
								_contentList.add(_sanitizeContentItem(item))
							} else if (item is Project) {
								item.isPrefetch = item.chapters != null // NB!
								_contentList.add(_sanitizeContentItem(item))
							} else if (item is MediaClipList) {
								item.isPrefetch = item.items != null // NB!
								_contentList.add(_sanitizeContentItem(item))
							}
						}
						if (item is MediaClip) {
							//get asset
							selectedAssetsForPreload.add(_getMediaUrl(item, true))
						} else {
							//set null
							selectedAssetsForPreload.add(null)
						}
					}
					if (_contentList.count() > 0) {
						_contentListIndex = if (_listOffset != null) {
							_listOffset!!
						} else if (_cliplistEntryPointId != null) {
							val idx = _contentList.indexOfFirst { it.id == _cliplistEntryPointId }
							if (idx >= 0) idx else 0
						} else {
							0
						}
					}
					_listOffset = null
					_cliplistEntryPointId = null
				}
				if (!_inProject()) { // always
					//_mediaController.setMediaData(null)
					//_setMediaData(null)
					_eventBus?.trigger(EventName.bb_project_loaded, mapOf("projectData" to null))
					// update poster
					val posterUrl = _getPosterUrl(null)
					_posterController?.load(posterUrl)
				}

				val cpRuleViolation = data.cpRuleViolations?.getOrNull(0)
				if (cpRuleViolation != null && cpRuleViolation != "NotFound") {
					if (!_playlistNextItem()) { // playlist depleted
						_eventBus?.trigger(EventName.bb_error, mapOf("msg" to  cpRuleViolation, "cpp" to  data.cpp))
					} else {
						return // NB!
					}
				}

				// Handle empty nested lists (per user decision: silently skip)
				if ((_contentList.isNullOrEmpty()) && !_isAtRootContext()) {
					// Empty nested list - pop back to parent immediately
					_popContext()
				}

				// println ("**** [ProgramController] _loadContentSuccess going to trigger bb_cliplist_loaded _clipListId: ${_clipListId}, nestingLevel: ${_nestingLevel}")
				_eventBus?.trigger(EventName.bb_cliplist_loaded, mapOf("clipListData" to data, "clipListId" to _clipListId, "nestingLevel" to _nestingLevel, "selectedAssets" to selectedAssetsForPreload))
			} else if (data is Project) {
				data.isPrefetch = true
				_content = data // _sanitizeContent?
				if (!data.rawJsonString.isNullOrEmpty()) _rawJsonString = data.rawJsonString // NB!
				_projectId = data.id
				_projectClipListIndex = -1
				if (data.chapters !== null && data.chapters.count() > 0) { // newest style since 14 Dec. 2018
					_projectClipList.clear()
					for (chapter in data.chapters) {
						if (chapter.steps !== null && chapter.steps.count() > 0) {
							for (step in chapter.steps) {
								if (step.entityType.isNullOrEmpty()) { step.entityType = "MediaClip"; step.entityId = step.mediaClipId } // compat.
								val re = Regex("""mediaclip""", RegexOption.IGNORE_CASE)
								if (re.matches("${step.entityType}") && step.entityId !== null) {
									var clip = MediaClip(step.entityId, "", null, null, null, "editorial")
									clip.projectId = _projectId
									val mainMediaClipData = data.mainMediaClipData
									if (clip.id == data.mainMediaClipId && mainMediaClipData !== null) {
										clip = mainMediaClipData
										clip.projectId = _projectId // force
									}
									_projectClipList.add(clip)
									if (clip.id == data.mainMediaClipId) _projectClipListIndex = _projectClipList.count() - 1
									if (_projectClipListIndex < 0 && step.isStart == true) _projectClipListIndex = _projectClipList.count() - 1 // just in case
									if (_projectClipListIndex < 0 && step.id == "id-startstep") _projectClipListIndex = _projectClipList.count() - 1 // just in case
									if (_projectClipListIndex < 0 && step.id == "id-startnode") _projectClipListIndex = _projectClipList.count() - 1 // just in case
								}
							}
						}
					}
				} else if (!data.mainMediaClipId.isNullOrEmpty()) { // fallback
					var clip = MediaClip(data.mainMediaClipId, "", null, null, null, "editorial")
					clip.projectId = _projectId
					_projectClipList.clear(); _projectClipList.add(clip)
					_projectClipListIndex = 0
				}

				// "gapless playback" optimization    turned of for now because of parse error na dnot needed for now (MVP 29-03-2012) OT
//				var mediaData = data.media
//				if (mediaData.count() > 0) {
//					//_mediaController.setMediaData(!_ignoreSingleMediaResource ? mediaData : null)
//					//_setMediaData(!_ignoreProjectMetadata ? mediaData : null)
//				} else {
//					//_mediaController.setMediaData(null)
//					//_setMediaData(null)
//				}

				val cpRuleViolation = data.cpRuleViolations?.getOrNull(0)
				if (cpRuleViolation != null && cpRuleViolation != "NotFound") {
					if (!_playlistNextItem()) { // playlist depleted
						_eventBus?.trigger(EventName.bb_error, mapOf("msg" to  cpRuleViolation, "cpp" to  data.cpp))
					} else {
						return // NB!
					}
				}

				_eventBus?.trigger(EventName.bb_project_loaded, mapOf("projectData" to data))
				// update poster
				val posterUrl = _getPosterUrl(data)
				_posterController?.load(posterUrl)
			} else if (data is MediaClip) { // || true?
				data.isPrefetch = true
				_content = data // _sanitizeContent?
				if (!data.rawJsonString.isNullOrEmpty()) _rawJsonString = data.rawJsonString // NB!
				_projectClipListIndex = -1
				if (_projectClipList.count() > 0) {
					// search clip in projectClipList
					var idx = 0
					while (idx < _projectClipList.count()) {
						val projectClip = _projectClipList.elementAtOrNull(idx);
						if (projectClip is MediaClip && data.id == projectClip.id) break
						idx++
					}
					if (idx < _projectClipList.count()) { // found
						data.projectId = _projectId
						// update projectClipList
						_projectClipList.set(idx, data)
						_projectClipListIndex = idx
					}
				}
				if (!_inProject()) { // not in project
					//_mediaController.setMediaData(null)
					//_setMediaData(null)
					_eventBus?.trigger(EventName.bb_project_loaded, mapOf("projectData" to null))
					// update poster
					val posterUrl = _getPosterUrl(null)
					_posterController?.load(posterUrl)
				}
			}

			// fill playlist
			_playlist.clear()
			if (_inProject()) { // in project
				_playlist.add(_projectClipList[_projectClipListIndex])
			} else { // not in project
				if (_contentListIndex >= 0 && _contentListIndex < _contentList.count()) {
					if (_autoLoopClip) {
						_playlist.add(_contentList[_contentListIndex])
					} else {
						val iter = _contentList.listIterator(_contentListIndex)
						iter.forEach { // NB starting at _contentListIndex!
							_playlist.add(it)
						}
					}
				}
			}

			// start playlist
			if (!_playlistNextItem()) {
				_clip = null
			}
		} else {
			_clip = null
		}
	}

	private fun _loadContentFailure(error: Exception?) {
		Logger.d(TAG, "_loadContentFailure error: ${error}")
		_cliplistEntryPointId = null
		if (_contentIndicator != "a") {
			_clip = null
			_eventBus?.trigger(EventName.bb_mediaclip_failed) // HMMM...
			_setState(State.ERROR, "Load content failure")
			_playlist.clear() // SURE?!?
			_mediaController?.load(null, null)
		} else {
			// _mediaController?.load(null, null) // FIX ME: needed for Shorts mainrolls?
		}
	}

	private fun _loadClip() {
		Logger.d(TAG,"_loadClip")
		if (_clip == null) {
			val clipUrl = _getClipUrl()
			if (clipUrl !== null) {
				_contentLoader?.getContentFromJsonUrl(clipUrl, { _loadClipSuccess(it) }, { _loadClipFailure(it) }) // fetchJsonData
			} else {
				_loadClipFailure(Exception("Could not compose url"));
			}
		} else {
			_loadClipSuccess(_clip)
		}
	}

	private fun _getClipUrl(clipId: String? = _clipId, clipSoftEmbargo: String? = _clipSoftEmbargo): String? {
		var url: String? = null

		if (clipId != null) {
			if (_dynamicMode && _dvid !== null) {
				url = _baseUrl + "/json/dynamicmediaclip/" + clipId.encodeURLParameter() + "?dvid=" + _dvid?.encodeURLParameter()
			} else {
				url = _baseUrl + "/json/mediaclip/" + clipId.encodeURLParameter()  + "?"
			}
		}
		if (clipSoftEmbargo != null) url += "&bbcb=" + clipSoftEmbargo.encodeURLParameter()

		return url
	}

	private fun _loadClipSuccess(data: ContentItemInterface?) {
		Logger.d(TAG, "_loadClipSuccess")
		_clip = if (data is MediaClip) data as MediaClip else null // _sanitizeClip?
		val payload = mutableMapOf(
			"clipData" to _clip,
			"autoPlay" to _pendingPlay
		)
		if (_clip != null) {
			val cpRuleViolation = _clip?.cpRuleViolations?.getOrNull(0)
			if (cpRuleViolation != null && cpRuleViolation != "NotFound") {
				if (_initiator?.startsWith("Channel/") == true ||
					_initiator === "RelatedItem" ||
					!_playlistNextItem()) { // playlist depleted
					_eventBus?.trigger(EventName.bb_error, mapOf("msg" to  cpRuleViolation, "cpp" to  _clip?.cpp))
					// _clip.softEmbargo = null // avoid starting embargo timer
					_pendingPlay = false; payload["autoPlay"] = _pendingPlay // avoid playing; show poster instead
				} else {
					return // NB!
				}
			}

			_clip?.isPrefetch = true
			_eventBus?.trigger(EventName.bb_mediaclip_loaded, payload)
		} else {
			_eventBus?.trigger(EventName.bb_mediaclip_failed, payload)
		}

		_mediaController_preloaded = false

		val now: Instant = Clock.System.now()
		val softEmbargo = _clip?.softEmbargo
		val softEmbargoDate = if (!softEmbargo.isNullOrEmpty()) InstantFactory.tryCreateOfDateTime(softEmbargo) else null
		println("**** softEmbargoDate: $softEmbargoDate")
		if (softEmbargoDate != null && softEmbargoDate > now) {
			_softEmbargoActive = true
			if (!_inProject() || _softEmbargoCustomPosterClipId != null) { // NB!
				// update poster
				val posterUrl = _getPosterUrl(_clip)
				_posterController?.load(posterUrl)
			}
			_posterController?.show()

			_clipId = _clip?.id
			_clipSoftEmbargo = _clip?.softEmbargo
			_clip = null // NB!
			_softEmbargoTimer?.start(softEmbargoDate) // triggers bb_softembargotimer_finished
		} else { // normal
			_softEmbargoActive = false
			if (!_inProject()) {
				// update poster
				val posterUrl = _getPosterUrl(_clip)
				_posterController?.load(posterUrl)
			} else if (_softEmbargoCustomPosterClipId != null) { // NB!
				// update poster
				val posterUrl = _getPosterUrl( Project(_projectId, ""))
				_posterController?.load(posterUrl)
			}
			if (!_pendingPlay) {
				_posterController?.show()
			}

			if (_phase == Phase.INIT || _autoPlayNext || _isAutoAdvance || !_session_started) {
				_session_started = true
				if (_mediaController != null) {
					val mediaUrl = _getMediaUrl(_clip)
					var chaptersJsonString = "{"
					_clip?.chapters?.forEach {
							it: Chapter -> chaptersJsonString += "\"${it.timeOffset}\":\"${("${it.title}").replace("\\", "\\\\").replace("\"", "\\\"")}\","
					}
					chaptersJsonString = chaptersJsonString.replace(Regex(""",$"""), "") + "}" // fixes last comma
					var highlightsJsonString = "{"
					_clip?.highlights?.forEach {
							it: Highlight -> highlightsJsonString += "\"${it.timeOffset}\":\"${("${it.title}").replace("\\", "\\\\").replace("\"", "\\\"")}\","
					}
					highlightsJsonString = highlightsJsonString.replace(Regex(""",$"""), "") + "}" // fixes last comma
					val metadata: Map<String, String?> = mapOf(
						"playerId" to _playerId,
						"title" to (_clip?.title ?: "<untitled>"),
						"thumbnailUrl" to _getPosterUrl(_clip),
						"description" to (_clip?.description ?: ""),
						"contentType" to _inferContentType(mediaUrl),
						"duration" to (_clip?.length ?: 0).toString(),
						"isLive" to if (_clip?.sourcetype == "live") "true" else "false",
						"chaptersJson" to chaptersJsonString,
						"highlightsJson" to highlightsJsonString
					)
					_mediaController?.load(mediaUrl, _seekPosition, metadata)
					_mediaController_preloaded = true
				}
			}
		}

		if (_pendingPlay) {
			this.play(userAction = false)
		}
	}

	private fun _loadClipFailure(error: Exception?) {
		Logger.d(TAG, "_loadClipFailure error: ${error}")
		if (_contentIndicator != "a") {
			_clip = null
			_eventBus?.trigger(EventName.bb_mediaclip_failed)
		}
	}

	private fun _playlistIsEmpty (): Boolean {
		return _playlist.isEmpty()
	}

	private fun _playlistNextItem(): Boolean {
		Logger.d(TAG, "_playlistNextItem")
		var ret: Boolean = false

		if (_playlist.count() > 0) { // !_playlist.isEmpty()
			_prev = _clip
			_clip = null
			_clipSoftEmbargo = null; // NB initially!

			val item = _playlist.removeFirstOrNull()

			_clearFailedItem() // now that we have shifted, check if last media failed, and remove from lists

			if (!_autoPlayNext && !_usingSuggest) _contentList_prefetchItem(_playlist, 0);
			if (item !== null) {
				_projectClipListIndex = _projectClipList.indexOf(item)
				if (!_inProject()) _contentListIndex = _contentList.indexOf(item) + 1
				if (item is MediaClipList) {
					// Push current context to stack before entering nested MediaClipList
					// (Projects remain separate from nesting system)
					_pushContext()

					_content = null
					_contentIndicator = "l"
					_contentId = item.id
					if (item.isPrefetch) { // optimization
						_content = item // _sanitizeContent just in case?
					}

					// autoPlayNext
					_autoPlayNext_excludeIds.add(item.id ?: "") // we suspect id clashes will not happen very often between types


					_loadContent() // recurse...
				} else if (item is Project) {
					_content = null
					_contentIndicator = "p"
					_contentId = item.id
					if (item.isPrefetch) { // optimization
						_content = item // _sanitizeContent just in case?
					}

					// autoPlayNext
					_autoPlayNext_excludeIds.add(item.id ?: "") // we suspect id clashes will not happen very often between types

					_loadContent() // recurse...
				} else if (item is MediaClip) {
					_clipId = item.id
					if (item.isPrefetch || item.assets != null) { // optimization
						_clip = item as MediaClip // _sanitizeClip just in case?
					}
					_loadClip()

					// autoPlayNext
					_autoPlayNext_excludeIds.add(_clipId ?: "") // obsolete (done in _play too)?
				}

				ret = true
			} else {
				_eventBus?.trigger(EventName.bb_mediaclip_failed) // should proceed to next in playlist
				if (!_inProject()) {
					_contentListIndex = -1
					// update poster
					val posterUrl = _getPosterUrl(_clip)
					_posterController?.load(posterUrl)
				}
			}
		}

		return ret
	}

	private fun _inProject(): Boolean {
		return (_projectClipList !== null && _projectClipListIndex >= 0 && _projectClipListIndex < _projectClipList.count())
	}

	private fun _inContentList(): Boolean {
		return (_contentList !== null && _contentListIndex >= 0 && _contentListIndex < _contentList.count())
	}

	private fun _sanitizeContentItem(item: ContentItemInterface): ContentItemInterface {
		return item // IMPLEMENT ME
	}

	private fun _onCanPlay() {
		if (_startCollapsed) {
			_eventBus?.trigger(EventName.bb_request_expand)
		}
		_eventBus?.trigger(EventName.canplay)
	}

	private fun _onPlaying() {
		_playing = _playing_med || _playing_com
		if (_playing && !_keepPosterShowingOnPlaying) {
			_posterController?.hide()
		}
		if (_playing) {
			_eventBus?.trigger(EventName.playing)
			_setState(State.PLAYING)
		}

		_updateMode()
	}

	private fun _onPause() {
		_playing = _playing_med || _playing_com
		if (_playing && !_keepPosterShowingOnPlaying) {
			_posterController?.hide()
		}
		if (!_playing) {
			_eventBus?.trigger(EventName.pause)
			_setState(State.PAUSED)
		}

		_updateMode()
	}

	private fun _updateMode() {
		val mode = _mode
		if (_phase == Phase.PRE || _phase == Phase.POST) {
			_mode = "commercial"
		} else if (_playing_com) {
			_mode = "commercial"
		} else { // INIT / MAIN / EXIT
			_mode = ProgramController.fakeMode(_clip)
		}
		if (_mode != mode) { // changed
			_eventBus?.trigger(EventName.bb_mode_change, mapOf("mode" to _mode))
		}
	}

	private fun _onMediaFinished(eventType: EventName?) {
		Logger.d(TAG, "_onMediaFinished")
		if (_phase != Phase.MAIN) return // bail out

		if (_phase == Phase.MAIN && _phase_started) _mediaMainFinished = true

		// only reposition if not mainroll (otherwise _onCommercialMainFinished will reposition)
		if (_clip !== null && _clip?.mediatype == "mainroll") {
			// nothing
		} else { // normal
			if (_mediaMainFinished && _msasMainFinished) {
				// reposition
				_phase = Phase.POST
				_phase_started = false
				_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to true))
				_updateMode()
				_play()
			}
		}
	}

	private fun _onMediaFailed() {
		Logger.d(TAG, "_onMediaFailed")
		_failedMediaContentIndex = _contentListIndex
		if ( _autoLoopClip == true ) {
			_contentListIndex++
		}
		_onMediaFinished(null)

		if (_phase != Phase.MAIN) return // bail out
	}

	private fun _clearFailedItem() {
		Logger.d(TAG, "_clearFailedItem")
		if ( _failedMediaContentIndex != -1 && _failedMediaContentIndex >= 0 && _failedMediaContentIndex < _contentList.count() ) {
			Logger.d(TAG, "_clearFailedItem ***** doing it")
			spliceOutoffContentList(_failedMediaContentIndex)
			_failedMediaContentIndex = -1
		}
	}

	private fun _onCommercialPreFinished(eventType: EventName?) {
		Logger.d(TAG, "_onCommercialPreFinished")
		if (_phase != Phase.PRE) return // bail out

		val prev_phase_started = _phase_started

		// reposition
		_mediaMainFinished = false; _msasMainFinished = false
		_phase = Phase.MAIN
		_phase_started = false
		_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to prev_phase_started)) // NB!
		_updateMode()

		var adCounter_clip: Int = _adSchedulingController?.get("adCounter_clip") as Int? ?: _msasController?.get("adCounter_clip") as Int? ?: 0
		if (!_userAction) {
			if (_isAutoAdvance && _autoPlayOnlyWithPrerollAd && adCounter_clip <= 0) {
				_posterController?.show();
				_eventBus?.trigger(EventName.bb_program_autopause, mapOf("why" to "autoAdvanceOnlyWithPrerollAd"))
			} else if (_autoPlayOnlyWithPrerollAd && adCounter_clip <= 0) {
				_posterController?.show();
				_eventBus?.trigger(EventName.bb_program_autopause, mapOf("why" to "autoPlayOnlyWithPrerollAd"))
			} else if (_showOnlyWhenPrerollAvailable) {
				_posterController?.show();
				_eventBus?.trigger(EventName.bb_program_autopause, mapOf("why" to "showOnlyWhenPrerollAvailable"))
			} else if (prev_phase_started) {
				_play();
				_eventBus?.trigger(EventName.bb_program_autopauseplay, mapOf("why" to "autoPlayOnlyWithPrerollAd"))
			}
		} else { // _userAction
			if (_isAutoAdvance && _autoPlayOnlyWithPrerollAd && adCounter_clip <= 0) {
				_posterController?.show();
				_eventBus?.trigger(EventName.bb_program_autopause, mapOf("why" to "autoAdvanceOnlyWithPrerollAd"))
			} else if (prev_phase_started) {
				_play();
				_eventBus?.trigger(EventName.bb_program_autopauseplay, mapOf("why" to "userAction"))
			}
		}
	}

	private fun _onCommercialMainFinished(eventType: EventName?) {
		Logger.d(TAG, "_onCommercialMainFinished")
		if (_phase != Phase.MAIN) return // bail out

		val prev_phase_started = _phase_started

		_msasMainFinished = true

		if (_clip !== null && _clip?.mediatype == "mainroll") {
			// reposition
			_phase = Phase.POST
			_phase_started = false
			_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to prev_phase_started))
			_updateMode()
			if (prev_phase_started) _play()
		} else { // normal
			if (_mediaMainFinished && _msasMainFinished) {
				// reposition
				_phase = Phase.POST
				_phase_started = false
				_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to prev_phase_started))
				_updateMode()
				if (prev_phase_started) _play()
			}
		}
	}

	private fun _onCommercialPostFinished(eventType: EventName?) {
		Logger.d(TAG, "_onCommercialPostFinished: $eventType")
		if (_phase != Phase.POST) return // bail out

		val prev_phase_started = _phase_started

		if (_view_started) {
			_view_started = false
			_eventBus?.trigger(EventName.bb_view_finished) // here?
		}

		// revive playlist if depleted by project
		if (_playlist.count() == 0) {
			if (_inContentList() && _inProject() && _clip?.isOutro == "true") {
				if (_contentListIndex >= 0 && _contentListIndex < _contentList.count()) {
					if (_autoLoopClip) {
						_playlist.add(_contentList[_contentListIndex])
					} else {
						_contentListIndex++ // NB!
						val iter = _contentList.listIterator(_contentListIndex)
						iter.forEach { // NB starting at _contentListIndex!
							_playlist.add(it)
						}
					}
				}
			}
		}

		// First check if we should pop back to a parent context
		if (_playlistIsEmpty()) {
			_handlePlaylistDepletion();
		}

		_isAutoAdvance = (_playlist.count() > 0); // NB before re-fill by autoLoop / autoPlayNext!

		// auto-loop / autoPlayNext
		if (_playlistIsEmpty()) {
			if (_autoLoop || _autoLoopClip) {
				// re-fill playlist
				_playlist.clear()
				if (_inProject()) { // in project
					_playlist.add(_projectClipList[_projectClipListIndex])
				} else { // not in project
					if (_contentListIndex >= 0 && _contentListIndex < _contentList.count()) {
						if (_autoLoopClip) {
							_playlist.add(_contentList[_contentListIndex])
						} else if (_autoLoop) {
							// Pop all contexts to root and restart full experience
							while (!_isAtRootContext()) {
								_popContext()
							}

							_contentListIndex = 0 // NB starting at 0!
							val iter = _contentList.listIterator(_contentListIndex)
							iter.forEach { // NB starting at _contentListIndex!
								_playlist.add(it)
							}
						}
					}
				}
			} else if (_autoPlayNext) {
				_playlist.clear()
				// find a clip that's not excluded
				for (item in _autoPlayNext_items) {
					if (item is MediaClip && !_autoPlayNext_excludeIds.contains(item.id)) { // not excluded
						_playlist.add(item)
						break // one is enough
					} else if (item is Project && !_autoPlayNext_excludeIds.contains(item.id)) { // not excluded
						_playlist.add(item)
						break // one is enough
					}
				}

				if (_playlist.count() > 0) {
					_phase = Phase.EXIT
					_phase_started = false
					_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to false))
					_updateMode()
					//handle thumbnail
					if (!_noPosterInExitPhase &&
						(!_inProject() || _clip?.isOutro == "true")) {
						Logger.d(TAG, "-- _onCommercialPostFinished - show postercontroller")
						_posterController?.show()
					}
					_eventBus?.trigger(EventName.bb_autoplaynext_item, mapOf("item" to _playlist[0]))
					if (prev_phase_started) _autoPlayNext_timer?.start()
					return // NB before _playlistNextItem!
				}
			}
		}

		_pendingPlay = false // will be controlled by prev_phase_started below
		if (_playlistNextItem()) {
			// autoLoop or next clip from cliplist
			if (_initiator === null) _initiator = "autoLoop"

			_phase = Phase.PRE
			_phase_started = false
			_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to prev_phase_started))
			_updateMode()
			_mediaController_preloaded = false
			if (prev_phase_started) _play()
		} else {
			_phase = Phase.EXIT
			_phase_started = false
			_eventBus?.trigger(EventName.bb_phase_change, mapOf("phase" to _phase, "willAutoPlay" to false))
			_updateMode()
			//handle thumbnail
			if (!_noPosterInExitPhase &&
				(!_inProject() || _clip?.isOutro == "true")) {
				Logger.d(TAG, "-- _onCommercialPostFinished - show postercontroller")

				_posterController?.show()		//maybe show ? (in certain cases ?)
			}
			// DO NOT _play()
			_eventBus?.trigger(EventName.ended)
			if (_hidePlayerOnEnd) {
				_eventBus?.trigger(EventName.bb_request_collapse)
			}
		}
	}

	private fun _onSoftEmbargoTimerFinished () {
		_softEmbargoActive = false
		if (_clipId != null) { // typically
			// if (_dataMediaClipsById) _dataMediaClipsById['#' + _clipId] = null; // NB clear cached clip!
			_clip = null // just to ensure _loadClip will fetch
			_loadClip()
		} else {
			// _dataMediaClipsById = null; // NB empty cache!
			_content = null; // just to ensure _loadContent will fetch
			_loadContent()
		}
	}

	private fun _onAdContentPauseReq() {
		if (_phase == Phase.MAIN && _phase_started) {
			_pauseRequested = true
			_mediaController?.pause(true)
		}
	}

	private fun _onAdContentResumeReq() {
		if (_phase == Phase.MAIN) { // && _phase_started) {
			_pauseRequested = false
			if (!_mediaMainFinished) _mediaController?.play(_userAction, requested = true)
			_userAction = true // reset
		}
	}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
	}

	private fun _onRelatedClipsChanged(eventType: EventName?, payload: Map<String, Any?>?) {
		// debug('[ProgramController] _onRelatedClipsChanged');
		if (payload != null && (payload["items"] != null || payload["clips"] != null)) {
			if (payload["items"] is MutableList<*>) _autoPlayNext_items = payload["items"] as MutableList<ContentItemInterface>
			else if (payload["clips"] is MutableList<*>) _autoPlayNext_items = payload["clips"] as MutableList<ContentItemInterface>
			else _autoPlayNext_items.clear()

			var idx = 0
			while (idx < _autoPlayNext_items.count()) {
				val autoPlayNextItem = _autoPlayNext_items.elementAtOrNull(idx)
				if (autoPlayNextItem is MediaClip && _autoPlayNext_excludeIds.indexOf(autoPlayNextItem.id) < 0) { // not found
					_contentList_prefetchItem(_autoPlayNext_items, idx);
					break // one is enough
				}
				idx++
			}
		}
	}

	private fun _contentList_prefetchItem(contentList: MutableList<ContentItemInterface>?, idx: Int): Boolean {
		// debug('[ProgramController] _contentList_prefetchItem idx: ' + idx);
		var ret = false

		val contentListItem = contentList?.elementAtOrNull(idx)
		if (contentListItem != null) {
			if (contentListItem is Project) {
				// TODO
			} else if (contentListItem is MediaClip) {
				if (contentListItem.isPrefetch) {
					// nothing needed
				} else {
					val clipId = contentListItem.id
					val clipUrl = _getClipUrl(clipId, null)
					if (clipUrl !== null) {
						_contentLoader?.getContentFromJsonUrl(clipUrl, { _prefetchClipSuccess(it, contentList, idx) }, { _prefetchClipFailure(it) }) // fetchJsonData
					} else {
						_prefetchClipFailure(Exception("Could not compose url"))
					}
				}
			}
		}

		return ret
	}

	private fun _prefetchClipSuccess(data: ContentItemInterface?, contentList: MutableList<ContentItemInterface>?, idx: Int) {
		val contentListItem = if (data is MediaClip) data as MediaClip else MediaClip("0", "-") // _sanitizeClip?
		contentListItem.isPrefetch = true

		if (contentList?.elementAtOrNull(idx) != null) contentList[idx] = contentListItem;
	}

	private fun _prefetchClipFailure(error: Exception?) {
		Logger.d(TAG, "_prefetchClipFailure error: ${error}")
	}

	private fun _ingestPlayoutData(playoutData: Playout) {
		if (playoutData.ignoreSingleMediaResource != null) _ignoreSingleMediaResource = (playoutData.ignoreSingleMediaResource == "true")
		if (playoutData.ignoreProjectMetadata != null) _ignoreProjectMetadata = (playoutData.ignoreProjectMetadata == "true")
		if (playoutData.noPosterInExitPhase != null) _noPosterInExitPhase = (playoutData.noPosterInExitPhase == "true")
		if (playoutData.softEmbargoHasCustomPoster == "true") _softEmbargoCustomPosterClipId = playoutData.softEmbargoCustomPosterClipId
		if (playoutData.autoPlayNext != null) _autoPlayNext = (playoutData.autoPlayNext == "true")
		if (playoutData.autoPlay != null) _autoPlay = (playoutData.autoPlay == "true")
		if (playoutData.autoLoop != null) _autoLoop = (playoutData.autoLoop == "true")
		if (playoutData.autoLoopClip != null) _autoLoopClip = (playoutData.autoLoopClip == "true")
		if (playoutData.autoPlayOnlyWithPrerollAd != null) _autoPlayOnlyWithPrerollAd = (playoutData.autoPlayOnlyWithPrerollAd == "true")
		if (playoutData.showOnlyWhenPrerollAvailable != null) _showOnlyWhenPrerollAvailable = (playoutData.showOnlyWhenPrerollAvailable == "true")
		if (playoutData.relatedItemsPause != null) _showRelatedItemsOnPause = (playoutData.relatedItemsPause == "Show") // NB!
		if (playoutData.useThumbsFromMetadata != null) _useThumbsFromMetadata = (playoutData.useThumbsFromMetadata == "true") // NB!
		if (playoutData.startCollapsed != null) _startCollapsed = (playoutData.startCollapsed == "true") // NB!
		if (playoutData.hidePlayerOnEnd != null) _hidePlayerOnEnd = (playoutData.hidePlayerOnEnd == "true") // NB!
	}

	private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>?) {
		Logger.d(TAG, "_ingestOpts")
		if (opts != null) {
			_rawJsonString = opts.rawJsonString ?: "{}"
			// println("[ProgramController] _ingestOpts _rawJsonString: ${_rawJsonString}")

			if (opts.publicationData != null) {
				if (!opts.publicationData.baseurl.isNullOrEmpty()) _baseUrl = opts.publicationData.baseurl
				if (!opts.publicationData.defaultMediaAssetPath.isNullOrEmpty()) _defaultMediaAssetPath = opts.publicationData.defaultMediaAssetPath
				if (!opts.publicationData.mobileMediaAssetPath.isNullOrEmpty()) _mobileMediaAssetPath = opts.publicationData.mobileMediaAssetPath
				if (opts.publicationData.useThumbsFromMetadata != null) _useThumbsFromMetadata = (opts.publicationData.useThumbsFromMetadata == "true") // NB!
			}

			// embed parameters
			if (opts.embedData != null) {
				if (!opts.embedData.baseurl.isNullOrEmpty()) _baseUrl = opts.embedData.baseurl
				if (!opts.embedData.contentIndicator.isNullOrEmpty()) _contentIndicator = opts.embedData.contentIndicator
				if (!opts.embedData.contentId.isNullOrEmpty()) _contentId = opts.embedData.contentId
			}

			// playout settings
			if (opts.playoutData != null) {
				_ingestPlayoutData(opts.playoutData)
				if (_startCollapsed) {
					_eventBus?.trigger(EventName.bb_request_collapse)
				}
			}

			// check options dict and override values
			if (options != null && options["autoPlay"] != null) {
				if (options["autoPlay"] is String) _autoPlay = (options["autoPlay"] as String == "true")
				if (options["autoPlay"] is Boolean) _autoPlay = options["autoPlay"] as Boolean
			}
			if (options != null && options["autoLoopClip"] != null) {
				if (options["autoLoopClip"] is String) _autoLoopClip = (options["autoLoopClip"] as String == "true")
				if (options["autoLoopClip"] is Boolean) _autoLoopClip = options["autoLoopClip"] as Boolean
			}
			if (options != null && options["listOffset"] != null) {
				if (options["listOffset"] is Int) _listOffset = options["listOffset"] as Int
			}
			if (options != null && options["initiator"] != null) {
				if (options["initiator"] is String) _initiator = options["initiator"] as String
			}

			// context from embed options
			var context: Map<String, String?>? = null
			if (options != null && (options["contextCollectionId"] != null || options["contextEntityId"] != null)) {
				context = mapOf(
					"contextCollectionType" to options["contextCollectionType"] as? String,
					"contextCollectionId" to options["contextCollectionId"] as? String,
					"contextEntityType" to options["contextEntityType"] as? String,
					"contextEntityId" to options["contextEntityId"] as? String
				)
			}

			// resources
			if (options?.get("playerType") == "shorts") {
				_adController?.set("mode", "SHORTS") // hack for Shorts-specific behavior
				_msasController = MsasController(_eventBus, opts, options)
				_msasController?.adController = _adController  // MsasController needs to get this adController

				_shortsEngine = ShortsEngine(_eventBus, opts, options)
				_shortsEngine?.programController = this
				_shortsEngine?.msasController = _msasController
			} else if (options?.get("playerType") == "renderer") {
				if (opts.adServicesData != null) {
					opts.adServicesData.forEach {
						it.lineitems = null // NB!
						it.assignedLineitems = null // NB!
					}
				}
				_msasController = MsasController(_eventBus, opts, options)
				_msasController?.adController = _adController  // MsasController needs to get this adController
			} else if (opts.adSchedulingData != null && opts.adSchedulingData.scheduleCode != null) {
				_adSchedulingController = AdSchedulingController(_eventBus, opts, options)
				_adSchedulingController?.adController = _adController  // AdSchedulingController needs to get this adController
			} else if (opts.adServicesData != null && !opts.adServicesData.isEmpty()) {
				_msasController = MsasController(_eventBus, opts, options)
				_msasController?.adController = _adController  // MsasController needs to get this adController
			}

			// content
			if (opts.clipListData != null) {
				// optimization
				_clipListPrefetchedItem = null
				if (opts.projectData != null && opts.projectData.cpp.isNullOrEmpty()) {
					opts.projectData.isPrefetch = true
					_clipListPrefetchedItem = opts.projectData
				} else if (opts.clipData != null && opts.clipData.cpp.isNullOrEmpty()) {
					opts.clipData.isPrefetch = true
					_clipListPrefetchedItem = opts.clipData
				}
				this.loadContent(opts.clipListData, _initiator, _autoPlay, _seekPosition, context, _listOffset)
			} else if (opts.projectData != null) {
				this.loadContent(opts.projectData, _initiator, _autoPlay, _seekPosition, context)
			} else if (opts.clipData != null) {
				// hack: fix missing clipData rawJsonString
				if (opts.clipData.rawJsonString.isNullOrEmpty()) {
					val jsonString = _rawJsonString
					if (jsonString != null) {
						var jsonClipDataAny: Any? = null
						try {
							val jsonElement = Json.parseToJsonElement(jsonString)
							if (jsonElement is JsonObject) {
								jsonClipDataAny = BlueBillywigLogger.getFromJsonObject("/clipData", jsonElement)
							}
						} catch (_: Exception) { }
						var jsonClipDataString: String? = null
						try {
							jsonClipDataString = when (jsonClipDataAny) {
								is JsonObject -> Json.encodeToString(JsonObject.serializer(), jsonClipDataAny)
								is JsonArray -> Json.encodeToString(JsonArray.serializer(), jsonClipDataAny)
								else -> null
							}
						} catch (_: Exception) { }
						opts.clipData.rawJsonString = jsonClipDataString
					}
				}

				this.loadContent(opts.clipData, _initiator, _autoPlay, _seekPosition, context)
			} else if (opts.adSchedulingData != null || opts.adServicesData != null) {
				// resilience; will be handled in MsasController
			} else {
				Logger.d(TAG, "_ingestOpts warning: no content")
			}
		}
	}

	private fun _assetTitle (asset: MediaAsset): String? {
		if (asset.title != null) return asset.title
		var title = ""

		val type = _clip?.mediatype ?: "video"
		when (type) {
			"video" -> {
				try {
					val assetHeight = asset.height?.toInt() ?: 0
					title = if (assetHeight > 0) (ceil(assetHeight.toDouble() / 120) * 120).toString()+"p" else "" // 272 -> 360p, 400/404/432 -> 480p
				} catch (_: Exception) {}
				if (asset.id == "-1" || asset.height == "auto") { // auto
					title = "auto" + if (!title.isEmpty()) " ("+title+")" else ""
				}
			}
			"audio" -> {
				try {
					val assetBandwidth = asset.bandwidth?.toInt() ?: 0
					title = if (assetBandwidth > 0) (assetBandwidth.toString()+" kbps") else "" // kbit/s, kbps, or kb/s
				} catch (_: Exception) {}
				if (asset.id == "-1" || asset.bandwidth == "auto") { // auto
					title = "auto" + if (!title.isEmpty()) " ("+title+")" else ""
				}
			}
			else -> {}
		}
		if (title.isEmpty()) {
			val assetMediatype = asset.mediatype ?: ""
			val assetSrc = asset.src ?: ""
			if (("""HLS$""").toRegex().containsMatchIn(assetMediatype) ||
				("""\.m3u8(\?.*|&.*|)$""").toRegex().containsMatchIn(assetSrc) ||
				("""MPD$""").toRegex().containsMatchIn(assetMediatype) ||
				("""\.mpd(\?.*|&.*|)$""").toRegex().containsMatchIn(assetSrc)) {
				title = "auto"
			}
		}

		return title
	}

	private fun _getMediaUrl(clip: MediaClip?, silent: Boolean = false): String? {
		var url: String? = null
		val assets = clip?.assets

		var imageAsset: MediaAsset? = null
		if (/*assets == null &&*/ clip?.mediatype == "image") {
			val ext = clip.src?.substringAfterLast('.', "") ?: ""
			imageAsset = MediaAsset("image/${ext.lowercase()}", clip.id, "published", clip.src, "5", "5.0", "768", "432", "1000", null, null, null, null, null, "#1" ) // fake asset
		}

		if (assets !== null || imageAsset != null) {
			// create shortlist
			val shortlist: MutableList<MediaAsset> = mutableListOf()
			if (assets !== null) {
				for (asset in assets) {
					if (!ProgramController.assetIsExcluded(asset)) shortlist.add(asset)
				}
			}
			if (imageAsset !== null) {
				shortlist.add(imageAsset)
			}

			// select best asset
			var selectedAsset: MediaAsset? = null
			if (clip?.mediatype == "audio") {
				for (asset in shortlist) {
					if (ProgramController.assetCompareAudio(selectedAsset, asset) > 0) selectedAsset = asset
				}
				// no asset found for some reason, try to find an asset anyway
				if (selectedAsset == null) {
					for (asset in shortlist) {
						if (asset.mediatype == "MP3") {
							selectedAsset = asset
						}
					}
				}
			} else { // video / image
				for (asset in shortlist) {
					if (ProgramController.assetCompareVisual(selectedAsset, asset) > 0) selectedAsset = asset
				}
				// no asset found for some reason, try to find an asset anyway
				if (selectedAsset == null) {
					for (asset in shortlist) {
						if (asset.mediatype == "MP4_MAIN") {
							selectedAsset = asset
						}
					}
				}
			}
			// no asset found for some reason, last try to find an asset anyway
			if (selectedAsset == null) {
				if (shortlist.count() > 0) {
					selectedAsset = shortlist[0]
				}
			}

			if (selectedAsset !== null && selectedAsset.src !== null) {
				selectedAsset.title = _assetTitle(selectedAsset)

				var map = _defaultMediaAssetPath
				if (clip?.mediatype != "image" && clip?.mediatype != "interactive" && _mobileMediaAssetPath.isNotEmpty())
					map = _mobileMediaAssetPath
				if (_forceSSL) map = map.replace(("""^http:""").toRegex(), "https:")
				if (_forceSSL) map = map.replace(("""protocol=[^&#]*""").toRegex(), "protocol=https")
				url = _fixRelativeUrl("${selectedAsset.src}", map)
			} else {
				Logger.d(TAG, "_getMediaUrl warning: no asset")
			}
			if (!silent) _eventBus?.trigger(EventName.bb_asset_selected, mapOf("asset" to selectedAsset))
		} else { // no assets
			Logger.d(TAG, "_getMediaUrl warning: no assets")
			if (!silent) _eventBus?.trigger(EventName.bb_asset_selected, mapOf("asset" to null))
		}

		return url
	}

	private fun _getPosterUrl(content: ContentItemInterface?, firstFrame: Boolean = false): String? {
		var url: String? = null
		if (_softEmbargoActive && _softEmbargoCustomPosterClipId != null) {
			url = _baseUrl + "/mediaclip/" + _softEmbargoCustomPosterClipId + "/pthumbnail/default/default.jpg"
		} else if (content is Project) {
			val useThumbsFromMetadata =
				if (content.useThumbsFromMetadata != null) (content.useThumbsFromMetadata == "true")
				else _useThumbsFromMetadata
			if (useThumbsFromMetadata && content.thumbnails != null) {
				url = _getMainThumbnailUrl(content.thumbnails)
			} else {
				url = _baseUrl + "/project/" + content.id + "/pthumbnail/default/default.jpg"
			}
		} else if (content is MediaClip) {
			val useThumbsFromMetadata =
				if (content.useThumbsFromMetadata != null) (content.useThumbsFromMetadata == "true")
				else _useThumbsFromMetadata
			if (useThumbsFromMetadata && content.thumbnails != null) {
				url = _getMainThumbnailUrl(content.thumbnails)
			} else if (content.mediatype != "mainroll") {
				url = _baseUrl + "/mediaclip/" + content.id + "/pthumbnail/default/default.jpg"
				if (firstFrame) {
					url += "?frame0"
				}
			}
		} else if (content is MediaClipList) {
			url = _baseUrl + "/mediacliplist/" + content.id + "/pthumbnail/default/default.jpg"
		} else {
			Logger.d(TAG, "_getPosterUrl warning: no content")
		}

		return url
	}

	private fun _getMainThumbnailUrl(items: List<Thumbnail>): String? {
		var url: String? = null

		var selectedThumb: Thumbnail? = null;
		for (item in items) {
			if (item.main == true) { // found
				selectedThumb = item
				break // one is enough
			}
		}
		if (selectedThumb != null && selectedThumb.src != null) {
			url = _fixRelativeUrl("${selectedThumb.src}")
		} else {
			Logger.d(TAG, "_getMainThumbnailUrl warning: no thumbnail")
		}

		return url
	}

	private fun _inferContentType(mediaUrl: String?): String? {
		var contentType: String? = null
		if (mediaUrl != null) {
			if (("""[?&=.]+m3u8""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "application/vnd.apple.mpegurl"
			} else if (("""[?&=.]+mpd""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "application/dash+xml"
			} else if (("""[?&=.]+aac""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "audio/aac"
			} else if (("""[?&=.]+mp3""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "audio/mp3"
			} else if (("""[?&=.]+jpg""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "image/jpg"
			} else if (("""[?&=.]+gif""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "image/gif"
			} else if (("""[?&=.]+png""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "image/png"
			} else if (("""[?&=.]+webp""").toRegex().containsMatchIn(mediaUrl)) {
				contentType = "image/webp"
			} else {
				contentType = "video/mp4"
			}
		}

		return contentType
	}

	private fun _fixRelativeUrl(url: String, map: String = _defaultMediaAssetPath): String {
		var fixedUrl = url

		// fix relative url; prepend map
		val re2 = Regex("""^(\w+:|)//.*""", RegexOption.IGNORE_CASE)
		if (!re2.matches(fixedUrl)) {
			val re3 = Regex("""\?.*=$""", RegexOption.IGNORE_CASE) // matches ...?...=
			if (re3.containsMatchIn(map)) {
				fixedUrl = map + fixedUrl.encodeURLParameter()
			} else {
				fixedUrl = map + fixedUrl
			}
		}

		// fix protocol-relative url; prepend https:
		val re1 = Regex("""^//.*""", RegexOption.IGNORE_CASE)
		if (re1.matches(fixedUrl)) {
			fixedUrl = "https:" + fixedUrl
		}

		return fixedUrl
	}
}
