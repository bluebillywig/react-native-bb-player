package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CustomField (
    val name: String? = null,
    val type: String? = null,
    val includeInStats: Boolean? = null
)

@Serializable
data class CustomFields (
    val mediaclip: List<CustomField>? = null
)

@Serializable
data class Publication (
    val id: String? = null,
    val name: String? = null,
    val status: String? = null,
    val type: String? = null,
    val publisherid: String? = null,
    val label: String? = null,
    val baseurl: String? = null,
    val baseuri: String? = null,
    val sourcepath: String? = null,

    @SerialName("#text")
    val text: String? = null,

    val bidadapters: String? = null,
    val usePreferredPlayMode: String? = null,
    val useThumbsFromMetadata: String? = null,
    val embedAsync: String? = null,
    val avoidPreload: String? = null,
    val avoidMediaManager: String? = null,
    val avoidAndroidNativeHLS: String? = null,
    val serverUploadScript: String? = null,
    val statsserver: String? = null,
    val statspublication: String? = null,

    @SerialName("playoutUrl")
    val playoutURL: String? = null,
    val defaultMediaAssetPath: String? = null,
    val contextMenuLink: String? = null,

    @SerialName("__streamingMediaAssetPath")
    val streamingMediaAssetPath: String? = null,

    val rtmphost: String? = null,
    val publicationLabel: String? = null,
    val streamingMediaAssetPathTimeline: String? = null,
    val mobileMediaAssetPath: String? = null,

    @SerialName("providerUrl")
    val providerURL: String? = null,

    val secureMediaAssetPath: String? = null,
    val timeZone: String? = null,

    val liveMediaAssetPath: String? = null,
    val enableChat: String? = null,
    val wsChatEndpoint: String? = null,
    val customfields: CustomFields? = null
) {
    constructor(id: String, name: String, status: String = "active") : this(id, name, status,null)
}
