package com.bluebillywig.bbnativeshared.interfaces

/**
 * @suppress
 */
interface PosterControllerInterface {
    fun load(posterUrl: String?, posterMediaType: String? = null): Boolean { return false; } // optional

    fun show(): Boolean

    fun hide(): Boolean
}
