package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class Highlight (
    val id: String? = null,
    val title: String? = null,
    val timeOffset: Float? = null,
)
