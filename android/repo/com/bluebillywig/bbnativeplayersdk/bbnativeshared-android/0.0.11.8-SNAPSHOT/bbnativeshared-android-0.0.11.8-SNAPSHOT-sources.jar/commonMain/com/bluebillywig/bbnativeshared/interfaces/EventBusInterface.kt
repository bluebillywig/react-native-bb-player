package com.bluebillywig.bbnativeshared.interfaces

import com.bluebillywig.bbnativeshared.enums.EventName

/**
 * @suppress
 */
interface EventBusInterface {
    var listeners: MutableList<EventListenerInterface>
    fun trigger(eventType: EventName)
    fun trigger(eventType: EventName, data: Map<String, Any?>)
    fun addEventlistener(listener: EventListenerInterface)
    fun removeEventlistener(listener: EventListenerInterface)
}
