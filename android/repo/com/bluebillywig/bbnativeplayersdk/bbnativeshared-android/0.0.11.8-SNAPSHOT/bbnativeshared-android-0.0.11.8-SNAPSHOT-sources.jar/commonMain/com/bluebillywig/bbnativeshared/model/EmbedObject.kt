package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.*

@Serializable
data class EmbedObject (
    val publicationData: Publication? = null,
    val embedData: EmbedData? = null,
    val playoutData: Playout? = null,
    val clipData: MediaClip? = null,
    val clipListData: MediaClipList? = null,
    val projectData: Project? = null,
    val adServicesData: List<AdUnit>? = null,
    val adSchedulingData: AdSchedulingData? = null,
    val appConfig: AppConfig? = null,

//    val previewMode: Any? = null,
    val protocol: String? = null,
    val userLanguage: String? = null,
    val userDeviceType: String? = null,
    val playoutSafeName: String? = null,
    val contentIndicator: String? = null,
    val contentId: String? = null,
//    val playqueueData: Any? = null,
    val playerWidth: String? = null,
    val playerHeight: String? = null,
    val playerUrl: String? = null,
    val scriptTarget: String? = null,
    val playerBase: String? = null,
    val playerPath: String? = null,
    val scriptLink: String? = null,
    val requestParams: RequestParams? = null,
    val versioningData: VersioningData? = null
):BBModel() {
    constructor(publicationData: Publication, clipData: MediaClip) : this(publicationData, null, null, clipData, null, null)
}

@Serializable
data class RequestParams (
    val mode: String? = null,
    val playoutlabel: String? = null,
    val contentindicator: String? = null,
    val contentid: String? = null
)

@Serializable
data class VersioningData (
    val timelineVersion: String? = null,
    val state: String? = null
)