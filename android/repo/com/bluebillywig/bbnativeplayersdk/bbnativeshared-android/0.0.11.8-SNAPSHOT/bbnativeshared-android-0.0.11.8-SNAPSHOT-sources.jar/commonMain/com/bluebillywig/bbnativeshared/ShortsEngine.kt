package com.bluebillywig.bbnativeshared

import com.bluebillywig.bbnativeshared.controller.MsasController
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.data.ContentLoader
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
// import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import com.bluebillywig.bbnativeshared.model.*

import kotlin.math.* // max

//import { fetchData } from '../Util';
//import debug from '../debug';
//import { loadIMA } from '../IMALoader';

//enum class SWIPE_DIRECTION {
//	LEFT: -1,
//	UNKNOWN: 0,
//	RIGHT: 1
//}

/**
 * The ShortsEngine listens to various player events to try and automatically insert mainroll ad items
 * in a playlist based on where the player currently is in the playlist
 */
/**
 * @suppress
 */
class ShortsEngine(eventBus: EventBusInterface?, opts: EmbedObject? = null, options: Map<String, Any?>? = null):EventListenerInterface {
    companion object {
        const val TAG = "ShortsEngine"

        fun findIndexForItemId(list: MutableList<ContentItemInterface>?, itemId: String?): Int {
            if (list != null && itemId != null) {
                for (item in list) {
                    if (item.id == itemId) return list.indexOf(item) // rather inefficient?!?
                }
            }
            return -1
        }
    }

    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_embed_loaded -> {
                val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
                if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
            }
            EventName.bb_cliplist_loaded, EventName.bb_cliplist_changed -> { _onCliplistChanged(eventType, data) }
            EventName.bb_mediaclip_loaded -> { _onMediaClipLoaded(eventType, data) }
//			EventName.bb_bandwidth_measured -> { _onBandwidthMeasured(eventType, data) }
            EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
            EventName.bb_adsystem_loaded -> { _onAdSystemLoaded(eventType, data) }
            EventName.bb_adsystem_started, EventName.bb_adsystem_failed -> { _onAdSystemStarted(eventType, data) }
            EventName.bb_adsystem_finished, EventName.bb_adsystem_skipped -> { _onAdSystemFinished(eventType, data) }
            else -> { return }
        }
    }

    // resources
    private var _eventBus: EventBusInterface? = eventBus
    private var _programController: ProgramController? = null
    private var _shortsAdController: MsasController? = null
    private var _contentLoader: ContentLoader = ContentLoader()
//		_headController = instanceService.getInstance('HeadController');
//		_mediaBufferManager = instanceService.getInstance('MediaBufferManager');
//		_detections = instanceService.getInstance('Detections');

    // settings
    private var _baseUrl: String = ""
    private var _shortsId: String = "0"
    private var _shortsAdunitCode: String = "0"
    private var _clipAdInterval: Int = 2
    private var _firstAdPosition: Int = 2
//	private var _assetPreloadWindow: Int = 1

    // state
    private var _swipeDirection = 0 // UNKNOWN
    private var _lastKnownClipIndex: Int = -1
    private var _lastKnownMainrollIndex: Int = -1
    private var _swipeAccumulator: Int = 0
    //	private var _bandwidth: Int = 2000 // _detections?.measuredBandwidth // default value, try and keep in sync with HeadController
//	private var _bandwidthMeasured: Boolean = false // _detections?.measuredBandwidth !== null
    // For the first preload we need some special behaviour for asset selection as the HeadController will usually be picking an asset
    // before we can decide which one to preload. After we can use our own behaviour and steer the HeadController to prefer the preloaded assets.
//	private var _firstPreload: Boolean = true
    // When flagged as true either _handleQueuedPreload or _onBandwidthMeasured will
    // fire _preloadClips when they are triggered
//	private var _preloadQueued: Boolean = false
    private var _shortsAdReady: Boolean = false
    private var _shortsAdSpliced: Boolean = false

    // data
    private var _clipListItems: MutableList<ContentItemInterface>? = null
    private var _clipData: MediaClip? = null
    private var _currentClip = null
    private var _shortsAdServicesData: List<AdUnit>? = null

    init {
        _eventBus?.addEventlistener(this)
        _ingestOpts(opts, options) // NB because bb_embed_loaded has already passed!
    }

    fun __destruct () {
        _eventBus?.removeEventlistener(this)
        _eventBus = null
    }

    var programController: ProgramController?
        get() = _programController
        set(value) {
            _programController = value
            _contentLoader.network = _programController?.network

            if (_programController != null && _shortsAdController != null) {
                _loadAdUnit()
            }
        }

    var msasController: MsasController?
        get() = _shortsAdController
        set(value) {
            _shortsAdController = value

            if (_shortsAdController != null && _programController != null) {
                _loadAdUnit()
            }
        }

    private fun _ingestPlayoutData(playout: Playout) {
        if (playout.shortsId != null) _shortsId = playout.shortsId
        if (playout.adunitId != null) _shortsAdunitCode = playout.adunitId // NB code?!?
        if (playout.clipAdInterval != null) _clipAdInterval = max(2, playout.clipAdInterval.toInt())
        if (playout.firstAdPosition != null) _firstAdPosition = playout.firstAdPosition.toInt()
//      if (playout.assetPreloadWindow != null) _assetPreloadWindow = playout.assetPreloadWindow.toInt()
    }

    private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>? = null) {
        if (opts != null) {
            if (opts.publicationData != null) {
                val publication = opts.publicationData as Publication
                if (!publication.baseurl.isNullOrEmpty()) _baseUrl = publication.baseurl as String
            }
            // embed parameters
            if (opts.embedData != null) {
                if (!opts.embedData.baseurl.isNullOrEmpty()) _baseUrl = opts.embedData.baseurl
            }

            // playout settings
            if (opts.playoutData != null) {
                _ingestPlayoutData(opts.playoutData)
            }

            if (options != null) {
                if (options["shortsId"] is String) _shortsId = options["shortsId"] as String
                if (options["adunitId"] is String) _shortsAdunitCode = options["adunitId"] as String // NB code?!?
                if (options["clipAdInterval"] is Int) _clipAdInterval = max(2, options["clipAdInterval"] as Int)
                if (options["firstAdPosition"] is Int) _firstAdPosition = options["firstAdPosition"] as Int
//				if (options["assetPreloadWindow"] is Int) _assetPreloadWindow = options["assetPreloadWindow"] as Int
            }

            if (opts.clipListData != null) {
                _clipListItems = null
                val items = opts.clipListData.items
                if (items != null) {
                    _clipListItems = mutableListOf()
                    for (item in items) {
                        _clipListItems?.add(item as ContentItemInterface)
                    }
                }
            }

            if (opts.clipData is MediaClip) {
                _onMediaClipLoaded(null, mapOf("clipData" to opts.clipData as MediaClip))
            }
        }
    }

    private fun _onCliplistChanged(_ev: EventName, payload: Map<String, Any?>?) {
        if (payload == null) return // bail out

        if (payload["clipListItems"] is MutableList<*>) {
            _clipListItems = payload["clipListItems"] as MutableList<ContentItemInterface>
        } else if (payload["clipListData"] is MediaClipList) {
            _clipListItems = null
            val items = (payload["clipListData"] as MediaClipList).items
            if (items != null) {
                _clipListItems = mutableListOf()
                for (item in items) {
                    _clipListItems?.add(item as ContentItemInterface)
                }
            }
        } else {
            _clipListItems = null
        }

//        _lastKnownClipIndex = -1
//        _lastKnownMainrollIndex = -1
//        _swipeDirection = 0 // UNKNOWN

        // Only trigger preload once we know current clip
        val clipListItems = _clipListItems
        if (clipListItems != null) {
            if (findIndexForItemId(clipListItems, _clipData?.id) !== -1) { // _clipListData.findIndex(c => c.id === _clipData.id)
                // If we have already measured the bandwidth start preload immediately,
                // otherwise give a little bit of time for it to potentially be measured
                // and then start the preload
                _preloadClipsWhenReady()
            }
        }
    }

    private fun _onMediaClipLoaded(_ev: EventName?, payload: Map<String, Any?>?) {
        if (payload == null || !(payload["clipData"] is MediaClip)) return
        _clipData = payload["clipData"] as MediaClip

        val clipIndex = findIndexForItemId(_clipListItems, _clipData?.id)
        if (_clipData?.mediatype == "mainroll") {
            if (clipIndex != -1) _lastKnownMainrollIndex = clipIndex
        } else {
            if (_lastKnownClipIndex != -1 && clipIndex != -1) {
                if (clipIndex > _lastKnownClipIndex) {
                    _swipeDirection = 1 // RIGHT
                } else if (clipIndex < _lastKnownClipIndex) {
                    _swipeDirection = -1 // LEFT
                }

                _swipeAccumulator += _swipeDirection
            } else {
                _swipeDirection = 0 // UNKNOWN
            }
            if (clipIndex != -1) _lastKnownClipIndex = clipIndex
        }

        // If we aren't in a cliplist trigger preload immediately,
        // if we are then check if we already have the clipListData.
        // If not then we'll trigger the preload in onCliplistLoaded
        if (payload["contextEntityType"] != "MediaClipList" || (payload["contextEntityType"] == "MediaClipList" && _lastKnownClipIndex != -1)) {
            // If we have already measured the bandwidth start preload immediately,
            // otherwise give a little bit of time for it to potentially be measured
            // and then start the preload
            _preloadClipsWhenReady()
            _checkForAds()
        }
    }

    private fun _loadAdUnit () {
        println("[ShortsEngine] _loadAdUnit _clipAdInterval: ${_clipAdInterval}, _shortsAdunitCode: ${_shortsAdunitCode}")
        if (_clipAdInterval > 0 && _shortsAdunitCode != "0") {
            val jsonEmbedUrl = "${_baseUrl}/a/${_shortsAdunitCode}.json"
            _contentLoader?.getObjectFromJsonUrl<EmbedObject>(jsonEmbedUrl, {
                Logger.d(TAG, "Embed loaded. ${it}")
                println("[ShortsEngine] _loadAdUnit Embed loaded.")
                _shortsAdServicesData = it.adServicesData
                if (!_shortsAdServicesData.isNullOrEmpty()) { // it.adServicesData?.[0]?.playout) {
                    _shortsAdController?.loadContent(_shortsAdServicesData)

                    _checkForAds()
                }
            }, {
                Logger.d(TAG, "Embed failed. ${it}")
                println("[ShortsEngine] _loadAdUnit Embed failed. ${it}")
            })

            // loadIMA()
        }
    }

    private fun _checkForAds () {
        if (_shortsAdServicesData.isNullOrEmpty()) return // bail out

        // If we have consecutively swiped at least interval amount into either direction,
        // load an ad if we have not already inserted one
        //
        // Only do this if there's a valid place left in the content list to insert an ad
        val interval = if (_clipAdInterval > 0) _clipAdInterval else 2 // NB default 2!
        val timeToLoadAd = _swipeAccumulator % interval == 0

        if (!_shortsAdReady) {
            if (timeToLoadAd) {
                _shortsAdController?.play(Phase.MAIN, true) // NB shouldPause = true; effectively a load!
            }
        } else { // ad ready
            if (!_shortsAdSpliced) {
                _findAdLocationAndSplice()
            }
        }
    }

    private fun _findPossibleAdLocation (): Int {
        val contentList = _programController?.getContentList()
        val contentListIndex = _programController?.getContentListIndex()
        if (contentList == null || contentListIndex == null) return -1
        // println("[ShortsEngine] _findPossibleAdLocation contentListIndex: ${contentListIndex}")

        val interval = if (_clipAdInterval > 0) _clipAdInterval else 2 // NB default 2!
        val offset = if (_firstAdPosition > -1) _firstAdPosition else interval // NB default to interval!
        // println("[ShortsEngine] _findPossibleAdLocation interval: ${interval}, offset: ${offset}")

        val step = if (_swipeDirection < 0) -1 else 1 // NB 1 when swipe direction unknown!
        var idx = (contentListIndex - 1) + step
        while (idx >= 0 && idx < contentList.count()) {
            val item = contentList.elementAtOrNull(idx)
            if ((!(item is MediaClip) || (item as MediaClip).mediatype != "mainroll") &&
                (idx % interval) == (offset % interval) && idx >= offset) break
            idx += step
        }
        // println("[ShortsEngine] _findPossibleAdLocation idx: ${idx}")

        // println("[ShortsEngine] _findPossibleAdLocation going to return: ${if (idx >= 0 && idx < contentList.count()) idx else -1}")
        return if (idx >= 0 && idx < contentList.count()) idx else -1
    }

    private fun _preloadClipsWhenReady() {
//		if (_bandwidthMeasured) {
//			_preloadClips()
//		} else {
//			_preloadQueued = true
//			setTimeout(_handleQueuedPreload.bind(this), 250)
//		}
    }

    private fun _handleQueuedPreload() {
//		if (_preloadQueued) {
//			_preloadClips()
//			_preloadQueued = false
//		}
    }

    /**
     * Check where we currently are in a playlist and then figure out which surrounding clips to preload if possible,
     * and start those preloads. If the player is not currently in a playlist we'll try to preload just the current clip.
     */
    private fun _preloadClips() {
//		val clipPlaylistIndex = findIndexForItemId(_clipListItems, _clipData?.id) else -1
//
//		// Always preload the current clip if we can
//		var clipsToPreload = [_clipData]
//
//		// If the clip is in the current playlist, check if we can also
//		// preload the surrounding clips
//		if (clipPlaylistIndex !== -1 && _assetPreloadWindow > 0) {
//			const left = _clipListData.slice(Math.max(clipPlaylistIndex - _assetPreloadWindow - 1, 0), clipPlaylistIndex);
//			// If end exceeds array length the array length is used
//			const right = _clipListData.slice(clipPlaylistIndex + 1, clipPlaylistIndex + _assetPreloadWindow + 1);
//
//			clipsToPreload = clipsToPreload.concat(left, right);
//		}
//
//		const preloadAssetIds = [];
//
//		for (const clip of clipsToPreload) {
//			const assets = clip.assets?.filter(asset => asset.mediatype?.startsWith('FMP4_')).sort(HeadController.sortShortList);
//
//			if (assets?.length && _headController) {
//				// On the very first time preloading, for the start clip, we should select exactly the same asset as the HeadController
//				// to make sure preloads align
//				// After that the HeadController will prefer assets that have already been preloaded, so we can choose different assets here
//				// (picking lower bandwidth ones as the Shorts player has no bandwidth controls)
//				const assetToPreload = _firstPreload && clip.id === _clipData.id ? assets[assets.length - 1] : (assets.filter(asset => parseInt(asset.bandwidth) < 0.8 * _bandwidth).slice(-1)[0] || assets[assets.length - 1]);
//				// Make sure the asset has a processedSrc as we need the fully qualified URL to (pre)load
//				_headController.processAsset(assetToPreload);
//				_mediaBufferManager.preloadAsset(assetToPreload);
//
//				// Mark the ID as one of the clips that should be preloaded
//				preloadAssetIds.push(assetToPreload.id);
//			}
//		}
//
//		// Destroy any preloaded MediaBuffers for assets that we are no longer interested in
//		_mediaBufferManager.unloadOtherAssetMediaBuffers(preloadAssetIds);
//		_firstPreload = false;
    }

    private fun _onBandwidthMeasured(_ev: EventName, payload: Map<String, Any?>?) {
//		if (payload?.measuredBandwidth) {
//			_bandwidth = payload.measuredBandwidth;
//			_bandwidthMeasured = true;
//		}
//
//		_handleQueuedPreload();
    }

    private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
        val playoutData = payload?.get("playoutData") as? Playout
        if (playoutData != null) {
            _ingestPlayoutData(playoutData)
        }
//        if (!payload?.playoutData) return;
//        const assetPreloadWindow = parseInt(payload.playoutData.assetPreloadWindow);
//        if (typeof assetPreloadWindow === 'number' && assetPreloadWindow >= 0) {
//            _assetPreloadWindow = assetPreloadWindow;
//            _preloadClips();
//        }
    }

    private fun _onAdSystemLoaded(_ev: EventName, payload: Map<String, Any?>?) {
        // Can we figure out if the load was a user action?
        val adPosition = if (payload != null && payload["adPosition"] is String) payload["adPosition"] as String else ""
        if (adPosition == "INARTICLE" && !_shortsAdReady) { // one-shot
            _shortsAdReady = true

            // If we found an ad, splice it into the playlist
            // Publish the playlist change?
            Logger.d(TAG, "Ad loaded!")

            _findAdLocationAndSplice()
        }
    }

    private fun _findAdLocationAndSplice () {
        val possibleAdLocation = _findPossibleAdLocation()
        if (possibleAdLocation != -1) {
            // create clip without assets
            val item = MediaClip("shorts_ad_${_shortsId}_${possibleAdLocation}", "advertisement", null, null, null, null, "mainroll") // usetype: "commercial"
            item.isPrefetch = true

            _programController?.spliceIntoContentList(possibleAdLocation, listOf(item))
            _shortsAdSpliced = true
        } else {
            _shortsAdSpliced = false
        }
    }

    private fun _onAdSystemStarted(_ev: EventName, payload: Map<String, Any?>?) {
        if (_shortsAdReady) { // one-shot
            _shortsAdReady = false
        }
    }

    private fun _onAdSystemFinished(_ev: EventName, payload: Map<String, Any?>?) {
        val adPosition = if (payload != null && payload["adPosition"] is String) payload["adPosition"] as String else ""
        if (adPosition == "INARTICLE" && _lastKnownMainrollIndex > -1) {
            _programController?.spliceOutoffContentList(_lastKnownMainrollIndex)
            _shortsAdSpliced = false
            _lastKnownMainrollIndex = -1
        }
    }
}
