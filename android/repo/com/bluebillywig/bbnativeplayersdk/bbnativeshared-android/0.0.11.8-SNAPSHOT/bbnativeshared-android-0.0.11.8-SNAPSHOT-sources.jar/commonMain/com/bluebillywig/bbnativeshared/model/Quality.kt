package com.bluebillywig.bbnativeshared.model

data class Quality (
    var id: String? = null,
    var index: Int? = null,
    var label: String? = null,
    var isSelected: Boolean? = null,
    var mimeType: String? = null,
    var origId: String? = null,
    var bitrate: Int = -1,
    var height: Int = -1
)