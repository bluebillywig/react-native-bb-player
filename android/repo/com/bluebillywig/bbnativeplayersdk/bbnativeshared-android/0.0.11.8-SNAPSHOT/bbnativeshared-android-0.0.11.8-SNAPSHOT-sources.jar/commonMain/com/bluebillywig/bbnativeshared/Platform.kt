package com.bluebillywig.bbnativeshared

/**
 * @suppress
 */
expect class Platform() {
    companion object {
        val platform: String
        val resolution: String
    }
}
