package com.bluebillywig.bbnativeshared.interfaces

import com.bluebillywig.bbnativeshared.enums.PosType

/**
 * @suppress
 */
interface AdControllerInterface {
    fun set(propertyName: String, propertyValue: Any?): Boolean
    fun get(propertyName: String): Any?

    fun loadAdTagUrl(vastUrl: String?, position: PosType = PosType.PREROLL): Boolean

    fun loadAdsResponse(responseXML: String?, position: PosType = PosType.PREROLL): Boolean

    fun play(): Boolean

    fun pause(): Boolean

    fun skipAd()
}