package com.bluebillywig.bbnativeshared

import android.content.res.Resources

/**
 * @suppress
 */
actual class Platform actual constructor() {
    actual companion object {
        actual val platform: String
            get() = "Android ${android.os.Build.VERSION.SDK_INT}"
        actual val resolution: String
            get() = "${Resources.getSystem().getDisplayMetrics().widthPixels}x${Resources.getSystem().getDisplayMetrics().heightPixels}"
    }
}
