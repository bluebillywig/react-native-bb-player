package com.bluebillywig.bbnativeshared.enums

enum class FitMode {
    FIT_SMART,
    FIT_NATIVE,
    FIT_VERTICAL,
    FIT_HORIZONTAL,
    FIT_BOTH,
    FIT_STRETCH,
    FIT_OVERSCAN
}
