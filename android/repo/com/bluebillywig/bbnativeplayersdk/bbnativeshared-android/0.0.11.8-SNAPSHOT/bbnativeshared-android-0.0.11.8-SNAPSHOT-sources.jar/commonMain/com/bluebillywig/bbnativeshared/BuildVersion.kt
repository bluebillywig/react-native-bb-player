package com.bluebillywig.bbnativeshared

object BuildVersion {
    const val versionTag = "release/v8.46-0"
}