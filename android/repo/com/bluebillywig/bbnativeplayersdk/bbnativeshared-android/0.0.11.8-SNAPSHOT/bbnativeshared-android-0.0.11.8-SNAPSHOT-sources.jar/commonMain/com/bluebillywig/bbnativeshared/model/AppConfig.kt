package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AppConfig (
    val id: String? = null,
    val type: String? = null, // Shorts
    val showThumbnails: Boolean? = null,
    val showNextPreviousControls: Boolean? = null,
    val subtype: String? = null,
    val swipeDirection: String? = null,
    val backgroundColor: String? = null,
    val skin_foregroundColor: String? = null,
    val clipAdInterval: Int? = null,
    val firstAdPosition: Int? = null,
    val minuteAdInterval: Int? = null,
    val listThumbnailHeight: Int? = null,
    val listThumbnailResponsiveHeight: Boolean? = null,
    val listThumbnailGap: Int? = null,
    val showThumbnailDuration: Boolean? = null,
    val showThumbnailTitle: Boolean? = null,
    val useThumbnailsInFullscreen: Boolean? = null,
    val thumbnailBackground: Boolean? = null,
    val cornerRadius: Int? = null,
    val adunitId: String? = null,
    val playout: Playout? = null,
    val cliplistid: String? = null,
    val viewedClipBehaviour: String? = null,
    val durationBackgroundColor: String? = null,
    val showOutlineForUnwatchedClips: Boolean? = null,
    val outlineColor: String? = null,
    val showPlayIconInTimestamp: Boolean? = true,
    val shelfMovingThumbnail: Boolean? = null
)
