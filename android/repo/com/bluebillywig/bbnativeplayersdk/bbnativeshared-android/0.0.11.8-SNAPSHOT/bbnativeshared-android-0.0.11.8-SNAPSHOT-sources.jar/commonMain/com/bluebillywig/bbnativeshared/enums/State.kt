package com.bluebillywig.bbnativeshared.enums

enum class State {
    IDLE,
    LOADING,
    PAUSED,
    PLAYING,
    ERROR
}