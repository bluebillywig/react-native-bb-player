package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class Step (
    val id: String? = null,
    val mediaClipId: String? = null,
    val isStart: Boolean? = null,
    var entityType: String? = null,
    var entityId: String? = null
)