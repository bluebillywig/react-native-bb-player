package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class MediaAsset (
    val mediatype: String? = null,
    val id: String? = null,
    val status: String? = null,
    val src: String? = null,
    val length: String? = null,
    val exactlength: String? = null,
    val width: String? = null,
    val height: String? = null,
    val bandwidth: String? = null,
    val jobdefid: String? = null,

    @SerialName("language-id")
    val languageId: String? = null,

    @SerialName("language-name")
    val languageName: String? = null,

    @SerialName("language-isocode")
    val languageIsocode: String? = null,

    val isDefaultLanguage: Boolean? = null,

    var title: String? = null
)