package com.bluebillywig.bbnativeshared.loggers

import com.bluebillywig.bbnativeshared.BuildVersion
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.Platform
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.KMMTimer
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.controller.*

import co.touchlab.stately.ensureNeverFrozen
import com.benasher44.uuid.uuid4
import com.soywiz.krypto.sha1
import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.datetime.Clock
import kotlin.coroutines.CoroutineContext
import kotlin.math.*
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.*

/**
 * @suppress
 */
open class BlueBillywigLogger:
	EventListenerInterface, CoroutineScope {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		// Logger.d(TAG + "onEvent", "GOT EVENT: $eventType")
		when (eventType) {
			EventName.bb_embed_loaded -> {
				val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
			}

			EventName.bb_cliplist_loaded -> {
				_onClipListDataLoaded(eventType, data)
			}
			EventName.bb_project_loaded -> {
				_onProjectDataLoaded(eventType, data)
			}
			EventName.bb_mediaclip_loaded -> {
				_onClipDataLoaded(eventType, data)
			}
			EventName.bb_mediaclip_failed -> {
				_onClipDataFailed(eventType)
			}
			EventName.bb_asset_selected -> {
				_onAssetSelected(eventType, data)
			}

			EventName.bb_view_started -> {
				_onViewStarted(eventType, data)
			}
			EventName.bb_view_finished -> {
				_onViewFinished(eventType)
			}

			EventName.bb_media_started -> {
				_onMediaStarted(eventType)
			}
			EventName.bb_media_finished -> {
				_onMediaFinished(eventType)
			}
			EventName.bb_media_paused -> {
				_onMediaPaused(eventType)
			}
			EventName.bb_media_resumed -> {
				_onMediaResumed(eventType)
			}
			EventName.bb_media_seeked -> {
				_onMediaSeeked(eventType, data)
			}
			EventName.bb_media_duration_change -> {
				_onMediaDurationChange(eventType, data)
			}
			EventName.bb_media_timeupdate -> {
				_onMediaTimeUpdate(eventType, data)
			}
			EventName.bb_master_mute -> { // fake bb_media_volume_change
				_masterMuted = true
				_onMediaVolumeChange(mapOf("masterMuted" to _masterMuted, "muted" to false, "masterVolume" to _masterVolume, "volume" to 1.0))
			}
			EventName.bb_master_unmute -> { // fake bb_media_volume_change
				_masterMuted = false
				_onMediaVolumeChange(mapOf("masterMuted" to _masterMuted, "muted" to false, "masterVolume" to _masterVolume, "volume" to 1.0))
			}
			EventName.bb_master_volume -> { // fake bb_media_volume_change
				_masterVolume = if (data != null && data["volume"] is Double) data["volume"] as Double else 1.0
				_onMediaVolumeChange(mapOf("masterMuted" to _masterMuted, "muted" to false, "masterVolume" to _masterVolume, "volume" to 1.0))
			}

			EventName.bb_media_cast_start -> {
				val castSessionId = if (data != null && data["sessionId"] is String) data["sessionId"] as String else ""
				_logExtensionEvent("xst", castSessionId, "CastSession", _viewId, "View")
			}

			EventName.bb_api_called -> {
				_onApiCalled(data)
			}

			EventName.bb_inview -> {
				_onInView()
			}
			EventName.bb_outview -> {
				_onOutView()
			}
			EventName.bb_fullscreen_change -> {
				_onFullscreenChange(data)
			}

			EventName.bb_adunit_initialized,
			EventName.bb_adunit_failed -> {
				_onAdUnitEvent(eventType, data)
			}
			EventName.bb_adsystem_initialized,
			EventName.bb_adsystem_loadstart,
			EventName.bb_adsystem_blocked,
			EventName.bb_adsystem_canplay,
			EventName.bb_adsystem_started,
			EventName.bb_adsystem_clicked,
			EventName.bb_adsystem_skipped,
			EventName.bb_adsystem_noad,
			EventName.bb_adsystem_failed,
			EventName.bb_adsystem_finished,
			EventName.bb_adsystem_quartile -> {
				_onAdSystemEvent(eventType, data)
			}

			EventName.bb_as_initialized,
			EventName.bb_as_placement_failed,
			EventName.bb_as_loadstart,
			EventName.bb_as_item_blocked,
			EventName.bb_as_item_canplay,
			EventName.bb_as_started,
			EventName.bb_as_ad_clicked,
			EventName.bb_as_item_skipped,
			EventName.bb_as_item_noad,
			EventName.bb_as_item_failed,
			EventName.bb_as_finished,
			EventName.bb_as_ad_quartile -> {
				_onAdSchedulingEvent(eventType, data)
			}

			EventName.bb_widget_shown,
			EventName.bb_widget_clicked,
			EventName.bb_widget_custom_analytics -> {
				_onWidgetEvent(eventType, data)
			}

			EventName.subtitleTracksChanged,
			EventName.subtitleTrackChanged -> {
				_onSubsChanged(eventType, data)
			}
			else -> {}
		}
	}
	// resources
	private var _network: NetworkInterface? = null
	private var _eventBus: EventBusInterface? = eventBus
	private var _progressTimer: KMMTimer? = null
	private var _progressOnceTimer: KMMTimer? = null
	private lateinit var ioDispatcher: CoroutineDispatcher
	private var _customStatistics: CustomStatistics? = null
	private var _rdid: String? = null

	// Proper CoroutineScope implementation with managed lifecycle
	private val job = SupervisorJob()
	override val coroutineContext: CoroutineContext = job + Dispatchers.IO  //use Dispatchers.IO to stay off the main thread

	constructor(eventBus: EventBusInterface?, network: NetworkInterface?) : this(eventBus, network, Dispatchers.IO)

	constructor(eventBus: EventBusInterface?, network: NetworkInterface?, ioDispatcher: CoroutineDispatcher = Dispatchers.IO) {
		println("**** network = ${network}")
		_network = network
		this.eventBus = eventBus
		this.ioDispatcher = ioDispatcher
		_customStatistics = CustomStatistics()
		_customStatistics?.eventBus = _eventBus

		_debouncedEventListMap = mutableMapOf()
		_stopDebouncedEventList = false

		_debouncedEventListMap.put("rs", MutableStateFlow(mutableMapOf()))
		_debouncedEventListMap.put("se", MutableStateFlow(mutableMapOf()))

		_debouncedEventListMap.forEach {
			launch(ioDispatcher) {
				_debouncedEventListMap[it.key]?.collect {
					if (it.isNotEmpty()) {
						_logEvent(it)
					}
					if (_stopDebouncedEventList) {
						currentCoroutineContext().cancel()
					}
				}
			}
		}
	}

	companion object { // this is Kotlin's way to support static class methods; don't ask...
		val TAG = "BlueBillywigLogger:"
		//private val client = HttpClient()

		private fun _simplifyAmt (mediatype: String?): String {
			if (mediatype != null) {
				if (mediatype.startsWith("MP4_HLS") == true) return "HLS"
				if (mediatype.startsWith("MP4") == true || mediatype.startsWith("FMP4") == true) return "MP4"
			}

			return mediatype ?: ""
		}

		/**
		 * Quantize bitrate
		 * @param {number} kbitrate input value
		 * @returns {number} quantized kbitrate
		 */
		private fun _quantizeBitrate(kbitrate: Double): Double {
			return max(250.0, (2.0).pow(round(log(kbitrate / 500.0, 2.0) / log(2.0, 2.0))) * 500.0); // 250, 500, 1000, 2000, 4000, 8000, 16000
			// bin boundaries: 353.5 707.1, 1414.2, 2828.4, 5656.8, 11313.7
		}

		// JSON parsing utility methods for custom fields
		fun getFromJsonObject(path: String, obj: JsonObject): Any? {
			val rex = """^/[^/]*""".toRegex()
			val result = rex.find(path)
			if (result != null) {
				val key = result.value.replace("/", "")
				try {
					val value = obj[key]
					val newPath = path.replace(rex, "")
					if (newPath.isNotEmpty()) { // recursion condition
						return when (value) {
							is JsonArray -> getFromJsonArray(newPath, value)
							is JsonObject -> getFromJsonObject(newPath, value)
							else -> null
						}
					} else { // recursion stop condition
						return when (value) {
							is JsonPrimitive -> {
								when {
									value.isString -> value.content
									value.booleanOrNull != null -> value.boolean
									value.doubleOrNull != null -> value.double
									value.longOrNull != null -> value.long
									value.intOrNull != null -> value.int
									else -> value.contentOrNull
								}
							}
							is JsonArray, is JsonObject -> value
							else -> null
						}
					}
				} catch (_: Exception) { }
			}
			return null
		}

		fun getFromJsonArray(path: String, arr: JsonArray): Any? {
			val rex = """^/[^/]*""".toRegex()
			val result = rex.find(path)
			if (result != null) {
				val key = result.value.replace("/", "")
				var idx = key.toIntOrNull() ?: -1
				if (key.contains(":")) {
					val parts = ":".toRegex().split(key, 2)
					idx = 0
					while (idx < arr.size) {
						try {
							val item = arr[idx]
							if (item is JsonObject) {
								if ("" == parts[0] && item["id"]?.jsonPrimitive?.content == parts[1]) break
								if (item["type"]?.jsonPrimitive?.content == parts[0] && "" == parts[1]) break
								if (item["type"]?.jsonPrimitive?.content == parts[0] && item["id"]?.jsonPrimitive?.content == parts[1]) break
							}
						} catch (_: Exception) { }
						idx++
					}
				}
				try {
					val value = arr.getOrNull(idx)
					val newPath = path.replace(rex, "")
					if (newPath.isNotEmpty()) { // recursion condition
						return when (value) {
							is JsonArray -> getFromJsonArray(newPath, value)
							is JsonObject -> getFromJsonObject(newPath, value)
							else -> null
						}
					} else { // recursion stop condition
						return when (value) {
							is JsonPrimitive -> {
								when {
									value.isString -> value.content
									value.booleanOrNull != null -> value.boolean
									value.doubleOrNull != null -> value.double
									value.longOrNull != null -> value.long
									value.intOrNull != null -> value.int
									else -> value.contentOrNull
								}
							}
							is JsonArray, is JsonObject -> value
							else -> null
						}
					}
				} catch (_: Exception) { }
			}
			return null
		}
	}

	// settings
	private var _playoutName: String = "default"
	private var _playoutPublicationName: String = "default"
	private var _disableCookies: String = "false"
	private var _logProgressAsQuartiles: Boolean = false
	private var _autoPlay: Boolean = false
	private var _autoMute: Boolean = false
	private var _autoLoop: Boolean = false
	private val _uuid = uuid4().toString()
	private var _playMode = "native"
	private var _commercialPlayMode = "native"
	private val _loggerUrl = "https://stats.bluebillywig.com"
	private var _noStats_content: Boolean = false
	private var _noStats_commercial: Boolean = false
	private var _doLogAdRequestUrl: Boolean = false

	// state
	private var _initialized: Boolean = false
	private var _enabled: Boolean = false
	protected var _enabledQueue: MutableList<MutableMap<String, String>> = mutableListOf()
	private var _playerSessionId: String = _generateSessionId()
	private var _playerSessionStartLogged: Boolean = false
	private var _sessionId = _generateSessionId()
	private var _adScheduleCode: String? = null
	private var _adScheduleItemCode: String? = null
	private var _creativeId: String? = null
	private var _referrer: String = "in-app"
	private var _realReferrer: String = "in-app"
	private var _fullScreen: Boolean = false
	private var _viewId: String? = null
	private var _prevViewId: String? = null
	private var _prevClipId: String? = null
	private var _paused: Boolean = false
	private var _startedClipId: String? = null // for detecting replay
	private var _isReplay: Boolean = false
	private var _projectXSTLogged: Boolean = false
	private var _timelineXSTLoggedMap: MutableMap<String, Boolean> = mutableMapOf()
	private var _currentTime: Double = 0.0
	private var _timeOffset: Long = 0
	private var _serialNumber = 0
	private var _timestampOffset = 0
	private var _to: Long = 0
	private var _to_now: Long = 0
	private var _to_num: Long = 0
	private var _quartile: Int = -1
	private var _isInView: Boolean = false
	private var _adUnitLoggedXiv: Boolean = false
	private var _adUnitLoggedXov: Boolean = false
	private var _adScheduleLoggedXiv: Boolean = false
	private var _adScheduleLoggedXov: Boolean = false
	private var _adScheduleLoggedXst: Boolean = false
	private var _adScheduleItemCodeLoggedXit: String? = null
	private var _lineItemLoggedXld: Boolean = false
	private var _lineItemLoggedXst: Boolean = false
	private var _creativeLoggedXit: Boolean = false
	private var _creativeLoggedXit_pi: Int? = null // pod index
	private var _cuePointTuples: MutableMap<String, MutableList<Pair<String, String>>> = mutableMapOf()
	private var _adSystemStarted: Boolean = false
	private var _adScheduleItemStarted: Boolean = false
	private var _masterVolume: Double = 1.0
	private var _masterMuted: Boolean = false
	private var _listIdsByLevel: MutableList<String> = mutableListOf()
	private var _maxLevel: Int = -1
	private var _contextEntityType: String? = null
	private var _contextEntityId: String? = null

	// data
	private var _clip: MediaClip? = null
	private var _clip_isInitial: Boolean = true
	private var _publicationCustomFields: CustomFields? = null
	private var _dvid: String? = null
	private var _projectId: String? = null
	private var _duration: Double = 0.0
	private var _asset: MediaAsset? = null
	private var _assetBandwidth: String? = null
	private var _adUnitAdPosition: String? = null
	private var _adScheduleAdPosition: String? = "vmap"
	private var _adUnitCode: String? = null
	private var _lineItemCode: String? = null
	private var _adProperties: Map<String, Any?>? = null
	private var _subtitles: List<Subtitle>? = null
	private var _cfl: MutableMap<String, Any>? = null

	private var _stopDebouncedEventList: Boolean
	protected var _debouncedEventListMap: MutableMap<String, MutableStateFlow<MutableMap<String,String>>>

	init {
		ensureNeverFrozen() // NB!?!
		_eventBus?.addEventlistener(this)
	}

	fun __destruct() {
		_stopDebouncedEventList = true
		_debouncedEventListMap.forEach {
			it.value.tryEmit(mutableMapOf())
		}
		_debouncedEventListMap.clear()
		_eventBus?.removeEventlistener(this)
		_eventBus = null
		_progressTimer?.cancel()
		_progressTimer = null
		_progressOnceTimer?.cancel()
		_progressOnceTimer = null
		// Cancel all coroutines to prevent crashes
		job.cancel()
		_customStatistics?.__destruct()
		_customStatistics = null
		_network?.__destruct()
		_network = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this)

			_customStatistics?.eventBus = _eventBus
		}

	fun enable() {
		_enabled = true
		while (_enabledQueue.count() > 0) {
			val item = _enabledQueue.removeAt(0)// NB! was removeFirst() but changed because of issue with SDK35: No interface method removeFirst()Ljava/lang/Object; in class Ljava/util/List; or its super classes (declaration of 'java.util.List' appears in /apex/com.android.art/javalib/core-oj.jar)
			_logEvent_enabled(item)
		}
	}

	fun disable() {
		_enabled = false
	}

	fun handleAutoPause() {
		var i = 0
		while (i < _enabledQueue.count()) {
			val item = _enabledQueue[i]
			if (item["et"] == "Session" ||
				item["ev"] == "it" ||
				item["ev"] == "pf" ||
				item["ev"] == "pw" ||
				item["et"] == "Creative" ||
				item["et"] == "AdUnit" ||
				item["et"] == "LineItem" ||
				item["et"] == "AdSchedule" ||
				item["et"] == "AdScheduleItem") {
				_enabledQueue.removeAt(i) // NB no need to increment i!
				_logEvent_enabled(item)
			} else {
				i++
			}
		}
	}

	private fun _generateSessionId(): String {
		val _uuid = _uuid
		val clipId = _clip?.id ?: "0"
		val now = Clock.System.now().toEpochMilliseconds().toString()
		val hash = (_uuid + '/' + clipId + '/' + now).encodeToByteArray().sha1().hex

		return hash
	}

	private fun _constructCreativeId(type: String, position: String, url: String): String {
		val hash = (type + '/' + position + '/' + url).encodeToByteArray().sha1().hex

		return hash;
	}

	private fun _onClipListDataLoaded (eventType: EventName, payload: Map<String, Any?>?) {
		var maxLevel = _maxLevel
		_maxLevel = ((payload?.get("nestingLevel") as? String)?.toInt() ?: 0) - 1

		while (_maxLevel > maxLevel) {
			_listIdsByLevel.add(0, "") // _listIdsByLevel.unshift("")
			maxLevel++
		}
		while (_maxLevel < maxLevel) {
			_listIdsByLevel.removeAt(0) // _listIdsByLevel.shift()
			maxLevel--
		}
		// always
		if (_maxLevel >= 0) {
			_listIdsByLevel[0] = payload?.get("clipListId") as? String ?: ""
		}
	}

	private fun _onProjectDataLoaded(eventType: EventName, payload: Map<String, Any?>?) {
		// always reset vars (project xst start logging)
		_projectXSTLogged = false
		_projectId = null

		_sessionId = _generateSessionId()
		_serialNumber = 0

		if (_clip != null && !_clip_isInitial) _prevClipId = _clip?.id

		_timelineXSTLoggedMap.clear()
		_currentTime = 0.0
		_timeOffset = 0
		_quartile = -1 // NB!
		_cfl = null

		val contextCollectionType = payload?.get("contextCollectionType") as? String
		val contextCollectionId = payload?.get("contextCollectionId") as? String
		if (contextCollectionType == "MediaClipList") {
			_listIdsByLevel[1] = contextCollectionId ?: ""
			_maxLevel = 1.coerceAtLeast(_maxLevel)
		} else {
			var maxLevel = _maxLevel;
			_maxLevel = 0.coerceAtMost(_maxLevel)
			while (_maxLevel < maxLevel) {
				_listIdsByLevel.removeAt(0)
				maxLevel--
			}
		}
		_contextEntityType = payload?.get("contextEntityType") as? String
		_contextEntityId = payload?.get("contextEntityId") as? String

		if (payload != null && payload["projectData"] != null) {
			_projectId = (payload["projectData"] as Project).id

			val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true; serializersModule = contentItemSerializersModule }
			_clip = jsonParser.decodeFromString<MediaClip>("{\"id\":\"\", \"title\":\"<unknown>\", \"projectId\":\""+_projectId+"\", \"date\":{\"published\":\"<unknown>\"}}")
			_clip_isInitial = false // ?!?

			_determineReferrer()
			var aux = mutableMapOf("xu" to _referrer, "xr" to _realReferrer, "pt" to _playoutName)
			aux["aup"] = if (_autoPlay) "1" else "0"
			aux["aum"] = if (_autoMute) "1" else "0"
			aux["aul"] = if (_autoLoop) "1" else "0"
			if (!_playerSessionStartLogged) {
				_playerSessionStartLogged = true
				_logExtensionEvent("xst", _playerSessionId, "Session", null, null, aux) // no parent
			}
			_logExtensionEvent("xit", _projectId ?: "0", "Project", _playerSessionId, "Session", aux)
		}
	}

	// OBSOLETE; FOR TESTING ONLY
	fun onClipDataLoaded(eventType: EventName, payload: Map<String, Any?>?) {
		_onClipDataLoaded(eventType, payload)
	}

	private fun _onClipDataLoaded(eventType: EventName, payload: Map<String, Any?>?) {
		_sessionId = _generateSessionId()
		_serialNumber = 0

		if (_clip != null && !_clip_isInitial) _prevClipId = _clip?.id

		_timelineXSTLoggedMap.clear()
		_currentTime = 0.0
		_timeOffset = 0
		_quartile = -1 // NB!
		_cfl = null

		val contextCollectionType = payload?.get("contextCollectionType") as? String
		val contextCollectionId = payload?.get("contextCollectionId") as? String
		if (contextCollectionType == "MediaClipList") {
			_listIdsByLevel[1] = contextCollectionId ?: ""
			_maxLevel = 1.coerceAtLeast(_maxLevel)
		} else {
			var maxLevel = _maxLevel;
			_maxLevel = 0.coerceAtMost(_maxLevel)
			while (_maxLevel < maxLevel) {
				_listIdsByLevel.removeAt(0)
				maxLevel--
			}
		}
		_contextEntityType = payload?.get("contextEntityType") as? String
		_contextEntityId = payload?.get("contextEntityId") as? String

		if (payload != null && payload["clipData"] != null) {
			_clip = payload["clipData"] as MediaClip
			_clip_isInitial = false
			if (_projectId != null) _clip?.projectId = _projectId // NB override, since 'loadedprojectdata' always precedes 'loadedclipdata'!

			_determineReferrer()
			var aux = mutableMapOf("xu" to _referrer, "xr" to _realReferrer, "pt" to _playoutName)
			aux["aup"] = if (_autoPlay) "1" else "0"
			aux["aum"] = if (_autoMute) "1" else "0"
			aux["aul"] = if (_autoLoop) "1" else "0"
			if (!_playerSessionStartLogged) {
				_playerSessionStartLogged = true
				//console.log("[BlueBillywigStatisticsLogger] _onViewStarted going to log xst for session: " + _playerSessionId);
				_logExtensionEvent("xst", _playerSessionId, "Session", null, null, aux)
			}

			val usetype = _clip?.usetype
			if (usetype != null) aux["ut"] = usetype

			val subtitles = _clip?.subtitles ?: _clip?.subtitletracks // the latter if the item comes from Solr...
			if (subtitles != null && subtitles.count() > 0) {
				aux["sls"] = (subtitles.map { it?.isocode }).joinToString(",") // subtitle languages string
			}

			var clipAspectRatio = -1.0 // unknown
			if ((_clip?.width ?: -1L) > 0 && (_clip?.height ?: -1L) > 0) {
				clipAspectRatio = (_clip?.width ?: -1L).toDouble() / (_clip?.height ?: -1L)
			} else if ((_clip?.originalWidth ?: -1L) > 0 && (_clip?.originalHeight ?: -1L) > 0) {
				clipAspectRatio = (_clip?.originalWidth ?: -1L).toDouble() / (_clip?.originalHeight ?: -1L)
			}
			aux["car"] = (kotlin.math.round(clipAspectRatio * 1000) / 1000).toString().removeSuffix(".0") // max three decimals

			// custom fields with includeInStats logging
			val csf = _constructCustomFieldLogging(_clip)
			if (csf != null) {
				try {
					aux["csf"] = Json.encodeToString(JsonObject.serializer(), JsonObject(csf.mapValues { (_, value) ->
						when (value) {
							is String -> JsonPrimitive(value)
							is Number -> JsonPrimitive(value)
							is Boolean -> JsonPrimitive(value)
							else -> JsonPrimitive(value.toString())
						}
					}))
				} catch (_: Exception) { }
			}

			_logMediaClipEvent("it", aux)
		} else {
			_clip = null
			_logErrorEvent("pf", mapOf("why" to "clip failed to open"))
		}

		_progressTimer?.cancel()
	}

	private fun _onClipDataFailed(eventType: EventName) {
		_onClipDataLoaded(eventType, null)
	}

	private fun _onAssetSelected(eventType: EventName, payload: Map<String, Any?>?) {
		if (payload != null && payload["asset"] != null) {
			val prevAssetLanguageId = _asset?.languageId
			val prevAssetMediatype = _asset?.mediatype
			val prevAssetTitle = _asset?.title

			_asset = payload["asset"] as MediaAsset

			val viewId = _viewId
			if (viewId != null) { // view started
				val aux: MutableMap<String, String> = mutableMapOf()
				val languageId = _asset?.languageId
				val languageIsocode = _asset?.languageIsocode
				if (languageId != null && languageIsocode != null && languageId !== prevAssetLanguageId) {
					aux["ali"] = languageId
					aux["alc"] = languageIsocode
				}
				val mediatype = _asset?.mediatype
				if (mediatype != null && mediatype != prevAssetMediatype) {
					aux["amt"] = BlueBillywigLogger._simplifyAmt(mediatype) // asset media type
				}
				val title = _asset?.title
				if (title != null && title != prevAssetTitle) {
					aux["aql"] = title // asset quality label
				}
				if (aux.size > 0) {
					_logExtensionEvent("xpc", viewId, "View", _playerSessionId, "Session", aux)
				}
			}
		} else {
			_asset = null
			_logErrorEvent("pf", mapOf("why" to "no playable media"))
		}
	}

	private fun _onViewStarted(eventType: EventName, payload: Map<String, Any?>?) {
		Logger.d(TAG + "_onViewStarted", eventType.toString())

		_determineReferrer()

		// hackje: just-in-time session init
		if (!_playerSessionStartLogged) {
			_playerSessionStartLogged = true
			var aux2 = mutableMapOf("xu" to _referrer, "xr" to _realReferrer, "pt" to _playoutName)
			aux2["aup"] = if (_autoPlay) "1" else "0"
			aux2["aum"] = if (_autoMute) "1" else "0"
			aux2["aul"] = if (_autoLoop) "1" else "0"
			_logExtensionEvent("xst", _playerSessionId, "Session", null, null, aux2)
		}

		if (_viewId != null) _onViewFinished(eventType) // just to be sure
		_viewId = _generateSessionId() // mwah

		// Log xst for project (only once per project, see _onProjectDataLoaded)
		if ( !_projectXSTLogged && _projectId != null ) {
			_logExtensionEvent("xst", "$_projectId", "Project", _viewId, "View")
			_projectXSTLogged = true
		}

		var aux = mutableMapOf("fs" to (if (_fullScreen) "1" else "0"), "xu" to _referrer, "xr" to _realReferrer, "pt" to _playoutName)
		if (payload != null && payload.containsKey("initiator") && payload["initiator"] is String) {
			val initiator_parts = (payload["initiator"] as String).split("/")
			if (initiator_parts.count() > 0) aux["iet"] = initiator_parts[0]
			if (initiator_parts.count() > 1) aux["iid"] = initiator_parts[1]
			if (_prevViewId != null) aux["pvid"] = "$_prevViewId"
			if (_prevClipId != null) aux["pcid"] = "$_prevClipId"
		}
		if (_asset != null) {
			if (_asset?.languageId != null) {
				aux["ali"] = "${_asset?.languageId}" // asset language id
			}
			if (_asset?.languageIsocode != null) {
				aux["alc"] = "${_asset?.languageIsocode}" // asset language code
			}
			if (_asset?.mediatype != null) {
				aux["amt"] = BlueBillywigLogger._simplifyAmt(_asset?.mediatype) // asset media type
			}
		}
		if (_clip?.usetype != null) aux["ut"] = "${_clip?.usetype}"
		//console.log("[BlueBillywigStatisticsLogger] _onViewStarted going to log xst for view: " + _viewId)
		_logExtensionEvent("xst", _viewId ?: "null", "View", _playerSessionId, "Session", aux )
	}

	private fun _onViewFinished(eventType: EventName) {
		Logger.d(TAG + "_onViewFinished", eventType.toString())

		_progressTimer?.cancel()

		_logExtensionEvent("xfn", _viewId ?: "null", "View", _playerSessionId, "Session", mapOf("fs" to (if (_fullScreen) "1" else "0")) )
		_prevViewId = _viewId
		_viewId = null
	}

	private fun _onMediaStarted(eventType: EventName) {
		Logger.d(TAG + "_onMediaStarted", eventType.toString())
		_paused = false
		_isReplay = false
		if (_clip?.id == _startedClipId) { // replay
			_logMediaClipEvent("rp", mapOf("to" to "0"))
			_isReplay = true
		}
		if (_clip != null) _startedClipId = _clip?.id

		var clipAspectRatio = -1.0 // unknown
		if ((_clip?.width ?: -1L) > 0 && (_clip?.height ?: -1L) > 0) {
			clipAspectRatio = (_clip?.width ?: -1L).toDouble() / (_clip?.height ?: -1L)
		} else if ((_clip?.originalWidth ?: -1L) > 0 && (_clip?.originalHeight ?: -1L) > 0) {
			clipAspectRatio = (_clip?.originalWidth ?: -1L).toDouble() / (_clip?.originalHeight ?: -1L)
		}
		val car = (kotlin.math.round(clipAspectRatio * 1000) / 1000).toString().removeSuffix(".0") // max three decimals

		val amt = BlueBillywigLogger._simplifyAmt(_asset?.mediatype)
		// Stats expects a number for bandwidth
		if (_asset?.bandwidth?.toIntOrNull() != null) {
			val ab = BlueBillywigLogger._quantizeBitrate(_asset?.bandwidth?.toDoubleOrNull() ?: 0.0)
			_logMediaClipEvent("st", mapOf("to" to "0", "car" to car, "amt" to amt, "ab" to "$ab"))
		} else if (_assetBandwidth?.toIntOrNull() != null) { // if the "normal" bandwidth is not defined, check if the creative bandwidth is set.
			val ab = BlueBillywigLogger._quantizeBitrate(_assetBandwidth?.toDoubleOrNull() ?: 0.0)
			_logMediaClipEvent("st", mapOf("to" to "0", "car" to car, "amt" to amt, "ab" to "$ab"))
		} else {
			_logMediaClipEvent("st", mapOf("to" to "0", "car" to car, "amt" to amt))
		}

		_progressTimer?.cancel()
		val interval = _determineProgressInterval() // in seconds
		// always log one progress event after 2 seconds
		if (interval > 2) {
			_progressOnceTimer?.cancel()
			_progressOnceTimer = KMMTimer("ProgressOnceTimer", 2000, 2000, { _progressOnceTimer?.cancel(); _handleProgressTimerTick() }) // new
			_progressOnceTimer?.start()
		}
		_progressTimer = KMMTimer("ProgressTimer", (interval * 1000).toLong(), (interval * 1000).toLong(), { _handleProgressTimerTick() }) // new
		_progressTimer?.start()

		//Log xst for project (only once per project, see _onProjectDataLoaded)
		if (!_projectXSTLogged && _projectId != null) {
			_logExtensionEvent("xst", "$_projectId", "Project", _viewId, "View")
			_projectXSTLogged = true
		}
	}

	private fun _onMediaFinished(eventType: EventName) {
		if (_logProgressAsQuartiles) {
			val wpa: String = if (_paused) "true" else "false"
			val quartile = 4
			while (_quartile < quartile) { // NB ensure all previous quartiles are also hit!
				_quartile++
				val pct: String = (_quartile * 25).toString()
				_logMediaClipEvent("pg", mapOf("pct" to pct, "pet" to "Session", "pid" to _playerSessionId, "wpa" to wpa))
			}
		}

		_logMediaClipEvent("fn", mapOf("to" to _getTimeOffset().toString()))

		_progressTimer?.cancel()
	}

	private fun _onMediaPaused(eventType: EventName) {
		_paused = true
		_logMediaClipEvent("pa", mapOf("to" to _getTimeOffset().toString()))

		_progressTimer?.cancel()
		val interval = 60.0 // in seconds
		_progressTimer = KMMTimer("ProgressTimer", (interval * 1000).toLong(), (interval * 1000).toLong(), { _handleProgressTimerTick() })
		_progressTimer?.start()
	}

	private fun _onMediaResumed(eventType: EventName) {
		_paused = false
		_logMediaClipEvent("rs", mapOf("to" to _getTimeOffset().toString()))

		_progressTimer?.cancel()
		val interval = _determineProgressInterval() // in seconds
		_progressTimer = KMMTimer("ProgressTimer", (interval * 1000).toLong(), (interval * 1000).toLong(), { _handleProgressTimerTick() })
		_progressTimer?.start()
	}

	private fun _onMediaSeeked(eventType: EventName, payload: Map<String, Any?>?) {
		if (payload != null && payload["seekOffset"] is String) {
			val seekOffset = (payload["seekOffset"] as String).toDoubleOrNull()
			if (seekOffset != null && seekOffset >= 0.0) { // numeric and non-negative
				_currentTime = seekOffset
				if (_duration > 0.0 && _currentTime > _duration) _currentTime = _duration
				_timeOffset = (_currentTime * 1000).roundToLong() // NB!
			}
		}

		_logMediaClipEvent("se", mapOf("to" to _getTimeOffset().toString()))
	}

	private fun _onMediaDurationChange(eventType: EventName, payload: Map<String, Any?>?) {
		if (payload != null && payload["duration"] != null) {
			val duration = (payload["duration"] as Double)
			if (duration != null && duration >= 0.0) { // numeric and non-negative
				_duration = duration
			}
		}
	}

	private fun _onMediaTimeUpdate(eventType: EventName, payload: Map<String, Any?>?) {
		if (payload != null && payload["currentTime"] != null) {
			val currentTime = (payload["currentTime"] as String).toDoubleOrNull()
			if (currentTime != null && currentTime >= 0.0) { // numeric and non-negative
				_currentTime = currentTime
				if (_duration > 0.0 && _currentTime > _duration) _currentTime = _duration
				_timeOffset = (_currentTime * 1000).roundToLong() // NB!
			}
		}

		// NB no logging here; done by progressTimer!
	}

	private fun _onMediaVolumeChange (payload: Map<String, Any?>?) {
		if (payload != null &&
			payload["masterVolume"] is Float && payload["masterMuted"] is Boolean &&
			payload["volume"] is Float && payload["muted"] is Boolean // exclude special cases that only carry master values
		) {
			val mediaVolume = payload["masterVolume"] as Float * payload["volume"] as Float
			val mediaMuted = if (payload["masterMuted"] as Boolean || payload["muted"] as Boolean) "true" else "false"

			val aux = mapOf("mv" to mediaVolume.toString(), "mm" to mediaMuted)
			_logExtensionEvent("xpc", "$_viewId", "View", _playerSessionId, "Session", aux)
		}
	}

	private fun _onApiCalled (payload: Map<String, Any?>?) {
		if (payload != null) {
			val aux: MutableMap<String, String> = mutableMapOf()
			val userAction = if (payload["userAction"] is Boolean) payload["userAction"] as Boolean else false
			val method = if (payload["method"] is String) payload["method"] as String else ""
			when (method) {
				"setMuted" -> {
					val muted = if (payload["muted"] is Boolean) payload["muted"] as Boolean else false
					if (userAction) {
						aux["api"] = if (muted) "mute_ua" else "unmute_ua"
					} else { // non-user action
						aux["api"] = if (muted) "mute" else "unmute"
					}
				}
				"setAsset" -> {
					aux["api"] = method;
					aux["ap0"] = if (payload["quality"] is String) payload["quality"] as String else "unknown"
				}
				"seek_relative" -> {
					aux["api"] = method;
					aux["ap0"] = if (payload["offsetInSeconds"] is Number) "${payload["offsetInSeconds"] as Number }" else "unknown"
				}
				"shortsNext", "shortsPrev" -> {
					aux["api"] = method;
					aux["ap0"] = if (payload["from"] is String) payload["from"] as String else "unknown"
					aux["ap1"] = if (payload["to"] is String) payload["to"] as String else "unknown"
				}
				else -> {
					aux["api"] = method
				}
			}
			if (_viewId != null || _playerSessionId != "") { // view or player session started
				_logExtensionEvent("xac", "$_viewId", "View", _playerSessionId, "Session", aux)
			}
			if (_adSystemStarted && _creativeId != null) { // creative started
				_logExtensionEvent("xac", "$_creativeId", "Creative", _viewId, "View", aux)
			}
		}
	}

	private fun _handleAdUnitInOutView() {
		val aux: MutableMap<String, String> = mutableMapOf()
		if (_adUnitAdPosition != null) aux["ap"] = "$_adUnitAdPosition"

		if (_adUnitCode != null) {
			if (_isInView) { // InView
				if (!_adUnitLoggedXiv) {
					_adUnitLoggedXiv = true;
					_logExtensionEvent("xiv", "$_adUnitCode", "AdUnit", _viewId, "View", aux);
				}
			} else { // OutView
				if (!_adUnitLoggedXov) {
					_adUnitLoggedXov = true;
					_logExtensionEvent("xov", "$_adUnitCode", "AdUnit", _viewId, "View", aux);
				}
			}
		}
	}

	private fun _handleAdScheduleInOutView() {
		val aux: MutableMap<String, String> = mutableMapOf()
		if (_adScheduleAdPosition != null) aux["ap"] = "$_adScheduleAdPosition"

		if (_adScheduleCode != null) {
			if (_isInView) { // InView
				if (!_adScheduleLoggedXiv) {
					_adScheduleLoggedXiv = true;
					_logExtensionEvent( "xiv", "$_adScheduleCode", "AdSchedule", _viewId, "View", aux)
				}
			} else { // OutView
				if (!_adScheduleLoggedXov) {
					_adScheduleLoggedXov = true;
					_logExtensionEvent( "xov", "$_adScheduleCode", "AdSchedule", _viewId, "View", aux)
				}
			}
		}
	}

	private fun _onInView() {
		_isInView = true
		_handleAdUnitInOutView()
		_handleAdScheduleInOutView()
	}

	private fun _onOutView() {
		_isInView = false
		_handleAdUnitInOutView()
		_handleAdScheduleInOutView()
	}

	private fun _onFullscreenChange(payload: Map<String, Any?>?) {
		if (payload != null && payload["fullscreen"] is Boolean) {
			_fullScreen = payload["fullscreen"] as Boolean

			val aux = mapOf("fs" to (if (_fullScreen) "1" else "0"))
			_logExtensionEvent("xpc", "$_viewId", "View", _playerSessionId, "Session", aux)
		}
	}

	private fun _onAdUnitEvent(eventType: EventName, payload: Map<String, Any?>?) {
		val params: Map<String, Any?> = if (payload != null) payload else mapOf()

		val adPosition = params["adPosition"] as String?
		if (!adPosition.isNullOrEmpty()) _adUnitAdPosition = adPosition.toLowerCase()

		val aux: MutableMap<String, String> = mutableMapOf()
		if (_adUnitAdPosition != null) aux["ap"] = "$_adUnitAdPosition"

		when (eventType) {
			EventName.bb_adunit_initialized -> {
				_creativeId = null // NB?!?
				_adUnitLoggedXiv = false;
				_adUnitLoggedXov = false;

				_adUnitCode = params["adUnitCode"] as String?
				if (_adUnitCode != null) {
					_logExtensionEvent( "xit", "$_adUnitCode", "AdUnit", _viewId, "View", aux.toMap());
				}
				_handleAdUnitInOutView()
			}
			EventName.bb_adunit_failed -> {
				_creativeId = null // NB?!?
				_adUnitCode = params["adUnitCode"] as String?
				if (_adUnitCode != null) {
					_logExtensionEvent( "xpf", "$_adUnitCode", "AdUnit", _viewId, "View", aux.toMap());
				}
				_handleAdUnitInOutView()
			}
			else -> {}
		}
	}

	private fun _onAdSystemEvent(eventType: EventName, payload: Map<String, Any?>?) {
		val params: Map<String, Any?> = if (payload != null) payload else mapOf()

		val aux: MutableMap<String, String> = mutableMapOf(
			"at" to (params["adType"] as String? ?: ""),
			"ap" to (params["adPosition"] as String? ?: "").toLowerCase()
		)
		if (_doLogAdRequestUrl) aux["ar"] = (params["adRequestUrl"] as String? ?: "")

		when (eventType) {
			EventName.bb_adsystem_initialized -> {
				_adProperties = null

				_lineItemLoggedXld = false
				_lineItemLoggedXst = false
				_creativeLoggedXit = false
				_creativeLoggedXit_pi = null
				_cuePointTuples = mutableMapOf()

				// LineItem xit
				_lineItemCode = params["lineItemCode"] as? String // required
				if (_adUnitCode != null && _lineItemCode != null) {
					_logExtensionEvent("xit", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", aux.toMap());
				}

				// Creative xit
				// nothing; logged later in _onAdSystemCanPlay
			}
			EventName.bb_adsystem_loadstart -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties // thread-safe
				if (adProperties != null) {
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				// LineItem xls
				if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
				if (_adUnitCode != null && _lineItemCode != null) {
					_logExtensionEvent("xls", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", aux.toMap());
				}

				// Creative xls
				// nothing; logged later in _onAdSystemCanPlay
			}
			EventName.bb_adsystem_blocked -> {}
			EventName.bb_adsystem_canplay -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties // thread-safe
				if (adProperties != null) {
					aux["adi"] = adProperties["adId"] as String? ?: ""
					aux["adt"] = adProperties["adTitle"] as String? ?: ""
					aux["ads"] = adProperties["adSystem"] as String? ?: ""
					aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					aux["add"] = "${adProperties["duration"]}"
					aux["sdk"] = adProperties["sdk"] as String? ?: ""

					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						aux["adp_ap"] = (adPodInfo["adPosition"] as Int? ?: 0).toString()
						aux["adp_ib"] = if (adPodInfo["isBumper"] == true) "true" else "false"
						aux["adp_md"] = (adPodInfo["maxDuration"] as Double? ?: 0.0).toString()
						aux["adp_pi"] = (adPodInfo["podIndex"] as Int? ?: 0).toString()
						aux["adp_to"] = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
						aux["adp_ta"] = (adPodInfo["totalAds"] as Int? ?: 0).toString()
					}
				}

				// LineItem xld + xst
				if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
				if (_adUnitCode != null && _lineItemCode != null) {
					val lineItemAux: MutableMap<String, String> = mutableMapOf(
						"at" to (params["adType"] as String? ?: ""),
						"ap" to (params["adPosition"] as String? ?: "").toLowerCase()
					)
					if (_doLogAdRequestUrl) aux["ar"] = (params["adRequestUrl"] as String? ?: "")
					if (adProperties != null) {
						lineItemAux["sdk"] = adProperties["sdk"] as String? ?: ""
					}
					if (!_lineItemLoggedXld) {
						_lineItemLoggedXld = true;
						_logExtensionEvent("xld", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux.toMap());
					}
					if (!_lineItemLoggedXst) {
						_lineItemLoggedXst = true;
						_logExtensionEvent("xst", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux.toMap());
					}
				}

				// Creative xit
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						if (_creativeLoggedXit_pi != adPodInfo["podIndex"]) { // once per pod
							_creativeLoggedXit_pi = adPodInfo["podIndex"] as Int?

							val isBumper = if (adPodInfo["isBumper"] == true) "true" else "false"
							val maxDuration = (adPodInfo["maxDuration"] as Double? ?: 0.0).toString()
							val podIndex = (adPodInfo["podIndex"] as Int? ?: 0).toString()
							val timeOffset = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
							val totalAds = adPodInfo["totalAds"] as Int? ?: 0
							for (adPosition_int in 1..totalAds) {
								val adPosition = "$adPosition_int"
								val creativeId = _constructCreativeId(adPosition, timeOffset, _lineItemCode ?: "") // NB!
								val vastId = if (adPodInfo["adPosition"] as Int? == adPosition_int) aux["vastid"] else "" // NB!
								if (_cuePointTuples["#"+timeOffset] == null) _cuePointTuples["#"+timeOffset] = mutableListOf()
								_cuePointTuples["#"+timeOffset]?.add(Pair(adPosition, creativeId))

								_logCreativeXit(creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], isBumper, maxDuration, podIndex, timeOffset, totalAds.toString(), adPosition, vastId)
							}
						}
					}
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true;
						if (params["adType"] == "vms") { // VMS "creative" system
							_creativeId = params["vmsClipId"] as String? ?: "" // default?
						} else { // Other ad systems
							_creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _lineItemCode ?: ""); // haha
						}
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}

				// Creative xls + xld
				aux["auc"] = _adUnitCode ?: ""
				aux["lic"] = _lineItemCode ?: ""
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						val adPosition = (adPodInfo["adPosition"] as Int? ?: 0).toString()
						val timeOffset = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
						val cuePointTuplesForTimeOffset = _cuePointTuples["#" + timeOffset]
						if (cuePointTuplesForTimeOffset != null) {
							for ((adPos, creativeId) in cuePointTuplesForTimeOffset) {
								if (adPos == adPosition) _creativeId = creativeId
							}
						}
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent("xls", "$_creativeId", "Creative", _viewId, "View", aux); // obsolete?
					_logExtensionEvent("xld", "$_creativeId", "Creative", _viewId, "View", aux);
				}
			}
			EventName.bb_adsystem_started -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				_adSystemStarted = true

				// LineItem xst
				if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
				if (_adUnitCode != null && _lineItemCode != null) {
					val lineItemAux = aux.toMap() // copy
					if (!_lineItemLoggedXst) {
						_lineItemLoggedXst = true;
						_logExtensionEvent("xst", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
				}

				// Creative xst
				// nothing; logged later in _onAdSystemQuartile case 0
			}
			EventName.bb_adsystem_clicked -> {
				if (params["__pretend"] != null) aux["hmm"] = "1" // WTF?!?

				// LineItem xcl
				if (_adUnitCode != null) {
					if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
					val lineItemAux = aux.toMap() // copy
					if (_lineItemCode != null && !_lineItemLoggedXst) {
						_lineItemLoggedXst = true
						_logExtensionEvent("xcl", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
					aux["auc"] = "$_adUnitCode" // for Creative logging below
					aux["lic"] = _lineItemCode ?: "" // for Creative logging below
				}

				// Creative xcl
				if (_creativeId != null) {
					_logExtensionEvent( "xcl", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_adsystem_skipped -> {
				_adSystemStarted = false;

				// LineItem xsk
				if (_adUnitCode != null) {
					if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
					val lineItemAux = aux.toMap() // copy
					if (_lineItemCode != null) {
						_logExtensionEvent("xsk", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
					aux["auc"] = "$_adUnitCode" // for Creative logging below
					aux["lic"] = _lineItemCode ?: "" // for Creative logging below
				}

				// Creative xsk
				if (_creativeId != null) {
					_logExtensionEvent( "xsk", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_adsystem_noad -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					val errorCode = adProperties["errorCode"]
					val errorMessage = adProperties["errorMessage"]
					aux["why"] = if (errorMessage != null) "AdError $errorCode: $errorMessage" else "No ad found"
					if (adProperties["adId"] != null) aux["adi"] = adProperties["adId"] as String
					if (adProperties["adTitle"] != null) aux["adt"] = adProperties["adTitle"] as String
					if (adProperties["adSystem"] != null) aux["ads"] = adProperties["adSystem"] as String
					if (adProperties["adLinear"] != null) aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					if (adProperties["duration"] != null) aux["add"] = "${adProperties["duration"]}"
					if (adProperties["sdk"] != null) aux["sdk"] = adProperties["sdk"] as String
				}
				val timeout = params["timeout"]
				if (timeout != null) {
					var timeout_double = 0.0
					try {
						timeout_double = (timeout as String).toDouble()
					} catch(er: Exception) {}
					aux["why"] = "timeout after " + (timeout_double/1000) + "s"
				}

				_adSystemStarted = false;

				// LineItem xpf
				if (_adUnitCode != null) {
					if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
					val lineItemAux = aux.toMap() // copy
					if (_lineItemCode != null) {
						_logExtensionEvent("xpf", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
					aux["auc"] = "$_adUnitCode" // for Creative logging below
					aux["lic"] = _lineItemCode ?: "" // for Creative logging below
				}

				// Creative xpf
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId == null) _creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _lineItemCode ?: ""); // haha
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					// nothing
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent( "xpf", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_adsystem_failed -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties // thread-safe
				if (adProperties != null) {
					val errorCode = adProperties["errorCode"]
					val errorMessage = adProperties["errorMessage"]
					aux["why"] = if (errorMessage != null) "AdError $errorCode: $errorMessage" else "Ad system failed"
					if (adProperties["adId"] != null) aux["adi"] = adProperties["adId"] as String
					if (adProperties["adTitle"] != null) aux["adt"] = adProperties["adTitle"] as String
					if (adProperties["adSystem"] != null) aux["ads"] = adProperties["adSystem"] as String
					if (adProperties["adLinear"] != null) aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					if (adProperties["duration"] != null) aux["add"] = "${adProperties["duration"]}"
					if (adProperties["sdk"] != null) aux["sdk"] = adProperties["sdk"] as String
				}

				_adSystemStarted = false;

				// LineItem xpf
				if (_adUnitCode != null) {
					if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
					val lineItemAux = aux.toMap() // copy
					if (_lineItemCode != null) {
						_logExtensionEvent("xpf", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
					aux["auc"] = "$_adUnitCode" // for Creative logging below
					aux["lic"] = _lineItemCode ?: "" // for Creative logging below
				}

				// Creative xpf
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId == null) _creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _lineItemCode ?: ""); // haha
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					// nothing
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent( "xpf", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_adsystem_finished -> {
				_adSystemStarted = false;

				// LineItem xfn
				if (_adUnitCode != null) {
					if (params["lineItemCode"] is String) _lineItemCode = params["lineItemCode"] as String?
					val lineItemAux = aux.toMap() // copy
					if (_lineItemCode != null) {
						_logExtensionEvent("xfn", "$_lineItemCode", "LineItem", _adUnitCode, "AdUnit", lineItemAux)
					}
				}

				// Creative xfn
				// nothing; logged earlier in _onAdSystemQuartile case 4
			}
			EventName.bb_adsystem_quartile -> {
				var quartile_int = 0
				try {
					quartile_int = (params["quartile"] as String? ?: "0").toInt()
				} catch(er: Exception) {}
				val percentage = quartile_int * 25
				aux["pct"] = "$percentage"

				// Creative xst/xpg/xfn
				aux["auc"] = _adUnitCode ?: ""
				aux["lic"] = _lineItemCode ?: ""
				if (_creativeId != null) {
					when (quartile_int) {
						0 -> {
							_logExtensionEvent("xst", "$_creativeId", "Creative", _viewId, "View", aux);
						}
						4 -> {
							_logExtensionEvent("xfn", "$_creativeId", "Creative", _viewId, "View", aux);
						}
						else -> {
							_logExtensionEvent("xpg", "$_creativeId", "Creative", _viewId, "View", aux);
						}
					}
				}
			}

			else -> {}
		}
	}

	private fun _onAdSchedulingEvent(eventType: EventName, payload: Map<String, Any?>?) {
		val params: Map<String, Any?> = if (payload != null) payload else mapOf()

		val aux: MutableMap<String, String> = mutableMapOf(
			"at" to (params["adType"] as String? ?: ""),
			"ap" to (params["adPosition"] as String? ?: "").toLowerCase()
		)
		if (_doLogAdRequestUrl) aux["ar"] = (params["adRequestUrl"] as String? ?: "")
		val ap = aux["ap"]
		if (!ap.isNullOrEmpty()) _adScheduleAdPosition = ap

		when (eventType) {
			EventName.bb_as_initialized -> {
				_adProperties = null

				_adScheduleLoggedXiv = false
				_adScheduleLoggedXov = false
				_adScheduleLoggedXst = false
				_adScheduleItemCodeLoggedXit = null
				_creativeLoggedXit = false
				_creativeLoggedXit_pi = null
				_cuePointTuples = mutableMapOf()

				// AdSchedule xit & xiv/xov
				_adScheduleCode = params["adScheduleCode"] as String? // required
				if (_adScheduleCode != null) {
					_logExtensionEvent("xit", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux)
				}
				_handleAdScheduleInOutView()

				// Creative xit
				// nothing; logged later in bb_as_item_canplay case
			}
			EventName.bb_as_placement_failed -> {
				// AdSchedule xpf & xiv/xov
				_adScheduleCode = params["adScheduleCode"] as String? // required
				if (_adScheduleCode != null) {
					_logExtensionEvent("xpf", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux)
				}
				_handleAdScheduleInOutView()
			}
			EventName.bb_as_loadstart -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				// AdSchedule xls
				if (_adScheduleCode != null) {
					_logExtensionEvent("xls", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux.toMap())
				}

				// Creative xls
				// nothing; logged later in bb_as_item_canplay case
			}
			EventName.bb_as_item_blocked -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				// AdScheduleItem xlb
				if (params["adScheduleItemCode"] != null) _adScheduleItemCode = params["adScheduleItemCode"] as String?
				if (_adScheduleCode != null && _adScheduleItemCode != null) {
					_logExtensionEvent("xlb", "$_adScheduleItemCode", "AdScheduleItem", _adScheduleCode, "AdSchedule", aux.toMap())
				}

				// Creative xlb
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId != null) {
					_logExtensionEvent("xlb", "$_creativeId", "Creative", _viewId, "View", aux);
				}
			}
			EventName.bb_as_item_canplay -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["adi"] = adProperties["adId"] as String? ?: ""
					aux["adt"] = adProperties["adTitle"] as String? ?: ""
					aux["ads"] = adProperties["adSystem"] as String? ?: ""
					aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					aux["add"] = "${adProperties["duration"]}"
					aux["sdk"] = adProperties["sdk"] as String? ?: ""

					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						aux["adp_ap"] = (adPodInfo["adPosition"] as Int? ?: 0).toString()
						aux["adp_ib"] = if (adPodInfo["isBumper"] == true) "true" else "false"
						aux["adp_md"] = (adPodInfo["maxDuration"] as Double? ?: 0.0).toString()
						aux["adp_pi"] = (adPodInfo["podIndex"] as Int? ?: 0).toString()
						aux["adp_to"] = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
						aux["adp_ta"] = (adPodInfo["totalAds"] as Int? ?: 0).toString()
					}
				}

				// AdScheduleItem xit
				if (params["adScheduleItemCode"] != null) _adScheduleItemCode = params["adScheduleItemCode"] as String?
				if (_adScheduleCode != null && _adScheduleItemCode != null) {
					val itemAux: MutableMap<String, String> = mutableMapOf(
						"at" to (params["adType"] as String? ?: ""),
						"ap" to (params["adPosition"] as String? ?: "").toLowerCase()
					)
					if (_doLogAdRequestUrl) aux["ar"] = (params["adRequestUrl"] as String? ?: "")
					if (adProperties != null) {
						itemAux["sdk"] = adProperties["sdk"] as String? ?: ""
					}
					if (_adScheduleItemCode !== _adScheduleItemCodeLoggedXit) {
						_adScheduleItemCodeLoggedXit = _adScheduleItemCode;
						_logExtensionEvent("xit", "$_adScheduleItemCode", "AdScheduleItem", _adScheduleCode, "AdSchedule", itemAux.toMap());
					}
				}

				// Creative xit
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						if (_creativeLoggedXit_pi != adPodInfo["podIndex"] as Int?) { // once per pod
							_creativeLoggedXit_pi = adPodInfo["podIndex"] as Int?

							val isBumper = if (adPodInfo["isBumper"] == true) "true" else "false"
							val maxDuration = (adPodInfo["maxDuration"] as Double? ?: 0.0).toString()
							val podIndex = (adPodInfo["podIndex"] as Int? ?: 0).toString()
							val timeOffset = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
							val totalAds = adPodInfo["totalAds"] as Int? ?: 0
							for (adPosition_int in 1..totalAds) {
								val adPosition = "$adPosition_int"
								val creativeId = _constructCreativeId(adPosition, timeOffset, _adScheduleItemCode ?: "") // NB!
								val vastId = if (adPodInfo["adPosition"] as Int? == adPosition_int) aux["vastid"] else "" // NB!
								if (_cuePointTuples["#"+timeOffset] == null) _cuePointTuples["#"+timeOffset] = mutableListOf()
								_cuePointTuples["#"+timeOffset]?.add(Pair(adPosition, creativeId))

								_logCreativeXit(creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], isBumper, maxDuration, podIndex, totalAds.toString(), timeOffset, adPosition, vastId)
							}
						}
					}
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true;
						if (params["adType"] == "vms") { // VMS "creative" system
							_creativeId = params["vmsClipId"] as String? ?: "" // default?
						} else { // Other ad systems
							_creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _adScheduleItemCode ?: ""); // haha
						}
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}

				// Creative xls + xld
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					val adPodInfoAny = adProperties["adPodInfo"]
					if (adPodInfoAny is Map<*,*>) {
						val adPodInfo = adPodInfoAny as Map<String, Any?>
						val adPosition = (adPodInfo["adPosition"] as Int? ?: 0).toString()
						val timeOffset = (adPodInfo["timeOffset"] as Double? ?: 0.0).toString()
						val cuePointTuplesForTimeOffset = _cuePointTuples["#" + timeOffset]
						if (cuePointTuplesForTimeOffset != null) {
							for ((adPos, creativeId) in cuePointTuplesForTimeOffset) {
								if (adPos == adPosition) _creativeId = creativeId
							}
						}
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent("xls", "$_creativeId", "Creative", _viewId, "View", aux); // obsolete?
					_logExtensionEvent("xld", "$_creativeId", "Creative", _viewId, "View", aux);
				}
			}
			EventName.bb_as_started -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				_adScheduleItemStarted = true

				// AdSchedule xst
				if (_adScheduleCode != null && !_adScheduleLoggedXst) {
					_adScheduleLoggedXst = true
					_logExtensionEvent("xst", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux.toMap())
				}

				// Creative xst
				// nothing; logged later in bb_as_ad_quartile case 0
			}
			EventName.bb_as_ad_clicked -> {
				if (params["__pretend"] != null) aux["hmm"] = "1" // WTF?!?

				// AdSchedule xcl
				if (_adScheduleCode != null) {
					_logExtensionEvent("xcl", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux.toMap())
				}

				// Creative xcl
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId != null) {
					_logExtensionEvent("xcl", "$_creativeId", "Creative", _viewId, "View", aux);
				}
			}
			EventName.bb_as_item_skipped -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					aux["adi"] = adProperties["adId"] as String? ?: ""
					aux["adt"] = adProperties["adTitle"] as String? ?: ""
					aux["ads"] = adProperties["adSystem"] as String? ?: ""
					aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					aux["add"] = "${adProperties["duration"]}"
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				_adScheduleItemStarted = false;

				// AdScheduleItem xsk
				if (params["adScheduleItemCode"] != null) _adScheduleItemCode = params["adScheduleItemCode"] as String?
				if (_adScheduleCode != null && _adScheduleItemCode != null) {
					_logExtensionEvent("xsk", "$_adScheduleItemCode", "AdScheduleItem", _adScheduleCode, "AdSchedule", aux.toMap())
				}

				// Creative xsk
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId != null) {
					_logExtensionEvent("xsk", "$_creativeId", "Creative", _viewId, "View", aux);
				}
			}
			EventName.bb_as_item_noad -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					val errorCode = adProperties["errorCode"]
					val errorMessage = adProperties["errorMessage"]
					aux["why"] = if (errorMessage != null) "AdError $errorCode: $errorMessage" else "No ad found"
					aux["adi"] = adProperties["adId"] as String? ?: ""
					aux["adt"] = adProperties["adTitle"] as String? ?: ""
					aux["ads"] = adProperties["adSystem"] as String? ?: ""
					aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					aux["add"] = "${adProperties["duration"]}"
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}
				val timeout = params["timeout"]
				if (timeout != null) {
					var timeout_double = 0.0
					try {
						timeout_double = (timeout as String).toDouble()
					} catch(er: Exception) {}
					aux["why"] = "timeout after " + (timeout_double/1000) + "s"
				}

				_adScheduleItemStarted = false;

				// AdScheduleItem xpf
				if (params["adScheduleItemCode"] != null) _adScheduleItemCode = params["adScheduleItemCode"] as String?
				if (_adScheduleCode != null && _adScheduleItemCode != null) {
					_logExtensionEvent("xpf", "$_adScheduleItemCode", "AdScheduleItem", _adScheduleCode, "AdSchedule", aux.toMap())
				}

				// Creative xpf
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId == null) _creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _adScheduleItemCode ?: ""); // haha
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					// nothing
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent( "xpf", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_as_item_failed -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;
				val adProperties = _adProperties
				if (adProperties != null) {
					val errorCode = adProperties["errorCode"]
					val errorMessage = adProperties["errorMessage"]
					aux["why"] = if (errorMessage != null) "AdError $errorCode: $errorMessage" else "Ad system failed"
					aux["adi"] = adProperties["adId"] as String? ?: ""
					aux["adt"] = adProperties["adTitle"] as String? ?: ""
					aux["ads"] = adProperties["adSystem"] as String? ?: ""
					aux["adl"] = if (adProperties["adLinear"] == true) "true" else "false"
					aux["add"] = "${adProperties["duration"]}"
					aux["sdk"] = adProperties["sdk"] as String? ?: ""
				}

				_adScheduleItemStarted = false;

				// AdScheduleItem xsk
				if (params["adScheduleItemCode"] != null) _adScheduleItemCode = params["adScheduleItemCode"] as String?
				if (_adScheduleCode != null && _adScheduleItemCode != null) {
					_logExtensionEvent("xpf", "$_adScheduleItemCode", "AdScheduleItem", _adScheduleCode, "AdSchedule", aux.toMap())
				}

				// Creative xpf
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId == null) _creativeId = _constructCreativeId(params["adType"] as String? ?: "", params["adPosition"] as String? ?: "", _adScheduleItemCode ?: ""); // haha
				if (adProperties != null && adProperties["adPodInfo"] != null) {
					// nothing
				} else {
					if (!_creativeLoggedXit) {
						_creativeLoggedXit = true
						val podIndex = if (aux["ap"] == "postroll") "-1" else (if (aux["ap"] == "preroll") "0" else "0")
						val timeOffset = if (aux["ap"] == "postroll") "-1" else "0"
						_logCreativeXit(_creativeId, aux["at"], aux["ap"], aux["ar"], aux["sdk"], "false", "0", podIndex, timeOffset, "1", "1", aux["vastid"])
					}
				}
				if (_creativeId != null) {
					_logExtensionEvent( "xpf", "$_creativeId", "Creative", _viewId, "View", aux)
				}
			}
			EventName.bb_as_finished -> {
				if (params.containsKey("adProperties")) _adProperties = params["adProperties"] as Map<String, Any?> // else _adProperties = null;

				_adScheduleItemStarted = false

				// AdSchedule xfn
				if (_adScheduleCode != null) { // && _adScheduleLoggedXst) {
					_adScheduleLoggedXst = false
					_logExtensionEvent("xfn", "$_adScheduleCode", "AdSchedule", _playerSessionId, "Session", aux.toMap())
				}

				// Creative xfn
				// nothing; logged later in bb_as_ad_quartile case 4
			}
			EventName.bb_as_ad_quartile -> {
				var quartile_int = 0
				try {
					quartile_int = (params["quartile"] as String? ?: "0").toInt()
				} catch(er: Exception) {}
				val percentage = quartile_int * 25
				aux["pct"] = "$percentage"

				// Creative xst/xpg/xfn
				aux["asc"] = _adScheduleCode ?: ""
				aux["asic"] = _adScheduleItemCode ?: ""
				val adWrapperAdIds = if (_adProperties?.get("adWrapperAdIds") is Array<*>) _adProperties?.get("adWrapperAdIds") as Array<String> else arrayOf()
				aux["vastid"] = if (adWrapperAdIds.count() > 0) adWrapperAdIds.last() else "[unknown]"
				if (_creativeId != null) {
					when (quartile_int) {
						0 -> {
							_logExtensionEvent("xst", "$_creativeId", "Creative", _viewId, "View", aux);
						}
						4 -> {
							_logExtensionEvent("xfn", "$_creativeId", "Creative", _viewId, "View", aux);
						}
						else -> {
							_logExtensionEvent("xpg", "$_creativeId", "Creative", _viewId, "View", aux);
						}
					}
				}
			}
			else -> {}
		}
	}

	private fun _onWidgetEvent(eventType: EventName, payload: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_widget_shown -> {
				if (payload != null && payload["entityId"] is String && payload["timelineId"] is String) {
					val entityId = payload["entityId"] as String
					val timelineId = payload["timelineId"] as String
					// Log xst for project (only once per project, see _onProjectDataLoaded)
					if (!_projectXSTLogged && _projectId != null) {
						_logExtensionEvent("xst", "$_projectId", "Project", _viewId, "View")
						_projectXSTLogged = true
					}

					// hackje: just-in-time timeline init
					if (_timelineXSTLoggedMap[timelineId] != true) {
						_timelineXSTLoggedMap[timelineId] = true
						if (_clip != null) {
							_logExtensionEvent("xst", timelineId, "Timeline", _clip?.id, "MediaClip")
						} else {
							_logExtensionEvent("xst", timelineId, "Timeline")
						}
					}

					_logExtensionEvent("xst", entityId, "Widget", timelineId, "Timeline", mapOf("to" to _getTimeOffset().toString(), "fs" to (if (_fullScreen) "1" else "0")))
				}
			}
			EventName.bb_widget_clicked -> {
				if (payload != null && payload["entityId"] is String && payload["timelineId"] is String) {
					val entityId = payload["entityId"] as String
					val timelineId = payload["timelineId"] as String
					_logExtensionEvent("xcl", entityId, "Widget", timelineId, "Timeline", mapOf("to" to _getTimeOffset().toString(), "fs" to (if (_fullScreen) "1" else "0")));
				}
			}
			EventName.bb_widget_custom_analytics -> {
				if (payload != null && payload["entityId"] is String && payload["timelineId"] is String) {
					val entityId = payload["entityId"] as String
					val timelineId = payload["timelineId"] as String
					_logExtensionEvent("xsl", entityId, "Widget", timelineId, "Timeline", mapOf("to" to _getTimeOffset().toString(), "fs" to (if (_fullScreen) "1" else "0")));
				}
			}
			else -> {}
		}
	}

	private fun _onSubsChanged(eventType: EventName, payload: Map<String, Any?>?) {
		when (eventType) {
			EventName.subtitleTracksChanged -> {
				if (payload != null && payload["subtitles"] is List<*>) {
					_subtitles = payload["subtitles"] as List<Subtitle>
				}
			}
			EventName.subtitleTrackChanged -> {
				var subtitleId = "off"
				if (payload != null && payload["id"] is String) {
					subtitleId = payload["id"] as String
				}

				// lookup iso
				var iso = "off"
				val subtitles = _subtitles
				if (subtitles != null) {
					for (subtitle: Subtitle in subtitles) {
						if (subtitle.id == subtitleId) {
							iso = subtitle.isocode ?: "---"
							break
						}
					}
				}

				// fake 'xac' (api called) event
				if (_initialized) { // avoid premature xac due to MediaController init
					val aux = mapOf("api" to "setSubtitle_${iso}")
					_logExtensionEvent("xac", "$_viewId", "View", _playerSessionId, "Session", aux)
				}
			}
			else -> {}
		}
	}

	private fun _logCreativeXit(creativeId: String?, at: String?, ap: String?, ar: String?, sdk: String?, isBumper: String = "false", maxDuration: String = "0", podIndex: String = "0", timeOffset: String = "0", totalAds: String = "1", adPosition: String = "1", vastId: String? = null) {
		val creativeXitAux: MutableMap<String, String> = mutableMapOf(
			"at" to (at as String? ?: ""),
			"ap" to (ap as String? ?: ""),
			"ar" to (ar as String? ?: ""),
			"sdk" to (sdk as String? ?: ""),
			"adp_ap" to adPosition,
			"adp_ib" to isBumper,
			"adp_md" to maxDuration,
			"adp_pi" to podIndex,
			"adp_to" to timeOffset,
			"adp_ta" to totalAds
		)
		if (!_adScheduleCode.isNullOrEmpty() && !_adScheduleItemCode.isNullOrEmpty()) { // or simply non-null?
			creativeXitAux["asc"] = _adScheduleCode ?: ""
			creativeXitAux["asic"] = _adScheduleItemCode ?: ""
		} else {
			creativeXitAux["auc"] = _adUnitCode ?: ""
			creativeXitAux["lic"] = _lineItemCode ?: ""
		}
		if (vastId != null) {
			creativeXitAux["vastid"] = vastId
		}
		if (creativeId != null) {
			_logExtensionEvent("xit", "$creativeId", "Creative", _viewId, "View", creativeXitAux)
		}
	}

	private fun _determineReferrer() {
		// nothing
	}

	// OBSOLETE; FOR TESTING ONLY
	fun logMediaClipEvent(event: String, aux: Map<String, String> = emptyMap()) {
		_logMediaClipEvent(event, aux)
	}

	private fun _logMediaClipEvent(event: String, aux: Map<String, String> = emptyMap()) {
		if (_noStats_content) return // bail out

		val clip_ = _clip
		if (clip_ != null) {
			Logger.d(TAG + "_logMediaClipEvent","Mediaclip initialized $event")
			val now = Clock.System.now().toEpochMilliseconds()
			val properties: MutableMap<String, String> = mutableMapOf()

			var uuid = _rdid
//			if (uuid.isNullOrEmpty()) {
//				uuid = localStorage?.get("uuid")
//			}
			if (uuid.isNullOrEmpty()) {
				uuid = _uuid
			}

			properties["vu"] = uuid
			properties["pm"] = _playMode
			properties["sid"] = _sessionId
			properties["prid"] = if (_projectId != null) (_projectId ?: "") else (clip_.projectId ?: "")
			properties["ts"] = (now + _timestampOffset++).toString()
			properties["pp"] = _playoutPublicationName
			properties["pt"] = _playoutName
			properties["pv"] = "native ${Platform.platform} ${BuildVersion.versionTag}"

			properties["ev"] = event
			properties["id"] = "${clip_.id}"
			properties["ct"] = "${clip_.title}"
			properties["pd"] = "${clip_.publisheddate}"

			properties["vs"] = "n/a"
			properties["rs"] = "${Platform.resolution}"// screen.width+"x"+screen.height
			properties["fs"] = if (_fullScreen) "1" else "0"

			if (clip_.mediatype?.isNotEmpty() == true) properties["mt"] =
				"${clip_.mediatype}"
			if (clip_.mediatype_override?.isNotEmpty() == true) properties["mt"] =
				"${clip_.mediatype_override}"
			if (clip_.length?.isNotEmpty() == true) properties["du"] =
				round((clip_.length?.toDouble() ?: 0.0) * 1000).toString() // this.duration
			if (clip_.sourcetype?.isNotEmpty() == true) properties["sot"] =
				"${clip_.sourcetype}"
			if (_dvid != null) properties["_dvid"] = "$_dvid"
			if (_contextEntityType == "MediaClipList" && _contextEntityId != null) properties["clid"] = _contextEntityId ?: ""
			for (i in 1.._maxLevel) { // .reversed()
				properties["cl${i}"] = _listIdsByLevel[i]
			}

			for ((key, value) in aux) {
				if (!properties.containsKey(key)) properties[key] = value
			}

			if (event.equals("se") || event.equals("rs")) {
				// Commented debug statement, but keeping because it's easy to test with, but relatively heavy for production...
//                 Logger.d(TAG + "_logMediaClipEvent","Sending $event event to debouncer; $properties")
				_debouncedEventListMap[event]?.tryEmit(properties)
			} else {
				_logEvent(properties)
			}

		} else {
			Logger.d(TAG + "_logMediaClipEvent","Mediaclip not initialized")
		}
	}

	private fun _logExtensionEvent(event: String, id: String, entityType: String, pid: String? = null, pet: String? = null, aux: Map<String, String> = emptyMap()) {
		val commercial = (entityType == "Creative" || entityType == "AdUnit" || entityType == "LineItem" || entityType == "AdSchedule" || entityType == "AdScheduleItem")
		if (commercial && _noStats_commercial || (!commercial && _noStats_content)) return // bail out

		val now = Clock.System.now().toEpochMilliseconds()
		val properties: MutableMap<String, String> = mutableMapOf()

		properties["pm"] = if (commercial) _commercialPlayMode else _playMode
		properties["sid"] = _sessionId
		properties["prid"] = if (_projectId != null) (_projectId ?: "") else (_clip?.projectId ?: "")
		properties["ts"] = (now + _timestampOffset++).toString()
		properties["pp"] = _playoutPublicationName

		properties["ev"] = event // should start with "x", denoting "extension"
		properties["id"] = id
		properties["et"] = entityType
		properties["cid"] = _clip?.id ?: "null"

		properties["pid"] = pid ?: "null" // default conform javascript
		properties["pet"] = pet ?: "null" // default conform javascript
		// TODO Is there even a thing that can block ads?
		// properties["abd"] = this.adBlockDetected
		if (_contextEntityType == "MediaClipList" && _contextEntityId != null) properties["clid"] = _contextEntityId ?: ""
		for (i in 1.._maxLevel) { // .reversed()
			properties["cl${i}"] = _listIdsByLevel[i]
		}

		for ((key, value) in aux) {
			if (!properties.containsKey(key)) properties[key] = value
		}

		// TODO Is there even a hostname?
		// if ((commercial || (event === 'xst' && entityType === 'View')) && _topMostHostname) properties.hn = _topMostHostname;

		_logEvent( properties )
	}

	private fun _logErrorEvent(event: String, aux: Map<String, String> = emptyMap()) {
		var faked = false
		if (_clip == null) {
			val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true; serializersModule = contentItemSerializersModule }
			_clip = jsonParser.decodeFromString<MediaClip>("{\"id\":0, \"projectId\":0, \"date\":{\"published\":\"<unknown>\"}}")
			faked = true
		}

		_logMediaClipEvent(event, aux)

		if (faked) {
			_clip = null
		}
	}

	private fun _constructCustomFieldLogging(clip: MediaClip?): Map<String, Any>? {
		if (clip == null) return null
		if (_cfl != null) return _cfl // use cached result

		// OVP custom field type to stats solr type mapping
		val typeSolrMapping = mapOf(
			"string" to "_str",
			"relation" to "_str",
			"multistring" to "_strmulti",
			"relationlist" to "_strmulti",
			"text" to "_txt",
			"boolean" to "_bool",
			"date" to "_date",
			"int" to "_int",
			"long" to "_long",
			"float" to "_float",
			"double" to "_double"
		)

		val customfields = _publicationCustomFields?.mediaclip
		if (customfields != null) {
			for (field in customfields) {
				if (field.includeInStats == true && field.name != null) {
					val key = field.name + (typeSolrMapping[field.type] ?: "_str")

					if (_cfl?.get(key) == null) {
						// Try to get value from clip's rawJsonString
						val rawJsonString = clip.rawJsonString
						if (rawJsonString != null) {
							try {
								val jsonElement = Json.parseToJsonElement(rawJsonString)
								val value = if (jsonElement is JsonObject) {
									getFromJsonObject("/${field.name}", jsonElement)
								} else {
									null
								}

								// Only store primitive values (not JsonArray/JsonObject, nor null)
								if (value is String || value is Boolean || value is Number) {
									if (_cfl == null) {
										_cfl = mutableMapOf()
									}
									_cfl?.set(key, value)
								}
							} catch (_: Exception) {
							}
						}
					}
				}
			}
		}

		// Add sourceid if present
		val sourceid = clip.sourceid
		if (sourceid != null) {
			if (_cfl == null) {
				_cfl = mutableMapOf()
			}
			_cfl?.set("sourceid_str", sourceid)
		}

		return _cfl
	}

	private fun _logEvent(properties: MutableMap<String, String>) {
		// Logger.d(TAG + "_logEvent", "Is logging enabled? $_enabled")
		if (_enabled) {
			_logEvent_enabled(properties)
		} else { // disabled
			_enabledQueue.add(properties)
		}
	}

	private fun _logEvent_enabled(properties: MutableMap<String, String>) {
		properties["sn"] = "$_serialNumber" // why not _serialNumber.toString()?
		_serialNumber++

		var queryString = ""
		for ((prop, value) in properties) {
			queryString += if (queryString.isEmpty()) "?" else "&"
			queryString += prop + "=" + value.encodeURLParameter()
		}

		queryString = queryString.replace("-", "%2d")
		queryString = queryString.replace("~~00~~", "%7E%7E00%7E%7E").replace("ad", "~~00~~")
		queryString = queryString.replace("~~01~~", "%7E%7E01%7E%7E").replace("aD", "~~01~~")
		queryString = queryString.replace("~~02~~", "%7E%7E02%7E%7E").replace("Ad", "~~02~~")
		queryString = queryString.replace("~~03~~", "%7E%7E03%7E%7E").replace("AD", "~~03~~")

		val url = _loggerUrl + queryString
		_network?.logStats(url, {
			Logger.d(TAG + "_logEvent_enabled", "Sent successfully to url: $url")
		}, {
			Logger.d(TAG + "_logEvent_enabled", "Loggin FAILED for url: $url")
		})

		_customStatistics?.send(_playerSessionId, "${properties["ev"]}", properties.toMap())
	}

	private fun _determineProgressInterval(): Double {
		// determines the interval of the amount of times the progress event is fired based on the mediaclip duration.
		var interval: Double = 10.0

		var clipDuration: Double = 0.0
		if ( _clip?.length != null && _clip?.length != "" ) {
			clipDuration = _clip?.length?.toDouble() ?: 0.0
		}

		val interval_max = 10.0 // minimum of one log event once per 'max' seconds
		if (clipDuration > 0) {
			val ticks = 10 // every 10 percent (NB: 100 / 10)
			val ticks_min = 5 // minimum of once every 20%
			var interval_min: Double = min(clipDuration / ticks_min, 3.0) // maximum one log event once per 'min' seconds
			if (_isReplay) interval_min = 4.0 // no need for very specific events when replaying short clips
			interval = if (_logProgressAsQuartiles) (clipDuration / 40) else min(max(interval_min, (clipDuration / ticks)), interval_max)
		} else {
			interval = if (_logProgressAsQuartiles) 1.0 else interval_max // default
		}

		return interval
	}

	private fun _handleProgressTimerTick() {
		val to = _getTimeOffset()
		if (to == _to) { // no change
			val now = Clock.System.now().toEpochMilliseconds()
			if (_to_num <= 0) _to_num = 1
			if (_to_now <= 0) _to_now = now
			if (_to_num++ > 60) return // bail out if no change for 60 logs
			if (now > (_to_now + 3600000)) return // bail out if no change for 1 hour
		} else { // change
			_to = to
			_to_num = 0
			_to_now = 0
		}
		val wpa: String = if (_paused) "true" else "false"
		if (_logProgressAsQuartiles) {
			val quartile: Int = if (_duration > 0) floor(4 * to / (_duration * 1000)).toInt() else 0
			while (_quartile < quartile) { // NB ensure all previous quartiles are also hit!
				_quartile++
				val pct: String = (_quartile * 25).toString()
				_logMediaClipEvent("pg", mapOf("pct" to pct, "pet" to "Session", "pid" to _playerSessionId, "wpa" to wpa))
			}
		} else { // normal progress
			_logMediaClipEvent("pg", mapOf("to" to to.toString(), "pet" to "Session", "pid" to _playerSessionId, "wpa" to wpa))
		}
	}

	private fun _getTimeOffset(): Long {
		if (_timeOffset <= 0) _timeOffset = 0
		if (_currentTime <= 0.0) _currentTime = 0.0
		_timeOffset = min(_timeOffset+60000, (_currentTime * 1000).roundToLong())

		return _timeOffset
	}

	// OBSOLETE; FOR TESTING ONLY
	fun ingestOpts(opts: EmbedObject?) {
		_ingestOpts(opts, null)
	}

	private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>?) {
		if (opts != null) {
			// publication parameters
			if (opts.publicationData != null) {
				_publicationCustomFields = opts.publicationData.customfields
				if (!opts.publicationData.name.isNullOrEmpty()) _playoutPublicationName = opts.publicationData.name // e.g. testsuite
			}

			// playout settings
			if (opts.playoutData != null) {
				if (opts.playoutData.name != null) _playoutName = opts.playoutData.name
				if (opts.playoutData.publication != null) _playoutPublicationName = opts.playoutData.publication // e.g. testsuite.acc
				if (opts.playoutData.disableCookies != null) _disableCookies = opts.playoutData.disableCookies
				if (opts.playoutData.logProgressAsQuartiles != null) _logProgressAsQuartiles = (opts.playoutData.logProgressAsQuartiles == "true")
				if (opts.playoutData.autoPlay != null) _autoPlay = (opts.playoutData.autoPlay == "true")
				if (opts.playoutData.autoMute != null) _autoMute = (opts.playoutData.autoMute == "true")
				if (opts.playoutData.autoLoop != null) _autoLoop = (opts.playoutData.autoLoop == "true")
			}

			// override from options dict
			if ( options != null ) {
				if (options["adsystem_rdid"] != null) _rdid = options["adsystem_rdid"] as? String
				if (options["noStats_content"] is Boolean) _noStats_content = options["noStats_content"] as Boolean? ?: false
				if (options["noStats_commercial"] is Boolean) _noStats_commercial = options["noStats_commercial"] as Boolean? ?: false
				if (options["doLogAdRequestUrl"] is Boolean) _doLogAdRequestUrl = options["doLogAdRequestUrl"] as Boolean? ?: false
			}

			// content
			if (opts.clipData != null) {
				_clip = opts.clipData
				_clip_isInitial = true // flag to prevent prevClipId
			}
		}
		_initialized = true
	}
}

class CustomStatistics () {
	private var _eventBus: EventBusInterface? = null

	fun __destruct() {
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus = value
		}

	fun send(ident: String, ev: String, aux: Map<String, String>) {
		_eventBus?.trigger(EventName.customStatistics, mapOf("ident" to ident, "ev" to ev, "aux" to aux))
	}
}
