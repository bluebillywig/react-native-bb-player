package com.bluebillywig.bbnativeshared

import io.ktor.util.*
import kotlinx.datetime.Instant

class InstantFactory {
	companion object {
		/**
		 * @param {String} str , e.g. "2024-05-25T23:59:00Z"
		 */
		fun tryCreateOfIso8601DateTime(str: String): Instant? {
			var ret: Instant? = null

			try {
				ret = Instant.parse(str)
			} catch (_:Exception ) {}

			return ret
		}

		/**
		 * @param {String} str , e.g. "Sat, 25 May 2024 23:59:00 +0200"
		 */
		fun tryCreateOfFullDateTime(str: String): Instant? {
			var ret: Instant? = null
			if (Regex("""\w{3}, \d{2} \w{3} \d{4} \d{2}:\d{2}:\d{2} [+-]\d{4}""").containsMatchIn(str)) {
				var year = "1970"
				var month = "01"
				var day = "01"
				var zone = "Z"
				var time = "00:00:00"
				val parts = str.split(" ")
				parts.forEach {
					if (Regex("""[+-]\d{4}""").matches(it)) { // +|- four digits
						zone = "${it.substring(0, 3)}:${it.substring(3)}" // interfix :
					} else if (Regex("""\d{2}:\d{2}:\d{2}""").matches(it)) { // 3 x two digits
						time = it
					} else if (Regex("""\d{4}""").matches(it)) { // four digits
						year = it
					} else if (Regex("""\w{3}""").matches(it)) { // three word characters
						val months = arrayOf(
							"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC",
							"JAN","FEB","MRT","APR","MEI","JUN","JUL","AUG","SEP","OKT","NOV","DEC"
						)
						val monthIndex = months.indexOf(it.toUpperCasePreservingASCIIRules()) % 12
						if (monthIndex > -1) { // found
							month = (monthIndex + 1).toString()
							if (month.length < 2) month = "0${month}" // prefix 0
						}
					} else if (Regex("""\d{2}""").matches(it)) { // two digits
						day = it
					}
				}
				try {
					ret = Instant.parse("${year}-${month}-${day}T${time}${zone}")
				} catch (_:Exception ) {}
			}

			return ret
		}

		/**
		 * @param {String} str , e.g. "2024-05-25T23:59:00" or "Sat, 25 May 2024 23:59:00 +0200"
		 */
		fun tryCreateOfDateTime(str: String): Instant? {
			return tryCreateOfIso8601DateTime(str) ?: tryCreateOfFullDateTime(str)
		}
	}
}