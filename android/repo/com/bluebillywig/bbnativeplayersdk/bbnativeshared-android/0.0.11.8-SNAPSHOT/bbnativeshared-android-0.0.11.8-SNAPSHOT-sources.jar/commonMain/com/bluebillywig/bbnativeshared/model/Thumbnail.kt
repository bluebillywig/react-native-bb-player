package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class Thumbnail (
    val src: String? = null,
    val width: String? = null,
    val height: String? = null,
    val main: Boolean? = null
)