package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Audiotrack (
    var id: String? = null,
    // val publicationid: String? = null, // sometimes string sometimes array with 1 string
    val type: String? = null,
    val status: String? = null,
    val createddate: String? = null,
    val name: String? = null,
    val createdBy: String? = null,
    val updateddate: String? = null,
    val updatedBy: String? = null,
    var audioId: Int? = null,
    var isocode: String? = null,
    var roleFlags: Int? = null,
    val mediaclipid: String? = null,
    val originalfilename: String? = null,
    val languageid: Long? = null,
    val src: String? = null,
    val remotesrc: String? = null,
    val exactlength: String? = null,
    val publisheddate: String? = null,
    var label: String? = null,
    val uri: String? = null,

    @SerialName("IsDefaultLanguage")
    val isDefaultLanguage: Boolean? = null,

    var isSelected: Boolean? = null,
    var origId: String? = null
)
