package com.bluebillywig.bbnativeshared

import io.ktor.http.*
import com.benasher44.uuid.uuid4
import io.ktor.util.*
import kotlinx.datetime.Clock
//import kotlinx.serialization.decodeFromString
//import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

class AdMacroHelper {
    companion object { // this is Kotlin's way to support static class methods; don't ask...
        // Bracket macros defined by the VAST specification
        // see: https://interactiveadvertisingbureau.github.io/vast/vast4macros/vast4-macros-latest.html
        private val VAST_SPEC_MACROS: Set<String> = setOf(
            "[CONTENTCAT]",
            "[PLAYBACKMETHODS]",
            "[STOREID]",
            "[STOREURL]",
            "[CACHEBUSTING]",
            "[TIMESTAMP]",
            "[ADCATEGORIES]",
            "[ADCOUNT]",
            "[ADTYPE]",
            "[BLOCKEDADCATEGORIES]",
            "[BREAKMAXADLENGTH]",
            "[BREAKMAXADS]",
            "[BREAKMAXDURATION]",
            "[BREAKMINADLENGTH]",
            "[BREAKPOSITION]",
            "[CONTENTPLAYHEAD]",
            "[MEDIAPLAYHEAD]",
            "[PLACEMENTTYPE]",
            "[UNIVERSALADID]",
            "[CLIENTUA]",
            "[DEVICEIP]",
            "[DEVICEUA]",
            "[IFA]",
            "[IFATYPE]",
            "[LATLONG]",
            "[SERVERSIDE]",
            "[SERVERUA]",
            "[APPBUNDLE]",
            "[DOMAIN]",
            "[PAGEURL]",
            "[APIFRAMEWORKS]",
            "[CLICKTYPE]",
            "[EXTENSIONS]",
            "[MEDIAMIME]",
            "[OMIDPARTNER]",
            "[PLAYERCAPABILITIES]",
            "[VASTVERSIONS]",
            "[VERIFICATIONVENDORS]",
            "[ADPLAYHEAD]",
            "[ADSERVINGID]",
            "[ASSETURI]",
            "[CONTENTID]",
            "[CONTENTURI]",
            "[INVENTORYSTATE]",
            "[PLAYERSIZE]",
            "[PLAYERSTATE]",
            "[PODSEQUENCE]",
            "[CLICKPOS]",
            "[ERRORCODE]",
            "[REASON]",
            "[GDPRCONSENT]",
            "[LIMITADTRACKING]",
            "[REGULATIONS]"
        )
    }

    // settings
    private var _queryStringParams: Parameters = parametersOf()
    private var _referrer = "in-app"
    private var _deeplink = ""
    private var _uuid: String? = null
    private var _width: Number = 768
    private var _height: Number = 432
    private var _clipTitle: String? = null
    private var _clipId: String? = null
    private val _corsdomain = "//imasdk.googleapis.com"
    private val _format = "application/javascript" // for Liverail?!?
    private val _playMode = "html5" // for Liverail?!?

    private var _buid: String? = null
    private var _rdid: String? = null
    private var _idtype: String? = null
    private var _is_lat: Boolean? = null

    private var _consentString: String = ""
    private var _consentGdprApplies: Int = 0
    private var _consentCmpVersion: Int = 0
    // private var _restriction_npaOnly: Boolean = false

    private var _clipJson: String? = null
    private var _clipJsonObject: JsonObject? = null
    private var _playoutJson: String? = null
    private var _playoutJsonObject: JsonObject? = null

    init {
        _uuid = _rdid
//        if (_uuid.isNullOrEmpty()) {
//            _uuid = localStorage?.get("uuid")
//        }
        if (_uuid.isNullOrEmpty()) {
            _uuid = uuid4().toString()
        }
    }

    fun updateSettings(settings: Map<String, Any?>) {
        if (settings["queryString"] is String) {
            val queryString = settings["queryString"] as String
            if (!queryString.isEmpty()) {
                _queryStringParams = queryString.parseUrlEncodedParameters() // NB max 100 params!
            }
        }

        if (settings["referrer"] is String) _referrer = settings["referrer"] as String
        if (settings["deeplink"] is String) _deeplink = settings["deeplink"] as String
        if (settings["uuid"] is String) _uuid = settings["uuid"] as String
        if (settings["width"] is Number) _width = settings["width"] as Number
        if (settings["height"] is Number) _height = settings["height"] as Number
        if (settings["clipTitle"] is String) _clipTitle = settings["clipTitle"] as String
        if (settings["clipId"] is String) _clipId = settings["clipId"] as String

        if (settings["playoutJson"] is String) _playoutJson = settings["playoutJson"] as String
        if (settings["clipJson"] is String) _clipJson = settings["clipJson"] as String

        if (settings["buid"] is String) _buid = settings["buid"] as String
        if (settings["rdid"] is String) _rdid = settings["rdid"] as String
        if (settings["idtype"] is String) _idtype = settings["idtype"] as String
        if (settings["is_lat"] is Boolean) _is_lat = settings["is_lat"] as Boolean

        if (settings["consent_string"] is String) _consentString = settings["consent_string"] as String
        if (settings["consent_gdprApplies"] is Int) _consentGdprApplies = settings["consent_gdprApplies"] as Int
        if (settings["consent_cmpVersion"] is Int) _consentCmpVersion = settings["consent_cmpVersion"] as Int

        // TODO: restriction_npaOnly
    }

    fun resolveMacro (macro: String): String? {
        var resolvedValue: String? = null // NB doNotReplace!
        val allowJSMacros = false // js macro's not possible in native

        if (macro.startsWith("%%")) {
            resolvedValue = this.resolvePercentMacro(macro) ?: "" // NB leave no %% macro's behind!
        } else if (macro.startsWith("[")) { // /\[.+\]/.test(macro)
            if (allowJSMacros && (macro.startsWith("[js:") || macro.startsWith("[js2:"))) {
                // resolvedValue = _resolveJsMacro(macro)
            } else if (macro.startsWith("[aps:")) {
                // resolvedValue = _resolveAPSMacro(macro)
            } else { // normal
                resolvedValue = this.resolveBracketMacro(macro)
            }
        }

        return resolvedValue
    }

    /**
     * Resolve a percent macro to its value
     *
     * @param {String} macro - the macro, including leading and trailing %% markers
     * @return {String} the resolved value, which might be an empty string, or NULL
     */
    fun resolvePercentMacro(macro: String): String? {
        val macroName = macro.replace("%%", "")
        val macroNameUC = macroName.toUpperCasePreservingASCIIRules()
        var macroVal = _queryStringParams["macro_" + macroName]
        if (macroVal != null) { // empty string is allowed
            // nothing; accept override from query string
        } else if (macroNameUC == "APP_BUNDLE_ID" && !_buid.isNullOrEmpty()) {
            macroVal = _buid
        } else if (!_rdid.isNullOrEmpty() && !_idtype.isNullOrEmpty() && _is_lat != null) { // all three must be present
            if (macroNameUC == "ADVERTISING_IDENTIFIER_PLAIN") {
                macroVal = _rdid
            } else if (macroNameUC == "ADVERTISING_IDENTIFIER_TYPE") {
                macroVal = _idtype
            } else if (macroNameUC == "ADVERTISING_IDENTIFIER_IS_LAT") {
                macroVal = if (_is_lat == true) "1" else "0"
            }
        }

        return macroVal
    }

    /**
     * Resolve a bracket macro to its value
     *
     * @param {string} macro - the macro, including leading and trailing brackets
     * @return {string|Object} the resolved value, which might be an empty string, or NULL
     */
    fun resolveBracketMacro(macro: String): String? {
        if (AdMacroHelper.VAST_SPEC_MACROS.contains(macro)) return null // doNotReplace

        val macroName = macro.replace("[", "").replace("]", "")
        val macroNameLC = macroName.toLowerCasePreservingASCIIRules()
        var macroVal = _queryStringParams["macro_" + macroName]
        if (macroVal != null) { // empty string is allowed
            // nothing; accept override from query string
        } else if (macroNameLC.startsWith("mediaclip_")) {
//            val clipJson = _clipJson
//            if (_clipJsonObject == null && clipJson != null) {
//                val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true; serializersModule = contentItemSerializersModule }
//                _clipJsonObject = jsonParser.decodeFromString<JsonObject>(clipJson)
//            }
//            macroVal = _clipJsonObject?.get(macroNameLC.split("mediaclip_")[1]).toString()
        } else if (macroNameLC.startsWith("playout_")) {
//            val playoutJson = _playoutJson
//            if (_playoutJsonObject == null && playoutJson != null) {
//                val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true; serializersModule = contentItemSerializersModule }
//                _playoutJsonObject = jsonParser.decodeFromString<JsonObject>(playoutJson)
//            }
//            macroVal = _playoutJsonObject?.get(macroNameLC.split("playout_")[1]).toString()
        } else if (macroNameLC == "url") { // referrer
            macroVal = _referrer
        } else if (macroNameLC == "deeplink" || macroName == "description_url") {
            macroVal = _deeplink
        } else if (macroNameLC == "correlator") {
            macroVal = _uuid
        } else if (macroNameLC == "timestamp" || macroName == "random") {
            macroVal = Clock.System.now().toEpochMilliseconds().toString()
        } else if (macroNameLC == "playerwidth") {
            macroVal = _width.toString()
        } else if (macroNameLC == "playerheight") {
            macroVal = _height.toString()
        } else if (macroNameLC == "cliptitle") {
            macroVal = _clipTitle
        } else if (macroNameLC == "clipid") {
            macroVal = _clipId
        } else if (macroNameLC == "corsdomain") {
            macroVal = _corsdomain
        } else if (macroNameLC == "consent_string") {
            macroVal = _consentString
        } else if (macroNameLC == "gdpr_applies") {
            macroVal = _consentGdprApplies.toString()
        } else if (macroNameLC == "cmp_version") {
            macroVal = _consentCmpVersion.toString()
        } else if (macroNameLC == "format") {
            macroVal = _format
        } else if (macroNameLC == "playmode") {
            macroVal = _playMode
        }

        return macroVal
    }
}
