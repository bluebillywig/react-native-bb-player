package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class Chapter (
    val id: String? = null,
    val title: String? = null, // for MediaClip chapters
    val timeOffset: Float? = null, // for MediaClip chapters
    val steps: List<Step>? = null // for Project chapters
)
