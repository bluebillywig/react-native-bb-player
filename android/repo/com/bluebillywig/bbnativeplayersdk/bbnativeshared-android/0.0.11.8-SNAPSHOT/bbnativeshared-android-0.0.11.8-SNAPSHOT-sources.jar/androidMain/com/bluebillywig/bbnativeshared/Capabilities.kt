package com.bluebillywig.bbnativeshared

/**
 * @suppress
 */
actual class Capabilities actual constructor() {
    actual companion object {
        actual fun canPlayType(type: String): Boolean {
            if (type.contains("MPD", true)) return false
            return true
        }
    }
}
