package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.enums.Phase
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
@SerialName("AdSchedulingData")
data class AdSchedulingData(
	val scheduleId: Int? = null,
	val scheduleCode: String? = null,
	val macros: Map<String, Array<String>>? = null
)
