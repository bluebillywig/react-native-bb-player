package com.bluebillywig.bbnativeshared.controller

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.loggers.BlueBillywigLogger

/**
 * @suppress
 */
class StatsController (eventBus: EventBusInterface?, network: NetworkInterface?): EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
			}
			EventName.bb_program_autopause -> {
				_onAutoPause(eventType)
			}
			EventName.bb_program_autopauseplay -> {
				_onAutoPausePlay(eventType)
			}
			EventName.bb_program_play -> {
				_onPlay(eventType)
			}
			else -> { return }
		}
		Logger.d("[StatsController] onEvent", "Processed event: $eventType")
	}
	// resources
	private var _network: NetworkInterface? = null
	private var _eventBus: EventBusInterface? = eventBus
	private var _bblogger: BlueBillywigLogger? = null

	// settings
	private var _noStats: Boolean = false
	private var _showOnlyWhenPrerollAvailable: Boolean = false
	private var _autoPlayOnlyWithPrerollAd: Boolean = false

	// state
	private var _autoPaused: Boolean = false

	init {
		_network = network
		_eventBus?.addEventlistener(this)
		_bblogger = BlueBillywigLogger(_eventBus, _network)
	}

	fun __destruct() {
		_eventBus?.removeEventlistener(this)
		_eventBus = null
		_bblogger?.__destruct()
		_bblogger = null
		_network?.__destruct()
		_network = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this)

			_bblogger?.eventBus = _eventBus
		}

	private fun _onAutoPause(eventType: EventName?) {
		Logger.d("[StatsController] _onAutoPause", "")
		_autoPaused = true
		if (!_noStats) {
			_handleAutoPauseAll()
		}
	}

	private fun _onAutoPausePlay(eventType: EventName?) {
		Logger.d("[StatsController] _onAutoPausePlay", "")
		_autoPaused = false
		if (!_noStats) {
			_enableAll()
		}
	}

	private fun _onPlay(eventType: EventName?) {
		Logger.d("[StatsController] _onPlay", "")
		if (_autoPaused) {
			Logger.d("[StatsEngine] _onPlay autoPaused", "")
			_autoPaused = false
			if (!_noStats) {
				_enableAll()
			}
		}
	}

	private fun _handleAutoPauseAll() {
		Logger.d("[StatsController] _handleAutoPauseAll", "")
		_bblogger?.handleAutoPause()
	}

	private fun _enableAll() {
		Logger.d("[StatsController] _enableAll", "")
		_bblogger?.enable()
	}

	private fun _disableAll() {
		Logger.d("[StatsController] _disableAll", "")
		_bblogger?.disable()
	}

	private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>?) {
		if (opts != null) {
			// playout settings
			if (opts.playoutData != null) {
				if (opts.playoutData.noStats != null) _noStats = (opts.playoutData.noStats == "true")
				if (opts.playoutData.showOnlyWhenPrerollAvailable != null) _showOnlyWhenPrerollAvailable = (opts.playoutData.showOnlyWhenPrerollAvailable == "true")
				if (opts.playoutData.autoPlayOnlyWithPrerollAd != null) _autoPlayOnlyWithPrerollAd = (opts.playoutData.autoPlayOnlyWithPrerollAd == "true")

				// check for noStats in the options dict and override value if so
				if ( options != null && options["noStats"] != null ) {
					_noStats = (options["noStats"] == true)
				}

				if (_noStats || _showOnlyWhenPrerollAvailable || _autoPlayOnlyWithPrerollAd) {
					_disableAll()
				} else {
					_enableAll()
				}
			}
		}
	}
}
