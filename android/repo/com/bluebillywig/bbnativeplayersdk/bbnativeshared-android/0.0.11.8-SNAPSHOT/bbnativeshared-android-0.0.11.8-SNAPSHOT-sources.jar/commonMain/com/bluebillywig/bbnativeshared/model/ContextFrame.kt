package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface

data class ContextFrame (
	val contentList: MutableList<ContentItemInterface>,
	val contentListIndex: Int = -1,
	val contextCollectionType: String? = null,
	val contextCollectionId: String? = null,
	val contextEntityType: String? = null,
	val contextEntityId: String? = null,
	val contentIndicator: String? = null,
	val contentId: String? = null,
	val clipListId: String? = null,
	val nestingLevel: Int = 0
)
