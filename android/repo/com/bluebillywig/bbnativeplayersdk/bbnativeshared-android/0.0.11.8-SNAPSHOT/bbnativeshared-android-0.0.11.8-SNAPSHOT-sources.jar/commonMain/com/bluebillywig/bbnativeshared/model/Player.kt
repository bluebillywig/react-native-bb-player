package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Player (
    val id: String? = null,
    val name: String? = null,
    val type: String? = null,
    val src: String? = null,
    val updateddate: String? = null
)