package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class TypedObject (
    val type: String? = null
)