package com.bluebillywig.bbnativeshared.controller

import com.benasher44.uuid.uuid4
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.PosType
import com.bluebillywig.bbnativeshared.interfaces.AdControllerInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.Chapter
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.model.Playout
import com.bluebillywig.bbnativeshared.AdMacroHelper

import io.ktor.http.*
import com.benasher44.uuid.uuid4
import kotlinx.datetime.Clock

/**
 * @suppress
 */
class AdSchedulingController (eventBus: EventBusInterface?, opts: EmbedObject? = null, options: Map<String, Any?>? = null):
    EventListenerInterface {
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_embed_loaded -> {
                val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
                if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
            }
            EventName.bb_playout_changed -> {
                _onPlayoutChanged(data)
            }
            EventName.bb_mediaclip_loaded -> {
                _onMediaClipLoaded(eventType, data)
            }
            EventName.bb_mediaclip_failed -> {
                _onMediaClipLoaded(eventType, mapOf("clipData" to null))
            }
            EventName.bb_resized -> {
                _onResized(eventType, data)
            }

            EventName.adLoaded -> {
                _onAdLoaded(data)
            }
            EventName.adCanPlay -> {
                _onAdCanPlay(data)
            }
            EventName.adStarted -> {
                _onAdStarted(data)
            }
            EventName.adFirstQuartile, EventName.adMidPoint, EventName.adThirdQuartile -> {
                _onAdQuartile(eventType, data)
            }
            EventName.adComplete -> {
                _onAdComplete(data)
            }
            EventName.allAdsCompleted -> {
                _onAllAdsCompleted(data)
            }
            EventName.adClicked -> {
                _onAdClicked(data)
            }
            EventName.adSkipped -> {
                _onAdSkipped(data)
            }
            EventName.adNoAd -> {
                _onAdNoAd(data)
            }
            EventName.adFailed -> {
                _onAdFailed(data)
            }
            EventName.adContentPauseReq -> {
                _mediaSuspended = true
            }
            EventName.adContentResumeReq -> {
                _mediaSuspended = false
            }

            EventName.playing -> {
                _playerStarted = true
            }
            EventName.ended -> {
                _playerStarted = false
            }
            else -> { return }
        }
//        Logger.d(TAG, "Processed event: $eventType")
    }

    // resources
    private var _eventBus: EventBusInterface? = eventBus
    private var _adController: AdControllerInterface? = null
    private var _adMacroHelper: AdMacroHelper? = null

    // settings
    private var _baseUrl: String = ""
    private var _scheduleId: Int = 0 // obsolete
    private var _scheduleCode: String = ""
    private var _macros: Map<String, Array<String>>? = null
    private var _queryStringParams: Parameters = parametersOf()
    private var _width: Number = 768
    private var _height: Number = 432
    private var _uuid: String? = null
    private var _buid: String? = null
    private var _rdid: String? = null
    private var _idtype: String? = null
    private var _is_lat: Boolean? = null
    private var _consentString: String = ""
    private var _consentGdprApplies: Int = 0
    private var _consentCmpVersion: Int = 0
    private var _queryString: String = ""
    private var _commercialBehaviour: String? = null
    private var _minClipDurationPreroll: String? = null
    private var _minClipDurationPostroll: String? = null
    private var _startCollapsed: Boolean = false;
    private var _hidePlayerOnEnd: Boolean = false;

    // state
    private var _disabled: Boolean = false
    private var _phase: Phase = Phase.INIT
    private var _pos: PosType = PosType.VMAP
    private var _adScheduleItemCode: String = ""
    private var _perPositionAdCounter_clip: MutableMap<PosType, Int> = mutableMapOf()
    private var _perPositionAdCounter_load: MutableMap<PosType, Int> = mutableMapOf()
    private var _perPositionAdCounter_sess: MutableMap<PosType, Int> = mutableMapOf()
    private var _mediaSuspended: Boolean = false
    private var _playerStarted: Boolean = false
    private var _started: Boolean = false

    // data
    private var _clipData: MediaClip? = null
    private var _clipId: String? = null
    private var _clipTitle: String? = null
    private var _deeplink: String? = null
    private var _clipDuration: Double = 0.0
    private var _clipDisabled: Boolean = false
    private var _clipIsInArticle: Boolean = false
    private var _adType: String = "ad-scheduling"
    private var _url: String = ""

    companion object { // this is Kotlin's way to support static class methods; don't ask...
        const val TAG = "AdSchedulingController"
    }

    init {
        _adMacroHelper = AdMacroHelper()
        _eventBus?.addEventlistener(this)
        _ingestOpts(opts, options)
    }

    fun __destruct() {
        _eventBus?.removeEventlistener(this)
        _eventBus = null
        _adMacroHelper = null
    }

    var eventBus: EventBusInterface?
        get() = _eventBus
        set(value) {
            _eventBus?.removeEventlistener(this)
            _eventBus = value
            _eventBus?.addEventlistener(this)
        }

    var adController: AdControllerInterface?
        get() = _adController
        set(value) {
            _adController = value
        }

    fun resetAdCounter_load() {
        _perPositionAdCounter_load = mutableMapOf()
    }

    fun set(propertyName: String, propertyValue: Any?): Boolean {
        return true
    }

    fun get(propertyName: String): Any? {
        if (propertyName == "adCounter_clip") {
            var count: Int = 0
            for (item in _perPositionAdCounter_clip) {
                if (item.key != PosType.LEADER) {
                    count += item.value
                }
            }
            return count
        }

        return null
    }

    fun load(phase: Phase): Boolean {
        _phase = phase
        _url = _getScheduleUrl()
        Logger.d("AdSchedulingController", "load _url: ${_url}")

        // TEMPORARILY only load _url in MAIN phase instead of urlWithPhase
        if (_phase == Phase.MAIN) {
            _adController?.loadAdTagUrl(_url)
            val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleCode" to _scheduleCode)
            _eventBus?.trigger(EventName.bb_as_initialized, params)
            return true
        } else {
            return false
        }

        val phaseStr = "${phase}"
        val urlWithPhase = _url + "&phase=${phaseStr.encodeURLParameter()}"
        _adController?.loadAdTagUrl(urlWithPhase)

        if (_phase == Phase.PRE) {
            val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleCode" to _scheduleCode)
            _eventBus?.trigger(EventName.bb_as_initialized, params)
        }

        return true
    }

    fun play(phase: Phase): Boolean { // shouldPause?
        if (_disabled || _clipDisabled) return false // bail out
        var ret = false

        if (true) { // _okForCommercialBehaviour() && _okForClipDuration()) {
            ret = this.load(phase)
            if (ret) _adController?.play()
        }

        return ret
    }

    fun pause(): Boolean {
        return _adController?.pause() ?: false
    }

    fun resume(): Boolean {
        return _adController?.play() ?: false
    }

    private fun _getScheduleUrl (): String {
        val macroParams: MutableMap<String, String> = mutableMapOf()
        val phaseStrs: Set<String> = setOf("pre", "main")
        phaseStrs.forEach { // it: String
            val macros = _macros?.get(it)
            if (macros != null) {
                macros.forEach {
                    val resolvedValue = _adMacroHelper?.resolveMacro(it)
                    if (resolvedValue != null) {
                        macroParams[it.encodeURLParameter()] = resolvedValue // double encode is intentional so ad-scheduling-api resolves this correctly
                    }
                }
            }
        }
        var macrosJsonString = "{"
        macroParams.forEach {
            macrosJsonString += "\"${it.key}\":\"${it.value.replace("\\", "\\\\").replace("\"", "\\\"")}\","
        }
        macrosJsonString = macrosJsonString.replace(Regex(""",$"""), "") + "}" // fixes last comma

        return "${_baseUrl}/ad-scheduling/document/vmap/1.0" +
                "?scheduleCode=${_scheduleCode.encodeURLParameter()}" +
                "&clipLength=${_clipDuration.toString().encodeURLParameter()}" +
                "&macros=${macrosJsonString.encodeURLParameter()}"
    }

    private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>? = null) {
        if (opts != null) {
            // publication parameters
            if (opts.publicationData != null) {
                if (!opts.publicationData.baseurl.isNullOrEmpty()) _baseUrl = opts.publicationData.baseurl
            }

            // embed parameters
            if (opts.embedData != null) {
                if (!opts.embedData.baseurl.isNullOrEmpty()) _baseUrl = opts.embedData.baseurl
                if (!opts.embedData.queryString.isNullOrEmpty()) {
                    _queryStringParams =
                        opts.embedData.queryString.parseUrlEncodedParameters() // NB max 100 params!
                }
            }

            // playout settings
            if (opts.playoutData is Playout) {
                _ingestPlayoutData(opts.playoutData as Playout)
            }

            // override from options dict
            if ( options != null ) {
                if (options["commercials"] is String) _disabled = options["commercials"] as String == "false"
                if (options["commercials"] is Boolean) _disabled = options["commercials"] as Boolean == false

                if (options["adsystem_buid"] != null) _buid = options["adsystem_buid"] as? String
                if (options["adsystem_rdid"] != null) _rdid = options["adsystem_rdid"] as? String
                if (options["adsystem_idtype"] != null) _idtype = options["adsystem_idtype"] as? String
                if (options["adsystem_is_lat"] != null) _is_lat = options["adsystem_is_lat"] as? Boolean
                if (_uuid.isNullOrEmpty()) {
                    _uuid = _rdid
                }
//                if (_uuid.isNullOrEmpty()) {
//                    _uuid = localStorage?.get("uuid")
//                }
                if (_uuid.isNullOrEmpty()) {
                    _uuid = uuid4().toString()
                }

                if (options["consent_string"] is String) _consentString = options["consent_string"] as String
                if (options["consent_gdprApplies"] is Int) _consentGdprApplies = options["consent_gdprApplies"] as Int
                if (options["consent_cmpVersion"] is Int) _consentCmpVersion = options["consent_cmpVersion"] as Int

                _queryString = ""
                for (option in options) {
                    if (option.key.startsWith("macro_")) { // macro override
                        val optionValue = "${option.value}"
                        _queryString += "&${option.key.encodeURLParameter()}=${optionValue.encodeURLParameter()}"
                    }
                }
            }

            // content
            if (opts.adSchedulingData != null) {
                if (opts.adSchedulingData.scheduleId != null) _scheduleId = opts.adSchedulingData.scheduleId
                if (opts.adSchedulingData.scheduleCode != null) _scheduleCode = opts.adSchedulingData.scheduleCode; else _scheduleCode = _scheduleId.toString()
                if (opts.adSchedulingData.macros != null) _macros = opts.adSchedulingData.macros
            }
            if (opts.clipData != null) {
                _clipData = opts.clipData

                _clipId = _clipData?.id
                _clipTitle = _clipData?.title
                val deeplink: String? = _clipData?.deeplink
                _deeplink = (if (!deeplink.isNullOrEmpty()) deeplink else _clipData?.gendeeplink) ?: "" // NB!
                try {
                    _clipDuration = (_clipData?.length ?: "0").toDouble()
                } catch (e: Exception) {
                }
                _clipDisabled = _clipData?.disablecommercials == "true"
                _clipIsInArticle = _clipData?.mediatype == "inarticle" || _clipData?.mediatype == "mainroll"
            }

            _update()
        }
    }

    private fun _update() {
        val adMacroHelperSettings: MutableMap<String, Any?> = mutableMapOf()

//        adMacroHelperSettings["referrer"] = _referrer
        adMacroHelperSettings["deeplink"] = _deeplink
        adMacroHelperSettings["uuid"] = _uuid
        adMacroHelperSettings["width"] = _width // Number
        adMacroHelperSettings["height"] = _height // Number
        adMacroHelperSettings["clipId"] = _clipId
        adMacroHelperSettings["clipTitle"] = _clipTitle

        adMacroHelperSettings["buid"] = _buid
        adMacroHelperSettings["rdid"] = _rdid
        adMacroHelperSettings["idtype"] = _idtype
        adMacroHelperSettings["is_lat"] = _is_lat

        adMacroHelperSettings["consent_string"] = _consentString
        adMacroHelperSettings["consent_gdprApplies"] = _consentGdprApplies // Int
        adMacroHelperSettings["consent_cmpVersion"] = _consentCmpVersion // Int

        adMacroHelperSettings["queryString"] = _queryString

        _adMacroHelper?.updateSettings(adMacroHelperSettings)
    }

    private fun _ingestPlayoutData(playoutData: Playout) {
        if (playoutData.commercials != null) _disabled = (playoutData.commercials == "false")
        try {
            if (playoutData.width != null) _width = playoutData.width.toInt()
        } catch (e: Exception) {
        }
        try {
            if (playoutData.height != null) _height = playoutData.height.toInt()
        } catch (e: Exception) {
        }
        if (playoutData.adsystem_buid != null) _buid = playoutData.adsystem_buid
        if (playoutData.adsystem_rdid != null) _rdid = playoutData.adsystem_rdid
        if (playoutData.adsystem_idtype != null) _idtype = playoutData.adsystem_idtype
        if (playoutData.adsystem_is_lat != null) _is_lat =
            playoutData.adsystem_is_lat == "true" || playoutData.adsystem_is_lat == "1"
        if (_uuid.isNullOrEmpty()) {
            _uuid = _rdid
        }
//        if (_uuid.isNullOrEmpty()) {
//            _uuid = localStorage?.get("uuid")
//        }
        if (_uuid.isNullOrEmpty()) {
            _uuid = uuid4().toString()
        }
        // TODO: restriction_npaOnly
    }

    private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
        val playoutData = payload?.get("playoutData") as? Playout
        if (playoutData != null) {
            _ingestPlayoutData(playoutData)
        }
        _update()
    }

    private fun _onMediaClipLoaded(eventType: EventName, data: Map<String, Any?>?) {
        _perPositionAdCounter_clip = mutableMapOf()

        if (data != null) {
            _clipData = if (data["clipData"] != null) data["clipData"] as MediaClip else null

            _clipId = _clipData?.id
            _clipTitle = _clipData?.title
            val deeplink: String? = _clipData?.deeplink
            _deeplink = (if (!deeplink.isNullOrEmpty()) deeplink else _clipData?.gendeeplink) ?: "" // NB!
            try {
                _clipDuration = (_clipData?.length ?: "0").toDouble()
            } catch (e: Exception) {
            }
            _clipDisabled = _clipData?.disablecommercials == "true"
            _clipIsInArticle = _clipData?.mediatype == "inarticle" || _clipData?.mediatype == "mainroll"
        }

        _update()
    }

    private fun _onResized(eventType: EventName, data: Map<String, Any?>?) {
        if (data != null) {
            if (data["width"] != null) _width = data["width"] as Number
            if (data["height"] != null) _height = data["height"] as Number
        }
    }

    private fun _onAdLoaded(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdLoaded")

        var podIndex: Int? = null
        if (data != null && data["adPodInfo"] is Map<*,*>) {
            val adPodInfo = data["adPodInfo"] as Map<String, Any?>
            podIndex = adPodInfo["podIndex"] as Int? ?: 0
        }
        _adScheduleItemCode = "${_scheduleCode}#${podIndex}" // NB!
        Logger.d("AdSchedulingController", "_onAdLoaded _adScheduleItemCode: ${_adScheduleItemCode}")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_as_item_loaded, params)
    }

    private fun _onAdCanPlay(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdCanPlay")

        var podIndex: Int? = null
        if (data != null && data["adPodInfo"] is Map<*,*>) {
            val adPodInfo = data["adPodInfo"] as Map<String, Any?>
            podIndex = adPodInfo["podIndex"] as Int? ?: 0
        }
        _adScheduleItemCode = "${_scheduleCode}#${podIndex}" // NB!
        Logger.d("AdSchedulingController", "_onAdCanPlay _adScheduleItemCode: ${_adScheduleItemCode}")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties);
        _eventBus?.trigger(EventName.bb_as_item_canplay, params)

        if (_mediaSuspended) _adController?.play() // NB!
    }

    private fun _onAdStarted(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdStarted")
        if (_startCollapsed) {
            _eventBus?.trigger(EventName.bb_request_expand)
        }

        if (!_started) { // TEMPORARILY without checking phase
            _started = true
            var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
            if (data != null) {
                adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
            }
            val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
            _eventBus?.trigger(EventName.bb_as_started, params)
        }

        _onAdQuartile(EventName.adStarted, data) // NB after triggering bb_adsystem_started!
    }

    private fun _onAdQuartile(eventType: EventName, data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdQuartile")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        var quartile = "0"
        when (eventType) {
            EventName.adStarted -> quartile = "0"
            EventName.adFirstQuartile -> quartile = "1"
            EventName.adMidPoint -> quartile = "2"
            EventName.adThirdQuartile -> quartile = "3"
            EventName.adComplete -> quartile = "4"
            else -> quartile = "0"
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties, "quartile" to quartile)
        _eventBus?.trigger(EventName.bb_as_ad_quartile, params)
    }

    private fun _onAdClicked(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdClicked")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_as_ad_clicked, params)
    }

    private fun _onAdSkipped(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdSkipped")
        _perPositionAdCounter_clip[_pos] =
            (_perPositionAdCounter_clip[_pos] ?: 0) + 1
        _perPositionAdCounter_load[_pos] =
            (_perPositionAdCounter_load[_pos] ?: 0) + 1
        _perPositionAdCounter_sess[_pos] =
            (_perPositionAdCounter_sess[_pos] ?: 0) + 1

        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_as_item_skipped, params)
    }

    private fun _onAdComplete(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdComplete")

        _onAdQuartile(EventName.adComplete, data) // NB before triggering bb_adsystem_finished!

        _perPositionAdCounter_clip[_pos] =
            (_perPositionAdCounter_clip[_pos] ?: 0) + 1
        _perPositionAdCounter_load[_pos] =
            (_perPositionAdCounter_load[_pos] ?: 0) + 1
        _perPositionAdCounter_sess[_pos] =
            (_perPositionAdCounter_sess[_pos] ?: 0) + 1
    }

    private fun _onAllAdsCompleted(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAllAdsCompleted")

        if (_phase == Phase.MAIN) { // && _started) {
            _started = false
            var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
            if (data != null) {
                adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
            }
            val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
            _eventBus?.trigger(EventName.bb_as_finished, params)
        }

        if (_phase == Phase.PRE) {
            _eventBus?.trigger(EventName.bb_as_pre_finished)
        } else if (_phase == Phase.MAIN) {
            _eventBus?.trigger(EventName.bb_as_main_finished)
        }
    }

    private fun _onAdNoAd(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "_onAdNoAd")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_as_item_noad, params)
    }

    private fun _onAdFailed(data: Map<String, Any?>?) {
        Logger.d("AdSchedulingController", "onAdFailed")
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val params: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adScheduleItemCode" to _adScheduleItemCode, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_as_item_failed, params)
    }

    private fun _okForCommercialBehaviour(): Boolean {
        var ok = false;
        if (_clipIsInArticle) return true; // Allow replay for mainroll

        if (_commercialBehaviour == "Once per load") {
            ok = !((_perPositionAdCounter_load[_pos] ?: 0) > 0)
        } else if (_commercialBehaviour == "Once per session") {
            ok = !((_perPositionAdCounter_sess[_pos] ?: 0) > 0)
        } else { // Once per clip
            ok = !((_perPositionAdCounter_clip[_pos] ?: 0) > 0)
        }

        if (!ok) Logger.d("[AdSchedulingController] _okForCommercialBehaviour", "ok: " + (if (ok) "true" else "false"));
        return ok;
    }

    private fun _okForClipDuration(): Boolean {
        var ok = true;
        when (_pos) {
            PosType.PREROLL, PosType.VMAP -> {
                try {
                    if (_clipDuration > 0 && _clipDuration < (_minClipDurationPreroll ?: "0").toDouble()) ok = false;
                } catch (e: Exception) {
                }
                if (!ok) Logger.d("[AdSchedulingController] _okForClipDuration", "Not playing PREROLL, _minClipDurationPreroll = " + _minClipDurationPreroll);
            }
            PosType.POSTROLL -> {
                try {
                    if (_clipDuration > 0 && _clipDuration < (_minClipDurationPostroll ?: "0").toDouble()) ok = false
                } catch (e: Exception) {
                }
                if (!ok) Logger.d("[AdSchedulingController] _okForClipDuration", "Not playing POSTROLL, _minClipDurationPreroll = " + _minClipDurationPreroll);
            }
            else -> {}
        }

        return ok
    }
}
