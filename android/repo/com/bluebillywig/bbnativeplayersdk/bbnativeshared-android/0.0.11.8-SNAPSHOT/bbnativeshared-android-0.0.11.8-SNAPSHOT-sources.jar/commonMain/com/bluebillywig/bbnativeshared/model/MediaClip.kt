package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
@SerialName("MediaClip")
data class MediaClip (
    override val id: String? = null,
    override val title: String? = null,
    override val deeplink: String? = null,
    val gendeeplink: String? = null,
    val sourcetype: String? = null,
    var length: String? = null, // why var?
    val mediatype: String? = null,

    val mediatype_override: String? = null,
    val fitmode: String? = null,
    val usetype: String? = null,
    val useThumbsFromMetadata: String? = null,
    val location: String? = null,
    val originalfilename: String? = null,
    val sourceid: String? = null,
    val description: String? = null,
    val copyright: String? = null,
    val author: String? = null,
    val status: String? = null,
    // val publicationid: String? = null, //sometimes string sometimes array with 1 string
    val createddate: String? = null,
    val updateddate: String? = null,
    val publisheddate: String? = null,
    // val views: Long? = null,
    val width: Long? = null,
    val height: Long? = null,
    val dar: String? = null,
    val originalWidth: Long? = null,
    val originalHeight: Long? = null,
    val date: Dates? = null,
    val src: String? = null,
    val cat: List<String>? = null,
    val thumbnails: List<Thumbnail>? = null,
    val movingThumbnails: List<Thumbnail>? = null,
    val assets: List<MediaAsset>? = null,
    val hasJobs: String? = null,
    val hasFailedJobs: Boolean? = null,
    val hasRunningJobs: Boolean? = null,
    val hasNewJobs: Boolean? = null,
    val transcodingFinished: Boolean? = null,
    val isYoutubeImport: Boolean? = null,
    val subtitles: List<Subtitle>? = null,
    val subtitletracks: List<Subtitle>? = null,
    val transcript: String? = null,
//    val nametags: Any? = null,
//    val exports: Any? = null,
    val timelineId: String? = null,
    val timelines: List<Timeline>? = null,
//    val adunits: Any? = null,
    val audiotracks: List<Audiotrack>? = null,

    @SerialName("youtubeImportId")
    val youtubeImportID: String? = null,

    val importSource: String? = null,

    @SerialName("importUrl")
    val importURL: String? = null,

    val disablecommercials: String? = null,
    val isDynamic: String? = null,
    val checkbox: String? = null,
    val comment: String? = null,
    val chapters: List<Chapter>? = null,
    val highlights: List<Highlight>? = null,
    val softEmbargo: String? = null,
//    val playoutoverride: Any? = null,
    val isOutro: String? = null,

    val cpRuleViolations: List<String>? = null,
    val cpp: String? = null,

    var projectId: String? = null
): ContentItem(), ContentItemInterface {
    constructor(id: String, title: String? = null, deeplink: String? = null, gendeeplink: String? = null, sourcetype: String? = null, length: String? = null, mediatype: String? = null, usetype: String? = null) : this(id, title, deeplink, gendeeplink, sourcetype, length, mediatype, null, null, usetype, null)
}

@Serializable
data class Dates (
    val created: String? = null,
    val updated: String? = null,
    val published: String? = null
)

