package com.bluebillywig.bbnativeshared.interfaces

/**
 * @suppress
 */
interface ContentItemInterface {
	val id: String?
	val title: String?
	val deeplink: String?
}
