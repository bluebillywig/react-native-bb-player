package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import kotlinx.serialization.internal.*

@Serializable
@SerialName("Project")
data class Project (
    override val id: String? = null,
    override val title: String? = null,
    override val deeplink: String? = null,
    //val publicationid: String? = null, //sometimes string sometimes array with 1 string
    val status: String? = null,
    val createddate: String? = null,
    val thumbnails: List<Thumbnail>? = null,
    val name: String? = null,
    val createdBy: String? = null,
    val updateddate: String? = null,
    val updatedBy: String? = null,
    val subtype: String? = null,
    val cat: List<String>? = null,
    val clipCount: Long? = null,
    val publisheddate: String? = null,
    val useGaplessPlayback: Boolean? = null,
    val distribution: String? = null,
    val goal: String? = null,
    val useGaplessMetadata: Boolean? = null,
    val useThumbsFromMetadata: String? = null,
    val noIntroClip: Boolean? = null,
    val analysis: String? = null,
    val description: String? = null,
    val author: String? = null,
    val copyright: String? = null,
    val transcript: String? = null,
    val label: String? = null,
    val chapters: List<Chapter>? = null,
    //val media: ProjectMedia? = null,

    val timelineId: String? = null,
    val timelines: List<Timeline>? = null,

    val cpRuleViolations: List<String>? = null,
    val cpp: String? = null,

    val mainMediaClipId: String? = null,
    var mainMediaClipData: MediaClip? = null
): ContentItem(), ContentItemInterface {
    constructor(id: String, title: String? = null, deeplink: String? = null) : this(id, title, deeplink, null)
}
