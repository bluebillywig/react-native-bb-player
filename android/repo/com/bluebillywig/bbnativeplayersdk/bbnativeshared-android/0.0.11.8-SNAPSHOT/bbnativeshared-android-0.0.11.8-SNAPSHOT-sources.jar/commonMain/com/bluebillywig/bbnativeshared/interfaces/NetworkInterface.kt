package com.bluebillywig.bbnativeshared.interfaces

/**
 * @suppress
 */
interface NetworkInterface {
    fun getJsonString(jsonUrl: String, onSuccess: (retObject: String) -> Unit, onFailure: (error: Boolean) -> Unit): Unit
    fun getJsonStringAndHeaders(jsonUrl: String, onSuccess: (retObject: String, responseHeaders: Map<String, List<String>>) -> Unit, onFailure: (error: Boolean) -> Unit): Unit {
        getJsonString(jsonUrl, { retObject -> onSuccess(retObject, mapOf()) }, onFailure)
    } // optional

    fun logStats(url: String, onSuccess: () -> Unit, onFailure: (error: Boolean) -> Unit): Unit

    fun __destruct(): Unit
}
