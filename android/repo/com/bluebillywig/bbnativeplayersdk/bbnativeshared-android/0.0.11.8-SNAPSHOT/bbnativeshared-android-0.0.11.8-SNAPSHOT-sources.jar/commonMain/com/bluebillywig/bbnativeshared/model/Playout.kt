package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.enums.FitMode
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject

@Serializable
data class Playout (
    val id: String? = null,
    val main: String? = null,
    // val publicationid: String? = null, // sometimes string sometimes array with 1 string
    val type: String? = null,
    val name: String? = null,
    val status: String? = null,
    val createddate: String? = null,
    val updateddate: String? = null,
    val label: String? = null,
    val publication: String? = null,
    val player: Player? = null,
    val playerid: String? = null,
    val centerButtonType: String? = null, // icon | round | square | border | outline | inversed
    val cornerRadius: String? = null,
    val responsiveSizing: String? = null,
    val aspectRatio: String? = null,
    val width: String? = null,
    val height: String? = null,
    val autoHeight: String? = null,
    val alphaControlBar: String? = null,
    val skin_backgroundColor: String? = null,
    val skin_foregroundColor: String? = null,
    val skin_widgetColor: String? = null,
    val bgColor: String? = null,
    val logoId: String? = null,
    val logoAlign: String? = null,
    val logoClickUrl: String? = null,
    val controlBar: String? = null,
    val controlBarPlacement: String? = null,
    val timeDisplay: String? = null,
    val timeLine: String? = null,
    val muteButton: String? = null,
    val volume: String? = null,
    val volumeOrientation: String? = null,
    val languageSelect: String? = null,
    val qualitySelector: String? = null,
    val playbackRateSelector: String? = null,
    val fullScreen: String? = null,
    val showStartControlBar: String? = null,
    val shareButton: String? = null,
    val shareButtonPause: String? = null,
    val shareButtonEnd: String? = null,
    val shareButtonEmbedCode: String? = null,
    val shareButtonEmail: String? = null,
    val shareButtonFacebook: String? = null,
    val shareButtonLinkedIn: String? = null,
    val shareButtonPinterest: String? = null,
    val shareButtonTwitter: String? = null,
    val shareButtonWhatsApp: String? = null,
    val castButton: String? = null,
    val showBigPlayButton: String? = null,
    val showBigReplayButton: String? = null,
    val title: String? = null,
    val date: String? = null,
    val authorCopyright: String? = null,
    val authorCopyrightAlign: String? = null,
    val authorCopyrightPrefixText: String? = null,
    val autoPlayNext: String? = null,
    val relatedItems: String? = null,
    val relatedItemsPause: String? = null,
    val useDeeplinkForRelatedItems: String? = null,
    val useDeeplinkForRelatedItemsPause : String? = null,
    val exitscreenItemsListId: String? = null,
    val randomizeRelatedItems: String? = null,
    val useDeeplinkForFacebook: String? = null,
    val shareTwitterText: String? = null,
    val sharePlayout: String? = null,
    val skinBehaviour: String? = null,
    val skinOnTimeline: String? = null,
    val nativeControls: String? = null,
    val youTubeHosting: String? = null,
    val youTubeSkinInMainPhase: String? = null,
    val forceNativeFullscreen: String? = null,
    val preferHD: String? = null,
    val nedStatLoggerUrl: String? = null,
    val googleAnalyticsId: String? = null,
    val piwikUrl: String? = null,
    val piwikSiteId: String? = null,
    val disableCookies: String? = null,
    val disableContextMenuNavigate: String? = null,
    val playerSignature: String? = null,
    val playerSignatureLink: String? = null,
    val autoPlay: String? = null,
    val autoMute: String? = null,
    val autoMuteIfNeededForAutoPlay: String? = null,
    val autoLoop: String? = null,

    @SerialName("float_player")
    val floatPlayer: String? = null,

    @SerialName("interactivity_inView")
    val interactivityInView: String? = null,

    @SerialName("interactivity_outView")
    val interactivityOutView: String? = null,

    val inviewMargin: String? = null,
    val textAbovePlayer: String? = null,
    val textCommercialSkip: String? = null,
    val startCollapsed: String? = null,
    val playInOverlay: String? = null,
    val hidePlayerOnEnd: String? = null,
    val waitForApproval: String? = null,

    @SerialName("interactivity_mouseIn")
    val interactivityMouseIn: String? = null,

    @SerialName("interactivity_mouseOut")
    val interactivityMouseOut: String? = null,

    @SerialName("interactivity_onClick")
    val interactivityOnClick: String? = null,

    @SerialName("clickUrl")
    val clickURL: String? = null,

    val nsiNoAutoPlay: String? = null,
    val nsiNoPlayer: String? = null,
    val placementOption: String? = null,
    val placementDOMSelector: String? = null,
    val iframeBreakout: String? = null,
    val clearBothOption: String? = null,
    val forceInview: String? = null,
    val customCode: String? = null, // OBSOLETE
    val preferFlashPlayback: String? = null,
    val preloadMainroll: String? = null,
    val disableHtml5VPAID: String? = null,
    val enableHtml5VPAID: String? = null,
    val commercialPauseButton: String? = null,
    val commercialMuteButton: String? = null,
    var commercialAdIcon: String? = null,
    val commercialProgressBar: String? = null,
    val commercialProgressBarColor: String? = null,
    val commercials: String? = null,
    val textCommercialTimeRemaining: String? = null,
    val commercialBehaviour: String? = null,
    val minClipDurationPreroll: String? = null,
    val minClipDurationPostroll: String? = null,
    val allowBBIma: String? = null,
    val fitmode: FitMode? = FitMode.FIT_BOTH,
    val mobileRotateOnFullScreenMismatch: String? = null,
    val noStats: String? = null,
    val forceAndroidNativeVideo: String? = null,
    val forceIOSNativeVideo: String? = null,

    @SerialName("use2018skin")
    val use2018Skin: String? = null,

    val useThumbsFromMetadata: String? = null,

    val audioTrackSelect: String? = null,
    val shareText: String? = null,
    val shareButtonDirectLink: String? = null,

    @SerialName("googleAnalytics_customVars")
    val googleAnalyticsCustomVars: String? = null,

    val supportIABConsent: String? = null,

    @SerialName("restriction_npaOnly")
    val restrictionNpaOnly: String? = null,

    @SerialName("restriction_npcOnly")
    val restrictionNpcOnly: String? = null,

    val defaultSubtitle: String? = null,
    val defaultSubtitleOnlyIfMuted: String? = null,
    val defaultAudioTrack: String? = null,
    val forceCanAutoPlay: String? = null,
    val avoidMutedAutoplay: String? = null,
    val stickyMode: String? = null,
    val disableKeyboardControls: String? = null,
    val taggingDisabled: String? = null,
    val skipOffset: String? = null,
    val skipCounterText: String? = null,
    val skipButtonText: String? = null,
    val blockInsecureVPAID: String? = null,
    val shareButtonGooglePlus: String? = null,

    val timelineId: String? = null,
    val templateId: String? = null,

    val adunits: JsonArray? = null,
    val hasAdunits: Boolean? = null,
    val adunitsPreroll: List<AdUnit>? = null,

    val ignoreSingleMediaResource: String? = null,
    val ignoreProjectMetadata: String? = null,
    val noPosterInExitPhase: String? = null,

    val logProgressAsQuartiles: String? = null,
    val autoPauseAfterPrePhase: String? = null,
    val autoPlayOnlyWithPrerollAd: String? = null,
    val showOnlyWhenPrerollAvailable: String? = null,

    val showBigPauseButtons: String? = null,
    val titlePause: String? = null,
    val authorCopyrightPause: String? = null,
    val authorCopyrightAlignPause: String? = null,
    val authorCopyrightPrefixTextPause: String? = null,
    val showStartDuration: String? = null,
    val disableMovingThumbnail: String? = null,
    val shareButtonHover: String? = null,
    val showBigHoverButtons: String? = null,
    val titleHover: String? = null,
    val authorCopyrightHover: String? = null,
    val titleEnd: String? = null,
    val authorCopyrightEnd: String? = null,

    val softEmbargoCustomPosterClipId: String? = null,
    val softEmbargoFontColor: String? = null,
    val softEmbargoHasCustomPoster: String? = null,
    val softEmbargoText: String? = null,
    val softEmbargoTimerHidden: String? = null,

    val adsystem_buid: String? = null,
    val adsystem_rdid: String? = null,
    val adsystem_idtype: String? = null,
    val adsystem_is_lat: String? = null,

    val swipeDirection: String? = null, // horizontal | vertical
    val hideSwipeControls: String? = null, // true | false
    @SerialName("description")
    val descriptionShowHide: String? = null, // Show | Hide
    val showPlayButton: String? = null, // true | false
    val autoLoopClip: String? = null, // true | false

    val shortsId: String? = null,
    val adunitId: String? = null,
    val clipAdInterval: String? = null,
    val firstAdPosition: String? = null,
    val assetPreloadWindow: String? = null,

    val placeholderText: String? = null,
    val placeholderTextColor: String? = null,
    val ctaExitScreen: String? = null,
    val ctaMidplay: String? = null,
    val ctaMidplayPosition: String? = null,
    val ctaText: String? = null,
    val ctaTextColor: String? = null,
    val ctaBackgroundColor: String? = null,

    val ctaUrlField: String? = null,
    val ctaButtonText: String? = null,
    val ctaButtonLabelField: String? = null,
    val ctaButtonUseAccentColor: String? = null,
    val ctaButtonPosition: String? = null,

    val eventHandlers: List<EventHandler>? = null,

//    Example of a value that will not be used in Serialisation
//    @Transient
//    val options: Map<String, Any?>? = null
)

@Serializable
data class EventHandler (
    val name: String? = null,
    val procedures: List<Procedure>? = null
)

@Serializable
data class Procedure (
    val id: String? = null,
    val condition: Condition? = null,
    val actions: List<Action>? = null,

    @SerialName("else_actions")
    val elseActions: JsonArray? = null,

    val type: String? = null
)

@Serializable
data class Action (
    val id: String? = null,
    val entity: String? = null,
    val command: String? = null,
    val parameters: List<Parameter>? = null
)

@Serializable
data class Parameter (
    val name: String? = null,
    val value: String? = null
)

@Serializable
data class Condition (
    val variables: JsonObject? = null,
    val expression: String? = null
)
