package com.bluebillywig.bbnativeshared.data

data class Language (
	var iso: String? = null,
	var translations: MutableMap<String, String> = mutableMapOf()
)

class Languages private constructor() {

	private var _languages: MutableList<Language> = mutableListOf<Language>()

	companion object {
		val instance:Languages by lazy {
			Languages()
		}
		fun translate (iso: String, text: String): String {
			return Languages.instance.translate(iso, text)
		}
	}

	// initialize languages and translation strings
	init {
		//------------------------------------------
		val nl = Language(
			iso = "nl",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Verbonden met",
				"Learn more" to "Meer informatie",
				"Playing on" to "Speelt op",
				"Related videos" to "Gerelateerde video's",
				"Related" to "Gerelateerd",
				"Up next in" to "Video begint over",
				"Up next" to "Hierna",
				"Cancel" to "Annuleren",
				"Off" to "Uit",
				"Skip" to "Doorgaan",
				"Normal" to "Normaal",
				"Logo" to "Logo",
				"Live" to "Live",
				"Live in" to "Live over",
				"Interactive" to "Interactief",
				"Image" to "Afbeelding",
				"Author" to "Auteur",
				"Source" to "Bron",
				"Play now" to "Nu afspelen",
				"Media not available" to "Media niet beschikbaar",
				"Replay" to "Opnieuw afspelen",
				"Unmute" to "Geluid aanzetten",
				"Blue Billywig video player" to "Blue Billywig video player",
				"live" to "live",
				"logo" to "logo",
				"Main menu" to "Hoofdmenu",

				// Player controls
				"Playback" to "Afspelen",
				"Playback speed" to "Afspeelsnelheid",
				"Speed" to "Snelheid",
				"Volume Up" to "Volume omhoog",
				"Volume Down" to "Volume omlaag",
				"Volume Off" to "Geluid gedempt",
				"Volume On" to "Geluid aan",

				// Settings and menus
				"Language" to "Taal",
				"Quality" to "Kwaliteit",
				"Accessibility" to "Toegankelijkheid",
				"Chapters" to "Hoofdstukken",
				"Highlights" to "Hoogtepunten",
				"Select chapter" to "Selecteer hoofdstuk",
				"Select highlight" to "Selecteer hoogtepunt",
				"Search video" to "Doorzoek video",

				// Subtitles and accessibility features
				"Subtitles" to "Ondertiteling",
				"Subtitle" to "Ondertiteling",
				"Subtitles on" to "Ondertiteling aan",
				"Subtitles off" to "Ondertiteling uit",
				"Transcript" to "Uitgeschreven tekst",
				"Transcript on" to "Transcript aan",
				"Transcript off" to "Transcript uit",
				"Toggle transcript" to "Transcript aan/uitzetten",
				"Audio description" to "Audiobeschrijving",
				"Audio description on" to "Audiobeschrijving aan",
				"Audio description off" to "Audiobeschrijving uit",
				"Sign language" to "Gebarentaal",
				"Sign language on" to "Gebarentaal aan",
				"Sign language off" to "Gebarentaal uit",
				"Audiotrack" to "Audiotrack",
				"Audiotracks" to "Audiotracks",

				// Sharing
				"Share this video" to "Deel deze video",
				"Share video" to "Deel video",
				"Embed" to "Embed",
				"Email" to "E-mail",
				"Copy URL" to "Kopieer URL",
				"Embedcode copied to clipboard" to "De embed code is gekopieerd naar het klembord",
				"Link copied to clipboard" to "De link is gekopieerd naar het klembord",
				"Failed to copy to clipboard" to "Het is niet gelukt om te kopiëren naar het klembord",

				// Downloads
				"Download" to "Download",
				"Downloads" to "Downloads",
				"Video files" to "Videobestanden",
				"Audio files" to "Audiobestanden",
				"Text files" to "Textbestanden",
				"Source video" to "Bronvideo",

				// Time units
				"day" to "dag",
				"days" to "dagen",
				"hour" to "uur",
				"hours" to "uur",
				"minute" to "minuut",
				"minutes" to "minuten",
				"second" to "seconde",
				"seconds" to "seconden",
				"at" to "om",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Toetsenbord sneltoetsen",
				"Enable keyboard shortcuts" to "Toetsenbord sneltoetsen inschakelen",
				"Disable keyboard shortcuts" to "Toetsenbord sneltoetsen uitschakelen",
				"Keyboard shortcuts off" to "Toetsenbord sneltoetsen uit",
				"Shortkey" to "Sneltoets",
				"Space" to "Spatie",
				"Press question mark for keyboard shortcuts" to "Druk op vraagteken voor toetsenbord sneltoetsen",

				// Input labels
				"Volume input" to "Volume input",
				"Time input" to "Tijd input",

				// Live features
				"Set reminder" to "Herinnering instellen",
				"Reminder set" to "Herinnering ingesteld",
				"AutomaticallyFollowText" to "Automatisch tekst volgen",
				"StartAt" to "Beginnen bij",
				"ShareStartAtTimeAriaLabel" to "Beginnen bij {time}",

				// ARIA labels
				"aria-settingsButton" to "Open instellingen menu/Sluit instellingen menu",
				"aria-chapterButton" to "Open hoofdstukken menu/Sluit hoofdstukken menu",
				"aria-accessibilityButton" to "Open toegankelijkheidsmenu/Sluit toegankelijkheidsmenu",
				"aria-castButton" to "Start casten/Stop casten",
				"aria-close" to "Sluiten",
				"aria-clearSearch" to "Zoekveld leegmaken",

				// Tooltip labels
				"tooltip-playPauseButton" to "Afspelen/Pauzeren",
				"tooltip-replayButton" to "Opnieuw afspelen",
				"tooltip-playNext" to "Volgende video afspelen",
				"tooltip-forwardVideo" to "10 seconden doorspoelen",
				"tooltip-rewindVideo" to "10 seconden terugspoelen",
				"tooltip-increasePlaybackRate" to "Verhoog de afspeelsnelheid",
				"tooltip-decreasePlaybackRate" to "Verlaag de afspeelsnelheid",
				"tooltip-muteButton" to "Geluid dempen/Geluid aanzetten",
				"tooltip-castButton" to "Casten/Stoppen met casten",
				"tooltip-fullscreenButton" to "Volledig scherm/Volledig scherm sluiten",
				"tooltip-accessibilityButton" to "Toegankelijkheidsmenu",
				"tooltip-subtitleButton" to "Zet ondertitels aan/Zet ondertitels uit",
				"tooltip-transcriptButton" to "Zet uitgeschreven tekst aan/Zet uitgeschreven tekst uit",
				"tooltip-audioDescriptionButton" to "Zet audiodescriptie aan/Zet audiodescriptie uit",
				"tooltip-signLanguageButton" to "Zet gebarentaal aan/Zet gebarentaal uit",
				"tooltip-settingsButton" to "Instellingen",
				"tooltip-shareButton" to "Delen",
				"tooltip-chapterButton" to "Hoofdstukken",
				"tooltip-close" to "Sluiten",
				"tooltip-previousRelatedButton" to "Ga naar vorige gerelateerde video's",
				"tooltip-nextRelatedButton" to "Ga naar volgende gerelateerde video's",
				"tooltip-shareEmbed" to "Deel via embed code",
				"tooltip-shareEmail" to "Deel via e-mail",
				"tooltip-shareWhatsApp" to "Deel op WhatsApp",
				"tooltip-shareFacebook" to "Deel op Facebook",
				"tooltip-shareTwitter" to "Deel op X",
				"tooltip-shareLinkedIn" to "Deel op LinkedIn",
				"tooltip-sharePinterest" to "Deel op Pinterest",
				"tooltip-cancel" to "Annuleren",
				"tooltip-goToLive" to "Ga naar live uitzending",
				"tooltip-highlights" to "Hoogtepunten",

				// State announcements
				"Playing" to "Speelt af",
				"Paused" to "Gepauzeerd",
				"Fullscreen" to "Volledig scherm",
				"Exited fullscreen" to "Volledig scherm afgesloten",

				// Error and loading announcements
				"Loading" to "Laden",
				"Buffering" to "Bufferen",
				"Advertisement" to "Advertentie",
				"Resuming video" to "Video hervatten",
				"Video ended" to "Video afgelopen",

				// Scrub bar
				"Video progress" to "Video voortgang",
				"of" to "van",

				// Shorts
				"Next short" to "Volgende short",
				"Previous short" to "Vorige short",

				// Player container
				"Video player" to "Videospeler",
			)
		)
		_languages.add(nl)
		val fy = Language(
			iso = "fy",
			translations = nl.translations
		)
		_languages.add(fy)

		//------------------------------------------
		val en = Language(
			iso = "en",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Connected to",
				"Learn more" to "Learn more",
				"Playing on" to "Playing on",
				"Related videos" to "Related videos",
				"Related" to "Related",
				"Up next in" to "Up next in",
				"Up next" to "Up next",
				"Cancel" to "Cancel",
				"Off" to "Off",
				"Skip" to "Skip",
				"Normal" to "Normal",
				"Logo" to "Logo",
				"Live" to "Live",
				"Live in" to "Live in",
				"Interactive" to "Interactive",
				"Image" to "Image",
				"Author" to "Author",
				"Source" to "Source",
				"Play now" to "Play now",
				"Media not available" to "Media not available",
				"Replay" to "Replay",
				"Unmute" to "Unmute",
				"Blue Billywig video player" to "Blue Billywig video player",
				"live" to "live",
				"logo" to "logo",
				"Main menu" to "Main menu",

				// Player controls
				"Playback" to "Playback",
				"Playback speed" to "Playback speed",
				"Speed" to "Speed",
				"Volume Up" to "Volume up",
				"Volume Down" to "Volume down",
				"Volume Off" to "Muted",
				"Volume On" to "Unmuted",

				// Settings and menus
				"Language" to "Language",
				"Quality" to "Quality",
				"Accessibility" to "Accessibility",
				"Chapters" to "Chapters",
				"Highlights" to "Highlights",
				"Select chapter" to "Select chapter",
				"Select highlight" to "Select highlight",
				"Search video" to "Search video",

				// Subtitles and accessibility features
				"Subtitles" to "Subtitle",
				"Subtitle" to "Subtitle",
				"Subtitles on" to "Subtitles on",
				"Subtitles off" to "Subtitles off",
				"Transcript" to "Transcript",
				"Transcript on" to "Transcript on",
				"Transcript off" to "Transcript off",
				"Toggle transcript" to "Toggle transcript",
				"Audio description" to "Audio description",
				"Audio description on" to "Audio description on",
				"Audio description off" to "Audio description off",
				"Sign language" to "Sign language",
				"Sign language on" to "Sign language on",
				"Sign language off" to "Sign language off",
				"Audiotrack" to "Audio track",
				"Audiotracks" to "Audio tracks",

				// Sharing
				"Share this video" to "Share this video",
				"Share video" to "Share video",
				"Embed" to "Embed",
				"Email" to "Email",
				"Copy URL" to "Copy URL",
				"Embedcode copied to clipboard" to "Embed code copied to clipboard",
				"Link copied to clipboard" to "Link copied to clipboard",
				"Failed to copy to clipboard" to "Failed to copy to clipboard",

				// Downloads
				"Download" to "Download",
				"Downloads" to "Downloads",
				"Video files" to "Video files",
				"Audio files" to "Audio files",
				"Text files" to "Text files",
				"Source video" to "Source video",

				// Time units
				"day" to "day",
				"days" to "days",
				"hour" to "hour",
				"hours" to "hours",
				"minute" to "minute",
				"minutes" to "minutes",
				"second" to "second",
				"seconds" to "seconds",
				"at" to "at",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Keyboard shortcuts",
				"Enable keyboard shortcuts" to "Enable keyboard shortcuts",
				"Disable keyboard shortcuts" to "Disable keyboard shortcuts",
				"Keyboard shortcuts off" to "Keyboard shortcuts off",
				"Shortkey" to "Shortkey",
				"Space" to "Space",
				"Press question mark for keyboard shortcuts" to "Press question mark for keyboard shortcuts",

				// Input labels
				"Volume input" to "Volume input",
				"Time input" to "Time input",

				// Live features
				"Set reminder" to "Set reminder",
				"Reminder set" to "Reminder set",
				"AutomaticallyFollowText" to "Automatically follow text",
				"StartAt" to "Start at",
				"ShareStartAtTimeAriaLabel" to "Start at {time}",

				// ARIA labels
				"aria-settingsButton" to "Open settings menu/Close settings menu",
				"aria-chapterButton" to "Open chapters menu/Close chapters menu",
				"aria-accessibilityButton" to "Open accessibility menu/Close accessibility menu",
				"aria-castButton" to "Start casting/Stop casting",
				"aria-close" to "Close",
				"aria-clearSearch" to "Clear search field",

				// Tooltip labels
				"tooltip-playPauseButton" to "Play/Pause",
				"tooltip-replayButton" to "Replay",
				"tooltip-playNext" to "Play next video",
				"tooltip-forwardVideo" to "Forward 10 seconds",
				"tooltip-rewindVideo" to "Rewind 10 seconds",
				"tooltip-increasePlaybackRate" to "Increase playback rate",
				"tooltip-decreasePlaybackRate" to "Decrease playback rate",
				"tooltip-muteButton" to "Mute/Unmute",
				"tooltip-castButton" to "Cast",
				"tooltip-fullscreenButton" to "Fullscreen/Close fullscreen",
				"tooltip-accessibilityButton" to "Accessibility menu",
				"tooltip-subtitleButton" to "Turn on subtitles/Turn off subtitles",
				"tooltip-transcriptButton" to "Turn on transcript/Turn off transcript",
				"tooltip-audioDescriptionButton" to "Turn on audio description/Turn off audio description",
				"tooltip-signLanguageButton" to "Turn on sign language/Turn off sign language",
				"tooltip-settingsButton" to "Settings",
				"tooltip-shareButton" to "Share",
				"tooltip-chapterButton" to "Chapters",
				"tooltip-close" to "Close",
				"tooltip-previousRelatedButton" to "Go to previous related videos",
				"tooltip-nextRelatedButton" to "Go to next related videos",
				"tooltip-shareEmbed" to "Share by embed code",
				"tooltip-shareEmail" to "Share by email",
				"tooltip-shareWhatsApp" to "Share on WhatsApp",
				"tooltip-shareFacebook" to "Share on Facebook",
				"tooltip-shareTwitter" to "Share on X",
				"tooltip-shareLinkedIn" to "Share on LinkedIn",
				"tooltip-sharePinterest" to "Share on Pinterest",
				"tooltip-cancel" to "Cancel",
				"tooltip-goToLive" to "Skip ahead to live broadcast",
				"tooltip-highlights" to "Highlights",

				// State announcements
				"Playing" to "Playing",
				"Paused" to "Paused",
				"Fullscreen" to "Fullscreen",
				"Exited fullscreen" to "Exited fullscreen",

				// Error and loading announcements
				"Loading" to "Loading",
				"Buffering" to "Buffering",
				"Advertisement" to "Advertisement",
				"Resuming video" to "Resuming video",
				"Video ended" to "Video ended",

				// Scrub bar
				"Video progress" to "Video progress",
				"of" to "of",

				// Shorts
				"Next short" to "Next short",
				"Previous short" to "Previous short",

				// Player container
				"Video player" to "Video player",
			)
		)
		_languages.add(en)

		//------------------------------------------
		val sv = Language(
			iso = "sv",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Ansluten till",
				"Learn more" to "Läs mer",
				"Playing on" to "Spelar på",
				"Related videos" to "Relaterade videos",
				"Related" to "Relaterad",
				"Up next in" to "Nästa video",
				"Up next" to "Nästa",
				"Cancel" to "Avbryt",
				"Off" to "Av",
				"Skip" to "Hoppa över",
				"Normal" to "Normal",
				"Logo" to "Logo",
				"Live" to "Live",
				"Live in" to "Live om",
				"Interactive" to "Interaktiv",
				"Image" to "Bild",
				"Author" to "Upphovsman",
				"Source" to "Källa",
				"Play now" to "Spela nu",
				"Media not available" to "Media inte tillgängligt",
				"Replay" to "Se igen",
				"Unmute" to "Ljud på",
				"Blue Billywig video player" to "Blue Billywig videospelare",
				"live" to "direktsändning",
				"logo" to "logotyp",
				"Main menu" to "Huvudmeny",

				// Player controls
				"Playback" to "Uppspelning",
				"Playback speed" to "Uppspelningshastighet",
				"Speed" to "Hastighet",
				"Volume Up" to "Volym upp",
				"Volume Down" to "Volym ned",
				"Volume Off" to "Ljud av",
				"Volume On" to "Ljud på",

				// Settings and menus
				"Language" to "Språk",
				"Quality" to "Kvalite",
				"Accessibility" to "Tillgänglighet",
				"Chapters" to "Kapitel",
				"Highlights" to "Höjdpunkter",
				"Select chapter" to "Välj kapitel",
				"Select highlight" to "Välj höjdpunkt",
				"Search video" to "Sök video",

				// Subtitles and accessibility features
				"Subtitles" to "Undertexter",
				"Subtitle" to "Undertexter",
				"Subtitles on" to "Undertexter på",
				"Subtitles off" to "Undertexter av",
				"Transcript" to "Transkriberad text",
				"Transcript on" to "Transkript på",
				"Transcript off" to "Transkript av",
				"Toggle transcript" to "Växla transkript",
				"Audio description" to "Ljudbeskrivning",
				"Audio description on" to "Ljudbeskrivning på",
				"Audio description off" to "Ljudbeskrivning av",
				"Sign language" to "Teckenspråk",
				"Sign language on" to "Teckenspråk på",
				"Sign language off" to "Teckenspråk av",
				"Audiotrack" to "Ljudspår",
				"Audiotracks" to "Ljudspår",

				// Sharing
				"Share this video" to "Dela video",
				"Share video" to "Dela video",
				"Embed" to "Inbäddningskod",
				"Email" to "E-mail",
				"Copy URL" to "Kopiera URL",
				"Embedcode copied to clipboard" to "Inbäddningskoden har kopierats till urklipp",
				"Link copied to clipboard" to "Länken har kopierats till urklipp",
				"Failed to copy to clipboard" to "Det gick inte att kopiera till urklipp",

				// Downloads
				"Download" to "Ladda ner",
				"Downloads" to "Nedladdningar",
				"Video files" to "Videofiler",
				"Audio files" to "Ljudfiler",
				"Text files" to "Textfiler",
				"Source video" to "Källvideo",

				// Time units
				"day" to "dag",
				"days" to "dagar",
				"hour" to "timme",
				"hours" to "timmar",
				"minute" to "minut",
				"minutes" to "minuter",
				"second" to "sekund",
				"seconds" to "sekunder",
				"at" to "kl",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Tangentbordsgenvägar",
				"Enable keyboard shortcuts" to "Aktivera tangentbordsgenvägar",
				"Disable keyboard shortcuts" to "Inaktivera tangentbordsgenvägar",
				"Keyboard shortcuts off" to "Tangentbordsgenvägar av",
				"Shortkey" to "Genväg",
				"Space" to "Mellanslag",
				"Press question mark for keyboard shortcuts" to "Tryck på frågetecken för tangentbordsgenvägar",

				// Input labels
				"Volume input" to "Volymingång",
				"Time input" to "Tidsinmatning",

				// Live features
				"Set reminder" to "Ställ påminnelse",
				"Reminder set" to "Påminnelse ställt",
				"AutomaticallyFollowText" to "Följ text automatiskt",
				"StartAt" to "Starta vid",
				"ShareStartAtTimeAriaLabel" to "Starta vid {time}",

				// ARIA labels
				"aria-settingsButton" to "Öppna inställningsmenyn/Stäng inställningsmenyn",
				"aria-chapterButton" to "Öppna inställningarna för kapitel/Stäng inställningarna för kapitel",
				"aria-accessibilityButton" to "Öppna tillgänglighetsmeny/Stäng tillgänglighetsmeny",
				"aria-castButton" to "Börja casta/Sluta casta",
				"aria-close" to "Stäng",
				"aria-clearSearch" to "Rensa sökfält",

				// Tooltip labels
				"tooltip-playPauseButton" to "Spela/Paus",
				"tooltip-replayButton" to "Se igen",
				"tooltip-playNext" to "Spela nästa video",
				"tooltip-forwardVideo" to "Hoppa fram 10 sekunder",
				"tooltip-rewindVideo" to "Spela tillbaka 10 sekunder",
				"tooltip-increasePlaybackRate" to "Öka Uppspelningshastighet",
				"tooltip-decreasePlaybackRate" to "Minska Uppspelningshastighet",
				"tooltip-muteButton" to "Ljud av/på",
				"tooltip-castButton" to "Casta/Sluta casta",
				"tooltip-fullscreenButton" to "Fullskärm/Stäng fullskärm",
				"tooltip-accessibilityButton" to "Tillgänglighetsmeny",
				"tooltip-subtitleButton" to "Slå på undertexter/Stäng av undertexter",
				"tooltip-transcriptButton" to "Sätt på transkript/Stäng av transkript",
				"tooltip-audioDescriptionButton" to "Sätt på ljudbeskrivning/Stäng av ljudbeskrivning",
				"tooltip-signLanguageButton" to "Sätt på teckenspråk/Stäng av teckenspråk",
				"tooltip-settingsButton" to "Inställningar",
				"tooltip-shareButton" to "Dela",
				"tooltip-chapterButton" to "Kapitel",
				"tooltip-close" to "Stäng",
				"tooltip-previousRelatedButton" to "Gå till tidigare relaterade videor",
				"tooltip-nextRelatedButton" to "Gå till tidigare nästa videor",
				"tooltip-shareEmbed" to "Dela med inbäddningskod",
				"tooltip-shareEmail" to "Dela via e-mail",
				"tooltip-shareWhatsApp" to "Dela via WhatsApp",
				"tooltip-shareFacebook" to "Dela via Facebook",
				"tooltip-shareTwitter" to "Dela via X",
				"tooltip-shareLinkedIn" to "Dela via LinkedIn",
				"tooltip-sharePinterest" to "Dela via Pintrest",
				"tooltip-cancel" to "Avbryt",
				"tooltip-goToLive" to "Hoppa vidare till livesändning",
				"tooltip-highlights" to "Höjdpunkter",

				// State announcements
				"Playing" to "Spelar",
				"Paused" to "Pausad",
				"Fullscreen" to "Fullskärm",
				"Exited fullscreen" to "Fullskärm stängd",

				// Error and loading announcements
				"Loading" to "Laddar",
				"Buffering" to "Buffrar",
				"Advertisement" to "Annons",
				"Resuming video" to "Återupptar video",
				"Video ended" to "Video avslutad",

				// Scrub bar
				"Video progress" to "Videoframsteg",
				"of" to "av",

				// Shorts
				"Next short" to "Nästa short",
				"Previous short" to "Föregående short",

				// Player container
				"Video player" to "Videospelare",
			)
		)
		_languages.add(sv)

		//------------------------------------------
		val pl = Language(
			iso = "pl",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Połączono z",
				"Learn more" to "Dowiedz się więcej",
				"Playing on" to "Odtwarzanie na",
				"Related videos" to "Powiązane filmy",
				"Related" to "Powiązane",
				"Up next in" to "Następny za",
				"Up next" to "Kolejny",
				"Cancel" to "Anuluj",
				"Off" to "Wyłączony",
				"Skip" to "Pomiń",
				"Normal" to "Normalna",
				"Logo" to "Logo",
				"Live" to "Na żywo",
				"Live in" to "Na żywo za",
				"Interactive" to "Interaktywny",
				"Image" to "Obraz",
				"Author" to "Autor",
				"Source" to "Źródło",
				"Play now" to "Odtwórz teraz",
				"Media not available" to "Media niedostępne",
				"Replay" to "Odtwórz ponownie",
				"Unmute" to "Włącz dźwięk",
				"Blue Billywig video player" to "Odtwarzacz wideo Blue Billywig",
				"live" to "na żywo",
				"logo" to "logo",
				"Main menu" to "Menu główne",

				// Player controls
				"Playback" to "Odtwarzanie",
				"Playback speed" to "Prędkość odtwarzania",
				"Speed" to "Prędkość",
				"Volume Up" to "Podgłośnij",
				"Volume Down" to "Ścisz",
				"Volume Off" to "Wyciszony",
				"Volume On" to "Niewyciszony",

				// Settings and menus
				"Language" to "Język",
				"Quality" to "Jakość",
				"Accessibility" to "Dostępność",
				"Chapters" to "Rozdziały",
				"Highlights" to "Wyróżnienia",
				"Select chapter" to "Wybierz rozdział",
				"Select highlight" to "Wybierz wyróżnienie",
				"Search video" to "Szukaj filmu",

				// Subtitles and accessibility features
				"Subtitles" to "Napisy",
				"Subtitle" to "Napisy",
				"Subtitles on" to "Napisy włączone",
				"Subtitles off" to "Napisy wyłączone",
				"Transcript" to "Przepisany tekst",
				"Transcript on" to "Transkrypcja włączona",
				"Transcript off" to "Transkrypcja wyłączona",
				"Toggle transcript" to "Przełącz transkrypcję",
				"Audio description" to "Opis dźwiękowy",
				"Audio description on" to "Opis dźwiękowy włączony",
				"Audio description off" to "Opis dźwiękowy wyłączony",
				"Sign language" to "Język migowy",
				"Sign language on" to "Język migowy włączony",
				"Sign language off" to "Język migowy wyłączony",
				"Audiotrack" to "Ścieżka dźwiękowa",
				"Audiotracks" to "Ścieżki dźwiękowe",

				// Sharing
				"Share this video" to "Udostępnij ten film",
				"Share video" to "Udostępnij film",
				"Embed" to "Umieść",
				"Email" to "E-mail",
				"Copy URL" to "Kopiuj URL",
				"Embedcode copied to clipboard" to "Kod skopiowany do schowka",
				"Link copied to clipboard" to "Link skopiowany do schowka",
				"Failed to copy to clipboard" to "Nie udało się skopiować do schowka",

				// Downloads
				"Download" to "Pobierz",
				"Downloads" to "Pobrane",
				"Video files" to "Pliki wideo",
				"Audio files" to "Pliki audio",
				"Text files" to "Pliki tekstowe",
				"Source video" to "Wideo źródłowe",

				// Time units
				"day" to "dzień",
				"days" to "dni",
				"hour" to "godzinę",
				"hours" to "godziny",
				"minute" to "minutę",
				"minutes" to "minuty",
				"second" to "sekundę",
				"seconds" to "sekundy",
				"at" to "o",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Skróty klawiszowe",
				"Enable keyboard shortcuts" to "Włącz skróty klawiszowe",
				"Disable keyboard shortcuts" to "Wyłącz skróty klawiszowe",
				"Keyboard shortcuts off" to "Skróty klawiszowe wyłączone",
				"Shortkey" to "Skrót",
				"Space" to "Spacja",
				"Press question mark for keyboard shortcuts" to "Wciśnij znak zapytania, aby uzyskać skróty klawiszowe",

				// Input labels
				"Volume input" to "Wprowadzenie głośności",
				"Time input" to "Wprowadzenie czasu",

				// Live features
				"Set reminder" to "Ustawić przypomnienie",
				"Reminder set" to "Przypomnienie ustawione",
				"AutomaticallyFollowText" to "Automatyczne śledzenie tekstu",
				"StartAt" to "Rozpocznij od",
				"ShareStartAtTimeAriaLabel" to "Rozpocznij od {time}",

				// ARIA labels
				"aria-settingsButton" to "Otwórz menu ustawień/Zamknij menu ustawień",
				"aria-chapterButton" to "Otwórz menu rozdziałów/Zamknij menu rozdziałów",
				"aria-accessibilityButton" to "Otwórz menu dostępności/Zamknij menu dostępności",
				"aria-castButton" to "Rozpocznij przesyłanie/Zatrzymaj przesyłanie",
				"aria-close" to "Zamknij",
				"aria-clearSearch" to "Wyczyść pole wyszukiwania",

				// Tooltip labels
				"tooltip-playPauseButton" to "Odtwórz/Wstrzymaj",
				"tooltip-replayButton" to "Odtwórz ponownie",
				"tooltip-playNext" to "Odtwórz następny film",
				"tooltip-forwardVideo" to "Przewiń o 10 sekund",
				"tooltip-rewindVideo" to "Cofnij o 10 sekund",
				"tooltip-increasePlaybackRate" to "Zwiększyć prędkość odtwarzania",
				"tooltip-decreasePlaybackRate" to "Zmniejszyć prędkość odtwarzania",
				"tooltip-muteButton" to "Wycisz/Wyłącz wyciszenie",
				"tooltip-castButton" to "Przesyłaj/Zakończ przesyłanie",
				"tooltip-fullscreenButton" to "Pełny ekran/Zamknij pełny ekran",
				"tooltip-accessibilityButton" to "Menu dostępności",
				"tooltip-subtitleButton" to "Włącz/Wyłącz napisy",
				"tooltip-transcriptButton" to "Włącz/Wyłącz transkrypcję",
				"tooltip-audioDescriptionButton" to "Włącz/Wyłącz opis dźwiękowy",
				"tooltip-signLanguageButton" to "Włącz/Wyłącz język migowy",
				"tooltip-settingsButton" to "Ustawienia",
				"tooltip-shareButton" to "Udostępnij",
				"tooltip-chapterButton" to "Rozdział",
				"tooltip-close" to "Zamknij",
				"tooltip-previousRelatedButton" to "Przejdź do poprzednich powiązanych filmów",
				"tooltip-nextRelatedButton" to "Przejdź do następnych powiązanych filmów",
				"tooltip-shareEmbed" to "Udostępnij: Umieść",
				"tooltip-shareEmail" to "Udostępnij przez Email",
				"tooltip-shareWhatsApp" to "Udostępnij przez WhatsApp",
				"tooltip-shareFacebook" to "Udostępnij przez Facebook",
				"tooltip-shareTwitter" to "Udostępnij przez X",
				"tooltip-shareLinkedIn" to "Udostępnij przez LinkedIn",
				"tooltip-sharePinterest" to "Udostępnij przez Pinterest",
				"tooltip-cancel" to "Anuluj",
				"tooltip-goToLive" to "Przejdź do transmisji na żywo",
				"tooltip-highlights" to "Wyróżnienia",

				// State announcements
				"Playing" to "Odtwarzanie",
				"Paused" to "Wstrzymano",
				"Fullscreen" to "Pełny ekran",
				"Exited fullscreen" to "Zamknięto pełny ekran",

				// Error and loading announcements
				"Loading" to "Ładowanie",
				"Buffering" to "Buforowanie",
				"Advertisement" to "Reklama",
				"Resuming video" to "Wznawianie wideo",
				"Video ended" to "Wideo zakończone",

				// Scrub bar
				"Video progress" to "Postęp wideo",
				"of" to "z",

				// Shorts
				"Next short" to "Następny short",
				"Previous short" to "Poprzedni short",

				// Player container
				"Video player" to "Odtwarzacz wideo",
			)
		)
		_languages.add(pl)

		//------------------------------------------
		val de = Language(
			iso = "de",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Verbunden mit",
				"Learn more" to "Mehr erfahren",
				"Playing on" to "Wird wiedergegeben auf",
				"Related videos" to "Ähnliche Videos",
				"Related" to "Ähnliche",
				"Up next in" to "Video beginnt in",
				"Up next" to "Als nächstes",
				"Cancel" to "Abbrechen",
				"Off" to "Aus",
				"Skip" to "Werbung überspringen",
				"Normal" to "Normal",
				"Logo" to "Logo",
				"Live" to "Live",
				"Live in" to "Live in",
				"Interactive" to "Interaktiv",
				"Image" to "Bild",
				"Author" to "Autor",
				"Source" to "Quelle",
				"Play now" to "Jetzt abspielen",
				"Media not available" to "Medien nicht verfügbar",
				"Replay" to "Wiederholen",
				"Unmute" to "Stummschaltung aufheben",
				"Blue Billywig video player" to "Blue Billywig Videoplayer",
				"live" to "live",
				"logo" to "Logo",
				"Main menu" to "Hauptmenü",

				// Player controls
				"Playback" to "Wiedergabe",
				"Playback speed" to "Wiedergabegeschwindigkeit",
				"Speed" to "Geschwindigkeit",
				"Volume Up" to "Lautstärke erhöhen",
				"Volume Down" to "Lautstärke runter",
				"Volume Off" to "Stummgeschaltet",
				"Volume On" to "Stummschaltung aufgehoben",

				// Settings and menus
				"Language" to "Sprache",
				"Quality" to "Qualität",
				"Accessibility" to "Barrierefreiheit",
				"Chapters" to "Kapitel",
				"Highlights" to "Highlights",
				"Select chapter" to "Kapitel auswählen",
				"Select highlight" to "Highlight auswählen",
				"Search video" to "Video durchsuchen",

				// Subtitles and accessibility features
				"Subtitles" to "Untertitel",
				"Subtitle" to "Untertitel",
				"Subtitles on" to "Untertitel an",
				"Subtitles off" to "Untertitel aus",
				"Transcript" to "Transkribierter Text",
				"Transcript on" to "Transkript an",
				"Transcript off" to "Transkript aus",
				"Toggle transcript" to "Transkript umschalten",
				"Audio description" to "Audiodeskription",
				"Audio description on" to "Audiodeskription an",
				"Audio description off" to "Audiodeskription aus",
				"Sign language" to "Gebärdensprache",
				"Sign language on" to "Gebärdensprache an",
				"Sign language off" to "Gebärdensprache aus",
				"Audiotrack" to "Audiospur",
				"Audiotracks" to "Audiospuren",

				// Sharing
				"Share this video" to "Teile dieses Video",
				"Share video" to "Teilen",
				"Embed" to "Einbetten",
				"Email" to "E-mail",
				"Copy URL" to "URL kopieren",
				"Embedcode copied to clipboard" to "Einbettungscode in die Zwischenablage kopiert",
				"Link copied to clipboard" to "Link in die Zwischenablage kopiert",
				"Failed to copy to clipboard" to "Fehler beim Kopieren in die Zwischenablage",

				// Downloads
				"Download" to "Herunterladen",
				"Downloads" to "Downloads",
				"Video files" to "Videodateien",
				"Audio files" to "Audiodateien",
				"Text files" to "Textdateien",
				"Source video" to "Quellvideo",

				// Time units
				"day" to "Tag",
				"days" to "Tage",
				"hour" to "Stunde",
				"hours" to "Stunden",
				"minute" to "Minute",
				"minutes" to "Minuten",
				"second" to "Sekunde",
				"seconds" to "Sekunden",
				"at" to "um",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Tastenkombinationen",
				"Enable keyboard shortcuts" to "Tastenkombinationen aktivieren",
				"Disable keyboard shortcuts" to "Tastenkombinationen deaktivieren",
				"Keyboard shortcuts off" to "Tastenkombinationen aus",
				"Shortkey" to "Tastenkombination",
				"Space" to "Leertaste",
				"Press question mark for keyboard shortcuts" to "Drücken Sie das Fragezeichen für Tastenkombinationen",

				// Input labels
				"Volume input" to "Lautstärkeeingabe",
				"Time input" to "Zeiteingabe",

				// Live features
				"Set reminder" to "Erinnerung einstellen",
				"Reminder set" to "Erinnerung eingestellt",
				"AutomaticallyFollowText" to "Text automatisch verfolgen",
				"StartAt" to "Starten bei",
				"ShareStartAtTimeAriaLabel" to "Starten bei {time}",

				// ARIA labels
				"aria-settingsButton" to "Einstellungsmenü öffnen/Einstellungsmenü schließen",
				"aria-chapterButton" to "Kapitelmenü öffnen/Kapitelmenü schließen",
				"aria-accessibilityButton" to "Barrierefreiheitmenü öffnen/Barrierefreiheitmenü schließen",
				"aria-castButton" to "Casten beginnen/Casten beenden",
				"aria-close" to "Schließen",
				"aria-clearSearch" to "Suchfeld leeren",

				// Tooltip labels
				"tooltip-playPauseButton" to "Spiel/Pause",
				"tooltip-replayButton" to "Wiederholung",
				"tooltip-playNext" to "Nächstes Video abspielen",
				"tooltip-forwardVideo" to "10 Sekunden vorspulen",
				"tooltip-rewindVideo" to "10 Sekunden zurückspulen",
				"tooltip-increasePlaybackRate" to "Wiedergabegeschwindigkeit erhöhen",
				"tooltip-decreasePlaybackRate" to "Wiedergabegeschwindigkeit verringern",
				"tooltip-muteButton" to "Stummschalten/Stummschalten aufheben",
				"tooltip-castButton" to "Casten/Casten beenden",
				"tooltip-fullscreenButton" to "Vollbild/Vollbildmodus beenden",
				"tooltip-accessibilityButton" to "Barrierefreiheit",
				"tooltip-subtitleButton" to "Untertitel einschalten/Untertitel ausschalten",
				"tooltip-transcriptButton" to "Transkript einschalten/Transkript ausschalten",
				"tooltip-audioDescriptionButton" to "Audiodeskription einschalten/Audiodeskription ausschalten",
				"tooltip-signLanguageButton" to "Gebärdensprache einschalten/Gebärdensprache ausschalten",
				"tooltip-settingsButton" to "Einstellungen",
				"tooltip-shareButton" to "Teilen",
				"tooltip-chapterButton" to "Kapitel",
				"tooltip-close" to "Schließen",
				"tooltip-previousRelatedButton" to "Sehen Sie sich weitere ähnliche Videos an",
				"tooltip-nextRelatedButton" to "Sehen Sie sich weitere ähnliche Videos an",
				"tooltip-shareEmbed" to "Einbetten",
				"tooltip-shareEmail" to "Per E-mail teilen",
				"tooltip-shareWhatsApp" to "Auf WhatsApp teilen",
				"tooltip-shareFacebook" to "Auf Facebook teilen",
				"tooltip-shareTwitter" to "Auf X teilen",
				"tooltip-shareLinkedIn" to "Auf LinkedIn teilen",
				"tooltip-sharePinterest" to "Auf Pinterest teilen",
				"tooltip-cancel" to "Abbrechen",
				"tooltip-goToLive" to "Springen Sie weiter zur Live-Übertragung",
				"tooltip-highlights" to "Highlights",

				// State announcements
				"Playing" to "Wiedergabe",
				"Paused" to "Pausiert",
				"Fullscreen" to "Vollbild",
				"Exited fullscreen" to "Vollbildmodus beendet",

				// Error and loading announcements
				"Loading" to "Wird geladen",
				"Buffering" to "Puffern",
				"Advertisement" to "Werbung",
				"Resuming video" to "Video wird fortgesetzt",
				"Video ended" to "Video beendet",

				// Scrub bar
				"Video progress" to "Videofortschritt",
				"of" to "von",

				// Shorts
				"Next short" to "Nächster Short",
				"Previous short" to "Vorheriger Short",

				// Player container
				"Video player" to "Videoplayer",
			)
		)
		_languages.add(de)

		//------------------------------------------
		val da = Language(
			iso = "da",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Forbundet til",
				"Learn more" to "Læs mere",
				"Playing on" to "Afspiller",
				"Related videos" to "Relaterede videoer",
				"Related" to "Relaterede",
				"Up next in" to "Næste video",
				"Up next" to "Afspiller nu",
				"Cancel" to "Fortryd",
				"Off" to "Deaktiveret",
				"Skip" to "Spring over",
				"Normal" to "Normal",
				"Logo" to "Logo",
				"Live" to "Direkte",
				"Live in" to "Live om",
				"Interactive" to "Interaktiv",
				"Image" to "Billede",
				"Author" to "Forfatter",
				"Source" to "Kilde",
				"Play now" to "Afspil nu",
				"Media not available" to "Video ikke tilgængelig",
				"Replay" to "Genafspil",
				"Unmute" to "Unmute",
				"Blue Billywig video player" to "Blue Billywig videospiller",
				"live" to "live",
				"logo" to "logo",
				"Main menu" to "Hovedmenu",

				// Player controls
				"Playback" to "Afspilning",
				"Playback speed" to "Afspilningshastighed",
				"Speed" to "Hastighed",
				"Volume Up" to "Skru op",
				"Volume Down" to "Skru ned",
				"Volume Off" to "Lyd slukket",
				"Volume On" to "Lyd tændt",

				// Settings and menus
				"Language" to "Sprog",
				"Quality" to "Kvalitet",
				"Accessibility" to "Tilgængelighed",
				"Chapters" to "Kapitler",
				"Highlights" to "Højdepunkter",
				"Select chapter" to "Vælg kapitel",
				"Select highlight" to "Vælg højdepunkt",
				"Search video" to "Søg video",

				// Subtitles and accessibility features
				"Subtitles" to "Undertekster",
				"Subtitle" to "Undertekst",
				"Subtitles on" to "Undertekster aktiveret",
				"Subtitles off" to "Undertekster aktiveret",
				"Transcript" to "Transskriberet tekst",
				"Transcript on" to "Transkription aktiveret",
				"Transcript off" to "Transkription deaktiveret",
				"Toggle transcript" to "Skift transkription",
				"Audio description" to "Lyd beskrivelse",
				"Audio description on" to "Lyd beskrivelse aktiveret",
				"Audio description off" to "Lyd beskrivelse deaktiveret",
				"Sign language" to "Tegnsprog",
				"Sign language on" to "Tegnsprog aktiveret",
				"Sign language off" to "Tegnsprog deaktiveret",
				"Audiotrack" to "Lydspor",
				"Audiotracks" to "Lydspor",

				// Sharing
				"Share this video" to "Del denne video",
				"Share video" to "Del video",
				"Embed" to "Indlejre",
				"Email" to "E-mail",
				"Copy URL" to "Kopier URL",
				"Embedcode copied to clipboard" to "Indlejret kode kopieret til udklipsholder",
				"Link copied to clipboard" to "Link kopieret til udklipsholder",
				"Failed to copy to clipboard" to "Kunne ikke kopiere indholdet",

				// Downloads
				"Download" to "Download",
				"Downloads" to "Downloads",
				"Video files" to "Videofiler",
				"Audio files" to "Lydfiler",
				"Text files" to "Tekstfiler",
				"Source video" to "Kildevideo",

				// Time units
				"day" to "dag",
				"days" to "dage",
				"hour" to "time",
				"hours" to "timer",
				"minute" to "minut",
				"minutes" to "minutter",
				"second" to "sekund",
				"seconds" to "sekunder",
				"at" to "kl",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Tastaturgenveje",
				"Enable keyboard shortcuts" to "Aktiver tastaturgenveje",
				"Disable keyboard shortcuts" to "Deaktiver tastaturgenveje",
				"Keyboard shortcuts off" to "Tastaturgenveje slukket",
				"Shortkey" to "Genvej",
				"Space" to "Mellemrum",
				"Press question mark for keyboard shortcuts" to "Tryk på spørgsmålstegn for tastaturgenveje",

				// Input labels
				"Volume input" to "Lydinput",
				"Time input" to "Tidsinput",

				// Live features
				"Set reminder" to "Indstil påmindelse",
				"Reminder set" to "Påmindelse indstillet",
				"AutomaticallyFollowText" to "Følg automatisk tekst",
				"StartAt" to "Start ved",
				"ShareStartAtTimeAriaLabel" to "Start ved {time}",

				// ARIA labels
				"aria-settingsButton" to "Åbn indstillingsmenu/Luk indstillingsmenu",
				"aria-chapterButton" to "Åbn kapitel menu/Luk kapitel menu",
				"aria-accessibilityButton" to "Åbn tilgængelighedsmenu/Luk tilgængelighedsmenu",
				"aria-castButton" to "Start casting/Stop casting",
				"aria-close" to "Luk",
				"aria-clearSearch" to "Ryd søgefelt",

				// Tooltip labels
				"tooltip-playPauseButton" to "Afspil/pause",
				"tooltip-replayButton" to "Genafspil",
				"tooltip-playNext" to "Spil næste",
				"tooltip-forwardVideo" to "Spol 10 sekunder",
				"tooltip-rewindVideo" to "Spol 10 sekunder tilbage",
				"tooltip-increasePlaybackRate" to "Forøg afspilningshastigheden",
				"tooltip-decreasePlaybackRate" to "Sænk afspilningshastigheden",
				"tooltip-muteButton" to "Mute/Unmute",
				"tooltip-castButton" to "Cast/stop cast",
				"tooltip-fullscreenButton" to "Fuldskærm/Luk fuldskærm",
				"tooltip-accessibilityButton" to "Tilgængelighedsmenu",
				"tooltip-subtitleButton" to "Tænd undertekster/sluk undertekster",
				"tooltip-transcriptButton" to "Tænd for transskript/Sluk for transskript",
				"tooltip-audioDescriptionButton" to "Tænd for lydbeskrivelse/Sluk for lydbeskrivelse",
				"tooltip-signLanguageButton" to "Tænd for tegnsprog/Sluk for tegnsprog",
				"tooltip-settingsButton" to "Indstillinger",
				"tooltip-shareButton" to "Del",
				"tooltip-chapterButton" to "Kapitel",
				"tooltip-close" to "Luk",
				"tooltip-previousRelatedButton" to "Gå til tidligere relaterede videoer",
				"tooltip-nextRelatedButton" to "Gå til næste relaterede videoer",
				"tooltip-shareEmbed" to "Del via indlejringskode",
				"tooltip-shareEmail" to "Del via e-mail",
				"tooltip-shareWhatsApp" to "Del på WhatsApp",
				"tooltip-shareFacebook" to "Del på Facebook",
				"tooltip-shareTwitter" to "Del på X",
				"tooltip-shareLinkedIn" to "Del på LinkedIn",
				"tooltip-sharePinterest" to "Del på Pinterest",
				"tooltip-cancel" to "Fortryd",
				"tooltip-goToLive" to "Gå til Live Broadcast",
				"tooltip-highlights" to "Højdepunkter",

				// State announcements
				"Playing" to "Afspiller",
				"Paused" to "Sat på pause",
				"Fullscreen" to "Fuldskærm",
				"Exited fullscreen" to "Fuldskærm lukket",

				// Error and loading announcements
				"Loading" to "Indlæser",
				"Buffering" to "Bufferer",
				"Advertisement" to "Reklame",
				"Resuming video" to "Genoptager video",
				"Video ended" to "Video afsluttet",

				// Scrub bar
				"Video progress" to "Videofremdrift",
				"of" to "af",

				// Shorts
				"Next short" to "Næste short",
				"Previous short" to "Forrige short",

				// Player container
				"Video player" to "Videoafspiller",
			)
		)
		_languages.add(da)

		//------------------------------------------
		val fr = Language(
			iso = "fr",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Connecté à",
				"Learn more" to "En savoir plus",
				"Playing on" to "Lecture sur",
				"Related videos" to "Vidéos associées",
				"Related" to "En lien",
				"Up next in" to "À suivre dans",
				"Up next" to "À suivre",
				"Cancel" to "Annuler",
				"Off" to "Désactivé",
				"Skip" to "Passer",
				"Normal" to "Normale",
				"Logo" to "Logo",
				"Live" to "En direct",
				"Live in" to "En direct dans",
				"Interactive" to "Interactif",
				"Image" to "Image",
				"Author" to "Auteur",
				"Source" to "Source",
				"Play now" to "Lire maintenant",
				"Media not available" to "Média non disponible",
				"Replay" to "Relire",
				"Unmute" to "Réactiver le son",
				"Blue Billywig video player" to "Lecteur vidéo Blue Billywig",
				"live" to "en direct",
				"logo" to "logo",
				"Main menu" to "Menu principal",

				// Player controls
				"Playback" to "Lecture",
				"Playback speed" to "Vitesse de lecture",
				"Speed" to "Vitesse",
				"Volume Up" to "Augmenter le volume",
				"Volume Down" to "Diminuer le volume",
				"Volume Off" to "Son désactivé",
				"Volume On" to "Son activé",

				// Settings and menus
				"Language" to "Langue",
				"Quality" to "Qualité",
				"Accessibility" to "Accessibilité",
				"Chapters" to "Chapitres",
				"Highlights" to "Temps forts",
				"Select chapter" to "Sélectionner un chapitre",
				"Select highlight" to "Sélectionner un temps fort",
				"Search video" to "Rechercher une vidéo",

				// Subtitles and accessibility features
				"Subtitles" to "Sous-titre",
				"Subtitle" to "Sous-titre",
				"Subtitles on" to "Sous-titres activés",
				"Subtitles off" to "Sous-titres désactivés",
				"Transcript" to "Transcription",
				"Transcript on" to "Transcription activée",
				"Transcript off" to "Transcription désactivée",
				"Toggle transcript" to "Activer/désactiver la transcription",
				"Audio description" to "Description audio",
				"Audio description on" to "Audio description activée",
				"Audio description off" to "Audio description désactivée",
				"Sign language" to "Langue des signes",
				"Sign language on" to "Langue des signes activée",
				"Sign language off" to "Langue des signes désactivée",
				"Audiotrack" to "Piste audio",
				"Audiotracks" to "Pistes audio",

				// Sharing
				"Share this video" to "Partager cette vidéo",
				"Share video" to "Partager la vidéo",
				"Embed" to "Intégrer",
				"Email" to "Email",
				"Copy URL" to "Copier l'URL",
				"Embedcode copied to clipboard" to "Code d'intégration copié dans le presse-papiers",
				"Link copied to clipboard" to "Lien copié dans le presse-papiers",
				"Failed to copy to clipboard" to "Échec de la copie dans le presse-papiers",

				// Downloads
				"Download" to "Téléchargement",
				"Downloads" to "Téléchargements",
				"Video files" to "Fichiers vidéo",
				"Audio files" to "Fichiers audio",
				"Text files" to "Fichiers texte",
				"Source video" to "Vidéo source",

				// Time units
				"day" to "jour",
				"days" to "jours",
				"hour" to "heure",
				"hours" to "heures",
				"minute" to "minute",
				"minutes" to "minutes",
				"second" to "seconde",
				"seconds" to "secondes",
				"at" to "à",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Raccourcis clavier",
				"Enable keyboard shortcuts" to "Activer les raccourcis clavier",
				"Disable keyboard shortcuts" to "Désactiver les raccourcis clavier",
				"Keyboard shortcuts off" to "Raccourcis clavier désactivés",
				"Shortkey" to "Raccourci clavier",
				"Space" to "Espace",
				"Press question mark for keyboard shortcuts" to "Appuyez sur la touche \"?\" pour afficher les raccourcis clavier",

				// Input labels
				"Volume input" to "Contrôle du volume",
				"Time input" to "Contrôle de la barre de progression",

				// Live features
				"Set reminder" to "Définir un rappel",
				"Reminder set" to "Rappel défini",
				"AutomaticallyFollowText" to "Synchroniser le texte au contenu",
				"StartAt" to "Démarrer à",
				"ShareStartAtTimeAriaLabel" to "Démarrer à {time}",

				// ARIA labels
				"aria-settingsButton" to "Ouvrir le menu des paramètres/Fermer le menu des paramètres",
				"aria-chapterButton" to "Ouvrir le menu des chapitres/Fermer le menu des chapitres",
				"aria-accessibilityButton" to "Ouvrir le menu d'accessibilité/Fermer le menu d'accessibilité",
				"aria-castButton" to "Commencer la diffusion/Arrêter la diffusion",
				"aria-close" to "Fermer",
				"aria-clearSearch" to "Effacer le champ de recherche",

				// Tooltip labels
				"tooltip-playPauseButton" to "Lecture/Pause",
				"tooltip-replayButton" to "Relire",
				"tooltip-playNext" to "Lire la vidéo suivante",
				"tooltip-forwardVideo" to "Avancer de 10 secondes",
				"tooltip-rewindVideo" to "Reculer de 10 secondes",
				"tooltip-increasePlaybackRate" to "Augmenter la vitesse de lecture",
				"tooltip-decreasePlaybackRate" to "Diminuer la vitesse de lecture",
				"tooltip-muteButton" to "Désactiver le son/Activer le son",
				"tooltip-castButton" to "Caster",
				"tooltip-fullscreenButton" to "Mode plein écran/Fermer le mode plein écran",
				"tooltip-accessibilityButton" to "Menu d'accessibilité",
				"tooltip-subtitleButton" to "Activer les sous-titres/Désactiver les sous-titres",
				"tooltip-transcriptButton" to "Activer la transcription/Désactiver la transcription",
				"tooltip-audioDescriptionButton" to "Activer la description audio/Désactiver la description audio",
				"tooltip-signLanguageButton" to "Activer la langue des signes/Désactiver la langue des signes",
				"tooltip-settingsButton" to "Paramètres",
				"tooltip-shareButton" to "Partager",
				"tooltip-chapterButton" to "Chapitres",
				"tooltip-close" to "Fermer",
				"tooltip-previousRelatedButton" to "Vidéos associées précédentes",
				"tooltip-nextRelatedButton" to "Vidéos associées suivantes",
				"tooltip-shareEmbed" to "Partager via un code d'intégration",
				"tooltip-shareEmail" to "Partager par email",
				"tooltip-shareWhatsApp" to "Partager sur WhatsApp",
				"tooltip-shareFacebook" to "Partager sur Facebook",
				"tooltip-shareTwitter" to "Partager sur X",
				"tooltip-shareLinkedIn" to "Partager sur LinkedIn",
				"tooltip-sharePinterest" to "Partager sur Pinterest",
				"tooltip-cancel" to "Annuler",
				"tooltip-goToLive" to "Passer au direct",
				"tooltip-highlights" to "Temps forts",

				// State announcements
				"Playing" to "Lecture en cours",
				"Paused" to "En pause",
				"Fullscreen" to "Plein écran",
				"Exited fullscreen" to "Plein écran fermé",

				// Error and loading announcements
				"Loading" to "Chargement",
				"Buffering" to "Mise en mémoire tampon",
				"Advertisement" to "Publicité",
				"Resuming video" to "Reprise de la vidéo",
				"Video ended" to "Vidéo terminée",

				// Scrub bar
				"Video progress" to "Progression de la vidéo",
				"of" to "sur",

				// Shorts
				"Next short" to "Short suivant",
				"Previous short" to "Short précédent",

				// Player container
				"Video player" to "Lecteur vidéo",
			)
		)
		_languages.add(fr)

		//------------------------------------------
		val fi = Language(
			iso = "fi",
			translations = mutableMapOf(
				// General UI
				"Connected to" to "Yhdistetty laitteeseen",
				"Learn more" to "Lue lisää",
				"Playing on" to "Toistetaan laitteella",
				"Related videos" to "Aiheeseen liittyvät videot",
				"Related" to "Aiheeseen liittyvät",
				"Up next in" to "Seuraavaksi alkaa",
				"Up next" to "Seuraavaksi",
				"Cancel" to "Peruuta",
				"Off" to "Pois päältä",
				"Skip" to "Ohita",
				"Normal" to "Normaali",
				"Logo" to "Logo",
				"Live" to "Suora lähetys",
				"Live in" to "Suora lähetys alkaa",
				"Interactive" to "Interaktiivinen",
				"Image" to "Kuva",
				"Author" to "Tekijä",
				"Source" to "Lähde",
				"Play now" to "Toista nyt",
				"Media not available" to "Media ei ole saatavilla",
				"Replay" to "Toista uudelleen",
				"Unmute" to "Poista mykistys",
				"Blue Billywig video player" to "Blue Billywig -videotoistin",
				"live" to "suora lähetys",
				"logo" to "logo",
				"Main menu" to "Päävalikko",

				// Player controls
				"Playback" to "Toisto",
				"Playback speed" to "Toiston nopeus",
				"Speed" to "Nopeus",
				"Volume Up" to "Äänenvoimakkuus ylös",
				"Volume Down" to "Äänenvoimakkuus alas",
				"Volume Off" to "Mykistetty",
				"Volume On" to "Mykistys poistettu",

				// Settings and menus
				"Language" to "Kieli",
				"Quality" to "Laatu",
				"Accessibility" to "Saavutettavuus",
				"Chapters" to "Luvut",
				"Highlights" to "Kohokohdat",
				"Select chapter" to "Valitse luku",
				"Select highlight" to "Valitse kohokohta",
				"Search video" to "Etsi video",

				// Subtitles and accessibility features
				"Subtitles" to "Tekstitykset",
				"Subtitle" to "Tekstitys",
				"Subtitles on" to "Tekstitykset päällä",
				"Subtitles off" to "Tekstitykset pois päältä",
				"Transcript" to "Transkriptio",
				"Transcript on" to "Transkriptio päällä",
				"Transcript off" to "Transkriptio pois päältä",
				"Toggle transcript" to "Vaihda transkriptio",
				"Audio description" to "Äänikuvaus",
				"Audio description on" to "Äänikuvaus päällä",
				"Audio description off" to "Äänikuvaus pois päältä",
				"Sign language" to "Viittomakieli",
				"Sign language on" to "Viittomakieli päällä",
				"Sign language off" to "Viittomakieli pois päältä",
				"Audiotrack" to "Ääniraita",
				"Audiotracks" to "Ääniraidat",

				// Sharing
				"Share this video" to "Jaa tämä video",
				"Share video" to "Jaa video",
				"Embed" to "Upota",
				"Email" to "Sähköposti",
				"Copy URL" to "Kopioi URL",
				"Embedcode copied to clipboard" to "Upotuskoodi kopioitu leikepöydälle",
				"Link copied to clipboard" to "Linkki kopioitu leikepöydälle",
				"Failed to copy to clipboard" to "Kopiointi leikepöydälle epäonnistui",

				// Downloads
				"Download" to "Lataa",
				"Downloads" to "Lataukset",
				"Video files" to "Videotiedostot",
				"Audio files" to "Äänitiedostot",
				"Text files" to "Tekstitiedostot",
				"Source video" to "Lähdevideo",

				// Time units
				"day" to "päivä",
				"days" to "päivät",
				"hour" to "tunti",
				"hours" to "tuntia",
				"minute" to "minuutti",
				"minutes" to "minuuttia",
				"second" to "sekunti",
				"seconds" to "sekuntia",
				"at" to "klo",

				// Keyboard shortcuts
				"Keyboard shortcuts" to "Näppäinoikotiet",
				"Enable keyboard shortcuts" to "Ota näppäinoikotiet käyttöön",
				"Disable keyboard shortcuts" to "Poista näppäinoikotiet käytöstä",
				"Keyboard shortcuts off" to "Näppäinoikotiet pois päältä",
				"Shortkey" to "Pikanäppäin",
				"Space" to "Välilyönti",
				"Press question mark for keyboard shortcuts" to "Paina kysymysmerkkiä saadaksesi tietoa näppäinoikoteistä",

				// Input labels
				"Volume input" to "Äänenvoimakkuuden syöttö",
				"Time input" to "Ajan syöttö",

				// Live features
				"Set reminder" to "Aseta muistutus",
				"Reminder set" to "Muistutus asetettu",
				"AutomaticallyFollowText" to "Seuraa tekstiä automaattisesti",
				"StartAt" to "Aloita kohdasta",
				"ShareStartAtTimeAriaLabel" to "Aloita kohdasta {time}",

				// ARIA labels
				"aria-settingsButton" to "Avaa asetukset-valikko/Sulje asetukset-valikko",
				"aria-chapterButton" to "Avaa luvut-valikko/Sulje luvut-valikko",
				"aria-accessibilityButton" to "Avaa saavutettavuusvalikko/Sulje saavutettavuusvalikko",
				"aria-castButton" to "Aloita lähetys/Lopeta lähetys",
				"aria-close" to "Sulje",
				"aria-clearSearch" to "Tyhjennä hakukenttä",

				// Tooltip labels
				"tooltip-playPauseButton" to "Toista/Tauko",
				"tooltip-replayButton" to "Toista uudelleen",
				"tooltip-playNext" to "Toista seuraava video",
				"tooltip-forwardVideo" to "Kelaa eteenpäin 10 sekuntia",
				"tooltip-rewindVideo" to "Kelaa taaksepäin 10 sekuntia",
				"tooltip-increasePlaybackRate" to "Lisää toiston nopeutta",
				"tooltip-decreasePlaybackRate" to "Vähennä toiston nopeutta",
				"tooltip-muteButton" to "Mykistä/Poista mykistys",
				"tooltip-castButton" to "Lähetä",
				"tooltip-fullscreenButton" to "Koko näyttö/Sulje koko näyttö",
				"tooltip-accessibilityButton" to "Saavutettavuusvalikko",
				"tooltip-subtitleButton" to "Ota tekstitykset käyttöön/Poista tekstitykset käytöstä",
				"tooltip-transcriptButton" to "Ota transkriptio käyttöön/Poista transkriptio käytöstä",
				"tooltip-audioDescriptionButton" to "Ota äänikuvaus käyttöön/Poista äänikuvaus käytöstä",
				"tooltip-signLanguageButton" to "Ota viittomakieli käyttöön/Poista viittomakieli käytöstä",
				"tooltip-settingsButton" to "Asetukset",
				"tooltip-shareButton" to "Jaa",
				"tooltip-chapterButton" to "Luvut",
				"tooltip-close" to "Sulje",
				"tooltip-previousRelatedButton" to "Siirry edellisiin aiheeseen liittyviin videoihin",
				"tooltip-nextRelatedButton" to "Siirry seuraaviin aiheeseen liittyviin videoihin",
				"tooltip-shareEmbed" to "Jaa upotuskoodilla",
				"tooltip-shareEmail" to "Jaa sähköpostitse",
				"tooltip-shareWhatsApp" to "Jaa WhatsAppissa",
				"tooltip-shareFacebook" to "Jaa Facebookissa",
				"tooltip-shareTwitter" to "Jaa X",
				"tooltip-shareLinkedIn" to "Jaa LinkedInissä",
				"tooltip-sharePinterest" to "Jaa Pinterestissä",
				"tooltip-cancel" to "Peruuta",
				"tooltip-goToLive" to "Siirry suoraan lähetykseen",
				"tooltip-highlights" to "Kohokohdat",

				// State announcements
				"Playing" to "Toistetaan",
				"Paused" to "Tauolla",
				"Fullscreen" to "Koko näyttö",
				"Exited fullscreen" to "Koko näyttö suljettu",

				// Error and loading announcements
				"Loading" to "Ladataan",
				"Buffering" to "Puskuroidaan",
				"Advertisement" to "Mainos",
				"Resuming video" to "Jatketaan videota",
				"Video ended" to "Video päättynyt",

				// Scrub bar
				"Video progress" to "Videon edistyminen",
				"of" to "/",

				// Shorts
				"Next short" to "Seuraava short",
				"Previous short" to "Edellinen short",

				// Player container
				"Video player" to "Videotoistin",
			)
		)
		_languages.add(fi)
	}

	fun translate (iso:String, text: String): String {
		var ret: String? = null
		val language: Language? = _languages.find { it.iso == iso }
		if (language != null) {
			ret = language.translations[text]
		}
		return ret ?: text
	}
}
