package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray


@Serializable
data class LineItem_ ( // somehow LineItem is already declared (built in Kotlin?!?)
    val id: String? = null,
    // val publicationid: String? = null, // sometimes string sometimes array with 1 string
    val type: String? = null,
    val status: String? = null,
    val createddate: String? = null,
    val createdBy: String? = null,
    val updateddate: String? = null,
    val updatedBy: String? = null,
    val creativeType: String? = null,
    val creativeId: String? = null,
    val timeout: Long? = null,
    val preferredPlayMode: String? = null,
    val playout: Map<String, String?>? = null,
    val title: String? = null,
    val code: String? = null,

    @SerialName("vast_url")
    val vastUrl: String? = null,

    @SerialName("vast_xml")
    val vastXml: String? = null,

    @SerialName("vast_subtype")
    val vastSubtype: String? = null,

    val label: String? = null,
    val relatedAdunits: JsonArray? = null
) {
    constructor(id: String, playout: Map<String, String?>?, code: String?, vastUrl: String?, vastXml: String?, vastSubtype: String?) : this(id, "LineItem", "published", null, null, null, null, "VAST", null, null, null, playout, null, code, vastUrl, vastXml, vastSubtype, null, null)
}
