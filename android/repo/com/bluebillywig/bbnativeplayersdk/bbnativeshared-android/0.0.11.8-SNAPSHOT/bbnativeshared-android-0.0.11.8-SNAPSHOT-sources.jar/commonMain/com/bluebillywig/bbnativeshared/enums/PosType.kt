package com.bluebillywig.bbnativeshared.enums

enum class PosType {
	PREROLL,
	LEADER,
	INARTICLE,
	VMAP,
	MIDROLL,
	OVERLAY,
	POSTROLL,
	EXITSCREEN
}