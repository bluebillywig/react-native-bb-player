package com.bluebillywig.bbnativeshared.controller

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.PosType
import com.bluebillywig.bbnativeshared.interfaces.AdControllerInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.AdUnit
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.model.Playout
import com.bluebillywig.bbnativeshared.AdMacroHelper

import io.ktor.http.*
import com.benasher44.uuid.uuid4
import kotlinx.datetime.Clock

/**
 * @suppress
 */
class MsasController (eventBus: EventBusInterface?, opts: EmbedObject? = null, options: Map<String, Any?>? = null):
    EventListenerInterface {
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_embed_loaded -> {
                val options = if (data != null && data["options"] != null) data["options"] as Map<String, Any?> else null
                if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?, options)
            }
            EventName.bb_playout_changed -> {
                _onPlayoutChanged(data)
            }
            EventName.bb_mediaclip_loaded -> {
                _onMediaClipLoaded(eventType, data)
            }
            EventName.bb_mediaclip_failed -> {
                _onMediaClipLoaded(eventType, mapOf("clipData" to null))
            }
            EventName.bb_resized -> {
                _onResized(eventType, data)
            }

            EventName.adInitialized -> {
                _onAdInitialized()
            }
            EventName.adLoaded -> {
                _onAdLoaded(data)
            }
            EventName.adCanPlay -> {
                _onAdCanPlay(data)
            }
            EventName.adStarted -> {
                _onAdStarted(data)
            }
            EventName.adFirstQuartile, EventName.adMidPoint, EventName.adThirdQuartile -> {
                _onAdQuartile(eventType, data)
            }
            EventName.adComplete -> {
                _onAdComplete(data)
            }
            EventName.allAdsCompleted -> {
                _onAllAdsCompleted(data)
            }
            EventName.adClicked -> {
                _onAdClicked(data)
            }
            EventName.adSkipped -> {
                _onAdSkipped(data)
            }
            EventName.adNoAd -> {
                _onAdNoAd(data)
            }
            EventName.adFailed -> {
                _onAdFailed(data)
            }
            EventName.adContentPauseReq -> {
                _mediaSuspended = true
            }
            EventName.adContentResumeReq -> {
                _mediaSuspended = false
            }

            EventName.playing -> {
                _playerStarted = true
            }
            EventName.ended -> {
                _playerStarted = false
            }
            else -> { return }
        }
        Logger.d(TAG, "Processed event: $eventType")
    }

    // resources
    private var _eventBus: EventBusInterface? = eventBus
    private var _adController: AdControllerInterface? = null
    private var _adMacroHelper: AdMacroHelper? = null

    // settings
    private var _baseUrl: String = ""
    private var _queryStringParams: Parameters = parametersOf()
    private var _width: Number = 768
    private var _height: Number = 432
    private var _uuid: String? = null
    private var _buid: String? = null
    private var _rdid: String? = null
    private var _idtype: String? = null
    private var _is_lat: Boolean? = null
    private var _adTagUrlParams: Map<String, String> = mapOf()
    private var _consentString: String = ""
    private var _consentGdprApplies: Int = 0
    private var _consentCmpVersion: Int = 0
    private var _queryString: String = ""
    private var _usePrebid: Boolean = false
    private var _prebid_direct: Boolean = false
    private var _restriction_npaOnly: Boolean = false
    private var _commercialBehaviour: String? = null
    private var _playout_commercialBehaviour: String? = null
    private var _adUnit_commercialBehaviour: String? = null
    private var _minClipDurationPreroll: String? = null
    private var _playout_minClipDurationPreroll: String? = null
    private var _adUnit_minClipDurationPreroll: String? = null
    private var _minClipDurationPostroll: String? = null
    private var _playout_minClipDurationPostroll: String? = null
    private var _adUnit_minClipDurationPostroll: String? = null
    private var _startCollapsed: Boolean = false;
    private var _hidePlayerOnEnd: Boolean = false;

    // state
    private var _disabled: Boolean = false
    private var _loaded:Boolean = false
    private var _pos: PosType = PosType.PREROLL
    private var _currentAdUnit: AdUnit? = null
    private var _line: Int = -1
    private var _perPositionAdCounter_clip: MutableMap<PosType, Int> = mutableMapOf()
    private var _perPositionAdCounter_load: MutableMap<PosType, Int> = mutableMapOf()
    private var _perPositionAdCounter_sess: MutableMap<PosType, Int> = mutableMapOf()
    private var _mediaSuspended: Boolean = false
    private var _shouldPause: Boolean = false
    private var _playerStarted: Boolean = false
    private var _adControllerPlayed: Boolean = false

    // data
    private var _adUnits: List<AdUnit>? = null
    private var _clipData: MediaClip? = null
    private var _clipId: String? = null
    private var _clipTitle: String? = null
    private var _deeplink: String? = null
    private var _clipDuration: Double = 0.0
    private var _clipDisabled: Boolean = false
    private var _clipIsInArticle: Boolean = false
    private var _adType: String = "generic"
    private var _url: String = ""

    companion object { // this is Kotlin's way to support static class methods; don't ask...
        const val TAG = "MsasController"
        private fun _urlSetDartParameter(url: String, paramName: String, paramValue: String = "", onlyIfPresent: Boolean = false): String {
            var res = url
            if ((""";""" + paramName + """=?[^;?&#]*""").toRegex().containsMatchIn(res)) {
                res = (""";""" + paramName + """=?[^;?&#]*""").toRegex()
                    .replace(res, ";" + paramName + "=" + paramValue.encodeURLParameter())
            } else if (!onlyIfPresent) { // url parameter not found
                val parts = ("""[?#]{1}""").toRegex().split(res, 2)
                val parts0 = if (parts.size > 0) parts[0] else ""
                val partsRest = res.subSequence(parts0.length, res.length)
                res = parts0 + ";" + paramName + "=" + paramValue.encodeURLParameter() + partsRest
            }

            return res
        }
        private fun _urlSetParameter(url: String, paramName: String, paramValue: String = "", onlyIfPresent: Boolean = false): String {
            var res = url
            if (("""[?&]{1}""" + paramName + """=?[^&#]*""").toRegex().containsMatchIn(url)) {
                res = ("""&""" + paramName + """=?[^&#]*""").toRegex()
                    .replace(res, "&" + paramName + "=" + paramValue.encodeURLParameter())
                res = ("""\?""" + paramName + """=?[^&#]*""").toRegex()
                    .replace(res, "?" + paramName + "=" + paramValue.encodeURLParameter())
            } else if (!onlyIfPresent) { // url parameter not found
                res += (if (res.indexOf("?") >= 0) "&" else "?") + paramName + "=" + paramValue.encodeURLParameter()
            }

            return res
        }

        private fun _urlSubstituteMacro(
            url: String,
            macroName: String,
            macroValue: String
        ): String {
            return ("""\[""" + macroName + """\]""").toRegex(RegexOption.IGNORE_CASE)
                .replace(url, macroValue.encodeURLParameter())
        }
    }

    init {
        _adMacroHelper = AdMacroHelper()
        _eventBus?.addEventlistener(this)
        _ingestOpts(opts, options)
    }

    fun __destruct() {
        _eventBus?.removeEventlistener(this)
        _eventBus = null
        _adMacroHelper = null
    }

    var eventBus: EventBusInterface?
        get() = _eventBus
        set(value) {
            _eventBus?.removeEventlistener(this)
            _eventBus = value
            _eventBus?.addEventlistener(this)
        }

    var adController: AdControllerInterface?
        get() = _adController
        set(value) {
            _adController = value
        }

    fun resetAdCounter_load() {
        _perPositionAdCounter_load = mutableMapOf()
    }

    fun loadContent(content: List<AdUnit>?) {
        _adUnits = content
    }

    fun set(propertyName: String, propertyValue: Any?): Boolean {
        return true
    }

    fun get(propertyName: String): Any? {
        if (propertyName == "adCounter_clip") {
            var count: Int = 0
            for (item in _perPositionAdCounter_clip) {
                if (item.key != PosType.LEADER) {
                    count += item.value
                }
            }
            return count
        }

        return null
    }

    fun load(phase: Phase): Boolean {
        return this.play(phase, true)
    }

    fun play(phase: Phase, shouldPause: Boolean = false): Boolean {
        if (_disabled || _clipDisabled) return false // bail out
        var ret = true

        if (shouldPause) {
            _shouldPause = true
        }

        _adControllerPlayed = false
        //console.log("[MSAS] play called for phase " + phase);

        when (phase) {
            Phase.PRE -> {
                if (!_playPosition(PosType.PREROLL)) { // fall through if pre-roll position not defined
                    ret = _playNextPosition() // LEADER
                }
            }

            Phase.MAIN -> {
                if(_clipIsInArticle) {
                    _shouldPause = false
                }

                if (!_playPosition(PosType.INARTICLE) &&
                    !_playPosition(PosType.VMAP) &&
                    !_playPosition(PosType.MIDROLL) &&
                    !_playPosition(PosType.OVERLAY)
                ) { // fall through if neither main-roll, nor mid-roll position defined
                    ret = _playNextPosition()
                }
            }

            Phase.POST -> {
                if (!_playPosition(PosType.POSTROLL)) { // fall through if post-roll position not defined
                    ret = _playNextPosition() // EXITSCREEN
                }
            }

            else -> {
                ret = false
            }
        }

        return ret
    }

    fun pause(): Boolean {
        return _adController?.pause() ?: false
    }

    fun resume(): Boolean {
        if (_adControllerPlayed) {
            _adControllerPlayed = _adController?.play() ?: false
        }

        return _adControllerPlayed
    }

    private fun _ingestOpts(opts: EmbedObject?, options: Map<String, Any?>? = null) {
        if (opts != null) {
            // publication parameters
            if (opts.publicationData != null) {
                if (!opts.publicationData.baseurl.isNullOrEmpty()) _baseUrl = opts.publicationData.baseurl
            }

            // embed parameters
            if (opts.embedData != null) {
                if (!opts.embedData.baseurl.isNullOrEmpty()) _baseUrl = opts.embedData.baseurl
                if (!opts.embedData.queryString.isNullOrEmpty()) {
                    _queryStringParams =
                        opts.embedData.queryString.parseUrlEncodedParameters() // NB max 100 params!
                }
            }

            // playout settings
            if (opts.playoutData is Playout) {
                _ingestPlayoutData(opts.playoutData as Playout)
            }

            // override from options dict
            if ( options != null ) {
                if (options["commercials"] is String) _disabled = options["commercials"] as String == "false"
                if (options["commercials"] is Boolean) _disabled = options["commercials"] as Boolean == false

                if (options["adsystem_buid"] != null) _buid = options["adsystem_buid"] as? String
                if (options["adsystem_rdid"] != null) _rdid = options["adsystem_rdid"] as? String
                if (options["adsystem_idtype"] != null) _idtype = options["adsystem_idtype"] as? String
                if (options["adsystem_is_lat"] != null) _is_lat = options["adsystem_is_lat"] as? Boolean
                if (_uuid.isNullOrEmpty()) {
                    _uuid = _rdid
                }
//                if (_uuid.isNullOrEmpty()) {
//                    _uuid = localStorage?.get("uuid")
//                }
                if (_uuid.isNullOrEmpty()) {
                    _uuid = uuid4().toString()
                }

                if (options["consent_string"] is String) _consentString = options["consent_string"] as String
                if (options["consent_gdprApplies"] is Int) _consentGdprApplies = options["consent_gdprApplies"] as Int
                if (options["consent_cmpVersion"] is Int) _consentCmpVersion = options["consent_cmpVersion"] as Int

                _queryString = ""
                val adTagParams = mutableMapOf<String, String>()
                for (option in options) {
                    if (option.key.startsWith("macro_")) { // macro override
                        val optionValue = "${option.value}"
                        _queryString += "&${option.key.encodeURLParameter()}=${optionValue.encodeURLParameter()}"
                    } else if (option.key.startsWith("adTagUrlParam_") && option.value != null) {
                        val paramKey = option.key.removePrefix("adTagUrlParam_")
                        adTagParams[paramKey] = option.value.toString()
                    }
                }
                _adTagUrlParams = adTagParams
            }

            // content
            if (opts.adServicesData != null) {
                this.loadContent(opts.adServicesData)
            }
            if (opts.clipData != null) {
                _updateClip(opts.clipData)
            }
        }

        _update()
    }

    private fun _update() {
        val adMacroHelperSettings: MutableMap<String, Any?> = mutableMapOf()

//        adMacroHelperSettings["referrer"] = _referrer
        adMacroHelperSettings["deeplink"] = _deeplink
        adMacroHelperSettings["uuid"] = _uuid
        adMacroHelperSettings["width"] = _width // Number
        adMacroHelperSettings["height"] = _height // Number
        adMacroHelperSettings["clipId"] = _clipId
        adMacroHelperSettings["clipTitle"] = _clipTitle

        adMacroHelperSettings["buid"] = _buid
        adMacroHelperSettings["rdid"] = _rdid
        adMacroHelperSettings["idtype"] = _idtype
        adMacroHelperSettings["is_lat"] = _is_lat

        adMacroHelperSettings["consent_string"] = _consentString
        adMacroHelperSettings["consent_gdprApplies"] = _consentGdprApplies // Int
        adMacroHelperSettings["consent_cmpVersion"] = _consentCmpVersion // Int

        adMacroHelperSettings["queryString"] = _queryString

        _adMacroHelper?.updateSettings(adMacroHelperSettings)
    }

    private fun _ingestPlayoutData(playoutData: Playout) {
        if (playoutData.commercials != null) _disabled = (playoutData.commercials == "false")
        try {
            if (playoutData.width != null) _width = playoutData.width.toInt()
        } catch (e: Exception) {
        }
        try {
            if (playoutData.height != null) _height = playoutData.height.toInt()
        } catch (e: Exception) {
        }
        if (playoutData.adsystem_buid != null) _buid = playoutData.adsystem_buid
        if (playoutData.adsystem_rdid != null) _rdid = playoutData.adsystem_rdid
        if (playoutData.adsystem_idtype != null) _idtype = playoutData.adsystem_idtype
        if (playoutData.adsystem_is_lat != null) _is_lat =
            playoutData.adsystem_is_lat == "true" || playoutData.adsystem_is_lat == "1"
        if (_uuid.isNullOrEmpty()) {
            _uuid = _rdid
        }
//        if (_uuid.isNullOrEmpty()) {
//            _uuid = localStorage?.get("uuid")
//        }
        if (_uuid.isNullOrEmpty()) {
            _uuid = uuid4().toString()
        }
        // TODO: restriction_npaOnly
    }

    private fun _updateClip (clipData: MediaClip? = null) {
        _clipData = clipData

        _clipId = _clipData?.id
        _clipTitle = _clipData?.title
        val deeplink: String? = _clipData?.deeplink
        _deeplink = (if (!deeplink.isNullOrEmpty()) deeplink else _clipData?.gendeeplink) ?: "" // NB!
        try {
            _clipDuration = (_clipData?.length ?: "0").toDouble()
        } catch (e: Exception) {
        }
        _clipDisabled = _clipData?.disablecommercials == "true"
        _clipIsInArticle = _clipData?.mediatype == "inarticle" || _clipData?.mediatype == "mainroll"
    }

    private fun _onMediaClipLoaded(eventType: EventName, data: Map<String, Any?>?) {
        _perPositionAdCounter_clip = mutableMapOf()

        if (data != null) {
            val clipData = if (data["clipData"] != null) data["clipData"] as MediaClip else null
            _updateClip(clipData)
        }
    }

    private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
        val playoutData = payload?.get("playoutData") as? Playout
        if (playoutData != null) {
            _ingestPlayoutData(playoutData)
        }
        _update()
    }

    private fun _onResized(eventType: EventName, data: Map<String, Any?>?) {
        if (data != null) {
            if (data["width"] != null) _width = data["width"] as Number
            if (data["height"] != null) _height = data["height"] as Number
        }
    }

    private fun _onAdInitialized() {
        Logger.d("MsasController", "_onAdInitialized")
        _loaded = false
    }

    private fun _onAdLoaded(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdLoaded")
        _loaded = true
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_loaded, adSystemData)
    }

    private fun _onAdCanPlay(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdCanPlay")
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_canplay, adSystemData)

        if (_mediaSuspended && !_shouldPause) {
            _adControllerPlayed = _adController?.play() ?: false
        } // NB!
    }

    private fun _onAdStarted(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdStarted")
        if (_startCollapsed) {
            _eventBus?.trigger(EventName.bb_request_expand)
        }

        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_started, adSystemData)

        _onAdQuartile(EventName.adStarted, data) // NB after triggering bb_adsystem_started!
    }

    private fun _onAdQuartile(eventType: EventName, data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdQuartile")
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        var quartile = "0"
        when (eventType) {
            EventName.adStarted -> quartile = "0"
            EventName.adFirstQuartile -> quartile = "1"
            EventName.adMidPoint -> quartile = "2"
            EventName.adThirdQuartile -> quartile = "3"
            EventName.adComplete -> quartile = "4"
            else -> quartile = "0"
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties, "quartile" to quartile)
        _eventBus?.trigger(EventName.bb_adsystem_quartile, adSystemData)
    }

    private fun _onAdClicked(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdClicked")
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_clicked, adSystemData)
    }

    private fun _onAdSkipped(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdSkipped")
        _perPositionAdCounter_clip[_pos] =
            (_perPositionAdCounter_clip[_pos] ?: 0) + 1
        _perPositionAdCounter_load[_pos] =
            (_perPositionAdCounter_load[_pos] ?: 0) + 1
        _perPositionAdCounter_sess[_pos] =
            (_perPositionAdCounter_sess[_pos] ?: 0) + 1

        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_skipped, adSystemData)
        if (_pos != PosType.VMAP) { // under-react for VMAP for now
            _playNextPosition(true);
        }
    }

    private fun _onAdComplete(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdComplete")

        _onAdQuartile(EventName.adComplete, data) // NB before triggering bb_adsystem_finished!

        _perPositionAdCounter_clip[_pos] =
            (_perPositionAdCounter_clip[_pos] ?: 0) + 1
        _perPositionAdCounter_load[_pos] =
            (_perPositionAdCounter_load[_pos] ?: 0) + 1
        _perPositionAdCounter_sess[_pos] =
            (_perPositionAdCounter_sess[_pos] ?: 0) + 1
    }

    private fun _onAllAdsCompleted(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAllAdsCompleted")
        _loaded = false

        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_finished, adSystemData)

        _playNextPosition(true)
    }

    private fun _onAdNoAd(data: Map<String, Any?>?) {
        Logger.d("MsasController", "_onAdNoAd")
        _loaded = false
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_noad, adSystemData)

        if (!_okForCommercialBehaviour() || !_okForClipDuration() || !_handleNextLineItem() ) {
            _playNextPosition(true);
        }
    }

    private fun _onAdFailed(data: Map<String, Any?>?) {
        Logger.d("MsasController", "onAdFailed")
        _loaded = false
        var posString = _pos.toString()
        var adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
        if (data != null) {
            if (data["pos"] is String) posString = data["pos"] as String
            adProperties = data // {adId, adSystem, adTitle, adLinear, adContentType, duration, sdk[, adPodInfo][, cuePoints]}
        }
        val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to posString, "adRequestUrl" to _url, "adProperties" to adProperties)
        _eventBus?.trigger(EventName.bb_adsystem_failed, adSystemData)

        if (!_okForCommercialBehaviour() || !_okForClipDuration() || !_handleNextLineItem() ) {
            _playNextPosition(true);
        }
    }

    private fun _playPosition(pos: PosType): Boolean {
        var ret = false
        _pos = pos

        Logger.d("MsasController","_playPosition PosType: ${pos}" )

        // reset settings possibly overridden by previous adunit / lineitem
        _commercialBehaviour = _playout_commercialBehaviour // OBSOLETE?
        _minClipDurationPreroll = _playout_minClipDurationPreroll // OBSOLETE?
        _minClipDurationPostroll = _playout_minClipDurationPostroll // OBSOLETE?

        // find position data
        val adUnits = _adUnits
        if (adUnits != null) {
            var shortsMode = false
            _currentAdUnit = null
            for (adUnit in adUnits) {
                var adUnitPositionType = adUnit.positionType
                if (adUnitPositionType == "shorts") {
                    // In the frontend we use the positionType "shorts" to filter on,
                    // but for the rest of the setup we just treat it as inarticle
                    adUnitPositionType = if (_clipIsInArticle || _shouldPause) PosType.INARTICLE.toString() else null
                    shortsMode = (_pos == PosType.INARTICLE)
                } // NB shorts magic!
                if (adUnitPositionType != null && PosType.valueOf(adUnitPositionType.toUpperCase()) == _pos && adUnit.status == "published") {
                    _currentAdUnit = adUnit
                    break
                }
            }

            val currentAdUnit = _currentAdUnit
            if (currentAdUnit != null) { // found
                Logger.d("MsasController", "currentAdUnit  FOUND")
                val adUnit = currentAdUnit // short-hand
                val adUnitSettings: MutableMap<String, String?> = mutableMapOf()
                if (adUnit.playout?.ctaExitScreen is String) adUnitSettings["ctaExitScreen"] = adUnit.playout?.ctaExitScreen as String
                if (!adUnit.playout?.bgColor.isNullOrEmpty()) adUnitSettings["bgColor"] = adUnit.playout?.bgColor as String
                if (adUnit.playout?.ctaText is String) adUnitSettings["ctaText"] = adUnit.playout?.ctaText as String
                if (!adUnit.playout?.ctaTextColor.isNullOrEmpty()) adUnitSettings["ctaTextColor"] = adUnit.playout?.ctaTextColor as String
                if (!adUnit.playout?.ctaBackgroundColor.isNullOrEmpty()) adUnitSettings["ctaBackgroundColor"] = adUnit.playout?.ctaBackgroundColor as String
                if (adUnit.playout?.placeholderText is String) adUnitSettings["placeholderText"] = adUnit.playout?.placeholderText as String
                if (!adUnit.playout?.placeholderTextColor.isNullOrEmpty()) adUnitSettings["placeholderTextColor"] = adUnit.playout?.placeholderTextColor as String
                if (adUnit.playout?.commercialMuteButton != null) adUnitSettings["commercialMuteButton"] = adUnit.playout.commercialMuteButton
                if (adUnit.playout?.commercialPauseButton != null) adUnitSettings["commercialPauseButton"] = adUnit.playout.commercialPauseButton
                if (adUnit.playout?.commercialAdIcon != null) adUnitSettings["commercialAdIcon"] = adUnit.playout.commercialAdIcon
                if (adUnit.playout?.commercialProgressBar != null) adUnitSettings["commercialProgressBar"] = adUnit.playout.commercialProgressBar
                if (adUnit.playout?.commercialProgressBarColor != null) adUnitSettings["commercialProgressBarColor"] = adUnit.playout.commercialProgressBarColor
                if (adUnit.playout?.inviewMargin != null) adUnitSettings["inviewMargin"] = adUnit.playout.inviewMargin
                if (shortsMode) {
                    adUnitSettings["autoPlay"] = "false" // => update settings ???
                    adUnitSettings["interactivityInview"] = "none" // => update settings InviewController...
                    adUnitSettings["preloadMainroll"] = "true" // not used
                }
                _eventBus?.trigger(EventName.bb_adunit_initialized, mapOf("adPosition" to _pos.toString(), "adUnitCode" to adUnit.code, "adUnitSettings" to adUnitSettings))

                _adUnit_commercialBehaviour = if (adUnit.playout != null && adUnit.playout.commercialBehaviour != null) adUnit.playout.commercialBehaviour else _playout_commercialBehaviour
                _commercialBehaviour = _adUnit_commercialBehaviour
                _adUnit_minClipDurationPreroll = if (adUnit.playout != null && adUnit.playout.minClipDurationPreroll != null) adUnit.playout.minClipDurationPreroll else _playout_minClipDurationPreroll
                _minClipDurationPreroll = _adUnit_minClipDurationPreroll
                _adUnit_minClipDurationPostroll = if (adUnit.playout != null && adUnit.playout.minClipDurationPostroll != null) adUnit.playout.minClipDurationPostroll else _playout_minClipDurationPostroll
                _minClipDurationPostroll = _adUnit_minClipDurationPostroll

                _startCollapsed = adUnit.playout?.startCollapsed == "true" ?: false
                _hidePlayerOnEnd = adUnit.playout?.hidePlayerOnEnd == "true" ?: false
                if (_startCollapsed && !_playerStarted) {
                    _eventBus?.trigger(EventName.bb_request_collapse)
                }

                _line = -1
                if (_okForCommercialBehaviour() && _okForClipDuration()) ret = _handleNextLineItem()
            }
        }

        return ret
    }

    private fun _playNextPosition(mayTrigger: Boolean = false): Boolean {
        //debug( "MSASController.prototype._playNextPosition: mayTrigger = " + mayTrigger );
        var ret = true
        Logger.d("MsasController","_playNextPosition PosType: ${_pos}" )
//        _resetPlayoutData()

        when (_pos) {
            PosType.PREROLL -> {
                // next
                if (!_playPosition(PosType.LEADER)) { // may trigger bb_msas_pre_finished
                    if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_pre_finished)
                    ret = false
                }
            }

            PosType.LEADER -> {
                if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_pre_finished)
                ret = false
            }

            PosType.INARTICLE -> {
                if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_main_finished)
                ret = false
            }

            PosType.VMAP,
            PosType.OVERLAY,
            PosType.MIDROLL -> {
                if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_main_finished)
                ret = false
            }

            PosType.POSTROLL -> {
                // next
                if (!_playPosition(PosType.EXITSCREEN)) { // may trigger bb_msas_post_finished
                    if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_post_finished)
                    if (_hidePlayerOnEnd) _eventBus?.trigger(EventName.bb_request_collapse)
                    ret = false
                }
            }

            PosType.EXITSCREEN -> {
                if (mayTrigger) _eventBus?.trigger(EventName.bb_msas_post_finished)
                if (_hidePlayerOnEnd) _eventBus?.trigger(EventName.bb_request_collapse)
                ret = false
            }
        }

        return ret
    }

    private fun _okForCommercialBehaviour(): Boolean {
        var ok = false;
        if (_clipIsInArticle) return true; // Allow replay for mainroll

        if (_commercialBehaviour == "Once per load") {
            ok = !((_perPositionAdCounter_load[_pos] ?: 0) > 0)
        } else if (_commercialBehaviour == "Once per session") {
            ok = !((_perPositionAdCounter_sess[_pos] ?: 0) > 0)
        } else { // Once per clip
            ok = !((_perPositionAdCounter_clip[_pos] ?: 0) > 0)
        }

        if (!ok) Logger.d("[MSASController] _okForCommercialBehaviour", "ok: " + (if (ok) "true" else "false"));
        return ok;
    }

    private fun _okForClipDuration(): Boolean {
        var ok = true;
        when (_pos) {
            PosType.PREROLL, PosType.VMAP -> {
                try {
                    if (_clipDuration > 0 && _clipDuration < (_minClipDurationPreroll ?: "0").toDouble()) ok = false;
                } catch (e: Exception) {
                }
                if (!ok) Logger.d("[MSASController] _okForClipDuration", "Not playing PREROLL, _minClipDurationPreroll = " + _minClipDurationPreroll);
            }
            PosType.POSTROLL -> {
                try {
                    if (_clipDuration > 0 && _clipDuration < (_minClipDurationPostroll ?: "0").toDouble()) ok = false
                } catch (e: Exception) {
                }
                if (!ok) Logger.d("[MSASController] _okForClipDuration", "Not playing POSTROLL, _minClipDurationPreroll = " + _minClipDurationPreroll);
            }
            else -> {}
        }

        return ok
    }

    private fun _handleNextLineItem(): Boolean {
        var ret = false

//        _resetPlayoutData()
        _adType = "generic"
        _url = ""

        val currentAdUnit = _currentAdUnit
        val currentLineItems = currentAdUnit?.lineitems
        if (currentAdUnit != null && currentLineItems != null) {
            _line++ // next;)
            if (_line < currentLineItems.count()) {
                Logger.d("MsasController", "_handleNextLineItem lineItem FOUND")
                val lineItem = currentLineItems[_line]

                val commercialBehaviour = if (lineItem.playout != null && lineItem.playout["commercialBehaviour"] != null) lineItem.playout["commercialBehaviour"] else _adUnit_commercialBehaviour
                _commercialBehaviour = commercialBehaviour
                val minClipDurationPreroll = if (lineItem.playout != null && lineItem.playout["minClipDurationPreroll"] != null) lineItem.playout["minClipDurationPreroll"] else _adUnit_minClipDurationPreroll
                _minClipDurationPreroll = minClipDurationPreroll
                val minClipDurationPostroll = if (lineItem.playout != null && lineItem.playout["minClipDurationPostroll"] != null) lineItem.playout["minClipDurationPostroll"] else _adUnit_minClipDurationPostroll
                _minClipDurationPostroll = minClipDurationPostroll

                if (_okForCommercialBehaviour() && _okForClipDuration()) {
                    if (lineItem.creativeType == "creative") {
                        if (lineItem.creativeId != null) {
                            if (_loaded && _clipIsInArticle && _pos == PosType.INARTICLE) { //  && _mediaSuspended && !_shouldPause
                                _adControllerPlayed = _adController?.play() ?: false // NB!
                            } else {
                                _adType = "vms"
                                _url = _baseUrl + "/mediaclip/" + lineItem.creativeId + ".xml?output=vast"
                                val adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")
                                val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adProperties" to adProperties, "lineItemCode" to lineItem.code, "vmsClipId" to lineItem.creativeId)
                                _eventBus?.trigger(EventName.bb_adsystem_initialized, adSystemData)
                                _eventBus?.trigger(EventName.bb_adsystem_loadstart, adSystemData)
                                if (lineItem.vastXml != null) {
                                    _adController?.loadAdsResponse(lineItem.vastXml, _pos)
                                } else if (lineItem.vastUrl != null) {
                                    _adController?.loadAdTagUrl(_url, _pos)
                                } else {
                                    return false
                                }
                            }
                            ret = true
                        }
                    } else { // VAST
                        if (lineItem.vastUrl != null || lineItem.vastXml != null) {
                            if (_loaded && _clipIsInArticle && _pos == PosType.INARTICLE) { // && _mediaSuspended && !_shouldPause
                                _adControllerPlayed = _adController?.play() ?: false // NB!
                            } else {
                                _adType = lineItem.vastSubtype ?: "generic"
                                _url = _preprocessVastUrl(lineItem.vastUrl ?: "")
                                val adProperties: Map<String, Any?> = mapOf("sdk" to "GOOGLE_IMA")

                                //ADD AD-CUSTOM-SKIP-INFO
                                var skipOffset: String? = currentAdUnit.playout?.skipOffset ?: "-1"
                                var skipCounterText: String? = currentAdUnit.playout?.skipCounterText ?: ""
                                var skipButtonText: String? = currentAdUnit.playout?.skipButtonText ?: ""
                                if (lineItem.playout != null && lineItem.playout["skipOffset"] != null && lineItem.playout["skipOffset"] != "-1") {
                                    skipOffset = lineItem.playout["skipOffset"] ?: "-1"
                                    skipCounterText = lineItem.playout["skipCounterText"] ?: ""
                                    skipButtonText = lineItem.playout["skipButtonText"] ?: ""
                                }

                                val adSystemData: Map<String, Any?> = mapOf("adType" to _adType, "adPosition" to _pos.toString(), "adRequestUrl" to _url, "adProperties" to adProperties, "lineItemCode" to lineItem.code, "skipOffset" to skipOffset, "skipCounterText" to skipCounterText, "skipButtonText" to skipButtonText)
                                _eventBus?.trigger(EventName.bb_adsystem_initialized, adSystemData)
                                _eventBus?.trigger(EventName.bb_adsystem_loadstart, adSystemData)
                                if (lineItem.vastXml != null) {
                                    _adController?.loadAdsResponse(lineItem.vastXml, _pos)
                                } else if (lineItem.vastUrl != null) {
                                    _adController?.loadAdTagUrl(_url, _pos)
                                } else {
                                    return false
                                }
                            }
                            ret = true
                        }
                    }
                }
            }
        }

        return ret
    }

    public fun test_preprocessVastUrl(vastUrl: String): String {
        return _preprocessVastUrl(vastUrl)
    }

    private fun _preprocessVastUrl(vastUrl: String): String {
        var url = vastUrl

        // determine substitution values
        val now = Clock.System.now()
        val timeStamp = now.toEpochMilliseconds()
        val referrer = "in-app" // NB!

        // determine subtype
        var subtype: String? = null
        // matches both doubleclick.net/pfadx/ and doubleclick.net/ddm/pfadx/
        if (("""doubleclick\.net\/[\w/]*pfadx\/""").toRegex(RegexOption.IGNORE_CASE).containsMatchIn(vastUrl)) {
            subtype = "dart"
        }
        if (vastUrl.indexOf("doubleclick.net/gampad/") != -1) {
            //debug('[MSASSystem.VAST] setting system to DfP because of URL structure');
            subtype = "dfp"
        }
        if (_usePrebid && (_prebid_direct || vastUrl == "__prebid_direct__")) {
            //debug('[MSASSystem.VAST] setting system to prebid_direct');
            subtype = "prebid_direct"
        }

        // %% macros
        val re = Regex("""%%[^%]*%%""")
        val matchResults = re.findAll(url)
        for (matchResult in matchResults) {
            val match = matchResult.value
            val macroVal = _adMacroHelper?.resolvePercentMacro(match)
            if (macroVal != null) {
                url = url.replace(match, macroVal.encodeURLParameter())
            } else {
                url = url.replace(match, "") // NB leave no %% macro's behind!
            }
        }

        if (subtype == "dart") {
            url = MsasController._urlSetDartParameter(url, "ord", timeStamp.toString(), true)
            if (!_rdid.isNullOrEmpty() && !_idtype.isNullOrEmpty() && _is_lat != null) { // all three must be present
                url = MsasController._urlSetDartParameter(url, "dc_rdid", "$_rdid")
                url = MsasController._urlSetDartParameter(url, "dc_lat", if (_is_lat == true) "1" else "0")
            }

            // restriction_npaOnly
            if (_restriction_npaOnly) {
                url = MsasController._urlSetDartParameter(url, "npa", "1")
            }

            // url = _addCustomDfPParameters(url)
        } else if (subtype == "dfp") {
            url = MsasController._urlSetParameter(url, "url", referrer, true)
            url = MsasController._urlSetParameter(url, "correlator", "$_uuid", true)
            if (!_rdid.isNullOrEmpty() && !_idtype.isNullOrEmpty() && _is_lat != null) { // all three must be present
                url = MsasController._urlSetParameter(url, "rdid", "$_rdid")
                url = MsasController._urlSetParameter(url, "idtype", "$_idtype")
                url = MsasController._urlSetParameter(
                    url,
                    "is_lat",
                    if (_is_lat == true) "1" else "0"
                )
            }

            // restriction_npaOnly
            if (_restriction_npaOnly) {
                url = MsasController._urlSetParameter(url, "npa", "1")
            }

            // url = _addCustomDfPParameters(url)
        } else if (subtype == "prebid_direct") {
            // nothing yet
        }

        // standard macros
        val bracketMatchResults = Regex("""\[[^\[\]]*\]""").findAll(url)
        for (matchResult in bracketMatchResults) {
            val match = matchResult.value
            val macroVal = _adMacroHelper?.resolveBracketMacro(match)
            if (macroVal != null) {
                url = url.replace(match, macroVal.encodeURLParameter())
            } else {
                // nothing; doNotReplace
            }
        }

        // Apply custom ad tag URL parameters
        for ((paramKey, paramValue) in _adTagUrlParams) {
            when (subtype) {
                "dart" -> url = MsasController._urlSetDartParameter(url, paramKey, paramValue)
                "dfp" -> url = MsasController._urlSetParameter(url, paramKey, paramValue)
                else -> url = MsasController._urlSetParameter(url, paramKey, paramValue)
            }
        }

        return MsasController._urlSetParameter(url, "_bbcb_", "${(0..1000000).random()}")
    }
}
