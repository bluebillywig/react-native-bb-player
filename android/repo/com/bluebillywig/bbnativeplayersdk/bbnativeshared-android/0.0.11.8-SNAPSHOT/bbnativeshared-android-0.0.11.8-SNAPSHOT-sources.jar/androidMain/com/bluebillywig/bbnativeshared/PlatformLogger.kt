package com.bluebillywig.bbnativeshared

import android.util.Log

/**
 * @suppress
 */
internal actual class PlatformLogger {

    actual fun debug(tag: String, message: String) {
//        if (BuildConfig.DEBUG) { // Kotlin has been debating this since 2015. R.I.P. Kotlin...
            Log.d(tag, message)
//        }
    }

    actual fun warn(tag: String, message: String) {
//        if (BuildConfig.DEBUG) { // Kotlin has been debating this since 2015. R.I.P. Kotlin...
            Log.w(tag, message)
//        }
    }

    actual fun error(tag: String, message: String) {
//        if (BuildConfig.DEBUG) { // Kotlin has been debating this since 2015. R.I.P. Kotlin...
            Log.e(tag, message)
//        }
    }
}
