package com.bluebillywig.bbnativeshared

import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.data.ContentLoader
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import com.bluebillywig.bbnativeshared.model.*
import io.ktor.http.*

/**
 * @suppress
 */
class RelatedItemsHelper(eventBus: EventBusInterface?, pc: ProgramController?):EventListenerInterface {
	companion object {
		const val TAG = "RelatedItemsHelper"
	}

	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_mediaclip_loaded -> { _onClipLoaded(eventType, data) }
			EventName.bb_mediaclip_failed -> { _onClipLoaded(eventType, data) }
			EventName.bb_project_loaded -> { _onProjectLoaded(eventType, data) }
			EventName.bb_playout_changed -> { _onPlayoutChanged(eventType, data) }
			else -> { return }
		}
		Logger.d(TAG, "Processed event: $eventType")
	}

	// resources
	private var _eventBus: EventBusInterface? = eventBus
	private var _pc: ProgramController? = pc
	private var _contentLoader: ContentLoader? = null

	// settings
	private var _baseUrl: String = ""
	private var _exitscreenItemsListId: String? = null
	private var _randomizeRelatedItems: Boolean = false
	private var _autoPlayNext: Boolean = false

	// state
	private var _mode: String? = null
	private var _clipsSeenThisSession: MutableList<String> = mutableListOf()
	private var _contentSeenThisSession: MutableList<String> = mutableListOf()
	private var _randomSeed: Int = -1

	// data
	private var _content: ContentItemInterface? = null
	private var _exitscreenAuxfield: String? = null
	private var _relatedClips: MutableList<ContentItemInterface> = mutableListOf()
	private var _relatedItems: MutableList<ContentItemInterface> = mutableListOf()
	private var _network: NetworkInterface? = null
	private var _externalItems: List<ContentItemInterface>? = null
	private var _externalItemsProvided = (_externalItems != null)
	private var _externalItemsEnriched = false

	var network: NetworkInterface?
		get() = _network
		set(value) {
			_network = value
			_contentLoader?.network = value
		}

	init {
		_eventBus?.addEventlistener(this)
		_contentLoader = ContentLoader()
	}

	fun __destruct() {
		_network = null

		_contentLoader?.__destruct()
		_contentLoader = null

		_eventBus?.removeEventlistener(this)
		_eventBus = null
		_pc = null
	}

	fun load(mode: String? = null) {
		Logger.d(TAG, "load mode: $mode")
		var mode_ = mode
		if (_externalItemsProvided && mode !== "append") {
			mode_ = "externalItems"
		}
		Logger.d(TAG, "load mode_: ${mode_}")
		if (_content != null || _baseUrl != "") { // && (_content as ContentItem).mediatype != "mainroll") {
			val titleParts: List<String>
			val title = _content?.title
			if (title != null) {
				titleParts = title.split(" ")
			} else {
				titleParts = listOf() // empty
			}

			if (_mode == null && mode_ == null) {
				/* Check if any of the clip's aux fields is filled */
				_exitscreenAuxfield = null // IMPROVE ME: make local var
//				val exitscreenAuxfields = "relateditems gerelateerdeitems relatedcliplist exitscreen exitscreenitems".split(" ");
//				for (var i = 0; i < exitscreenAuxfields.length; i++) {
//					var f = _content[exitscreenAuxfields[i]];
//					if (typeof f != "undefined" && f != "" && f != null) {
//						_exitscreenAuxfield = f;
//					}
//				}
				if (_exitscreenAuxfield != null) {
					_mode = "exitscreenAuxfield"
				} else {
					/* Check the playout for an exitscreenItemsListId */
					if (_exitscreenItemsListId != null && _exitscreenItemsListId != "") {
						_mode = "exitscreenItemsListId"
					} else {
						/* Try a tag search */
						val cat = if (_content is MediaClip) (_content as MediaClip).cat else null
						if (!cat.isNullOrEmpty() || titleParts.count() > 0) {
							_mode = "tagSearch"
						} else {
							_mode = "latestItems"
						}
					}
				}
			}
			if (mode_ != null) _mode = mode_ // NB override!
			//debug('Loading exitscreen in mode: ' + _mode)
			var searchString = ""
			var sortString = ""
			var cliplistid = ""
			var filterQuery = ""
			val noTimelineFilterQuery = "-timeline_multistring:[* TO *]"

			when (_mode) {
				"externalItems" -> {
					if (!_externalItemsEnriched) {
						_externalItemsEnriched = true
						var filtersJsonString = "["
						_externalItems?.forEach {
							filtersJsonString += "{\"id\":\"#\",\"type\":\"search\",\"field\":\"id\",\"operator\":\"equals\",\"value\":\"${it.id}\"},"
						}
						filtersJsonString = filtersJsonString.replace(Regex(""",$"""), "") + "]" // fixes last comma
						if (filtersJsonString.length > 2) {
							val filtersetJsonString = "[{\"filters\":${filtersJsonString}}]"
							val filterSetQueryObj: Map<String, String> = mapOf("filterset" to filtersetJsonString, "filterbyusetype" to "editorial", "limit" to "15")
							_doFilterSetSearch(filterSetQueryObj) // will call _onDataLoaded, resulting in load('append') if nothing found
						}
					}
					return // NB!
				}
				"exitscreenAuxfield" -> {
					searchString = ""
					cliplistid = _exitscreenAuxfield ?: ""
				}
				"exitscreenItemsListId" -> {
					searchString = ""
					cliplistid = _exitscreenItemsListId ?: ""
					if (_randomizeRelatedItems) {
						if (_randomSeed < 0) _randomSeed = (0..10).random()
						sortString = "random_$_randomSeed desc"
						_randomSeed = (_randomSeed + 1) % 10
					}
				}
				"tagSearch" -> {
					var searchStringCatsAND = ""
					var searchStringCatsOR = ""
					var searchStringCatsTitleAND = ""
					var searchStringCatsTitleOR = ""
					var searchStringRest = ""

					// searchstring for categories in categories
					if (_content is MediaClip) {
						val cat = (_content as MediaClip).cat ?: emptyList()
						val searchStringCats: MutableList<String> = mutableListOf() // empty
						for (item in cat) {
							searchStringCats.add("catSort:\"$item\"")
							searchStringRest += "$item "
						}
						searchStringCatsAND += searchStringCats.joinToString(" AND ")
						searchStringCatsOR += searchStringCats.joinToString(" OR ")
					}

					// searchstring for title parts in categories
					if (titleParts.count() > 0) {
						val searchStringCatsTitle: MutableList<String> = mutableListOf() // empty
						for (item in titleParts) {
							searchStringCatsTitle.add("catSort:\"$item\"")
							searchStringRest += "$item "
						}
						searchStringCatsTitleAND += searchStringCatsTitle.joinToString(" AND ")
						searchStringCatsTitleOR += searchStringCatsTitle.joinToString(" OR ")
					}

					// filter query string for clips seen this session
					if (_clipsSeenThisSession.count() > 0) {
						filterQuery = "-id:(\"" + _clipsSeenThisSession.joinToString("\",\"") + "\")"
					}

					if (searchStringCatsAND != "") searchString += "($searchStringCatsAND)^10 OR "
					if (searchStringCatsOR != "") searchString += "($searchStringCatsOR)^5 OR "
					if (searchStringCatsTitleAND != "") searchString += "($searchStringCatsTitleAND)^3 OR "
					if (searchStringCatsTitleOR != "") searchString += "($searchStringCatsTitleOR)^3 OR "
					if (searchStringRest != "") searchString += "($searchStringRest)^1"

					if (_randomizeRelatedItems) {
						if (_randomSeed < 0) _randomSeed = (0..10).random()
						sortString = "random_${_randomSeed} desc"
						_randomSeed = (_randomSeed + 1) % 10
					} else {
						searchString += " OR (typeSort:MediaClip)^1 OR (typeSort:Project)^1"
						sortString = "score desc,id desc"
					}
				}
				else -> { // "latestItems", "append"
					if (_mode == "append" && !_autoPlayNext) {
						if (_randomizeRelatedItems) {
							if (_randomSeed < 0) _randomSeed = (0..10).random()
							sortString = "random_${_randomSeed} desc"
							_randomSeed = (_randomSeed + 1) % 10
						} else {
							sortString = "id desc"
						}
						searchString += "typeSort:MediaClip OR typeSort:Project"
					}
				}
			}


			var query = "((typeSort:MediaClip AND usetypeSort:editorial AND (mediatypeSort:video OR mediatypeSort:audio)) OR (typeSort:Project)) AND statusSort:\"published\""
			if ( searchString != "" ) {
				query +=  " AND ($searchString)"
			}

			var searchData = mutableMapOf(
				"query" to query,
				"fq[0]" to filterQuery,
				"fq[1]" to noTimelineFilterQuery,
				"filterbyusetype" to "all",
				"genericEntity" to "1",
				"className[0]" to "MediaClip",
				"className[1]" to "Project",
				"limit" to "15",
				"allowCache" to "true"
			)
			if (sortString != "") searchData["sort"] = sortString
			if (cliplistid != "") {
				searchData["cliplistid"] = cliplistid
				searchData["fq[1]"] = ""
			}

			var url = _baseUrl + "/json/search?"
			for (entry in searchData) {
				try {
					url += "&" + entry.key.encodeURLParameter() + "=" + entry.value.encodeURLParameter()
				} catch (_: Exception) {}
			}
			Logger.d("RelatedItemsHelper", "loading: " + url)
			_contentLoader?.getObjectFromJsonUrl<MediaClipList>(url, { _loadContentSuccess(it) }, { _loadContentFailure(it) })
		}
	}

	public fun setItems (items: List<ContentItemInterface>? = null): Boolean {
		_externalItems = items
		_externalItemsProvided = (_externalItems != null)
		_externalItemsEnriched = false

		val externalItems_ = _externalItems
		if (externalItems_ != null && externalItems_.isNotEmpty()) {
			// sanity-test the first item
			val item0 = externalItems_[0]
			if (!item0.id.isNullOrEmpty() && !item0.title.isNullOrEmpty() && !item0.deeplink.isNullOrEmpty()) {
				// use directly without enriching
				_externalItemsEnriched = true
				_relatedItems.clear()
				_relatedClips.clear()
				for (item in externalItems_) {
					if (item is MediaClip) {
						val contentId = "MediaClip:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
							_relatedClips.add(_sanitizeContentItem(item) as MediaClip) // legacy
						}
					}
					if (item is MediaClipList) {
						val contentId = "MediaClipList:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
						}
					}
					if (item is Project) {
						val contentId = "Project:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
						}
					}
				}
				_eventBus?.trigger(EventName.bb_related_clips_changed, mapOf("clips" to _relatedClips, "items" to _relatedItems))
				return true
			}
		}
		_mode = null
		this.load()
		return true;
	}

	private fun _loadContentSuccess(data: ContentItemInterface?) {
		Logger.d("RelatedItemsHelper", "load success")
		if (data != null && data is MediaClipList) { // && data.error != "true") {
			if (data.allowDatasource == "true" || data.allowDatasource_boolean == true) {
//				if (DataSourceHelper) {
//					_dataSourceHelper = new DataSourceHelper(this.$element, _opts);
//					if (typeof data.filters_string === 'string') {
//						var filterSetContainer = JSON.parse(data.filters_string);
//						_dataSourceHelper.processFiltersContainer(filterSetContainer, function(processedFilterSet) {
//							__doFilterSetSearch(processedFilterSet);
//						});
//					} // else?
//				}
			} else {
				_onDataLoaded(data)
			}
		} else {
			_onDataLoaded(data)
		}
	}

	private fun _loadContentFailure(error: Exception?) {
		Logger.d("RelatedItemsHelper", "load failed")

		if (_mode != "append") {
			this.load("append") // NB RECURSION!
		} else {
			_eventBus?.trigger(EventName.bb_related_clips_changed, mapOf("clips" to _relatedClips, "items" to _relatedItems))
		}
	}

	private fun _doFilterSetSearch (filterSetQueryObj: Map<String, String>?) {
		if (filterSetQueryObj == null || filterSetQueryObj["filterset"] == null) return
		var url = _baseUrl + "/json/search?"
		for (entry in filterSetQueryObj) {
			url += "&" + entry.key.encodeURLParameter() + "=" + entry.value.encodeURLParameter()
		}
		Logger.d(TAG, "_doFilterSetSearch going to load: $url")
		_contentLoader?.getObjectFromJsonUrl<MediaClipList>(url, { _onDataLoaded(it) }, { })
	}

	private fun _onDataLoaded(data: ContentItemInterface?) {
		if (data != null && data is MediaClipList) { // && data.error != "true") {
			val list = data as MediaClipList
			val items: MutableList<ContentItem> = list.items?.toMutableList() ?: mutableListOf()
			var numfound = list.numfound ?: items.count().toLong()
			if (_mode == "externalItems" && numfound <= 0) {
				_externalItems?.forEach {
					if (it is ContentItem) { // CHECK ME!
						items.add(it as ContentItem) // NB hope for completeness!
					}
				}
				numfound = items.count().toLong()
			}
			if (numfound > 0) {
				if (_mode != "append") {
					_relatedItems.clear()
				}
				if (_mode != "append") {
					_relatedClips.clear()
				}

				for (item in items) {
					if (item is MediaClip) {
						val contentId = "MediaClip:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
							_relatedClips.add(_sanitizeContentItem(item) as MediaClip) // legacy
						}
					}
					if (item is MediaClipList) {
						val contentId = "MediaClipList:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
						}
					}
					if (item is Project) {
						val contentId = "Project:${item.id}"  // NB!
						if (_contentSeenThisSession.indexOf(contentId) < 0) {
							_relatedItems.add(item)
						}
					}
				}

				if (numfound < 14 && _mode == "tagSearch") {
					this.load("append") // NB RECURSION!
				} else {
					if (_randomizeRelatedItems) {
						_relatedItems.shuffle()
						_relatedClips.shuffle()
					}
					_eventBus?.trigger(EventName.bb_related_clips_changed, mapOf("clips" to _relatedClips, "items" to _relatedItems))
				}
			} else { // nothing found
				if (_mode != "append") {
					this.load("append") // NB RECURSION!
				} else {
					_eventBus?.trigger(EventName.bb_related_clips_changed, mapOf("clips" to _relatedClips, "items" to _relatedItems))
				}
			}
		} else { // error! Load something
			if (_mode != "append") {
				this.load("append") // NB RECURSION!
			} else {
				_eventBus?.trigger(EventName.bb_related_clips_changed, mapOf("clips" to _relatedClips, "items" to _relatedItems))
			}
		}
	}

	private fun _sanitizeContentItem(item: ContentItem):ContentItem {
		return item // IMPLEMENT ME
	}

	private fun _onClipLoaded(eventType: EventName, payload: Map<String, Any?>?) {
		_externalItems = null // NB _externalItemsProvided stays the same!
		_externalItemsEnriched = false
		if (payload != null && payload["clipData"] != null) {
			_content = payload["clipData"] as ContentItemInterface
			if (_content is MediaClip) {
				_clipsSeenThisSession.add("${_content?.id}") // legacy
				val contentId = "MediaClip:${_content?.id}"  // NB!
				_contentSeenThisSession.add(contentId)
			}
		} else {
			_content = null
		}
	}

	private fun _onProjectLoaded(eventType: EventName, payload: Map<String, Any?>?) {
		if (payload != null && payload["projectData"] != null) {
			_content = payload["projectData"] as ContentItemInterface
			if (_content is Project) {
				val contentId = "Project:${_content?.id}" // NB!
				_contentSeenThisSession.add(contentId)
			}
		} else {
			_content = null
		}
	}

	private fun _onPlayoutChanged(eventType: EventName?, payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
	}

	private fun _ingestPlayoutData(playoutData: Playout) {
		if (playoutData.exitscreenItemsListId != null) _exitscreenItemsListId = playoutData.exitscreenItemsListId
		if (playoutData.randomizeRelatedItems != null) _randomizeRelatedItems = playoutData.randomizeRelatedItems == "true"
		if (playoutData.autoPlayNext != null) _autoPlayNext = playoutData.autoPlayNext == "true"
	}

	private fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			if (opts.publicationData != null) {
				if (!opts.publicationData.baseurl.isNullOrEmpty()) _baseUrl = opts.publicationData.baseurl
			}

			// embed parameters
			if (opts.embedData != null) {
				if (!opts.embedData.baseurl.isNullOrEmpty()) _baseUrl = opts.embedData.baseurl
			}

			// playout settings
			if (opts.playoutData != null) {
				_ingestPlayoutData(opts.playoutData)
			}
		}
	}
}
