package com.bluebillywig.bbnativeshared

/**
 * @suppress
 */
expect class Capabilities() {
    companion object {
        fun canPlayType(type: String): Boolean
    }
}
