package com.bluebillywig.bbnativeshared.controller

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.data.ContentLoader
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.enums.*
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import io.ktor.http.*

/**
 * @suppress
 */
class EmbedController(eventBus: EventBusInterface?, jsonEmbedUrl: String?) {
	private var _eventBus: EventBusInterface? = eventBus
	private var _jsonEmbedUrl: String? = jsonEmbedUrl

	private var _baseUrl: String = ""
	private var _appIndicator: String = "p"
	private var _appId: String = "default"
	private var _contentIndicator: String? = null
	private var _contentId: String? = null

	private var _publicationName: String = ""

	// data
	private var _embedObject: EmbedObject? = null

	// resources
	private var _contentLoader: ContentLoader? = null

	private var _network: NetworkInterface? = null
	
	private var _options: Map<String, Any?>? = null

	var network: NetworkInterface?
		get() = _network
		set(value) {
			_network = value
			_contentLoader?.network = value
		}

	companion object { // this is Kotlin's way to support static class methods; don't ask...
		fun publicationNameFromBaseUrl(baseUrl: String): String {
			var publicationName = ""

			val re = Regex("""^[\w:]*//([\w-.]+)\.[\w-]+\.[\w-]+/?""",
				RegexOption.IGNORE_CASE) // matches testsuite.acc in https://testsuite.acc.bbvms.com
			val found = re.find(baseUrl)
			if (found != null && found.groupValues.count() > 1) {
				publicationName = found.groupValues.get(1)
			}

			return publicationName
		}

		fun createJsonEmbedUrl(baseUrl: String, appIndicator: String, appId: String): String {
			return EmbedController.createJsonEmbedUrl(baseUrl, appIndicator, appId, null, null)
		}

		fun createJsonEmbedUrl(baseUrl: String, appIndicator: String, appId: String, contentIndicator: String?, contentId: String?): String {
			var jsonEmbedUrl: String = baseUrl

			val aMap = mapOf("appIndicator" to appIndicator.encodeURLParameter(), "appId" to appId.encodeURLParameter())
			jsonEmbedUrl += "/" + aMap.get("appIndicator") + "/" + aMap.get("appId")
			if (contentIndicator != null && contentId != null) {
				val cMap = mapOf("contentIndicator" to contentIndicator.encodeURLParameter(), "contentId" to contentId.encodeURLParameter())
				jsonEmbedUrl += "/" + cMap.get("contentIndicator") + "/" + cMap.get("contentId")
			}
			jsonEmbedUrl += ".json"

			return jsonEmbedUrl
		}
	}

	init {
		_contentLoader = ContentLoader()
		_contentLoader?.network = _network // typically null
		val jsonEmbedUrl = _jsonEmbedUrl
		if (jsonEmbedUrl != null) {
			this.load(jsonEmbedUrl, _options)
		}
	}

	fun __destruct() {
		_network = null

		_contentLoader?.__destruct()
		_contentLoader = null

		_eventBus = null
		_embedObject = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) { _eventBus = value }

	fun load(jsonEmbedUrl: String, options: Map<String, Any?>? = null) {
		// e.g. https://testsuite.acc.bbvms.com/p/default/c/1234567.json?foo#bar
		_options = options
		var url = jsonEmbedUrl;
		url = url.replace(Regex("""[?#]+.*$"""), "") // strip query string
		url = url.replace(Regex("""\.[^.]*$"""), "") // strip extension
		val parts = url.split("/"); // 'https:', '', 'testsuite.acc.bbvms.com', 'p', 'default', 'c', '1234567.json?foo#bar'
		if (parts.count() > 4) {
			_baseUrl = parts.get(0) + "//" + parts.get(2) // NB no trailing slash!
			_appIndicator = parts.get(3)
			_appId = parts.get(4)
			_contentIndicator = parts.getOrNull(5)
			_contentId = parts.getOrNull(6)

			_publicationName = EmbedController.publicationNameFromBaseUrl(_baseUrl)
		}

		_contentLoader?.getObjectFromJsonUrl<EmbedObject>(jsonEmbedUrl, {
			_embedObject = it;
			Logger.d("EmbedController", "Embed loaded. Going to trigger 'bb_embed_loaded'")
			_eventBus?.trigger(EventName.bb_embed_loaded, mapOf("url" to url, "embedObject" to _embedObject, "options" to options))
		}, {
			Logger.d("EmbedController", "Embed load failed. Going to trigger 'bb_embed_failed' : ${it}")
			_eventBus?.trigger(EventName.bb_embed_failed)
		})
	}

	var baseUrl: String = ""
		get() = _baseUrl

	var appIndicator: String = ""
		get() = _appIndicator

	var appId: String = ""
		get() = _appId

	var contentIndicator: String? = ""
		get() = _contentIndicator

	var contentId: String? = ""
		get() = _contentId

	var publicationName: String = ""
		get() = _publicationName

	var publication: Publication? = null
		get() = _embedObject?.publicationData

	var playout: Playout? = null
		get() = _embedObject?.playoutData

	var project: Project? = null
		get() = _embedObject?.projectData

	var cliplist: MediaClipList? = null
		get() = _embedObject?.clipListData

	var clip: MediaClip? = null
		get() = _embedObject?.clipData

}
