package com.bluebillywig.bbnativeshared.interfaces

import com.bluebillywig.bbnativeshared.enums.EventName

/**
 * @suppress
 */
interface EventListenerInterface {
    fun onEvent(eventType: EventName, data: Map<String, Any?>?)
}