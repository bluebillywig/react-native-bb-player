package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PlayerSettings(
    @SerialName("playout")
    val playout: String,
    @SerialName("autoPlay")
    val autoPlay: Boolean = false
)
{
    constructor(playout: String) : this(playout, false)
}
