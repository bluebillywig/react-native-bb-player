package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Transient

abstract class BBModel {

    var rawJsonString: String? = null
    var bbCpJwtCookieString: String? = null
}