package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import kotlinx.serialization.Polymorphic
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

@Serializable
@SerialName("MediaClipList")
data class MediaClipList (
    override val id: String? = null,
    override val title: String? = null,
    override val deeplink: String? = null,
    val numfound: Long? = null,
    val offset: Long? = null,
    val parentid: String? = null,
    val status: String? = null,
    val publication: List<String>? = null,
    // val publicationid: Long? = null, // sometimes string sometimes array with 1 string
    val parentpublicationid: String? = null,
    val mediatype: String? = null,
    val usetype: String? = null,
    //val type: String? = null,
    val modifieddate: String? = null,
    val createddate: String? = null,

    @SerialName("published_date")
    val publishedDate: String? = null,

    @SerialName("listtype_string")
    val listtypeString: String? = null,

    @SerialName("isEmpty_boolean")
    val isEmptyBoolean: Boolean? = null,

    @SerialName("filters_string")
    val filtersString: String? = null,

    @SerialName("createdby_string")
    val createdbyString: String? = null,

    @SerialName("updatedby_string")
    val updatedbyString: String? = null,

    val allowDatasource: String? = null,
    val allowDatasource_boolean: Boolean? = null,

    val cpRuleViolations: List<String>? = null,
    val cpp: String? = null,

    val score: Double? = null,
    val count: Long? = null,
    val items: List<ContentItem>? = null
): ContentItem(), ContentItemInterface {
    constructor(id: String, title: String? = null, deeplink: String? = null) : this(id, title, deeplink, null)
}

