package com.bluebillywig.bbnativeshared.enums

enum class ApiMethod {
	load,
	play,
	pause,
	seek,
	autoPlayNextCancel,
	collapse,
	expand,
	enterFullScreen,
	exitFullScreen,
	handleWidgetEvent,
	setVolume,
	setMuted,
	skipAd,
	showInterfaceElement,
	hideInterfaceElement,
	enableInterfaceElement,
	disableInterfaceElement,
	doOpenUrl,
	doShare,
	setSubtitle,
	selectAudioTrack,
	updatePlayout
}
