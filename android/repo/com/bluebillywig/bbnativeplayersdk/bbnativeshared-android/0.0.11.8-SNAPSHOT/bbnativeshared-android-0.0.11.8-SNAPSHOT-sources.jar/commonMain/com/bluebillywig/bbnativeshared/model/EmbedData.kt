package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class EmbedData (
    val forceSSL: Boolean? = null,
    val baseurl: String? = null,
    val appId: String? = null,
    val appIndicator: String? = null,
    val contentIndicator: String? = null,
    val contentId: String? = null,
    val playoutIndicator: String? = null,
    val playoutSafeName: String? = null,
    val queryString: String? = null
)
