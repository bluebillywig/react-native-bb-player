package com.bluebillywig.bbnativeshared.enums

enum class ApiProperty {
	phase,
	state,
	mode,
	playoutData,
	projectData,
	clipData,
	relatedItems,
	volume,
	muted,
	controls,
	duration,
	adMediaWidth,
	adMediaHeight,
	inView,
	isCasting
}
