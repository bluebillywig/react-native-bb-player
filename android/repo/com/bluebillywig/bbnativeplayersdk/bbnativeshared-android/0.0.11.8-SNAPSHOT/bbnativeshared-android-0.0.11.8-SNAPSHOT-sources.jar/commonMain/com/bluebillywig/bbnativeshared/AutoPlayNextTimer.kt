package com.bluebillywig.bbnativeshared

import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

/**
 * AutoPlayNextTimer to automatically go to the next video in the list
 *
 * This class has no useful logic; it's just a documentation example.
 *
 * @suppress
 *
 * @param EventBusInterface? I need it
 * @param ProgramController? I need it
 * @property name the name of this group.
 * @constructor Creates an empty group.
 */
class AutoPlayNextTimer (eventBus: EventBusInterface?, pc: ProgramController?):
    EventListenerInterface, CoroutineScope {
    companion object {
        const val TAG = "AutoPlayNextTimer"
    }

    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_inview -> { _onInView(eventType, data) }
            EventName.bb_outview -> { _onOutView(eventType, data) }
            else -> { return }
        }
        Logger.d(TAG, "Processed event: $eventType data: $data")
    }

    // resources
    private var _eventBus: EventBusInterface? = eventBus
    private var _pc: ProgramController? = pc
    private var _timer: KMMTimer? = null

    // settings
    private val _tickDuration = 0.5 // seconds
    private val _totalDuration = 8.0 // seconds

    // state
    private var _ticks = 0
    private var _remainingTime = 0.0
    private var _isOutView: Boolean = false // keeps track of being outview
    private var _shouldResume: Boolean = false // keeps track of going outview while timer is running
    private var _shouldStart: Boolean = false // keeps track of timer not starting because we are outview

    // Proper CoroutineScope implementation with managed lifecycle
    private val job = SupervisorJob()
    override val coroutineContext: CoroutineContext = job + Dispatchers.Main

    init {
        _eventBus?.addEventlistener(this)
    }

    fun __destruct() {
        // Cancel all coroutines to prevent crashes
        job.cancel()
        _eventBus?.removeEventlistener(this)
        _eventBus = null
        _pc = null
        _timer?.cancel()
        _timer = null
    }

    fun start() {
        if (_isOutView) {
            _shouldStart = true
            _shouldResume = false
            return
        }
        _timer?.cancel()
        _timer = KMMTimer("AutoPlayNextTimer", (_tickDuration * 1000).toLong(), (_tickDuration * 1000).toLong(), {
            try {
                launch {
                    _onTick()
                }
            } catch (ce: CancellationException) {
                Logger.d("AutoPlayNextTimer", "Coroutine cancelled, ignoring timer tick")
            }
        })

        _ticks = 0
        _remainingTime = _totalDuration

        if (!(_timer?.isRunning() ?: false)) { // not running
            _timer?.start()
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_started, mapOf("ticks" to _ticks, "remainingTime" to _remainingTime))
        }
    }

    fun pause() {
        _pause()
    }

    fun resume() {
        _resume()
    }

    fun cancel() {
        _shouldStart = false
        _shouldResume = false

        if ((_timer?.isRunning() ?: false)) { // running
            _timer?.cancel()
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_cancelled, mapOf("ticks" to _ticks, "remainingTime" to _remainingTime))
        }
    }

    private fun _resume() {
        if (!(_timer?.isRunning() ?: false)) { // not running
            _timer?.start()
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_resumed, mapOf("ticks" to _ticks, "remainingTime" to _remainingTime))
        }
    }

    private fun _pause() {
        if ((_timer?.isRunning() ?: false)) { // running
            _timer?.cancel()
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_paused, mapOf("ticks" to _ticks, "remainingTime" to _remainingTime))
        }
    }

    private fun _finish() {
        _shouldStart = false
        _shouldResume = false

        if ((_timer?.isRunning() ?: false)) { // running
            _timer?.cancel()
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_finished, mapOf("ticks" to _ticks, "remainingTime" to 0.0))
        }
    }

    private fun _onTick() {
        _ticks++
        _remainingTime -= _tickDuration
        if (_remainingTime > 0.0) {
            Logger.d("[AutoPlayNextTimer] tick", "")
            _eventBus?.trigger(EventName.bb_autoplaynexttimer_tick,  mapOf("ticks" to _ticks, "remainingTime" to _remainingTime))
        } else {
            Logger.d("[AutoPlayNextTimer] finished", "")
            _finish()
            _pc?.autoPlayNextProceed()
        }
    }

    private fun _onInView(eventType: EventName, data: Map<String, Any?>?) {
        _isOutView = false

        if (_shouldResume) {
            _shouldResume = false
            _resume()
        } else if (_shouldStart ) {
            _shouldStart = false
            this.start()
        }
    }

    private fun _onOutView(eventType: EventName, data: Map<String, Any?>?) {
        _isOutView = true

        if ((_timer?.isRunning() ?: false)) { // running
            _shouldResume = true
            _pause()
        }
    }
}
