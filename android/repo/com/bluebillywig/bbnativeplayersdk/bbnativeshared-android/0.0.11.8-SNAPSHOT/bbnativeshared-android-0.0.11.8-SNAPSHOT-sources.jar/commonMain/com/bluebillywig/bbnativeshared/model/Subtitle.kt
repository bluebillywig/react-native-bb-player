package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.Serializable

@Serializable
data class Subtitle (
    var languageid: String? = null,
    var languagename: String? = null,
    var id: String? = null,
    val name: String? = null,
    val default: String? = null,
    var isocode: String? = null,
    var roleFlags: Int? = null,
    val status: String? = null,
    var isSelected: Boolean? = null
)
