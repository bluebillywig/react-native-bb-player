package com.bluebillywig.bbnativeshared.model

import com.bluebillywig.bbnativeshared.model.LineItem_
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import kotlinx.serialization.descriptors.*
import kotlinx.serialization.encoding.*

@Serializable
data class AdUnit(
    val id: String? = null,
    // val publicationid: String? = null, // sometimes string sometimes array with 1 string
    val type: String? = null,
    val status: String? = null,
    val createddate: String? = null,
    val createdBy: String? = null,
    val updateddate: String? = null,
    val updatedBy: String? = null,
    val playout: Playout? = null,
    val positionType: String? = null,
    val positionDisplayType: String? = null,
    val playoutCode: String? = null,
    val title: String? = null,
    val code: String? = null,
    var assignedLineitems: List<String>? = null,
    val label: String? = null,
    var lineitems: List<LineItem_>? = null
) {
    constructor(id: String, playout: Playout?, positionType: String?, code: String?, lineitems: List<LineItem_>?) : this(id, "AdUnit", "published", null, null, null, null, playout, positionType, null, null, null, code, null, null, lineitems)
}
