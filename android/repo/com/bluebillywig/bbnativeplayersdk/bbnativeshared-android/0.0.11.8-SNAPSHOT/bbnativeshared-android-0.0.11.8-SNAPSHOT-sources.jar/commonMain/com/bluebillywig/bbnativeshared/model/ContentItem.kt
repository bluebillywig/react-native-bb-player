package com.bluebillywig.bbnativeshared.model

import kotlinx.serialization.*
import kotlinx.serialization.descriptors.*
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

@Polymorphic
@Serializable
abstract class ContentItem:BBModel() {
    abstract val id: String?
    var isPrefetch: Boolean = false
    var isPlayed: Boolean = false
}


val contentItemSerializersModule = SerializersModule {
    polymorphic(ContentItem::class) {
        subclass(MediaClip::class)
        subclass(Project::class)
        subclass(MediaClipList::class)
    }
}

class ContentItemFactory {
    companion object {
        public fun createMediaClip(id: String): MediaClip {
            return MediaClip(id, null)
        }
        public fun createMediaClip(id: String, title: String?, deeplink: String?): MediaClip {
            return MediaClip(id, title, deeplink, null)
        }
        public fun createMediaClip(id: String, title: String?, deeplink: String?, gendeeplink: String?, sourcetype: String?, length: String?, mediatype: String?): MediaClip {
            return MediaClip(id, title, deeplink, gendeeplink, sourcetype, length, mediatype, null)
        }
        public fun createMediaClip(id: String, title: String?, deeplink: String?, gendeeplink: String?, sourcetype: String?, length: String?, mediatype: String?, usetype: String?): MediaClip {
            return MediaClip(id, title, deeplink, gendeeplink, sourcetype, length, mediatype, null, null, usetype, null)
        }
        public fun createProject(id: String): Project {
            return Project(id, null)
        }
        public fun createProject(id: String, title: String?, deeplink: String?): Project {
            return Project(id, title, deeplink, null)
        }
        public fun createMediaClipList(id: String): MediaClipList {
            return MediaClipList(id, null)
        }
        public fun createMediaClipList(id: String, title: String?, deeplink: String?): MediaClipList {
            return MediaClipList(id, title, deeplink, null)
        }
    }
}
