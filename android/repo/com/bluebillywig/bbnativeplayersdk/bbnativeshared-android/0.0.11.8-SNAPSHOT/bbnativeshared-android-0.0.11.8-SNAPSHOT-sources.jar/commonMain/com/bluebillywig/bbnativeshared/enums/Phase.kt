package com.bluebillywig.bbnativeshared.enums

enum class Phase {
    INIT,
    PRE,
    MAIN,
    POST,
    EXIT
}
