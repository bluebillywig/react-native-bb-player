package com.bluebillywig.bbnativeshared

import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import kotlinx.coroutines.*
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlin.time.DurationUnit
import kotlin.coroutines.CoroutineContext

/**
 * SoftEmbargoTimer to automatically go to the next video in the list
 *
 * @suppress
 *
 * @param EventBusInterface? I need it
 * @param ProgramController? I need it
 */
class SoftEmbargoTimer (eventBus: EventBusInterface?, pc: ProgramController?) : CoroutineScope {
	companion object {
		const val TAG = "SoftEmbargoTimer"
	}

	// resources
	private var _eventBus: EventBusInterface? = eventBus
	private var _pc: ProgramController? = pc
	private var _timer: KMMTimer? = null

	// settings
	private val _tickDuration = 1.0 // seconds
	private var _endDate: Instant = Clock.System.now()

	// state
	private var _ticks = 0

	// Proper CoroutineScope implementation with managed lifecycle
	private val job = SupervisorJob()
	override val coroutineContext: CoroutineContext = job + Dispatchers.Main

	fun __destruct() {
		// Cancel all coroutines to prevent crashes
		job.cancel()
		_eventBus = null
		_pc = null
		_timer?.cancel()
		_timer = null
	}

	fun start(endDate: Instant) {
		_endDate = endDate

		_ticks = 0
		val now: Instant = Clock.System.now()
		val remainingTime = _endDate.minus(now).toDouble(DurationUnit.SECONDS)
		if (remainingTime > 0.0) {
			_timer?.cancel()
			_timer = KMMTimer("SoftEmbargoTimer", (_tickDuration * 1000).toLong(), (_tickDuration * 1000).toLong()) {
				try {
					launch {
						_onTick()
					}
				} catch (ce: CancellationException) {
					Logger.d("SoftEmbargoTimer", "Coroutine cancelled, ignoring timer tick")
				}
			}
			_timer?.start()
			_eventBus?.trigger(EventName.bb_softembargotimer_started, mapOf("ticks" to _ticks, "remainingTime" to remainingTime, "endDate" to endDate.toString()))
		} else {
			_timer?.cancel()
			Logger.d("[SoftEmbargoTimer] finished", "")
			_eventBus?.trigger(EventName.bb_softembargotimer_finished, mapOf("ticks" to _ticks, "remainingTime" to 0.0))
		}
	}

	fun cancel() {
		if ((_timer?.isRunning() ?: false)) { // running
			_timer?.cancel()
			_eventBus?.trigger(EventName.bb_softembargotimer_cancelled, mapOf("ticks" to _ticks, "remainingTime" to 0.0))
		}
	}

	private fun _onTick() {
		_ticks++
		val now: Instant = Clock.System.now()
		val remainingTime = _endDate.minus(now).toDouble(DurationUnit.SECONDS)
		if (remainingTime > 0.0) {
			Logger.d("[SoftEmbargoTimer] tick", "")
			_eventBus?.trigger(EventName.bb_softembargotimer_tick,  mapOf("ticks" to _ticks, "remainingTime" to remainingTime))
		} else {
			_timer?.cancel()
			Logger.d("[SoftEmbargoTimer] finished", "")
			_eventBus?.trigger(EventName.bb_softembargotimer_finished, mapOf("ticks" to _ticks, "remainingTime" to 0.0))
		}
	}
}
