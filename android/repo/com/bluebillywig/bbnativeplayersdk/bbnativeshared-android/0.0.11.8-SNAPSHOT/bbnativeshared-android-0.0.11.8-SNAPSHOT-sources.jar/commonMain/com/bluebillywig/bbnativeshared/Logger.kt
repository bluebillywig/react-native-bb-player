package com.bluebillywig.bbnativeshared

internal expect class PlatformLogger() {

    fun debug(tag: String, message: String)

    fun warn(tag: String, message: String)

    fun error(tag: String, message: String)
}

/**
 * @suppress
 */
object Logger {
    private val logger = PlatformLogger()

    fun d(tag: String, message: String) {
        logger.debug(tag, message + "\n")
    }

    fun w(tag: String, message: String) {
        logger.warn(tag, message + "\n")
    }

    fun e(tag: String, message: String) {
        logger.error(tag, message + "\n")
    }
}