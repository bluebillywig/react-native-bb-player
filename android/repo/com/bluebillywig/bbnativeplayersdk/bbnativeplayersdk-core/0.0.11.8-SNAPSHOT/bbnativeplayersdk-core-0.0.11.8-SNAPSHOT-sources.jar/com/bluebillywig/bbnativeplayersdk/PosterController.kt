package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.interfaces.PosterControllerInterface
import com.bluebillywig.bbnativeshared.model.*
import java.net.URL

// Extension on Context to get screen width/height
val Context.screenWidth: Int
	get() = resources.displayMetrics.widthPixels
val Context.screenHeight: Int
	get() = resources.displayMetrics.heightPixels

/**
 * @suppress
 */
class PosterController(eventBus: EventBusInterface?, imageView: ImageView?): PosterControllerInterface, EventListenerInterface {

	private var _eventBus: EventBusInterface? = eventBus
	private var _imageView: ImageView? = imageView
	private var _isAudio: Boolean = false

	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_mediaclip_loaded -> {
				val clip = if (data != null && data["clipData"] is MediaClip) data["clipData"] as MediaClip else null
				_isAudio = (clip?.mediatype == "audio") ?: false
			}
			else -> { return }
		}
	}

	/**
	 * Load poster URL
	 * @param String posterUrl, null to unload
	 * @param String posterMediaType, optional
	 * @return Boolean success
	 */
	override fun load(posterUrl: String?, posterMediaType: String?): Boolean {
		if (posterUrl != null) {
			val h = _imageView?.context?.screenHeight
			var url = posterUrl

			if (h != null) {
				url = posterUrl.replace("/default/default", "/${h}/default")   // using height as width to cover all bases while still preventing /default/default
			}
	
			if (posterMediaType == "video") {
				_imageView?.setImageDrawable(null)
			} else { // still image
				if (_imageView != null) {
					DownLoadImageTask(_imageView!!)
						.execute(url)
				}
			}
		} else {
			_imageView?.setImageDrawable(null)
		}

		return true
	}

	init {
		_eventBus?.addEventlistener(this)
	}

	override fun show(): Boolean {
		_imageView?.visibility = View.VISIBLE
		return true
	}

	override fun hide(): Boolean {
		if (_isAudio == false) {
			_imageView?.visibility = View.INVISIBLE
		}
		return true
	}



	fun __destruct() {
		_eventBus = null
		_imageView = null
	}
}

// Class to download an image from url and display it into an image view
internal class DownLoadImageTask(internal val imageView: ImageView) : AsyncTask<String, Void, Bitmap?>() {
	override fun doInBackground(vararg urls: String): Bitmap? {
		val urlOfImage = urls[0]
		return try {
			val inputStream = URL(urlOfImage).openStream()
			BitmapFactory.decodeStream(inputStream)
		} catch (e: Exception) { // Catch the download exception
			e.printStackTrace()
			null
		}
	}
	override fun onPostExecute(result: Bitmap?) {
		if (result != null) {
			// Display the downloaded image into image view
			imageView.setImageBitmap(result)
		} else {
			imageView.setImageDrawable(null)
		}
	}
}