package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.controller.EmbedController

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface

/**
 * @suppress
 */
// Check to see if references are garbage collected after pressing "destroy player"
// var USE_LEAKCANARY = false

// see: https://antonioleiva.com/custom-views-android-kotlin/
class BBNativeShortsView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) , EventListenerInterface, BBNativePlayerViewDelegate {
	// EventListenerInterface::onEvent
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				val url = if (data != null && data["url"] is String) data["url"] as String else null
				val options: Map<String, Any?>? = if (data != null && data["options"] is Map<*, *>) data["options"] as Map<String, Any?> else null
				if (data != null) {
					if (data["embedObject"] is EmbedObject) {
						val embedObject = data["embedObject"] as EmbedObject

						var baseUrl = "https://bbvms.com"
						_embedData = embedObject.embedData
						val embedData = _embedData
						if (embedData != null) {
							baseUrl = embedData.baseurl ?: "" // NB mind lowercase 'u'!
						}

						var defaultMediaAssetPath = ""
						var useThumbsFromMetadata = false
						val publicationData = embedObject.publicationData
						if (publicationData != null) {
							defaultMediaAssetPath = publicationData.defaultMediaAssetPath ?: ""
							useThumbsFromMetadata = (publicationData.useThumbsFromMetadata == "true")
						}
						val playoutData = embedObject.playoutData
						if (playoutData != null) {
							useThumbsFromMetadata = (playoutData.useThumbsFromMetadata == "true")
						}

						_appConfig = embedObject.appConfig
						val appConfig: AppConfig? = _appConfig
						if (appConfig != null) {
							// settings
							if (appConfig.showThumbnails != null) { _showThumbnails = appConfig.showThumbnails ?: false }
							if (appConfig.showNextPreviousControls != null) { _showNextPreviousControls = appConfig.showNextPreviousControls ?: false }
							if (appConfig.subtype != null) { _subtype = appConfig.subtype ?: "" }
							if (appConfig.swipeDirection != null) { _swipeDirection = appConfig.swipeDirection ?: "" }
							if (appConfig.backgroundColor != null) { _backgroundColor = appConfig.backgroundColor ?: "" }
							if (appConfig.clipAdInterval != null) { _clipAdInterval = appConfig.clipAdInterval ?: -1 }
							if (appConfig.firstAdPosition != null) { _firstAdPosition = appConfig.firstAdPosition ?: -1 }
							if (appConfig.minuteAdInterval != null) { _minuteAdInterval = appConfig.minuteAdInterval ?: -1 }
							if (appConfig.listThumbnailHeight != null) { _listThumbnailHeight = appConfig.listThumbnailHeight ?: -1 }
							if (appConfig.listThumbnailResponsiveHeight != null) { _listThumbnailResponsiveHeight = appConfig.listThumbnailResponsiveHeight ?: false }
							if (appConfig.listThumbnailGap != null) { _listThumbnailGap = appConfig.listThumbnailGap ?: -1 }
							if (appConfig.showThumbnailDuration != null) { _showThumbnailDuration = appConfig.showThumbnailDuration ?: false }
							if (appConfig.showThumbnailTitle != null) { _showThumbnailTitle = appConfig.showThumbnailTitle ?: false }
							if (appConfig.useThumbnailsInFullscreen != null) { _useThumbnailsInFullscreen = appConfig.useThumbnailsInFullscreen ?: false }
							if (appConfig.thumbnailBackground != null) { _thumbnailBackground = appConfig.thumbnailBackground ?: false }
							if (appConfig.cornerRadius != null) { _cornerRadius = appConfig.cornerRadius ?: -1 }
							if (appConfig.id != null) { _shortsId = appConfig.id ?: "" }
							if (appConfig.adunitId != null) { _adunitId = appConfig.adunitId ?: "" }
							if (appConfig.skin_foregroundColor != null) { _skin_foregroundColor = appConfig.skin_foregroundColor ?: "" }
							if (appConfig.playout?.logoId != null) { _logoUrlString = "${baseUrl}/mediaclip/${appConfig.playout?.logoId}/pthumbnail/200/default.png" ?: "" }
							if (appConfig.viewedClipBehaviour != null) { _viewedClipBehaviour = appConfig.viewedClipBehaviour ?: "" }
							if (appConfig.durationBackgroundColor != null) { _durationBackgroundColor = appConfig.durationBackgroundColor ?: "" }
							if (appConfig.showOutlineForUnwatchedClips != null) { _showOutlineForUnwatchedClips = appConfig.showOutlineForUnwatchedClips ?: false }
							if (appConfig.outlineColor != null) { _outlineColor = appConfig.outlineColor ?: "" }
							if (appConfig.showPlayIconInTimestamp != null) { _showPlayIconInTimestamp = appConfig.showPlayIconInTimestamp ?: true }
							if (appConfig.shelfMovingThumbnail != null) { _shelfMovingThumbnail = appConfig.shelfMovingThumbnail ?: false }

							val playerOptions: MutableMap<String, Any?> = mutableMapOf("initiator" to "Shorts")
							playerOptions["playerType"] = "shorts" // NB!
							playerOptions["skin_backgroundColor"] = "ffffff"
							playerOptions["skin_foregroundColor"] = _skin_foregroundColor ?: "3578bb"
							playerOptions["skin_widgetColor"] = "6caedf"
							playerOptions["bgColor"] = "ffffff"
							playerOptions["cornerRadius"] = _cornerRadius
							playerOptions["shortsId"] = _shortsId
							playerOptions["adunitId"] = _adunitId
							playerOptions["clipAdInterval"] = _clipAdInterval
							playerOptions["firstAdPosition"] = _firstAdPosition
							playerOptions["swipeDirection"] = _swipeDirection // shorts-specific
							playerOptions["hideSwipeControls"] = false // shorts-specific
							playerOptions["showDescription"] = false // shorts-specific
							playerOptions["showPlayButton"] = false // shorts-specific
							playerOptions["autoLoopClip"] = false // shorts-specific
							playerOptions["logoUrlString"] = _logoUrlString // shorts-specific
							playerOptions["viewedClipBehaviour"] = _viewedClipBehaviour // shorts-specific
							playerOptions["useThumbnailsInFullscreen"] = _useThumbnailsInFullscreen // shorts-specific

							val playout = appConfig.playout
							if (playout != null) {
								if (playout.languageSelect != null) { playerOptions["languageSelect"] = playout.languageSelect ?: "" }
								if (playout.swipeDirection != null) { playerOptions["swipeDirection"] = playout.swipeDirection ?: "" }
								if (playout.hideSwipeControls != null) { playerOptions["hideSwipeControls"] = playout.hideSwipeControls == "true" }
								if (playout.title != null) { playerOptions["title"] = playout.title ?: "" }
								if (playout.descriptionShowHide != null) { playerOptions["showDescription"] = playout.descriptionShowHide == "Show" }
								if (playout.showPlayButton != null) { playerOptions["showPlayButton"] = playout.showPlayButton == "true" }
								if (playout.skin_foregroundColor != null) { playerOptions["skin_foregroundColor"] = playout.skin_foregroundColor ?: "" }
								if (playout.autoPlay != null) { playerOptions["autoPlay"] = playout.autoPlay == "true" }
								if (playout.autoLoopClip != null) { playerOptions["autoLoopClip"] = playout.autoLoopClip == "true" }
								if (playout.label != null) { playerOptions["label"] = playout.label ?: "" }
								if (playout.ctaUrlField != null) { playerOptions["ctaUrlField"] = playout.ctaUrlField ?: "" }
								if (playout.ctaButtonPosition != null) { playerOptions["ctaButtonPosition"] = playout.ctaButtonPosition ?: "" }
								if (playout.ctaButtonText != null) { playerOptions["ctaButtonText"] = playout.ctaButtonText ?: "" }
								if (playout.ctaButtonLabelField != null) { playerOptions["ctaButtonLabelField"] = playout.ctaButtonLabelField ?: "" }
								if (playout.ctaButtonUseAccentColor != null) { playerOptions["ctaButtonUseAccentColor"] = playout.ctaButtonUseAccentColor == "true" }
							}
							// handle shelfStartSpacing and shelfEndSpacing options for list display format
							if (options?.get("shelfStartSpacing") is Int) {
								playerOptions["shelfStartSpacing"] = options["shelfStartSpacing"] as Int
							}
							if (options?.get("shelfEndSpacing") is Int) {
								playerOptions["shelfEndSpacing"] = options["shelfEndSpacing"] as Int
							}
							
							// all embed options override player options
							options?.forEach { // it
								playerOptions[it.key] = it.value
							}

							var playerViewJsonUrl:String = ""

							// create embed url for BBNativePlayerView
							var shortsListItems = options?.get("shortsListItems") as? MutableList<ContentItemInterface>
							if (shortsListItems != null) {
								var qString = ""
								var idx = 0

								shortsListItems.forEach { // it
									val item = it as ContentItemInterface
									if (idx > 0) {
										qString += " OR "
									}
									val mediaClip: MediaClip? = item as? MediaClip
									if (mediaClip != null) {
										qString += "id:${mediaClip.id}"
									}

									val project: Project? = item as? Project
									if (project != null) {
										qString += "(type:Project AND id:${project.id})"
									}

									val mediaClipList: MediaClipList? = item as? MediaClipList
									if (mediaClipList != null) {
										qString += "(type:MediaClipList AND id:${mediaClipList.id})"
									}
									idx++
								}
								playerViewJsonUrl = BBNativePlayer.createJsonEmbedUrl(baseUrl, "p", "_", "q", qString)
							} else {
								playerViewJsonUrl = BBNativePlayer.createJsonEmbedUrl(baseUrl, "p", "_", "l", appConfig.cliplistid)
							}

							when (_displayFormat) { // "mode"
								"list" -> { // Shelf
									if (_shelfView != null) this.removeView(_shelfView)
									_shelfView?.__destruct()
									val shelfViewJsonUrl = playerViewJsonUrl
									println("[BBNativeShortsView] onEvent bb_embed_loaded shelfViewJsonUrl: ${shelfViewJsonUrl}")
									_shelfView = ShelfView(context)
									_shelfView?.id = View.generateViewId()
									if (_shelfView != null) this.addView(_shelfView)
									_shelfView?.updateSettings(mapOf(
										"baseUrl" to baseUrl,
										"defaultMediaAssetPath" to defaultMediaAssetPath,
										"useThumbsFromMetadata" to useThumbsFromMetadata,
										"viewedClipBehaviour" to _viewedClipBehaviour,
										"showThumbnailDuration" to _showThumbnailDuration,
										"useThumbnailsInFullscreen" to _useThumbnailsInFullscreen,
										"showThumbnailTitle" to _showThumbnailTitle,
										"listThumbnailHeight" to _listThumbnailHeight,
										"listThumbnailHeightResponsive" to _listThumbnailResponsiveHeight,
										"listThumbnailGap" to _listThumbnailGap,
										"shelfStartSpacing" to playerOptions["shelfStartSpacing"],
										"shelfEndSpacing" to playerOptions["shelfEndSpacing"],
										"durationBackgroundColor" to _durationBackgroundColor,
										"showOutlineForUnwatchedClips" to _showOutlineForUnwatchedClips,
										"outlineColor" to _outlineColor,
										"showPlayIconInTimestamp" to _showPlayIconInTimestamp,
										"movingThumbnail" to _shelfMovingThumbnail
									))
									_shelfView?.playerOptions = playerOptions
									_shelfView?.playerViewDelegate = _playerViewDelegate
									_shelfView?.network = _network
									_shelfView?.jsonUrl = shelfViewJsonUrl // kicks off content load
								}
								else -> { // Player or Fullscreen
									if (_playerView != null) this.removeView(_playerView)
									_playerView?.__destruct()

									println("[BBNativeShortsView] onEvent bb_embed_loaded playerViewJsonUrl: ${playerViewJsonUrl}")
									_playerView = BBNativePlayer.createPlayerView(context, playerViewJsonUrl, playerOptions)
									_playerView?.delegate = _playerViewDelegate
									_playerView?.id = View.generateViewId()
									if (_playerView != null) this.addView(_playerView)
								}
							}
						}
					}
				}
				_delegate?.didSetupWithJsonUrl(this, url)
			}
			EventName.bb_embed_failed -> {
				val error = if (data != null && data["error"] is String) data["error"] as String else null
				_delegate?.didFailWithError(this, "Embed failed - $error")
			}
			else -> {}
		}
	}

	// BBNativePlayerViewDelegate::didSetupWithJsonUrl
	override fun didSetupWithJsonUrl(playerView: BBNativePlayerView, url: String?) {
		println("[BBNativeShortsView] didSetupWithJsonUrl url: ${url}")
	}
	// BBNativePlayerViewDelegate::didFailWithError
	override fun didFailWithError(playerView: BBNativePlayerView, error: String?) {
		println("[BBNativeShortsView] didFailWithError error: ${error}")
	}

	private var _eventBus: EventBus? = null
	private var _network: Network? = null
	private var _embedController: EmbedController? = null

	private var _shelfView: ShelfView? = null
	private var _playerView: BBNativePlayerView? = null
	private var _playerViewDelegate: BBNativePlayerViewDelegate? = null

	private var _delegate: BBNativeShortsViewDelegate? = null

	// settings
	private var _displayFormat: String? = null
	private var _autoPlay: Boolean = false
	private var _showThumbnails: Boolean = false
	private var _showNextPreviousControls: Boolean = false
	private var _subtype: String = "unversioned"
	private var _swipeDirection: String = "vertical"
	private var _backgroundColor: String = "#000000"
	private var _clipAdInterval: Int = -1
	private var _minuteAdInterval: Int = -1
	private var _firstAdPosition: Int = -1
	private var _listThumbnailHeight: Int = 240
	private var _listThumbnailResponsiveHeight: Boolean = false
	private var _listThumbnailGap: Int = 16
	private var _showThumbnailDuration: Boolean = false
	private var _showThumbnailTitle: Boolean = false
	private var _useThumbnailsInFullscreen: Boolean = false
	private var _thumbnailBackground: Boolean = false
	private var _cornerRadius: Int = 0
	private var _shortsId: String = "0"
	private var _adunitId: String = "0"
	private var _skin_foregroundColor: String = "ffffff"
	private var _logoUrlString: String = ""
	private var _viewedClipBehaviour: String = ""
	private var _durationBackgroundColor: String = ""
	private var _showOutlineForUnwatchedClips: Boolean = false
	private var _outlineColor: String = ""
	private var _showPlayIconInTimestamp: Boolean = true
	private var _shelfMovingThumbnail: Boolean = false

	// data
	private var _embedData: EmbedData? = null
	private var _appConfig: AppConfig? = null

	init {
		_eventBus = EventBus()
		_eventBus?.addEventlistener(this)

		_network = Network()

		val layoutParams = this.layoutParams as LayoutParams? ?: LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT) // this.layoutParams ?:
		this.setLayoutParams(layoutParams)

		_embedController = EmbedController(_eventBus, null)
		_embedController!!.network = _network
	}

	fun __destruct () {
		_eventBus?.removeEventlistener(this) // OBSOLETE
		_eventBus?.__destruct()
		// if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_eventBus, "_eventBus was detached")
		_eventBus = null

		this.removeAllViews()
		_shelfView?.__destruct()
		_shelfView = null
		_playerView?.__destruct()
		_playerView = null

		_playerViewDelegate = null
		_delegate = null

		_embedData = null
		_appConfig = null
	}

	/**
	 * @suppress
	 */
	public override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec)
	}

	/**
	 * Delegate for handling API events
	 */
	var delegate: BBNativeShortsViewDelegate?
		get() = _delegate
		set(value) { _delegate = value }

	/**
	 * Delegate for handling Player API events
	 */
	var playerViewDelegate: BBNativePlayerViewDelegate?
		get() = _playerViewDelegate
		set(value) {
			_playerView?.delegate = null
			_shelfView?.playerViewDelegate = null
			_playerViewDelegate = value
			_playerView?.delegate = _playerViewDelegate
			_shelfView?.playerViewDelegate = _playerViewDelegate
		}

	/**
	 * Setup with json URL
	 * * jsonUrl: the json embed URL
	 * * options: the options dictionary (optional), options recognized:
	 *	* autoPlay: auto play (Boolean or String), overrides playout setting
	 * @param jsonUrl the json embed URL
	 * @param options the options dictionary (optional), options recognized:
	 */
	fun setupWithJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
		if (options != null) {
			// if (options["autoPlay"] is String) _autoPlay = (options["autoPlay"] as String == "true")
			// if (options["autoPlay"] is Boolean) _autoPlay = options["autoPlay"] as Boolean
			// if (_autoPlay) _play() // NB!
			if (options["displayFormat"] is String) _displayFormat = options["displayFormat"] as String
		}

		_loadJsonUrl(jsonUrl, options)
	}

	private fun _loadJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
		val modifiedOptions: MutableMap<String, Any?> = options?.toMutableMap() ?: mutableMapOf()
		_embedController?.load(jsonUrl, modifiedOptions)
	}
}
