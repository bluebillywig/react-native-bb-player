package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.ApiMethod
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.Logger

import org.json.JSONException
import org.json.JSONObject

import android.annotation.SuppressLint
import android.webkit.WebView
import android.view.View
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * @suppress
 */
@SuppressLint("SetJavaScriptEnabled")
class InteractivityController(eventBus: EventBusInterface?, interactivityView: InteractivityView?, playerView: BBNativePlayerView?): EventListenerInterface {
    @SuppressLint("ClickableViewAccessibility")
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_embed_loaded -> {
                Logger.d("InteractivityController", "onEvent bb_embed_loaded")
                if (data != null && data["options"] != null && data["options"] is Map<*,*>) {
                    val options = data["options"] as Map<String,Any?>
                    if (options["allowInteractivity"] is String) _allowInteractivity = (options["allowInteractivity"] as String == "true")
                    if (options["allowInteractivity"] is Boolean) _allowInteractivity = options["allowInteractivity"] as Boolean
                }
                Logger.d("InteractivityController", "onEvent bb_embed_loaded allowInteractivity: ${_allowInteractivity}")
                if (data != null && data["embedObject"] is EmbedObject) {
                    val opts = data["embedObject"] as EmbedObject
                    if (opts.embedData is EmbedData) {
                        val embedData = opts.embedData as EmbedData
                        val baseurl = embedData.baseurl
                        val playoutSafeName = embedData.playoutSafeName
                        val contentIndicator = embedData.contentIndicator
                        val contentId = embedData.contentId
                        val queryString = embedData.queryString ?: ""
                        val interactivityUrl = "$baseurl/i/$playoutSafeName/$contentIndicator/$contentId.html?$queryString"
                        if (_allowInteractivity) {
                            this.enable()
                            this.load(interactivityUrl)
                        }
                    }
                }
            }

            EventName.bb_project_loaded -> {
                if (_allowInteractivity) {
                    val id: String? = if (data != null && data["projectData"] is Project) (data["projectData"] as Project).id else null
                    _bridge.callWeb("handleMetadataEvent", mapOf("eventType" to "loadedprojectdata", "id" to id))

                    val needsTimelineEngine = (data != null && _needsTimelineEngine(data))
                    Logger.d("InteractivityController", "onEvent bb_project_loaded needsTimelineEngine: ${needsTimelineEngine}")
                    if (needsTimelineEngine) this.enable() else this.disable()
                }
            }
            EventName.bb_mediaclip_loaded -> {
                if (_allowInteractivity) {
                    val id: String? = if (data != null && data["clipData"] is MediaClip) (data["clipData"] as MediaClip).id else null
                    _bridge.callWeb("handleMetadataEvent", mapOf("eventType" to "loadedclipdata", "id" to id))

                    val needsTimelineEngine = (data != null && _needsTimelineEngine(data))
                    Logger.d("InteractivityController", "onEvent bb_mediaclip_loaded needsTimelineEngine: ${needsTimelineEngine}")
                    if (needsTimelineEngine) this.enable() else this.disable()
                }
            }

            EventName.bb_media_duration_change -> {
                if (_enabled) {
                    val duration: Double = if (data != null && data["duration"] is Double) data["duration"] as Double else 0.0
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "durationchange", "duration" to duration))
                }
            }
            EventName.bb_media_playing -> {
                if (_enabled) {
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "playing"))
                }
            }
            EventName.bb_media_finished -> {
                if (_enabled) {
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "ended"))
                }
            }
            EventName.bb_media_seeking -> {
                if (_enabled) {
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "seeking"))
                }
            }
            EventName.bb_media_seeked -> {
                if (_enabled) {
                    val seekedPosition: String = if (data != null && data["seekOffset"] is String) data["seekOffset"] as String else "0.0"
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "seeked", "seekedPosition" to seekedPosition))
                }
            }
            EventName.bb_media_timeupdate -> {
                if (_enabled) {
                    val currentTime: String = if (data != null && data["currentTime"] is String) data["currentTime"] as String else "0.0"
                    _bridge.callWeb("handleMediaEvent", mapOf("eventType" to "timeupdate", "currentTime" to currentTime))
                }
            }
            else -> {}
        }
    }

    /**
     * Load interactivity URL
     * @param String interactivityUrl, null to unload
     * @return Boolean success
     */
    fun load(interactivityUrl: String?): Boolean {
        Logger.d("InteractivityController", "load interactivityUrl: ${interactivityUrl}")
        _interactivityView?.stopLoading()
        if (interactivityUrl != null) {
            // _interactivityView?.postWebMessage(message: WebMessage, targetOrigin: Uri)
            _interactivityView?.loadUrl(interactivityUrl)
        } else {
            _interactivityView?.goBack()
            _interactivityView?.clearHistory()
        }

        return true
    }

    private var _eventBus: EventBusInterface? = eventBus
    private var _interactivityView: InteractivityView? = interactivityView
    private var _playerView: BBNativePlayerView? = playerView
    private var _bridge: BBNativeWebBridge

    // settings
    private var _allowInteractivity = false

    // state
    private var _enabled = true
    private var _showView = false

    init {
        _bridge = BBNativeWebBridge(_playerView, _interactivityView?.webView)
        _interactivityView?.addJavascriptInterface(_bridge, "BBNativePlayerBridge")
        // _interactivityView?.setWebViewClient(client: WebViewClient)
        _interactivityView?.clearHistory()
        // _interactivityView?.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        // _interactivityView?.setInitialScale(scaleInPercent: Int)

        // _bridge.onMessage()
        _eventBus?.addEventlistener(this)

        this.disable()
    }

    fun __destruct() {
        _eventBus?.removeEventlistener(this)
        _eventBus = null
        _interactivityView?.removeJavascriptInterface("InteractivityControllerBridge")
        _bridge.__destruct()
        _interactivityView?.__destruct()
        _interactivityView = null
    }

    fun enable(): Boolean {
        _enabled = true
        if (_enabled && _showView) {
            _interactivityView?.visibility = View.VISIBLE
        }
        return true
    }

    fun disable(): Boolean {
        _enabled = false
        _interactivityView?.visibility = View.GONE
        return true
    }

    fun showView(): Boolean {
        _showView = true
        if (_enabled && _showView) {
            _interactivityView?.visibility = View.VISIBLE
        }
        return true
    }

    fun hideView(): Boolean {
        _showView = false
        _interactivityView?.visibility = View.GONE
        return true
    }

    private fun _needsTimelineEngine (meta: Map<String, Any?>, timelineHostEntityType: String = "all"): Boolean {
        if (timelineHostEntityType == "all" || timelineHostEntityType == "MediaClip") {
            val clipData: MediaClip? = if (meta["clipData"] is MediaClip) meta["clipData"] as MediaClip else null
            if (clipData != null) {
                if (!clipData.timelineId.isNullOrEmpty()) return true
                if ((clipData.timelines?.count() ?: 0) >= 1) return true
            }
            val playoutData: Playout? = if (meta["playoutData"] is Playout) meta["playoutData"] as Playout else null
            if (playoutData != null) {
                if (!playoutData.timelineId.isNullOrEmpty()) return true
                if (!playoutData.templateId.isNullOrEmpty()) return true
            }
        }

        if (timelineHostEntityType == "all" || timelineHostEntityType == "Project") {
            val projectData: Project? = if (meta["projectData"] is Project) meta["projectData"] as Project else null
            if (projectData != null) {
                if (!projectData.timelineId.isNullOrEmpty()) return true
                if ((projectData.timelines?.count() ?: 0) >= 1) return true
            }
        }

        return false;
    }
}

/**
 * @suppress
 */
public class BBNativeWebBridge (nativeView: BBNativePlayerView?, webView: WebView?) {
    val mainScope = MainScope()
    private var _nativeView: BBNativePlayerView? = nativeView
    private var _webView: WebView? = webView
    private var _webInstanceId: String? = null
    private var _webClassName: String? = null

    fun __destruct() {
        _webClassName = null
        _webInstanceId = null
        _webView = null
        _nativeView = null
    }

    @android.webkit.JavascriptInterface
    fun onBlueBillywigInstanceReady(instanceId: String, className: String) {
        println("*** BBNativeWebBridge onBlueBillywigInstanceReady instanceId: $instanceId, className: $className")
        _webInstanceId = instanceId
        _webClassName = className
    }

    @android.webkit.JavascriptInterface
    fun callNative(methodName: String) {
        callNative(methodName, null)
    }
    @android.webkit.JavascriptInterface
    fun callNative(methodName: String, paramsJson: String?) {
        println("*** BBNativeWebBridge callNative methodName: $methodName")
        var method: ApiMethod? = null
        try {
            method = ApiMethod.valueOf(methodName)
        } catch (er: Error) { }
        println("*** BBNativeWebBridge callNative method: $method")
        if (method != null) {
            var params: MutableMap<String, Any?>? = null
            // parse paramsJson into params
            if (paramsJson != null) {
                params = mutableMapOf()
                try {
                    val paramsJsonObject = JSONObject(paramsJson)
                    paramsJsonObject.keys().forEach {
                        val value = if (paramsJsonObject.isNull(it)) null else paramsJsonObject.get(it)
                        if (value is String || value is Number || value is Boolean || value == null) params[it] = value
                    }
                } catch (er: JSONException) { }
            }
            mainScope.launch(Dispatchers.Main) {
                _nativeView?.callApiMethod(method, params?.toMap())
            }
        }
    }

    fun callWeb(methodName: String, params: Map<String, Any?>? = null) {
        val instancesName = "${_webClassName?.replaceFirstChar { it.lowercase() }}s"
        println("*** BBNativeWebBridge callWeb instancesName: $instancesName")

        var paramsJson = "{}"
        // stringify params into paramsJson
        try {
            val paramsJsonObject = JSONObject()
            params?.forEach { if (it.value is String || it.value is Number || it.value is Boolean || it.value == null) paramsJsonObject.put(it.key, it.value) }
            paramsJson = paramsJsonObject.toString()
        } catch (er: JSONException) { }
        println("*** BBNativeWebBridge callWeb paramsJson: $paramsJson")

        var methodCall = "instance['$methodName'](JSON.parse('$paramsJson'));"
        val script = """
            var instance = window.bluebillywig && window.bluebillywig['$instancesName'] && window.bluebillywig['$instancesName'][0]
            if (instance && typeof instance['$methodName'] === 'function') {
                $methodCall
            }
            """.trimIndent()
        _webView?.evaluateJavascript(script, { /* return value? */ }) // resultCallback: ValueCallback<String!>?)
    }
}
