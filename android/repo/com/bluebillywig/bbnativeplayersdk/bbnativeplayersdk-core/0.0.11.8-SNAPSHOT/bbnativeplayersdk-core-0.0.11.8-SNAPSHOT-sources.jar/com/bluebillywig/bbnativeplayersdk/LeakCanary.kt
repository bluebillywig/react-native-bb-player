package com.bluebillywig.bbnativeplayersdk

/**
 * @suppress
 */
object Leakcanary {
	fun expectWeaklyReachable(`object`: Any?, description: String?) {}
}
