package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.data.Languages
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import java.util.*


/**
 * @suppress
 */
class RelatedItemsView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface {
	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	private val _layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
	private var _adapter: RelatedItemsAdapter? = null
	private val _recy = RecyclerView(context, attrs, defStyleAttr)
	private val _captionView = TextView(context)

	// settings
	private var _settings: Map<String, Any?> = mapOf()
	private var _useDeeplink = false

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()

	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_related_clips_changed -> {
				if (data != null && data["items"] is MutableList<*>) {
					val items = data["items"] as MutableList<ContentItemInterface>
					_recy.adapter = null
					_adapter?.__destruct()
					_adapter = RelatedItemsAdapter(items)
					_adapter?.updateSettings(_settings)
					_adapter?.programController = _programController
					_adapter?.eventBus = _eventBus
					_recy.adapter = _adapter
				}
			}
			else -> {}
		}
	}

	init {
		//this.setBackgroundColor(Color.parseColor("#99000000")) // acc. Deniz

		this.setId(View.generateViewId())
		this.setPadding(0, 16, 0, 16)

		val r: Int = Color.red(_foregroundColor)
		val g: Int = Color.green(_foregroundColor)
		val b: Int = Color.blue(_foregroundColor)
		val shadowColor = if (r + g + b < 384) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
		val shadowD = if (r + g + b < 384) -2F else 2F

		val set = ConstraintSet()
		set.clone(this)

		_recy.setId(View.generateViewId())
		_recy.layoutManager = _layoutManager
		_recy.setHasFixedSize(true)
		_recy.adapter = _adapter
		set.constrainHeight(_recy.getId(), 240)
		set.connect(_recy.getId(), ConstraintSet.BOTTOM, this.getId(), ConstraintSet.BOTTOM, 200)
		set.connect(_recy.getId(), ConstraintSet.LEFT, this.getId(), ConstraintSet.LEFT, 60)
		set.connect(_recy.getId(), ConstraintSet.RIGHT, this.getId(), ConstraintSet.RIGHT, 50)
		this.addView(_recy)

		_captionView.setId(View.generateViewId())
		_captionView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_captionView.text = Languages.translate(Locale.getDefault().getLanguage(), "Related videos")
		_captionView.setTextSize(16F)
		_captionView.setTextColor(_foregroundColor)
		val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato)
		_captionView.typeface = typeface
		_captionView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
		set.constrainMinHeight(_captionView.getId(), 64)
		set.connect(_captionView.getId(), ConstraintSet.BOTTOM, _recy.getId(), ConstraintSet.TOP, 16)
		set.connect(_captionView.getId(), ConstraintSet.LEFT, _recy.getId(), ConstraintSet.LEFT, 0)
		set.connect(_captionView.getId(), ConstraintSet.RIGHT, this.getId(), ConstraintSet.RIGHT, 16)
		this.addView(_captionView)
		_recy.addItemDecoration(
			MarginItemDecoration(14)
		)
		set.applyTo(this)
	}

	fun __destruct() {
		_recy.adapter = null
		_adapter?.__destruct()
		_adapter = null

		this.removeAllViews()
		_programController = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_adapter?.eventBus = null
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
			_adapter?.eventBus = _eventBus
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_adapter?.programController = null
			_programController = value
			_adapter?.programController = _programController
		}

	fun updateSettings(settings: Map<String, Any?>) {
		_settings = settings
		_adapter?.updateSettings(_settings)
	}
}

/**
 * @suppress
 */
class MarginItemDecoration(private val spaceSize: Int) : RecyclerView.ItemDecoration() {
	override fun getItemOffsets(
		outRect: Rect, view: View,
		parent: RecyclerView,
		state: RecyclerView.State
	) {
		with(outRect) {
			left = spaceSize
			right = spaceSize
		}
	}
}