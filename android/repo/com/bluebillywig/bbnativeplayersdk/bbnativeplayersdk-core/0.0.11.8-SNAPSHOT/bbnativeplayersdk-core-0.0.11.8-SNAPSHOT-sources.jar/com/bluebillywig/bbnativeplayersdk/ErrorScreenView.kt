package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity

import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

/**
 * @suppress
 */
class ErrorScreenView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				val options = if (data != null && data["options"] is Map<*,*>) data["options"] as Map<String, Any?> else null
				if (data != null && data["embedObject"] is EmbedObject) _ingestOpts(data["embedObject"] as EmbedObject, options)
			}
			EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
			EventName.bb_embed_failed -> _errorMessage = context.getString(R.string.error_screen_embed_failed)
			EventName.bb_media_failed,
			EventName.bb_mediaclip_failed -> _errorMessage = context.getString(R.string.error_screen_mediaclip_failed)
			EventName.bb_mediaclip_loaded -> _handleClipLoaded(data)
			EventName.bb_error -> _handleError(data)
			else -> return
		}
		Logger.d(TAG, "Processed event: $eventType")
	}

	private var _eventBus: EventBusInterface? = null
	private var _textView: TextView = TextView(context)
	private var _errorMessage: String? = null
	private var _displayView: ErrorDisplayView? = null
	private val _legacyBackgroundColor: Int = Color.parseColor("#B3000000")

	// settings
	private var _publicationName: String? = null
	private var _baseUrl: String? = null
	private var _jwt: String = ""
	private var _rpcToken: String = ""
	private var _bbCpJwtCookieString: String = ""

	companion object {
		const val TAG = "ErrorScreenView"
	}

	init {
		this.setBackgroundColor(_legacyBackgroundColor)

		val textViewLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		textViewLayoutParams.gravity = Gravity.CENTER
		textViewLayoutParams.setMargins(16, 16, 16, 16)
		_textView.layoutParams = textViewLayoutParams
		_textView.setTextColor(Color.WHITE)
		_textView.text = context.getString(R.string.error_screen_message)
		this.addView(_textView)

		_eventBus?.addEventlistener(this)

//		this.setOnClickListener {
//			this.visibility = View.INVISIBLE
//		}
	}

	fun __destruct() {
		if (_displayView != null) this.removeView(_displayView)
		_displayView?.__destruct()
		_displayView = null
		this.removeView(_textView)
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	override fun setVisibility(visibility: Int) {
		super.setVisibility(visibility)
		if (_errorMessage == null) {
			_errorMessage = context.getString(R.string.error_screen_message)
		}
		_textView.text = _errorMessage
		_errorMessage = null
	}

	private fun _update() {
		// nothing yet
	}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}

		_update()
	}

	private fun _ingestPlayoutData(playout: Playout) {
		if (!playout.publication.isNullOrEmpty()) _publicationName = playout.publication
	}

	private fun _ingestOpts(opts: EmbedObject, options: Map<String, Any?>? = null) {
		val publicationData = opts.publicationData
		if (publicationData != null) {
			if (!publicationData.name.isNullOrEmpty()) _publicationName = publicationData.name
			if (!publicationData.baseurl.isNullOrEmpty()) _baseUrl = publicationData.baseurl
		}
		// embed parameters
		val embedData = opts.embedData
		if (embedData != null) {
			if (!embedData.baseurl.isNullOrEmpty()) _baseUrl = embedData.baseurl
		}

		// playout settings
		if (opts.playoutData != null) {
			_ingestPlayoutData(opts.playoutData as Playout)
		}

		// bbCpJwtCookieString
		val bbCpJwtCookieString = opts.bbCpJwtCookieString
		if (bbCpJwtCookieString != null) {
			_bbCpJwtCookieString = bbCpJwtCookieString
		}

		// options
		if (options != null) {
			if (options["jwt"] is String) _jwt = options["jwt"] as String
			if (options["rpcToken"] is String) _rpcToken = options["rpcToken"] as String
		}

		_update()
	}

	private fun _handleClipLoaded(data: Map<String, Any?>?) {
		val clipData = data?.get("clipData")
		if (clipData is MediaClip) {
			if (clipData.cpRuleViolations.isNullOrEmpty()) {
				_displayView?.visibility = View.GONE
				_textView.visibility = View.VISIBLE
				this.setBackgroundColor(_legacyBackgroundColor)
			}
		}
	}

	private fun _handleError(data: Map<String, Any?>?) {
		val cpp = data?.get("cpp")
		if (cpp is String && cpp.isNotEmpty()) {
			if (_displayView != null) this.removeView(_displayView)
			if (_displayView == null) {
				_displayView = ErrorDisplayView(context)
			}
			val displayLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
			_displayView?.layoutParams = displayLayoutParams
			_displayView?.visibility = View.VISIBLE
			_displayView?.id = View.generateViewId()
			 this.addView(_displayView)
			 _textView.visibility = View.GONE
			 this.setBackgroundColor(0) // transparent
			_displayView?.updateSettings(mapOf("publicationName" to _publicationName, "violation" to data?.get("msg"), "baseUrl" to _baseUrl, "cpp" to cpp, "jwt" to _jwt, "rpcToken" to _rpcToken, "bbCpJwtCookieString" to _bbCpJwtCookieString))
		}
	}
}
