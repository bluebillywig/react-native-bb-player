package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout

/**
 * ChromecastMiniControlsView
 *   is what you place in your layout and will become visible when a cast session is detected.
 *   It extends the platform’s core UI View class (more specifically: ConstraintLayout)
 *
 * @constructor
 *   no need to call this directly; use BBNativePlayer's getChromecastMiniControlsView singleton getter
 *
 * @param context
 * @param attrs (optional, default: null)
 * @param defStyleAttr (optional, default: 0)
 */
class ChromecastMiniControlsView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr) {
	init {
		val inflater = LayoutInflater.from(getContext())
		inflater.inflate(R.layout.chromecast_mini_controls, this)
	}
}
