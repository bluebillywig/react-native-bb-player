package com.bluebillywig.bbnativeplayersdk

import android.content.res.Resources
import android.graphics.Color
import android.graphics.Rect
import android.os.Build
import android.view.View
import com.bluebillywig.bbnativeshared.controller.InViewController
import com.bluebillywig.bbnativeshared.controller.MasterController
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.model.*
import io.ktor.client.*
import io.ktor.client.plugins.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.*
import kotlin.concurrent.fixedRateTimer

/**
 * @suppress
 */
class PollingInViewController (eventBus: EventBusInterface?, pc: ProgramController?, mc: MasterController? = null): InViewController (eventBus, pc, mc) {
	private val _mainScope = MainScope()
	private var _view: View? = null
	private var _timer: Timer? = null
	private var _screenRect: Rect = Rect()
	private var _viewRect: Rect = Rect()

	override fun __destruct() {
		super.__destruct()
		_timer?.cancel()
		_timer?.purge()
		_timer = null
		_view = null
		_mainScope.cancel()
	}

	var view: View?
		get() = _view
		set(value) { _view = value }

	override fun _ingestOpts(opts: EmbedObject?) {
		super._ingestOpts(opts)
		if (opts?.playoutData is Playout) {
			val playout = opts.playoutData as Playout // Smart cast is impossible...
			var inViewMarginString = ""
			if (playout.inviewMargin != null) inViewMarginString = playout.inviewMargin as String
			inViewMarginString = inViewMarginString.replace("%", "")
			try {
				_inViewMargin = inViewMarginString.toInt()
			} catch (e: Exception) {}
		}
		if (!_inViewAction.isEmpty() || !_outViewAction.isEmpty()) {
			_timer = fixedRateTimer(
				name = "inOutViewTimer",
				initialDelay = 0,
				period = 200
			) {
				_checkInOutView()
			}
		} else {
			_checkInOutView()
		}
	}

	fun calculatePercentageVisibility(view: View?): Int {
		if (view == null) return 0 // bail out

		_screenRect.set(0, 0, view.rootView?.width ?: 0, view.rootView?.height ?: 0)
		val isVisible = view.getGlobalVisibleRect(_viewRect)

		if (isVisible) {
			val visibleArea = _viewRect.width() * _viewRect.height()
			val totalArea = view.width * view.height
			val percentageVisible = if (totalArea != 0) visibleArea * 100 / totalArea else 0
			return percentageVisible
		}
		return 0
	}

	private fun _checkInOutView() {
		if (_view == null || _view?.isShown == false) {
			// don't bother looking
			return
		}

		val percentageVisible = calculatePercentageVisibility(_view)
		if (percentageVisible > _inViewMargin) {
			if (_inView_forced == null && !_inView) {
				_mainScope.launch(Dispatchers.Main) {
					_eventBus?.trigger(EventName.bb_inview)
				}
			}
		} else {
			// println("***OutView")
			if (_inView_forced == null && _inView) {
				_mainScope.launch(Dispatchers.Main) {
					_eventBus?.trigger(EventName.bb_outview)
				}
			}
		}
	}
}
