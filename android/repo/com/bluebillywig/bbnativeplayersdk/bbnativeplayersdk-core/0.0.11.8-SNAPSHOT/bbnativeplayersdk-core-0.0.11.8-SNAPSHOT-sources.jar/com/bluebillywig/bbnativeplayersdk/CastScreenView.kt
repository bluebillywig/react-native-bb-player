package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.data.Languages

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * @suppress
 */
class CastScreenView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		val iso = Locale.getDefault().getLanguage()
		when (eventType) {
			EventName.bb_media_cast_start, EventName.bb_media_cast_info -> {
				_casting = (data?.get("deviceName") != null)
				val deviceName = if (data?.get("deviceName") is String) data.get("deviceName") as String else "Chromecast"
				_ours = if (data?.get("ours") is Boolean) data.get("ours") as Boolean else false
				if (_ours) {
					_messageView.text = "  ${Languages.translate(iso, "Playing on")} ${deviceName}  "
				} else {
					_messageView.text = "  ${Languages.translate(iso, "Connected to")} ${deviceName}  "
				}

				_messageView.visibility = if (_casting && (!_playing || _ours)) View.VISIBLE else View.GONE
			}
			EventName.bb_media_playing -> {
				_playing = true

				_messageView.visibility = if (_casting && (!_playing || _ours)) View.VISIBLE else View.GONE
			}
			EventName.bb_media_paused -> {
				_playing = false

				_messageView.visibility = if (_casting && (!_playing || _ours)) View.VISIBLE else View.GONE
			}
			else -> {}
		}
	}
	private var _eventBus: EventBusInterface? = null
	private var _messageView: TextView = TextView(this.context)

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0x33000000.toInt()

	// data
	private var _casting: Boolean = false
	private var _ours: Boolean = false
	private var _playing: Boolean = false

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	init {
		this.setOrientation(LinearLayout.HORIZONTAL)
		this.setPadding(0, 0, 0, 105)
		this.setVerticalGravity(Gravity.BOTTOM)
		this.setHorizontalGravity(Gravity.LEFT)
		_messageView.text = ""
		_messageView.textSize = 14F
		_messageView.setTextColor(_foregroundColor)
		_messageView.setBackgroundColor(_backgroundColor)
		_messageView.visibility = View.GONE
		_messageView.id = View.generateViewId()
		this.addView(_messageView)
	}

	fun __destruct() {
		this.removeView(_messageView)
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}
}
