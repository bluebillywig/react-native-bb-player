package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.drawable.AnimationDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout

import androidx.appcompat.widget.AppCompatImageButton


/**
 * @suppress
 */
class ImageButtonBBAnimated : androidx.appcompat.widget.AppCompatImageButton {

    private var _animation: AnimationDrawable? = null
    private var test: String = ""
    constructor(context: Context) : super(context) {        // TODO Auto-generated constructor stub

    }

    constructor(context: Context, attrs: AttributeSet?) : super(
        context,
        attrs
    ) {        // TODO Auto-generated constructor stub

    }

    constructor(context: Context, attrs: AttributeSet?, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    ) {        // TODO Auto-generated constructor stub

    }

    public fun showBackgroundAnimation() {
        this.setBackgroundResource(R.drawable.bb_button_bg_anim)
        _animation = this.background as AnimationDrawable
        _animation?.start()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if ( event != null ) {
            val e: MotionEvent = event!!
            if ( MotionEvent.actionToString( e.action ) == "ACTION_UP" ) {
                this.showBackgroundAnimation()
            } else if ( MotionEvent.actionToString( e.action ) == "ACTION_DOWN" ) {
                _animation?.stop()
                this.setBackgroundResource(R.drawable.bb_button_anim_1)
            }
        }

        return super.onTouchEvent(event)
    }
}
