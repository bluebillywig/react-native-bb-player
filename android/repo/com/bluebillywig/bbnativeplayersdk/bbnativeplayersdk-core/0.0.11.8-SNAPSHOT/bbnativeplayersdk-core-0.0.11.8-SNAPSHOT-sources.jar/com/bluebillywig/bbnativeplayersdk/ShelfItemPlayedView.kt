package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
// import com.bluebillywig.bbnativeshared.controller.ProgramController

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/**
 * @suppress
 */
class ShelfItemPlayedView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {

	private var _eventBus: EventBusInterface? = null
	// private var _programController: ProgramController? = null
	private var _bigReplayButtonView = BigButtonView(this.context)

	init {
		this.setOrientation(LinearLayout.HORIZONTAL)
		this.setPadding(0, 0, 0, 0)
		this.setVerticalGravity(Gravity.CENTER_VERTICAL)
		this.setHorizontalGravity(Gravity.CENTER)

		_bigReplayButtonView.type = "REPLAY"
		_bigReplayButtonView.minimumWidth = 32
		_bigReplayButtonView.minimumHeight = 32
		// _bigReplayButtonView.setOnClickListener { view -> _programController?.play() }
		_bigReplayButtonView.id = View.generateViewId()
		this.addView(_bigReplayButtonView)
	}

	fun __destruct() {
		this.removeView(_bigReplayButtonView)

		// _programController = null
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus = value
			_bigReplayButtonView.eventBus = _eventBus
		}

//	var programController: ProgramController?
//		get() = _programController
//		set(value) {
//			_programController = value
//		}
}
