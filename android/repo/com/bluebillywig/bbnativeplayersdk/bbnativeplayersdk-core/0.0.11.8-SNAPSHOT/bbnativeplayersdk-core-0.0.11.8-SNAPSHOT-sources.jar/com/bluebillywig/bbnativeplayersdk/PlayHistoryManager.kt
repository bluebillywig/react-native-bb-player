package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.MediaClip
// import com.bluebillywig.bbnativeshared.model.MediaClipList
// import com.bluebillywig.bbnativeshared.model.Project

import android.content.Context
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import com.bluebillywig.bbnativeshared.model.Project

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock

class PlayHistoryManager (context: Context, eventBus: EventBusInterface?) : EventListenerInterface {
	override fun onEvent (eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_mediaclip_loaded, EventName.bb_mediaclip_failed -> {
				_onMediaclipLoaded(data)
			}
//			EventName.bb_mediacliplist_loaded, EventName.bb_mediacliplist_failed -> {
//				_onMediacliplistLoaded(data)
//			}
//			EventName.bb_project_loaded, EventName.bb_project_failed -> {
//				_onProjectLoaded(data)
//			}

			EventName.bb_media_playing -> {
				_onMediaPlaying()
			}

			EventName.bb_media_finished -> {
				_onMediaFinished()
			}

			EventName.bb_media_timeupdate -> {
				_onMediaTimeUpdate(data)
			}

			else -> {}
		}
	}

	companion object {
		fun <T> throttleFirst(
			intervalMs: Long = 300L,
			coroutineScope: CoroutineScope,
			destinationFunction: (T) -> Unit
		): (T) -> Unit {
			var throttleJob: Job? = null
			return { param: T ->
				if (throttleJob?.isCompleted != false) {
					throttleJob = coroutineScope.launch {
						destinationFunction(param)
						delay(intervalMs)
					}
				}
			}
		}
//		fun <T> throttleLatest(
//			intervalMs: Long = 300L,
//			coroutineScope: CoroutineScope,
//			destinationFunction: (T) -> Unit
//		): (T) -> Unit {
//			var throttleJob: Job? = null
//			var latestParam: T
//			return { param: T ->
//				latestParam = param
//				if (throttleJob?.isCompleted != false) {
//					throttleJob = coroutineScope.launch {
//						delay(intervalMs)
//						latestParam.let(destinationFunction)
//					}
//				}
//			}
//		}
	}

	// resources
	private var _databaseConnection: SQLiteConnection
	private var _eventBus: EventBusInterface? = eventBus
	private val _mainScope = MainScope()

	// data
	private var _clipData: MediaClip? = null

	// state
	private var _currentTime: Double? = null

	init {
		val dbPath = context.getDatabasePath("bb_play_history.db").path
		_databaseConnection = BundledSQLiteDriver().open(dbPath)
		_databaseConnection.execSQL(
			"CREATE TABLE IF NOT EXISTS Entry (entityTypedId VARCHAR(255) PRIMARY KEY, lastTimeOffset INTEGER, maxTimeOffset INTEGER, lastPlayedTS INTEGER, firstPlayedTS INTEGER, lastFinishedTS INTEGER, entityTitle TEXT)"
		)
		_eventBus?.addEventlistener(this)
	}

	fun __destruct() {
		_currentTime = null
		_clipData = null
		_eventBus?.removeEventlistener(this)
		_databaseConnection.close()
	}

	fun getMediaClipEntry(clipId: String): PlayHistoryEntry {
		return _getEntityEntry("MediaClip", clipId)
	}

	fun getMediaClipListEntry(clipListId: String): PlayHistoryEntry {
		return _getEntityEntry("MediaClipList", clipListId)
	}

	fun getProjectEntry(projectId: String): PlayHistoryEntry {
		return _getEntityEntry("Project", projectId)
	}

	private fun _getEntityEntry (entityType: String = "MediaClip", id: String): PlayHistoryEntry {
		val entry = PlayHistoryEntry()
		_databaseConnection.prepare("SELECT lastTimeOffset, maxTimeOffset, lastPlayedTS, firstPlayedTS, lastFinishedTS, entityTitle FROM Entry WHERE entityTypedId = ?").use { stmt ->
			stmt.bindText(index = 1, value = "${entityType}:${id}")
			if (stmt.step()) {
				entry.lastTimeOffset = stmt.getInt(0)
				entry.maxTimeOffset = stmt.getInt(1)
				entry.lastPlayedTS = stmt.getLong(2)
				entry.firstPlayedTS = stmt.getLong(3)
				entry.lastFinishedTS = stmt.getLong(4)
				entry.title = stmt.getText(5)
			}
		}
		return entry
	}

	private fun _setEntityEntry (entityType: String = "MediaClip", id: String, entry: PlayHistoryEntry) {
		// depends on UPSERT syntax (SQLite 3.24.0+, see: https://www.sqlite.org/lang_upsert.html )
		_databaseConnection.prepare("INSERT INTO Entry" +
				"(entityTypedId, lastTimeOffset, maxTimeOffset, lastPlayedTS, firstPlayedTS, lastFinishedTS, entityTitle) " +
				"VALUES(?, ?, ?, ?, ?, ?, ?) " +
				"ON CONFLICT(entityTypedId) DO UPDATE SET " +
				"lastTimeOffset = excluded.lastTimeOffset, " +
				"maxTimeOffset = excluded.maxTimeOffset, " +
				"lastPlayedTS = excluded.lastPlayedTS, " +
				"firstPlayedTS = excluded.firstPlayedTS, " +
				"lastFinishedTS = excluded.lastFinishedTS, " +
				"entityTitle = excluded.entityTitle").use { stmt ->
			stmt.bindText(index = 1, value = "${entityType}:${id}")
			stmt.bindInt(index = 2, value = entry.lastTimeOffset)
			stmt.bindInt(index = 3, value = entry.maxTimeOffset)
			stmt.bindLong(index = 4, value = entry.lastPlayedTS)
			stmt.bindLong(index = 5, value = entry.firstPlayedTS)
			stmt.bindLong(index = 6, value = entry.lastFinishedTS)
			stmt.bindText(index = 7, value = entry.title)
			stmt.step()
		}
	}

	private fun _onMediaclipLoaded (payload: Map<String, Any?>?) {
		if (payload != null && payload["clipData"] is MediaClip) {
			_clipData = payload["clipData"] as MediaClip
		} else {
			_clipData = null
		}
		_currentTime = 0.0
	}

//	private fun _onMediacliplistLoaded (payload: Map<String, Any?>?) {
//		if (payload != null && payload["clipListData"] is MediaClipList) {
//			_clipListData = payload["clipListData"] as MediaClipList
//		} else {
//			_clipListData = null
//		}
//		_currentTime = 0.0
//	}
//
//	private fun _onProjectLoaded (payload: Map<String, Any?>?) {
//		if (payload != null && payload["projectData"] is Project) {
//			_projectData = payload["projectData"] as Project
//		} else {
//			_projectData = null
//		}
//		_currentTime = 0.0
//	}
//
	private fun _onMediaPlaying () {
		val clipId = _clipData?.id
		if (clipId != null) {
			_mainScope.launch(Dispatchers.Main) {
				val entry = _getEntityEntry("MediaClip", clipId)
				// println("[PlayHistoryManager] _onMediaPlaying entry (before): ${entry.lastPlayedTS}")
				entry.lastPlayedTS = Clock.System.now().toEpochMilliseconds()
				entry.firstPlayedTS = entry.firstPlayedTS.coerceAtMost(entry.lastPlayedTS) // minimum
				entry.title = _clipData?.title ?: ""
				// println("[PlayHistoryManager] _onMediaPlaying entry (after): ${entry.lastPlayedTS}")
				_setEntityEntry("MediaClip", clipId, entry)
			}
		}
//		val clipListId = _clipListData?.id
//		if (clipListId != null) {
//			_mainScope.launch(Dispatchers.Main) {
//				val entry = _getEntityEntry("MediaClipList", clipListId)
//				// println("[PlayHistoryManager] _onMediaPlaying entry (before): ${entry.lastPlayedTS}")
//				entry.lastPlayedTS = Clock.System.now().toEpochMilliseconds()
//				entry.firstPlayedTS = entry.firstPlayedTS.coerceAtMost(entry.lastPlayedTS) // minimum
//				entry.title = _clipListData?.title ?: ""
//				// println("[PlayHistoryManager] _onMediaPlaying entry (after): ${entry.lastPlayedTS}")
//				_setEntityEntry("MediaClipList", clipListId, entry)
//			}
//		}
//		val projectId = _projectData?.id
//		if (projectId != null) {
//			_mainScope.launch(Dispatchers.Main) {
//				val entry = _getEntityEntry("Project", projectId)
//				// println("[PlayHistoryManager] _onMediaFinished entry (before): ${entry.lastFinishedTS}")
//				entry.lastPlayedTS = Clock.System.now().toEpochMilliseconds()
//				entry.firstPlayedTS = entry.firstPlayedTS.coerceAtMost(entry.lastPlayedTS) // minimum
//				entry.title = _projectData?.title ?: ""
//				// println("[PlayHistoryManager] _onMediaFinished entry (after): ${entry.lastFinishedTS}")
//				_setEntityEntry("Project", projectId, entry)
//			}
//		}
	}

	private fun _onMediaFinished () {
		val clipId = _clipData?.id
		if (clipId != null) {
			_mainScope.launch(Dispatchers.Main) {
				val entry = _getEntityEntry("MediaClip", clipId)
				// println("[PlayHistoryManager] _onMediaFinished entry (before): ${entry.lastFinishedTS}")
				entry.lastFinishedTS = Clock.System.now().toEpochMilliseconds()
				// println("[PlayHistoryManager] _onMediaFinished entry (after): ${entry.lastFinishedTS}")
				_setEntityEntry("MediaClip", clipId, entry)
			}
		}
	}

	private fun _onMediaTimeUpdate (payload: Map<String, Any?>?) {
		if (payload != null && payload["currentTime"] is String) {
			_currentTime = (payload["currentTime"] as String).toDoubleOrNull()
		} else {
			_currentTime = null
		}
		_onMediaTimeUpdateThrottled(Unit)
	}

	private val _onMediaTimeUpdateThrottled = throttleFirst<Unit>(500L, _mainScope) {
		val clipId = _clipData?.id
		if (clipId != null) {
			val entry = _getEntityEntry("MediaClip", clipId)
			// println("[PlayHistoryManager] _onMediaTimeUpdateThrottled entry ${clipId} (before): ${entry.lastTimeOffset}")
			entry.lastTimeOffset = (_currentTime ?: -1.0).toInt() // rounds down
			entry.maxTimeOffset = entry.maxTimeOffset.coerceAtLeast(entry.lastTimeOffset) // maximum
			// println("[PlayHistoryManager] _onMediaTimeUpdateThrottled entry ${clipId} (after): ${entry.lastTimeOffset}")
			_setEntityEntry("MediaClip", clipId, entry)
		}
	}
}
