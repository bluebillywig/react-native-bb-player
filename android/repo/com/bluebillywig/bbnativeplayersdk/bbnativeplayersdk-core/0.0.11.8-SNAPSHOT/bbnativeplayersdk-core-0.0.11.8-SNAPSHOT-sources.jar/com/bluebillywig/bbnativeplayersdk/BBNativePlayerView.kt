package com.bluebillywig.bbnativeplayersdk

// import androidx.mediarouter.media.*

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.AnimationDrawable
import android.net.Uri
import android.text.TextUtils
import android.util.AttributeSet
import android.view.*
import android.view.GestureDetector
import android.view.ViewTreeObserver
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat.invalidateOptionsMenu
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import androidx.media3.common.AdViewProvider
import androidx.media3.common.Format
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ads.AdsLoader
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.trackselection.TrackSelector
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import androidx.preference.PreferenceManager
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.controller.EmbedController
import com.bluebillywig.bbnativeshared.controller.MasterController
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.controller.StatsController
import com.bluebillywig.bbnativeshared.data.ContentLoader
import com.bluebillywig.bbnativeshared.data.Languages
import com.bluebillywig.bbnativeshared.enums.ApiMethod
import com.bluebillywig.bbnativeshared.enums.ApiProperty
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.State
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import com.google.android.gms.cast.framework.*
import com.google.android.ump.*
import com.google.android.ump.ConsentInformation.ConsentStatus
import io.ktor.http.encodeURLParameter
import kotlinx.coroutines.*
import java.lang.Thread.sleep
import java.net.URI
import java.util.Locale
import java.util.Timer
import java.util.TimerTask
import android.os.Handler
import android.os.Looper
import com.bluebillywig.bbnativeshared.controller.AdSchedulingController
import com.bluebillywig.bbnativeshared.controller.MsasController


/**
 * @suppress
 */
// Check to see if references are garbage collected after pressing "destroy player"
var USE_LEAKCANARY = false

/**
 * BBNativePlayerView
 *   is what you place in your layout.
 *   It extends the platform’s core UI View class (more specifically: FrameLayout)
 *
 * @constructor
 *   no need to call this directly; use BBNativePlayer's createPlayerView factory function
 *
 * @param context should be of type AppCompatActivity for fullscreen functionality
 * @param attrs (optional, default: null)
 * @param defStyleAttr (optional, default: 0)
 */

// see: https://antonioleiva.com/custom-views-android-kotlin/
@OptIn(UnstableApi::class)
class BBNativePlayerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) , EventListenerInterface {
    @OptIn(UnstableApi::class)
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
//        Logger.d("BBNativePlayerView: ", "GOT EVENT: $eventType")
        when (eventType) {
            EventName.bb_embed_loaded -> {
                val url = if (data != null && data["url"] is String) data["url"] as String else null
                val options: Map<String, Any?>? = if (data != null && data["options"] is Map<*, *>) data["options"] as Map<String, Any?> else null
                if (data != null) {
                    if (data["embedObject"] != null) {
                        val embedObject = data["embedObject"] as EmbedObject
						_ingestOpts(embedObject)

                        // start listener for castButton to know when it is shown for the first time. Before this time the rect of the castbutton is 0 se we need this 'wait' to check for overlap on other ui elements
                        val castButton: MediaRouteButton? = _playerView?.findViewById(R.id.exo_cast_button)
                        castButton?.viewTreeObserver?.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                            override fun onGlobalLayout() {
                                val rect = Rect()
                                val isVisible = castButton?.getGlobalVisibleRect(rect) ?: false && _subtitlesButton?.visibility == View.VISIBLE
                                if (isVisible) {
                                    castButton?.viewTreeObserver?.removeOnGlobalLayoutListener(this)
                                    handleOverlappingUI(castButton)
                                }
                            }
                        })

                        _playerType = options?.get("playerType") as? String ?: "main"
                        if (embedObject.clipData?.mediatype == "inarticle" || embedObject.clipData?.mediatype == "mainroll") _playerType = "outstream"
                        if (embedObject.adSchedulingData?.scheduleId != null && embedObject.adSchedulingData?.scheduleCode != null) {
                            // ad scheduling ads will be played through primary _playerView
                            _adController?.setPlayer(_player)
                            this.removeView(_auxiliaryPlayerView)
                        } else if (_playerType == "renderer") {
                            // renderer ads will be played through primary _playerView
                            _adController?.setPlayer(_player)
                            this.removeView(_auxiliaryPlayerView)
                        } else if (_playerType == "outstream") {
                            // outstream ads will be played through primary _playerView
                            _adController?.setPlayer(_player)
                            this.removeView(_auxiliaryPlayerView)
                        } else if (!embedObject.adServicesData.isNullOrEmpty()) {
                            // ads will be played through auxiliary _playerView
                            _adController?.set("mode", "AUXILIARY")
                        }

                        if (options?.get("playerType") == "shorts") { // || _playout?.playerType == "shorts"
                            _playerType = "shorts"
                            _adController?.set("mode", "SHORTS") // hack for Shorts-specific behavior

                            val swipeableListViewSettings: MutableMap<String, Any?> = mutableMapOf(
                                "swipeDirection" to options["swipeDirection"], // String
                                "hideSwipeControls" to options["hideSwipeControls"], // Boolean
                                "showDescription" to options["showDescription"], // Boolean
                                "viewedClipBehaviour" to options["viewedClipBehaviour"], // String
                                "ctaUrlField" to options["ctaUrlField"], // String
                                "ctaButtonLabelField" to options["ctaButtonLabelField"], // String
                                "useThumbnailsInFullscreen" to options["useThumbnailsInFullscreen"], // Boolean
                                "skipShortsAdOnSwipe" to true // Boolean
                            )
                            if (options.get("skin_foregroundColor") is String) {
                                try {
                                    try {
                                        _timeBar?.setPlayedColor(Color.parseColor("#" + options["skin_foregroundColor"] as String))
                                    } catch (_: Exception) {}

                                    swipeableListViewSettings["foregroundColor"] = Color.parseColor("#" + options["skin_foregroundColor"] as String)
                                } catch (_: Exception) {}
                            }
                            _swipeableListView?.updateSettings(swipeableListViewSettings)

                            val showPlayButton = if (options["showPlayButton"] is Boolean) options["showPlayButton"] as Boolean else false
                            _showControlBar = false // NB otherwise useController would hamper tap-to-resume!
                            setUseController(true) // OBSOLETE; no-op for shorts
                            if (_showControlBar) _playerView?.showController() else _playerView?.hideController()
                            if (_playerViewFitme != null) {
                                this.removeView(_playerViewFitme)
                                _swipeableListView?.addView(_playerViewFitme)
                            } else {
                                this.removeView(_playerView)
                                _swipeableListView?.addView(_playerView)
                            }

                            // println("**** going to move _auxiliaryPlayerView into _swipeableListView")
                            this.removeView(_auxiliaryPlayerView)
                            _auxiliaryPlayerView?.useController = _showControlBar
                             if (_showControlBar) _auxiliaryPlayerView?.showController() else _auxiliaryPlayerView?.hideController()
                            _swipeableListViewHasAux = true
                            _swipeableListView?.addView(_auxiliaryPlayerView)

                            _swipeableListView?.visibility = View.VISIBLE
                            _swipeableListView?.playHistoryManager = _playHistoryManager
                            _swipeableListView?.setExoPLayer(_player)

                            // first make swipeableListViewHolder("BBShortsPlayerView") and add _swipeableListView to that and add UI too
                            val swipeableListViewHolder: FrameLayout = FrameLayout(context)
                            val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            swipeableListViewHolder.layoutParams = layoutParams
                            swipeableListViewHolder.id = View.generateViewId()
                            this.addView(swipeableListViewHolder)
                            swipeableListViewHolder.addView(_swipeableListView) // id already generated in init

                            // UI
                            val centerControls = LinearLayout(this.context)
                            centerControls.id = View.generateViewId()
                            centerControls.tag = "centerControls"
                            centerControls.orientation = LinearLayout.HORIZONTAL
                            centerControls.setVerticalGravity(Gravity.CENTER)
                            centerControls.setHorizontalGravity(Gravity.CENTER)
                            centerControls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
                            centerControls.dividerDrawable = ContextCompat.getDrawable(context, R.drawable.empty_tall_divider)
                            centerControls.isClickable = false // NB clicks are caught by SwipeableListItemViews!
                            val centerControlsLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, 240)
                            centerControlsLayoutParams.gravity = Gravity.CENTER
                            centerControlsLayoutParams.setMargins(20, 20, 20, 90) // ltrb
                            centerControls.setLayoutParams(centerControlsLayoutParams)
                            _playPauseIcon = BigIconView(context)
                            _playPauseIcon?.isClickable = false
                            _playPauseIcon?.minimumWidth = 180
                            _playPauseIcon?.minimumHeight = 180
                            _playPauseIcon?.id = View.generateViewId()
                            centerControls.addView(_playPauseIcon)
                            swipeableListViewHolder.addView(centerControls)
                            _swipeableListView?.playPauseIcon = _playPauseIcon // NB so it can animate in togglePlayPause!

                            _shortsTopControls = LinearLayout(this.context)
                            val topControls = _shortsTopControls
                            if (topControls != null) {
                                topControls.id = View.generateViewId()
                                topControls.tag = "topControls"
                                topControls.orientation = LinearLayout.VERTICAL
                                topControls.setVerticalGravity(Gravity.TOP)
                                topControls.setHorizontalGravity(Gravity.CENTER_HORIZONTAL)
                                topControls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
                                val topControlsLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
                                topControlsLayoutParams.gravity = Gravity.TOP
                                topControlsLayoutParams.setMargins(0, 0, 0, 0) // ltrb
                                topControls.setLayoutParams(topControlsLayoutParams)
                                swipeableListViewHolder.addView(topControls)
                            }

                            _shortsBottomControls = LinearLayout(this.context)
                            val bottomControls = _shortsBottomControls
                            if (bottomControls != null) {
                                bottomControls.id = View.generateViewId()
                                bottomControls.tag = "bottomControls"
                                bottomControls.orientation = LinearLayout.VERTICAL
                                bottomControls.setVerticalGravity(Gravity.BOTTOM)
                                bottomControls.setHorizontalGravity(Gravity.LEFT)
                                bottomControls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
                                val bottomControlsLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
                                bottomControlsLayoutParams.gravity = Gravity.BOTTOM
                                bottomControlsLayoutParams.setMargins(0, 0, 0, 0) // ltrb
                                bottomControls.setLayoutParams(bottomControlsLayoutParams)
                                swipeableListViewHolder.addView(bottomControls)
                            }

                            _shortsRightControls = LinearLayout(this.context)
                            val rightControls = _shortsRightControls
                            if (rightControls != null) {
                                rightControls.id = View.generateViewId()
                                rightControls.tag = "rightControls"
                                rightControls.orientation = LinearLayout.VERTICAL
                                rightControls.setVerticalGravity(Gravity.BOTTOM)
                                rightControls.setHorizontalGravity(Gravity.CENTER)
                                rightControls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
                                rightControls.dividerDrawable = ContextCompat.getDrawable(context, R.drawable.empty_tall_divider)
                                val rightControlsLayoutParams = FrameLayout.LayoutParams(120, LayoutParams.MATCH_PARENT)
                                rightControlsLayoutParams.gravity = Gravity.RIGHT
                                rightControlsLayoutParams.bottomMargin = 90
                                rightControlsLayoutParams.rightMargin = 20
                                rightControls.setLayoutParams(rightControlsLayoutParams)
                                swipeableListViewHolder.addView(rightControls)
                            }

                            (_subtitlesButton?.parent as ViewGroup)?.removeView(_subtitlesButton)
                            (_muteButton?.parent as ViewGroup)?.removeView(_muteButton)
                            (_shareButton?.parent as ViewGroup)?.removeView(_shareButton)

                            _shortsRightControls?.addView(_shareButton)
                            _shortsRightControls?.addView(_muteButton)
                            _shortsRightControls?.addView(_subtitlesButton)

                            val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato)
                            val foregroundColor = 0xFFFFFFFF.toInt()
                            val shadowColor = 0xFF000000.toInt()
                            val shadowD = 2F

                            // CTA button
                            _ctaButton = Button(this.context)
                            _ctaButton?.setTextColor(foregroundColor)
                            _ctaButton?.setBackgroundColor(shadowColor)
                            // Store default CTA button text
                            if (options.get("ctaButtonText") is String) _ctaText = options["ctaButtonText"] as String
                            _ctaButton?.text = _ctaText
                            _ctaButton?.setTypeface(typeface, Typeface.BOLD)
                            _ctaButton?.isAllCaps = false
                            _ctaButton?.maxLines = 1
                            _ctaButton?.ellipsize = TextUtils.TruncateAt.END
                            _ctaButton?.setPadding(20, 0, 20, 0)

                            val ctaButtonLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

                            if (options.get("ctaButtonPosition") is String && options["ctaButtonPosition"] == "bottomLeft") {
                                _ctaButton?.setBackgroundResource(R.drawable.cta_rounded_corners)
                                ctaButtonLayoutParams.setMargins(60, 0, 50, 0)
                            } else {
                                _ctaButton?.setBackgroundResource(R.drawable.cta_round_corners)
                                ctaButtonLayoutParams.setMargins(120, 120, 120, 0)
                            }
                            if (options.get("ctaButtonUseAccentColor") is Boolean && options["ctaButtonUseAccentColor"] as Boolean) {
                                val drawable = _ctaButton?.getBackground()
                                var accentColor = shadowColor
                                if (options.get("skin_foregroundColor") is String) accentColor = Color.parseColor("#" + options["skin_foregroundColor"] as String)
                                drawable?.setColorFilter(
                                    BlendModeColorFilterCompat.createBlendModeColorFilterCompat(accentColor, BlendModeCompat.SRC_OVER)
                                )
                            }

                            _ctaButton?.layoutParams = ctaButtonLayoutParams
                            _ctaButton?.setOnClickListener {
                                var ctaUrl = _ctaUrl
                                if (!ctaUrl.isNullOrEmpty()) {
                                    if (!("""^(\w+:|)\/\/""").toRegex().containsMatchIn(ctaUrl)) ctaUrl = "http://${ctaUrl}"
                                    try {
                                        val ctaIntent = Intent(Intent.ACTION_VIEW, Uri.parse(ctaUrl))
                                        this.context.startActivity(ctaIntent)
                                    } catch (_: Exception) {
                                        _eventBus?.trigger(EventName.requestOpenUrl, mapOf("url" to ctaUrl))
                                    }
                                }
                            }

                            // title
                            _titleView = TextView(this.context)
                            _titleView?.setTypeface(typeface, Typeface.BOLD)
                            _titleView?.setTextColor(foregroundColor)
                            _titleView?.setShadowLayer(2F, shadowD, shadowD, shadowColor)
                            _titleView?.setPadding(60, 0, 120, 20)
                            _titleView?.textSize = 20F
                            _titleView?.maxLines = 1
                            _titleView?.ellipsize = TextUtils.TruncateAt.END
                            _titleView?.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                            val titleViewLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
                            titleViewLayoutParams.gravity = Gravity.BOTTOM or Gravity.LEFT
                            titleViewLayoutParams.setMargins(0, 0, 0, 20)
                            _titleView?.layoutParams = titleViewLayoutParams
                            _titleView?.text = ""
                            _titleView?.visibility = if (options.get("title") is String && options["title"] as String == "Show") View.VISIBLE else View.GONE

                            // description
                            _descriptionView = TextView(this.context)
                            _descriptionView?.setTypeface(typeface)
                            _descriptionView?.setTextColor(foregroundColor)
                            _descriptionView?.setShadowLayer(2F, shadowD, shadowD, shadowColor)
                            _descriptionView?.setPadding(60, 0, 220, 20)
                            _descriptionView?.maxLines = 2
                            _descriptionView?.ellipsize = TextUtils.TruncateAt.END
                            _descriptionView?.textSize = 18F
                            _descriptionView?.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                            val descriptionViewLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
                            descriptionViewLayoutParams.gravity = Gravity.BOTTOM or Gravity.LEFT
                            _descriptionView?.layoutParams = descriptionViewLayoutParams
                            _descriptionView?.text = ""
                            _descriptionView?.visibility = if (_showDescription == true || (options.get("description") is String && options["description"] as String == "Show")) View.VISIBLE else View.GONE
                            _descriptionView?.setOnClickListener {
                                _descriptionView?.maxLines = if (_descriptionView?.maxLines == 2) 40 else 2
                            }

                            _playerView?.controllerShowTimeoutMs = 0
                            _playerView?.controllerHideOnTouch = false
                            _playerView?.setControllerHideDuringAds(true)

                            // time bar
                            _timeBar = _playerView?.findViewById(R.id.exo_progress)
                            (_timeBar?.parent as ViewGroup)?.removeView(_timeBar)
                            _timeBar?.hideScrubber()
                            val timeBarLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, 10)
                            timeBarLayoutParams.gravity = Gravity.BOTTOM
                            timeBarLayoutParams.bottomMargin = 0
                            _timeBar?.setLayoutParams(timeBarLayoutParams)

                            _ctaButton?.id = View.generateViewId()
                            if (options["ctaButtonPosition"] == "bottomLeft") _shortsBottomControls?.addView(_ctaButton) else _shortsTopControls?.addView(_ctaButton)
                            _titleView?.id = View.generateViewId()
                            _shortsBottomControls?.addView(_titleView)
                            _descriptionView?.id = View.generateViewId()
                            _shortsBottomControls?.addView(_descriptionView)

                            _playPauseButton = _playerView?.findViewById(R.id.exo_play_pause)
                            val castButton: MediaRouteButton? = _playerView?.findViewById(R.id.exo_cast_button)
                            val settingsButton: ImageView? = _playerView?.findViewById(R.id.exo_settings_icon)
                            val fullscreenButton: ImageView? = _playerView?.findViewById(R.id.exo_fullscreen_icon)
                            val positionText: TextView? = _playerView?.findViewById(R.id.exo_position)
                            val timeDeviderText: TextView? = _playerView?.findViewById(R.id.exo_time_devider)
                            val durationText: TextView? = _playerView?.findViewById(R.id.exo_duration)
                            (_playPauseButton?.parent as ViewGroup?)?.removeView(_playPauseButton)
                            (castButton?.parent as ViewGroup)?.removeView(castButton)
                            (settingsButton?.parent as ViewGroup)?.removeView(settingsButton)
                            (fullscreenButton?.parent as ViewGroup)?.removeView(fullscreenButton)
                            (positionText?.parent as ViewGroup)?.removeView(positionText)
                            (timeDeviderText?.parent as ViewGroup)?.removeView(timeDeviderText)
                            (durationText?.parent as ViewGroup)?.removeView(durationText)
                            if (showPlayButton) {
                                _playPauseButton?.setOnClickListener { _ -> if (_programController?.getState() == State.PLAYING) _programController?.pause() else _programController?.play() }
                                _shortsBottomControls?.addView(_playPauseButton)
                            }
                            _shortsBottomControls?.addView(_timeBar)

                            // _exoOverlayFrameLayout?.removeView(_pauseScreenView)
                            (_commercialScreenView.parent as ViewGroup).removeView(_commercialScreenView)
                            swipeableListViewHolder?.addView(_commercialScreenView)

                            if (options.get("logoUrlString") is String && options.get("logoUrlString") != "") {
                                val logoUrlString = options["logoUrlString"] as String
                                _logoView = LogoView(this.context)
                                _logoView.setPadding(10,10,10,10)
                                _logoView.setVerticalGravity(Gravity.TOP)
                                _logoView.setHorizontalGravity(Gravity.LEFT)

                                _logoView.minimumHeight = 150
                                _logoView.id = View.generateViewId()
                                swipeableListViewHolder.addView(_logoView)
                                _logoView.url = logoUrlString
                            }
                        }
                    }
                }
                _delegate?.didSetupWithJsonUrl(this, url)
            }
            EventName.bb_embed_failed -> {
                val error = if (data != null && data["error"] is String) data["error"] as String else null
                _delegate?.didFailWithError(this, "Embed failed - $error")
            }

            EventName.bb_api_ready -> {
                _delegate?.didTriggerApiReady(this)
            }

            EventName.bb_program_autopause -> {
                val why = if (data != null && data["why"] is String) data["why"] as String else null
                _delegate?.didTriggerAutoPause(this, why)
            }
            EventName.bb_program_autopauseplay -> {
                val why = if (data != null && data["why"] is String) data["why"] as String else null
                _delegate?.didTriggerAutoPausePlay(this, why)
            }
            EventName.bb_program_play -> {
                _delegate?.didTriggerPlay(this)
            }
            EventName.bb_phase_change -> {
                _onPhaseChange(data)
            }
            EventName.bb_state_change -> {
                _onStateChange(data)
            }
            EventName.bb_mode_change -> {
                _onModeChange(data)
            }
			EventName.bb_playout_changed -> {
				_onPlayoutChanged(data)
			}
            EventName.bb_error -> {
                _onError(data)
            }
            EventName.playing -> {
                this.keepScreenOn = true
                _mediaFinished = false
                _playPauseButton?.setImageResource(R.drawable.bb_icon_play)
                _playPauseButton?.contentDescription = accessibilityTranslate("Pause")
                val fullscreenPlayPauseButtonPlaying: ImageView? = _fullScreenPlayerView?.findViewById(R.id.exo_play_pause)
                fullscreenPlayPauseButtonPlaying?.contentDescription = accessibilityTranslate("Pause")
                _delegate?.didTriggerPlaying(this)
                val shareButton: ImageView? = findViewById(R.id.exo_share_icon)
                if ( shareButton != null ) {
                    shareButton.visibility = View.GONE
                    this.hideFullScreenShareButton()
                    if (_playout?.shareButton == "Show") {
                        shareButton.visibility = View.VISIBLE
                        this.showFullScreenShareButton()
                    }
                }
                _playerView?.hideController()
            }
            EventName.pause -> {
                this.keepScreenOn = false
                _delegate?.didTriggerPause(this)
                if (!_mediaFinished ) { // needed because pause event also comes AFTER bb_media_finished
                    val shareButton: ImageView? = findViewById(R.id.exo_share_icon)
                    if ( shareButton != null ) {
                        shareButton.visibility = View.GONE
                        this.hideFullScreenShareButton()
                        if (_playout?.shareButtonPause == "Show") {
                            shareButton.visibility = View.VISIBLE
                            this.showFullScreenShareButton()
                        }
                    }
                }
            }
            EventName.ended -> {
                this.keepScreenOn = false
                _playerView?.showController()
                _delegate?.didTriggerEnded(this)
            }
            EventName.bb_request_expand -> {
                if (_allowCollapseExpand) {
                    _expand()
                }
                _delegate?.didRequestExpand(this)
            }
            EventName.bb_request_collapse -> {
                if (_allowCollapseExpand) {
                    _collapse()
                }
                _delegate?.didRequestCollapse(this)
            }
            EventName.bb_project_loaded -> {
                val projectData = if (data != null && data["projectData"] is Project) data["projectData"] as Project else null
                _delegate?.didTriggerProjectLoaded(this, projectData)
            }
            EventName.bb_mediaclip_loaded -> {
                _clip = if (data != null && data["clipData"] is MediaClip) data["clipData"] as MediaClip else null
                val mediaWidth = _clip?.width ?: 0
                val mediaHeight = _clip?.height ?: 0
                if (mediaHeight > 0 && !_aspectRatioSetOnce) {
                    _aspectRatioSetOnce = true
                    _aspectRatio = mediaWidth.toDouble() / mediaHeight.toDouble()
                    Logger.d("BBNativePlayerView", "bb_mediaclip_loaded aspect ratio: $_aspectRatio")
                    _expandHeight = (this.width.toDouble() / _aspectRatio).toInt()
                    Logger.d("BBNativePlayerView", "bb_mediaclip_loaded stored height: $_expandHeight")
                }
                val clip = _clip
                _ctaUrl = if (clip != null) _swipeableListView?.getCtaUrlForItem(clip) else ""
                val ctaLabel = if (clip != null) _swipeableListView?.getCtaLabelForItem(clip) else ""
                _ctaButton?.text = if (!ctaLabel.isNullOrEmpty()) ctaLabel else _ctaText
                _ctaButton?.visibility = if (!_ctaUrl.isNullOrEmpty()) View.VISIBLE else View.GONE
                _titleView?.text = _clip?.title ?: ""
                _descriptionView?.text = stripHtmlTags(_clip?.description ?: "")
                _delegate?.didTriggerMediaClipLoaded(this, _clip)
            }
            EventName.bb_mediaclip_failed -> {
                _delegate?.didTriggerMediaClipFailed(this)
            }
            EventName.bb_media_failed -> {
                this.keepScreenOn = false
                // _delegate?.didTriggerMediaFailed(this)
            }
            EventName.bb_view_started -> {
                _delegate?.didTriggerViewStarted(this)
            }
            EventName.bb_view_finished -> {
                _delegate?.didTriggerViewFinished(this)
            }
            EventName.bb_media_finished -> {
                this.keepScreenOn = false
                _mediaFinished = true
                _playPauseButton = findViewById(R.id.exo_play_pause)
                _playPauseButton?.postDelayed({
                    _playPauseButton?.setImageResource(R.drawable.bb_icon_replay_small)
                    _playPauseButton?.contentDescription = accessibilityTranslate("Replay")
                }, 100)
                val fullscreenPlayPauseButton: ImageView? = _fullScreenPlayerView?.findViewById(R.id.exo_play_pause)
                fullscreenPlayPauseButton?.postDelayed({
                    fullscreenPlayPauseButton?.setImageResource(R.drawable.bb_icon_replay_small)
                    fullscreenPlayPauseButton?.contentDescription = accessibilityTranslate("Replay")
                }, 100)
                val shareButton: ImageView? = findViewById(R.id.exo_share_icon)
                if ( shareButton != null ) {
                    shareButton.visibility = View.GONE
                    this.hideFullScreenShareButton()
                    if (_playout?.shareButtonEnd == "Show") {
                        shareButton.visibility = View.VISIBLE
                        this.showFullScreenShareButton()
                    }
                }
            }
            EventName.canplay -> {
                _canPlay = true
                _delegate?.didTriggerCanPlay(this)
                if (_allowCollapseExpand) {
                    _expand() // NB trick to ensure proper working of startCollapsed!
                }
                if (_pendingPlay) {
                    _play()
                }

            }
            EventName.durationchange -> {
                _duration = if (data != null && data["duration"] is Double) data["duration"] as Double else 0.0
                _delegate?.didTriggerDurationChange(this, _duration)
            }
            EventName.fullscreen -> {
                _delegate?.didTriggerFullscreen(this)
            }
            EventName.retractfullscreen -> {
                _delegate?.didTriggerRetractFullscreen(this)
            }

            EventName.bb_media_seeking -> {
                _delegate?.didTriggerSeeking(this)
            }
            EventName.bb_media_seeked -> {
                val seekOffset = if (data != null && data["seekOffset"] is String) (data["seekOffset"] as String).toDoubleOrNull() else null
                _delegate?.didTriggerSeeked(this, seekOffset ?: -1.0)
            }
            EventName.bb_media_stalled -> {
                _delegate?.didTriggerStall(this)
            }

            EventName.bb_master_volume -> {
                if (data != null && data["volume"] is Double) {
                    _masterVolume = data["volume"] as Double
                }
                val volume: Double = if (_masterMuted) 0.0 else _masterVolume
                _delegate?.didTriggerVolumeChange(this, volume)
            }
            EventName.bb_master_mute, EventName.bb_master_unmute -> {
                _masterMuted = (eventType == EventName.bb_master_mute)
                val muteButton2: ImageView? = _fullScreenPlayerView?.findViewById(R.id.exo_mute)
                if (_masterMuted) {
                    _muteButton?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeoff))
                    _muteButton?.contentDescription = accessibilityTranslate("Volume Off")
                    muteButton2?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeoff))
                    muteButton2?.contentDescription = accessibilityTranslate("Volume Off")
                } else { // not muted
                    _muteButton?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeon))
                    _muteButton?.contentDescription = accessibilityTranslate("Volume On")
                    muteButton2?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeon))
                    muteButton2?.contentDescription = accessibilityTranslate("Volume On")
                }
                val volume: Double = if (_masterMuted) 0.0 else _masterVolume
                _delegate?.didTriggerVolumeChange(this, volume)
            }
            EventName.bb_adsystem_initialized -> {
                // Recreate auxiliary player in all but the first init
                if (!_adSystemInitialized) {
                    _adSystemInitialized = true
                } else {
                    _recreateAuxiliaryPlayer()
                }
            }
            EventName.bb_adsystem_loadstart, EventName.bb_as_loadstart -> {
                Logger.d("BBNativePlayerView", "bb_adsystem_loadstart")
                _delegate?.didTriggerAdLoadStart(this)
            }
            EventName.bb_adsystem_loaded, EventName.bb_as_item_loaded -> {
                val adProperties = if (data != null && data["adProperties"] is Map<*,*>) data["adProperties"] as Map<String,Any?> else mapOf()
                val mediaWidth = if (adProperties["vastMediaWidth"] is Int) adProperties["vastMediaWidth"] as Int else 0
                val mediaHeight = if (adProperties["vastMediaHeight"] is Int) adProperties["vastMediaHeight"] as Int else 0
                if (mediaHeight > 0 && !_aspectRatioSetOnce) {
                    _aspectRatioSetOnce = true
                    _aspectRatio = mediaWidth.toDouble() / mediaHeight.toDouble()
                    Logger.d("BBNativePlayerView", "bb_adsystem_loaded aspect ratio: $_aspectRatio")
                    _expandHeight = (this.width.toDouble() / _aspectRatio).toInt()
                    Logger.d("BBNativePlayerView", "bb_adsystem_loaded stored height: $_expandHeight")
                }
                _adMediaWidth = mediaWidth
                _adMediaHeight = mediaHeight
                _delegate?.didTriggerAdLoaded(this)
                _collapseHeight = 0

                // Renderer Overscan
                if (_overscanAd && !_allowCollapseExpand) {
                    _setPlayerViewFitmeLayout()
                }
            }
            EventName.bb_adsystem_noad, EventName.bb_as_item_noad -> {
                this.keepScreenOn = false
                _adMediaWidth = 0
                _adMediaHeight = 0
                _delegate?.didTriggerAdNotFound(this)
                _collapseHeight = 0

                _auxiliaryPlayerView?.visibility = View.GONE

                _resetPlayerViewFitmeLayout()
            }
            EventName.bb_adsystem_failed, EventName.bb_as_item_failed -> {
                this.keepScreenOn = false
                val error = if (data != null && data["error"] is String) data["error"] as String else null
                if (error != null) {
                    _delegate?.didTriggerAdError(this, error)
                } else {
                    _delegate?.didTriggerAdError(this, null)
                }
                _collapseHeight = 0

                _auxiliaryPlayerView?.visibility = View.GONE

                _resetPlayerViewFitmeLayout()
            }
            EventName.bb_adsystem_quartile, EventName.bb_as_ad_quartile -> {
                this.keepScreenOn = true

                if (eventType == EventName.bb_adsystem_quartile) {
                    _auxiliaryPlayerView?.visibility = View.VISIBLE
                }

                val quartile = if (data != null && data["quartile"] is String) data["quartile"] as String else null
                if (quartile != null) {
                    when (quartile) {
                        "0" -> {
                            _delegate?.didTriggerAdStarted(this)
                        }
                        "1" -> {
                            _delegate?.didTriggerAdQuartile1(this)
                        }
                        "2" -> {
                            _delegate?.didTriggerAdQuartile2(this)
                        }
                        "3" -> {
                            _delegate?.didTriggerAdQuartile3(this)
                        }
                        "4" -> {
                            _delegate?.didTriggerAdFinished(this)
                        }
                        else -> {}
                    }
                }
                _collapseHeight = 0
            }
            EventName.bb_adsystem_skipped, EventName.bb_as_item_skipped -> {
                this.keepScreenOn = false
//                _delegate?.didTriggerAdSkipped(this) // DOESN'T EXIST YET
                _collapseHeight = 0

                _auxiliaryPlayerView?.visibility = View.GONE

                _resetPlayerViewFitmeLayout()
            }
            EventName.bb_adsystem_finished, EventName.bb_as_finished -> {
                this.keepScreenOn = false
                _delegate?.didTriggerAllAdsCompleted(this)
                _collapseHeight = 0

                _auxiliaryPlayerView?.visibility = View.GONE

                _resetPlayerViewFitmeLayout()
            }

            EventName.requestOpenUrl -> {
                val url = if (data != null && data["url"] is String) data["url"] as String else null
                _delegate?.didRequestOpenUrl(this, url)
            }

            EventName.playbackSpeedChanged -> {
                val speed = if (data != null && data["speed"] is Float) data["speed"] as Float else null
                if ( speed != null ) {
                    val param = PlaybackParameters(speed)
                    _player?.setPlaybackParameters(param)
                }
            }
            EventName.subtitleTracksChanged -> {
                var hideSubtitleButton: Boolean = false

                if (data != null && data["subtitles"] != null) {
                    val subtitles = data["subtitles"] as List<Subtitle>
                    if ( subtitles.count() == 0 ) {
                        hideSubtitleButton = true
                    }
                } else {
                    hideSubtitleButton = true
                }

                if (hideSubtitleButton || _mediaController?._currentSubtitleId == "off") {
                    _subtitlesButton?.visibility = View.GONE

                    val subtitlesButton: ImageView? = _fullScreenPlayerView?.findViewById(R.id.exo_subtitles_icon)
                    if (subtitlesButton != null) {
                        subtitlesButton.visibility = View.GONE
                    }
                } else {
                    _subtitlesButton?.visibility = View.VISIBLE

                    val subtitlesButton: ImageView? = _fullScreenPlayerView?.findViewById(R.id.exo_subtitles_icon)
                    if (subtitlesButton != null) {
                        subtitlesButton.visibility = View.VISIBLE
                    }
                }
            }
            EventName.subtitleTrackChanged -> {
                if (data != null && data["id"] != null) {
                    val subtitlesButton2 = _fullScreenPlayerView?.findViewById<ImageView>(R.id.exo_subtitles_icon)
                    if (data["id"] == "off") {
                        _subtitlesOn = false // help toggle
                        _subtitlesButton?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_subtitlesoff))
                        _subtitlesButton?.contentDescription = accessibilityTranslate("Subtitles off")
                        subtitlesButton2?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_subtitlesoff))
                        subtitlesButton2?.contentDescription = accessibilityTranslate("Subtitles off")
                    } else {
                        _subtitlesOn = true // help toggle
                        _subtitlesButton?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_subtitleson))
                        _subtitlesButton?.contentDescription = accessibilityTranslate("Subtitles on")
                        subtitlesButton2?.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_subtitleson))
                        subtitlesButton2?.contentDescription = accessibilityTranslate("Subtitles on")
                    }
                }
            }
            EventName.customStatistics -> {
                val ident = if (data != null && data["ident"] is String) data["ident"] as String else ""
                val ev = if (data != null && data["ev"] is String) data["ev"] as String else ""
                val aux = if (data != null && data["aux"] is Map<*,*>) data["aux"] as Map<String,String> else mapOf()
                _delegate?.didTriggerCustomStatistics(this, ident, ev, aux)
            }
            else -> {}
        }
    }
    private var _api: BBNativePlayerAPI? = null
    private var _delegate: BBNativePlayerViewDelegate? = null
    private var _exoOverlayFrameLayout: FrameLayout? = null
    private var _exoOverlayViewsArray: MutableList<View?> = mutableListOf<View?>()

    internal var _eventBus: EventBus? = null
    private var _programController: ProgramController? = null
    private var _statsController: StatsController? = null
    private var _embedController: EmbedController? = null
    private var _playHistoryManager: PlayHistoryManager? = null
    private var _network: Network? = null

    private var _playerViewFitme: FrameLayout? = null
    private var _playerView: PlayerView? = null
    private var _auxiliaryPlayerView: PlayerView? = null
    private var _swipeableListView: SwipeableListView? = null
    internal var _fullScreenPlayerView: PlayerView? = null
    internal var _player: ExoPlayer? = null
    internal var _auxiliaryPlayer: ExoPlayer? = null
    private var _bbForwardingPlayer: BBForwardingPlayer? = null
    private var _auxiliaryBBForwardingPlayer: BBForwardingPlayer? = null
    private var _forwardingPlayer: ForwardingPlayer? = null
    private var _timeBar: YouTubeTimeBar? = null
    private var _posterView: ImageView? = null
    private var _interactivityView: InteractivityView? = null
    private var _masterController: MasterController? = null
    private var _mediaController: MediaController? = null
    private var _adController: AdController? = null
    private var _posterController: PosterController? = null
    private var _interactivityController: InteractivityController? = null
    private var _inViewController: PollingInViewController? = null
    internal var modalAppCompatActivity:AppCompatActivity? = null
    internal var backArrow: ImageButton? = null
    private var _muteButton: ImageView? = null
    private var _shareButton: ImageView? = null
    private var _titleView: TextView? = null
    private var _descriptionView: TextView? = null
    private var _playPauseIcon: BigIconView? = null
    private var _playPauseButton: ImageView? = null
    private var _ctaButton: Button? = null
    private var _shortsTopControls: LinearLayout? = null
    private var _shortsBottomControls: LinearLayout? = null
    private var _shortsRightControls: LinearLayout? = null

    // state
    private var _enabled: Boolean = true
    private var _phase: Phase = Phase.INIT
    private var _state: State = State.IDLE
    private var _mode: String = ""
    private var _duration: Double = 0.0
    private var _expectPlaying: Boolean = false
    private var _pendingPlay: Boolean = false
    private var _canPlay: Boolean = false
    private var _aspectRatio: Double = 16.0 / 9.0
    private var _aspectRatioSetOnce: Boolean = false
    private var _adMediaWidth: Int = 0
    private var _adMediaHeight: Int = 0
    private var _masterVolume: Double = 1.0
    internal var _masterMuted: Boolean = false
    private var _mediaFinished: Boolean = false
    private var _skipOnMeasure = false
    private var _expandHeight = 0
    private var _collapseHeight = 1 // NB!
    private var _savedRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED // -1
    private var _adSystemInitialized: Boolean = false
    private var _swipeableListViewHasAux: Boolean = false
	private var _exoCastButtonsSetUp: Boolean = false

    private var _onSharedPreferenceChangeListenerJsonUrl: String = ""
    private var _onSharedPreferenceChangeListenerOptions: Map<String, Any?>? = null

    // screens
    private val _startScreenView: StartScreenView = StartScreenView(this.context)
    private val _pauseScreenView: PauseScreenView = PauseScreenView(this.context)
    internal val _endScreenView: EndScreenView = EndScreenView(this.context)
    private val _scrubberPreviewScreenView: ScrubberPreviewScreenView = ScrubberPreviewScreenView(this.context)
    private val _commercialScreenView: CommercialScreenView = CommercialScreenView(this.context)
    private val _errorScreenView: ErrorScreenView = ErrorScreenView(this.context)
    private val _castScreenView: CastScreenView = CastScreenView(this.context)

    // Double-tap seek views and gesture detection (iOS naming convention)
    private val leftDoubleTapSeekView: DoubleTapSeekView = DoubleTapSeekView(this.context)
    private val rightDoubleTapSeekView: DoubleTapSeekView = DoubleTapSeekView(this.context)
    private var _gestureDetector: GestureDetector? = null
    internal var _gestureDetectorFullScreen: GestureDetector? = null
    private var seekDelayTimer: Runnable? = null
    private var seekAmount = 0
    private var seekDirection: DoubleTapSeekView.SeekDirection? = null
    private val _seekHandler = Handler(Looper.getMainLooper())

    private val _activityIndicatorView: ActivityIndicatorView = ActivityIndicatorView(this.context)
    private val _miniControlsContainerView: LinearLayout = LinearLayout(this.context)
    private val _commercialPlaceholderView: CommercialPlaceholderView = CommercialPlaceholderView(this.context)
    private var _settingsDialog: SettingsBottomSheetDialog? = SettingsBottomSheetDialog()
    private var _subtitlesButton: ImageView? = null
    private var _logoView: LogoView = LogoView(this.context)

    // gradient backgrounds for controls
    private var _topGradientView: View? = null
    private var _bottomGradientView: View? = null

    // data
    private var _options: Map<String, Any?>? = null
    internal var _playout: Playout? = null
    private var _project: Project? = null
    private var _clip: MediaClip? = null
    private var _ctaUrl: String? = null
    private var _embedData: EmbedData? = null
    private var _consentInfo: ConsentInformation? = null

    //  inOutView
    private val mainScope = MainScope()
    private var _inOutViewState: String = "outView";
    private var timer: Timer? = null

    // settings
    internal var _noChromeCast: Boolean = false
    private var _showChromeCastMiniControls: Boolean = false
    private var _allowCollapseExpand: Boolean = false
    private var _canRequestAds: Boolean = true // NB!
    private var _waitForCmp: Boolean = false
    private var _handleConsentManagement: Boolean = false
    private var _tagForUnderAgeOfConsent: Boolean = false
    internal var _subtitlesOn: Boolean = true
    private var _playerType: String = ""
    private var _showTitle: Boolean = false
    private var _showDescription: Boolean = false
	private var _showControlBar: Boolean = true
    private var _showBigPlayButton: Boolean = true
	private var _showCastButton: Boolean = true
    private var _forceFullscreenLandscape: Boolean = false
    private var _mobileRotateOnFullScreenMismatch: Boolean = false
    private var _overscanAd: Boolean = false
    private var _ctaText: String = "Learn more"

	// ChromeCast
    private lateinit var _gmsCastContext: CastContext
	private var _gmsCastSession: CastSession? = null
	private lateinit var _gmsSessionManager: SessionManager
	private val _gmsSessionManagerListener: SessionManagerListener<CastSession> = SessionManagerListenerImpl() as SessionManagerListener<CastSession>
	private inner class SessionManagerListenerImpl : SessionManagerListener<CastSession?> {
		override fun onSessionStarting(session: CastSession) {
			Logger.d("BBNativePlayerView", "onSessionStarting")
		}
		override fun onSessionStarted(session: CastSession, sessionId: String) {
			Logger.d("BBNativePlayerView", "onSessionStarted sessionId: ${sessionId}")
            _gmsCastSession = session
            _mediaController?.setCastSession(_gmsCastSession, true)
            if (context is Activity) invalidateOptionsMenu(context as Activity)
		}
		override fun onSessionStartFailed(session: CastSession, error: Int) {
			Logger.d("BBNativePlayerView", "onSessionStartFailed error: ${error}")
		}
		override fun onSessionResuming(session: CastSession, p1: String) {
			Logger.d("BBNativePlayerView", "onSessionResuming p1: ${p1}")
		}
		override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
			Logger.d("BBNativePlayerView", "onSessionResumed wasSuspended: ${wasSuspended}")
            _gmsCastSession = session
            _mediaController?.setCastSession(_gmsCastSession, false)
            if (context is Activity) invalidateOptionsMenu(context as Activity)
		}
		override fun onSessionResumeFailed(session: CastSession, error: Int) {
			Logger.d("BBNativePlayerView", "onSessionResumeFailed error: ${error}")
		}
		override fun onSessionEnding(session: CastSession) {
			Logger.d("BBNativePlayerView", "onSessionEnding")
		}
		override fun onSessionEnded(session: CastSession, error: Int) {
			Logger.d("BBNativePlayerView", "onSessionEnded error: ${error}")
            _gmsCastSession = null
            _mediaController?.setCastSession(_gmsCastSession, true)
		}
		override fun onSessionSuspended(session: CastSession, p1: Int) {
			Logger.d("BBNativePlayerView", "onSessionSuspended p1: ${p1}")
            _gmsCastSession = null
            _mediaController?.setCastSession(_gmsCastSession, false)
		}
	}
    private var _gmsMiniControlsView: ChromecastMiniControlsView? = null
    private lateinit var rocketAnimation: AnimationDrawable

    init {
        _eventBus = EventBus()
        _eventBus?.addEventlistener(this)
        _errorScreenView.eventBus = _eventBus

        _network = Network()

        val layoutParams = this.layoutParams as LayoutParams? ?: LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT) // this.layoutParams ?:
        this.setLayoutParams(layoutParams)

        val backgroundView: View = View(this.context)
        backgroundView.setBackgroundColor(0xFF000000.toInt()) // AARRGGBB
        backgroundView.id = View.generateViewId()
        this.addView(backgroundView)

        _adController = AdController(this.context, _eventBus)

        _statsController = StatsController(_eventBus, _network)
        _playHistoryManager = PlayHistoryManager(this.context, _eventBus)
        _programController = ProgramController(_eventBus)
        _programController!!.network = _network
        _embedController = EmbedController(_eventBus, null)
        _embedController!!.network = _network

        _api = BBNativePlayerAPI(this, _eventBus)

        var trackSelector: TrackSelector = DefaultTrackSelector(this.context)

        // player
        _playerView = LayoutInflater.from(this.context).inflate(R.layout.bb_exo_player_view, null, false) as PlayerView

        // Set up the factory for media sources, passing the ads loader and ad view providers.
        val dataSourceFactory: DataSource.Factory = DefaultDataSource.Factory(this.context)
        val adsLoaderProvider = AdsLoader.Provider { _adController?.adsLoader }
        val adViewProvider = AdViewProvider { _playerView }
        val mediaSourceFactory: MediaSource.Factory = DefaultMediaSourceFactory(dataSourceFactory)
            .setAdsLoaderProvider(adsLoaderProvider)
            .setAdViewProvider(adViewProvider)
        _player = ExoPlayer.Builder(this.context).setMediaSourceFactory(mediaSourceFactory).setTrackSelector(trackSelector).build()
        _bbForwardingPlayer = BBForwardingPlayer(_player, _playerView, _api)

        (_playerView?.player as ForwardingPlayer).preparePlayerForFullScreen(_playerView!!, false, _exoOverlayViewsArray, _eventBus, this)

        _playerView?.controllerShowTimeoutMs = 3000
        setUseController(false) //will be handled in _updateScreenVisibility

        // Sync gradient visibility with controller visibility
        _playerView?.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
            val isVisible = visibility == View.VISIBLE
            _topGradientView?.visibility = if (isVisible) View.VISIBLE else View.GONE
            _bottomGradientView?.visibility = if (isVisible) View.VISIBLE else View.GONE
            backArrow?.visibility = if (isVisible) View.VISIBLE else View.GONE
        })

        this.addView(_playerView)

        _exoOverlayFrameLayout = _playerView?.getOverlayFrameLayout()

        _swipeableListView = SwipeableListView(this.context)
        _swipeableListView?.eventBus = _eventBus
        _swipeableListView?.programController = _programController
        _swipeableListView?.visibility = View.GONE

        // NB!
        _auxiliaryPlayerView = LayoutInflater.from(this.context).inflate(R.layout.bb_exo_player_view, null, false) as PlayerView
        _auxiliaryPlayerView?.useController = false
        val auxiliaryPlayerLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        auxiliaryPlayerLayoutParams.gravity = Gravity.CLIP_HORIZONTAL or Gravity.CLIP_VERTICAL
        auxiliaryPlayerLayoutParams.setMargins(0, 0, 0, 0) // ltrb
        _auxiliaryPlayerView?.setLayoutParams(auxiliaryPlayerLayoutParams)
        val auxiliaryDataSourceFactory: DataSource.Factory = DefaultDataSource.Factory(this.context)
        val auxiliaryTrackSelector: TrackSelector = DefaultTrackSelector(this.context)
        val auxiliaryAdsLoaderProvider = AdsLoader.Provider { _adController?.adsLoader }
        val auxiliaryAdViewProvider = AdViewProvider { _auxiliaryPlayerView } // NB!
        val auxiliaryMediaSourceFactory: MediaSource.Factory = DefaultMediaSourceFactory(auxiliaryDataSourceFactory)
            .setAdsLoaderProvider(auxiliaryAdsLoaderProvider)
            .setAdViewProvider(auxiliaryAdViewProvider)
        _auxiliaryPlayer = ExoPlayer.Builder(this.context).setMediaSourceFactory(auxiliaryMediaSourceFactory).setTrackSelector(auxiliaryTrackSelector).build()
        _auxiliaryBBForwardingPlayer = BBForwardingPlayer(_auxiliaryPlayer, _auxiliaryPlayerView, _api)
        _adController?.setPlayer(_auxiliaryPlayer)
        _adController?.setCompanionAdSlotContainer(_commercialPlaceholderView.bgLayer)
        _auxiliaryPlayerView?.visibility = View.GONE
        this.addView(_auxiliaryPlayerView)

        _posterView = ImageView(this.context)
        _posterView?.id = View.generateViewId()
        _exoOverlayViewsArray.add(_posterView)
        _interactivityView = InteractivityView(this.context)
        _interactivityView?.visibility = View.GONE
        _interactivityView?.eventBus = _eventBus
        _interactivityView?.id = View.generateViewId()
        _exoOverlayViewsArray.add(_interactivityView)

        // Create gradient views for control backgrounds
        // These are added early in the overlay array so they render behind pause/end screens
        val topGradientHeightDp = 85 // Height in dp, matching original XML
        val topGradientHeightPx = (topGradientHeightDp * resources.displayMetrics.density).toInt()

        _topGradientView = View(this.context)
        _topGradientView?.id = View.generateViewId()
        _topGradientView?.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            topGradientHeightPx
        ).apply {
            gravity = Gravity.TOP
        }
        _topGradientView?.setBackgroundResource(R.drawable.top_controls_bg)
        _topGradientView?.visibility = View.GONE // Initially hidden, shown with controls
        _exoOverlayViewsArray.add(_topGradientView)

        _bottomGradientView = View(this.context)
        _bottomGradientView?.id = View.generateViewId()
        _bottomGradientView?.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply {
            gravity = Gravity.BOTTOM
        }
        _bottomGradientView?.setBackgroundResource(R.drawable.controls_bg)
        _bottomGradientView?.visibility = View.GONE // Initially hidden, shown with controls
        _exoOverlayViewsArray.add(_bottomGradientView)

        _mediaController = MediaController(_eventBus, _player)
        _mediaController?.setContext(this.context)
        _timeBar = findViewById(R.id.exo_progress)
        _mediaController?.setTimeBar(_timeBar)
        _posterController = PosterController(_eventBus, _posterView)
        _interactivityController = InteractivityController(_eventBus, _interactivityView, this)
        _masterController = MasterController(_eventBus)
        _inViewController = PollingInViewController(_eventBus, _programController, _masterController)
        _inViewController!!.view = this

        _programController!!.mediaController = _mediaController
        _programController!!.adController = _adController
        _programController!!.posterController = _posterController

        // screens
        _startScreenView.visibility = View.GONE
        _startScreenView.eventBus = _eventBus
        _startScreenView.programController = _programController
        _startScreenView._bbNativePlayerView = this
        _startScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_startScreenView)

        _pauseScreenView.visibility = View.GONE
        _pauseScreenView.eventBus = _eventBus
        _pauseScreenView.programController = _programController
        _pauseScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_pauseScreenView)

        _endScreenView.visibility = View.GONE
        _endScreenView.eventBus = _eventBus
        _endScreenView.programController = _programController
        _endScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_endScreenView)

        _scrubberPreviewScreenView.visibility = View.VISIBLE
        _scrubberPreviewScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_scrubberPreviewScreenView)

        _commercialScreenView.visibility = View.GONE
        _commercialScreenView.setId(View.generateViewId())
        _commercialScreenView.eventBus = _eventBus
        _commercialScreenView.playerAPI = _api
        _commercialScreenView.setProgramcontroller(this._programController)
        _commercialScreenView.id = View.generateViewId()
        this.addView(_commercialScreenView) // NB not in _exoOverlayViewsArray for clickability
        _adController?.registerFriendlyObstruction(_commercialScreenView)

        _errorScreenView.visibility = View.GONE
        // _errorScreenView.eventBus = _eventBus // done earlier (line 980); before ProgramController
        _errorScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_errorScreenView)

        _settingsDialog?.eventBus = _eventBus
        _settingsDialog?.programController = _programController

        _castScreenView.visibility = View.GONE // self-hiding
        _castScreenView.eventBus = _eventBus
        _castScreenView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_castScreenView)

        _activityIndicatorView.visibility = View.GONE // self-hiding
        _activityIndicatorView.eventBus = _eventBus
        _activityIndicatorView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_activityIndicatorView)

        _miniControlsContainerView.setVerticalGravity(Gravity.TOP)
        _miniControlsContainerView.visibility = View.GONE
        _miniControlsContainerView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_miniControlsContainerView)

        _commercialPlaceholderView.visibility = View.GONE
        _commercialPlaceholderView.eventBus = _eventBus
        _commercialPlaceholderView.id = View.generateViewId()
        _exoOverlayViewsArray.add(_commercialPlaceholderView)

        // Initialize double-tap seek views
        _initializeDoubleTapSeek()
        _exoOverlayViewsArray.add(leftDoubleTapSeekView)
        _exoOverlayViewsArray.add(rightDoubleTapSeekView)

        _exoOverlayViewsArray.forEach {
            _exoOverlayFrameLayout?.addView(it)
        }

        // Set proper width for double-tap seek views after they're added to overlay
        _exoOverlayFrameLayout?.viewTreeObserver?.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                _exoOverlayFrameLayout?.viewTreeObserver?.removeOnGlobalLayoutListener(this)

                val overlayWidth = _exoOverlayFrameLayout?.width ?: 0
                if (overlayWidth > 0) {
                    val seekViewWidth = (overlayWidth * 0.33f).toInt()

                    // Update left view width
                    val leftParams = leftDoubleTapSeekView.layoutParams as? FrameLayout.LayoutParams
                    leftParams?.width = seekViewWidth
                    leftDoubleTapSeekView.layoutParams = leftParams

                    // Update right view width
                    val rightParams = rightDoubleTapSeekView.layoutParams as? FrameLayout.LayoutParams
                    rightParams?.width = seekViewWidth
                    rightDoubleTapSeekView.layoutParams = rightParams
                }
            }
        })

        _subtitlesButton = findViewById(R.id.exo_subtitles_icon)
        _subtitlesButton?.contentDescription = accessibilityTranslate("Subtitles off")
        _subtitlesButton?.setOnClickListener {
            _enableDisableSubtitles(_subtitlesButton)
        }

        // Set initial accessibility label for play/pause button
        val initPlayPauseButton: ImageView? = findViewById(R.id.exo_play_pause)
        initPlayPauseButton?.contentDescription = accessibilityTranslate("Play")

        // ChromeCast
        _gmsCastContext = CastContext.getSharedInstance(this.context) // lazily initializes CastContext
		_gmsSessionManager = _gmsCastContext.sessionManager

        this.setBackgroundColor(Color.parseColor("#000000"))

        val foregroundColor = _playout?.skin_foregroundColor // OBSOLETE
        if (foregroundColor is String) {
            try {
                _timeBar?.setPlayedColor(Color.parseColor("#" + foregroundColor as String))
            } catch (_: Exception) {}
        }
        _timeBar?.showScrubber()
        _timeBar?.timeBarPreview(_scrubberPreviewScreenView.timeBarPreview)

        _muteButton = findViewById(R.id.exo_mute)
        if (_muteButton != null) {
            val playerVolume = _player?.volume ?: 0F
            if (playerVolume > 0F) {
                this.player?.muted = false // triggers bb_master_unmute
                _muteButton?.contentDescription = accessibilityTranslate("Volume On")
            } else {
                this.player?.muted = true // triggers bb_master_mute
                _muteButton?.contentDescription = accessibilityTranslate("Volume Off")
            }

            _muteButton?.setOnClickListener() {
                if (_muteButton != null) {
                    _muteUnmute(_muteButton!!)
                }
            }
        }

        val settingsButton: ImageView = findViewById(R.id.exo_settings_icon)
        settingsButton.contentDescription = accessibilityTranslate("Settings")
        settingsButton.setOnClickListener {
           _showSettingsDialog()
        }

        _shareButton = findViewById(R.id.exo_share_icon)
        _shareButton?.contentDescription = accessibilityTranslate("Share")
        _shareButton?.setOnClickListener {
            _handleShareButton()
        }
        _endScreenView._shareButton = this._shareButton  // share button in exocontrols but want to hide/show it in exitscreen when related items are shown or not, so passing it on as an internal
        _pauseScreenView._shareButton = this._shareButton  // share button in exocontrols but want to hide/show it in pausescreen when related items are shown or not, so passing it on as an internal

        _ctaText = Languages.translate(Locale.getDefault().getLanguage(), _ctaText)
    }

    private fun showFullScreenShareButton() {
        if (_forwardingPlayer != null) {
            _forwardingPlayer?.handleShareButton(_playerView!!, this, true)
        }
    }

    private fun hideFullScreenShareButton() {
        if (_forwardingPlayer != null) {
            _forwardingPlayer?.handleShareButton(_playerView!!, this, false)
        }
    }

    internal fun accessibilityTranslate(key: String): String {
        return Languages.translate(Locale.getDefault().getLanguage(), key)
    }

    internal fun _handleShareButton() {
        var url:String = ""
        if (_clip != null) {
            if (_clip?.deeplink != null && _clip?.deeplink != "") {
                url = _clip?.deeplink!!
            } else if (_clip?.gendeeplink != null && _clip?.gendeeplink != "") {
                url = _clip?.gendeeplink!!
            } else {
                url = _embedData?.baseurl + "/view/" + _embedData?.playoutSafeName + "/" + _clip?.id + ".html";
            }
        }

        // handle share_ options
        if ( this._options != null ) {
            this._options!!.forEach { entry ->
                var urlAddons: String = ""
                if (entry.key.startsWith("share_")) {
                    try {
                        val entryValue: String = entry.value as? String ?: ""
                        urlAddons += "&" + entry.key.encodeURLParameter() + "=" + entryValue.encodeURLParameter()
                    } catch (_: Exception) {}
                }

                if (urlAddons != "") {
                    val uri = URI(url)
                    var query = uri.query
                    if (query == null) {
                        url += "?" + urlAddons.substring(1)
                    } else {
                        url += urlAddons
                    }
                }
            }
        }

        val shareIntent = Intent()
        shareIntent.action = Intent.ACTION_SEND
        shareIntent.type="text/plain"
        shareIntent.putExtra(Intent.EXTRA_TEXT, url)
        this.context.startActivity(Intent.createChooser(shareIntent,""))
    }

    internal fun _enableDisableSubtitles(subtitlesButton: ImageView?) {
        // ignore passed-in subtitlesButton; will be updated in subtitleTrackChanged handler
        if (_subtitlesOn == true) {
            _mediaController?.subtitlesOff() // triggers subtitleTrackChanged
        } else {
            _mediaController?.subtitlesOn() // triggers subtitleTrackChanged
        }
    }

    internal fun _muteUnmute(muteButton: ImageView) {
        // ignore passed-in muteButton; will be updated in bb_master_(un)mute handler
        if (this.player?.muted == true) {
            this.player?.setMuted(false, true) // triggers bb_master_unmute
        } else { // not muted
            this.player?.setMuted(true, true) // triggers bb_master_mute
        }
    }

    internal fun _showSettingsDialog() {
        val closestActivity = getActivity()
        val fragmentManager = closestActivity?.supportFragmentManager
        if (fragmentManager != null && !(_settingsDialog?.dialog?.isShowing() == true)) {
            try {
                _settingsDialog?.show(fragmentManager, "")
            } catch (_: Exception) {} // IllegalStateException
        }
    }

    private fun getActivity(): AppCompatActivity? {
        var myContext = this.context

        if ( this.modalAppCompatActivity != null ) {
            return this.modalAppCompatActivity
        }
        while (myContext is ContextWrapper) {
            if (myContext is ModalActivity) {
                return myContext
            }
            if (myContext is AppCompatActivity) {
                return myContext
            }
            myContext = (myContext as ContextWrapper).getBaseContext()
        }
        return null
    }

    /**
    * @suppress
    */
    companion object {
        const val ANIMATION_DURATION: Long = 500

        // Double-tap seek constants
        const val SEEK_ACCUMULATION_DELAY_MS: Long = 600L
        const val SEEK_SECONDS_INCREMENT: Int = 10

        fun stripHtmlTags(richText: String): String {
            return ("""<[^>]*>""").toRegex().replace(richText, "")
        }
    }

    /**
    * @suppress
    */
    public override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
//        Logger.d("BBNativePlayerView", "onMeasure width: ${this.width}")
//        Logger.d("BBNativePlayerView", "onMeasure height: ${this.height}")

        val wmsMode = MeasureSpec.getMode(widthMeasureSpec)
        val wmsSize = MeasureSpec.getSize(widthMeasureSpec)
        val hmsMode = MeasureSpec.getMode(heightMeasureSpec)
        val hmsSize = MeasureSpec.getSize(heightMeasureSpec)
//        Logger.d("BBNativePlayerView", "onMeasure width: $wmsSize, mode: $wmsMode")
//        Logger.d("BBNativePlayerView", "onMeasure height: $hmsSize, mode: $hmsMode")

        if (!_skipOnMeasure) {
            val desiredHeight = (wmsSize.toDouble() / _aspectRatio).toInt() // auto height
            if (hmsMode == MeasureSpec.EXACTLY) {
//                Logger.d("BBNativePlayerView", "onMeasure EXACTLY going to keep height: ${hmsSize}")
                super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            } else if (hmsMode == MeasureSpec.AT_MOST) {
//                Logger.d("BBNativePlayerView", "onMeasure AT_MOST going to spec height: ${Math.min(desiredHeight, hmsSize)}")
                val newHeightMeasureSpec = MeasureSpec.makeMeasureSpec(Math.min(desiredHeight, hmsSize), MeasureSpec.EXACTLY)
                super.onMeasure(widthMeasureSpec, newHeightMeasureSpec)
            } else { // UNSPECIFIED
//                Logger.d("BBNativePlayerView", "onMeasure going to spec height: ${desiredHeight}")
                val newHeightMeasureSpec = MeasureSpec.makeMeasureSpec(desiredHeight, MeasureSpec.EXACTLY)
                super.onMeasure(widthMeasureSpec, newHeightMeasureSpec)
            }
        } else {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        }
    }

    /**
     * Destruct, freeing all memory allocated internally
     */
    fun __destruct() {
        _gmsSessionManager.removeSessionManagerListener(_gmsSessionManagerListener, CastSession::class.java)
        _gmsCastSession = null
        _mediaController?.setCastSession(_gmsCastSession, false)

        _exoOverlayFrameLayout?.removeView(_commercialPlaceholderView)
        _commercialPlaceholderView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_commercialPlaceholderView, "_commercialPlaceholderView was detached")

        _exoOverlayFrameLayout?.removeView(_castScreenView)
        _castScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_castScreenView, "_castScreenView was detached")

        _adController?.unregisterAllFriendlyObstructions()
        this.removeView(_commercialScreenView)
        _commercialScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_commercialScreenView, "_commercialScreenView was detached")

        _exoOverlayFrameLayout?.removeView(_endScreenView)
        _endScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_endScreenView, "_endScreenView was detached")

        _exoOverlayFrameLayout?.removeView(_pauseScreenView)
        _pauseScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_pauseScreenView, "_pauseScreenView was detached")

        _exoOverlayFrameLayout?.removeView(_startScreenView)
        _startScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_startScreenView, "_startScreenView was detached")

        _exoOverlayFrameLayout?.removeView(_errorScreenView)
        _errorScreenView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_errorScreenView, "_errorScreenView was detached")

        _exoOverlayFrameLayout?.removeView(_activityIndicatorView)
        _activityIndicatorView.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_activityIndicatorView, "_activityIndicatorView was detached")

        _exoOverlayFrameLayout?.removeView(_posterView)
        //_posterView?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_posterView, "_posterView was detached")
        _posterView = null

        _exoOverlayFrameLayout?.removeView(_topGradientView)
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_topGradientView, "_topGradientView was detached")
        _topGradientView = null

        _exoOverlayFrameLayout?.removeView(_bottomGradientView)
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_bottomGradientView, "_bottomGradientView was detached")
        _bottomGradientView = null

        this.backArrow = null

        _exoOverlayFrameLayout?.removeAllViews()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_exoOverlayFrameLayout, "_exoOverlayFrameLayout was detached")
        _exoOverlayFrameLayout = null

        _embedController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_embedController, "_embedController was detached")
        _embedController = null

        _mediaController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_mediaController, "_mediaController was detached")
        _mediaController = null

        _inViewController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_inViewController, "_inViewController was detached")
        _inViewController = null

        _masterController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_masterController, "_masterController was detached")
        _masterController = null

        _posterController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_posterController, "_posterController was detached")
        _posterController = null

        _statsController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_statsController, "_statsController was detached")
        _statsController = null

        _adController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_adController, "_adController was detached")
        _adController = null

        _swipeableListView?.removeAllViews()
        _swipeableListView?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_swipeableListView, "_swipeableListView was detached")
        _swipeableListView = null

        _playerViewFitme?.removeAllViews()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_playerViewFitme, "_playerViewFitme was detached")
        _playerViewFitme = null

        this.removeView(_playerView)
        _playerView?.setPlayer(null)
        _playerView?.removeAllViews()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_playerView, "_playerView was detached")
        _playerView = null
        _player?.release()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_player, "_player was detached")
        _player = null

        // Auxiliary player cleanup
        val auxParent = _auxiliaryPlayerView?.parent as? ViewGroup
        auxParent?.removeView(_auxiliaryPlayerView)
        _auxiliaryPlayerView?.player = null
        _auxiliaryPlayerView = null
        _auxiliaryPlayer?.stop()
        _auxiliaryPlayer?.release()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_auxiliaryPlayer, "_auxiliaryPlayer was detached")
        _auxiliaryPlayer = null

        _auxiliaryBBForwardingPlayer?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_auxiliaryBBForwardingPlayer, "_auxiliaryBBForwardingPlayer was detached")
        _auxiliaryBBForwardingPlayer = null

        _exoOverlayViewsArray.clear()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_exoOverlayViewsArray, "_exoOverlayViewsArray was detached")
        // _exoOverlayViewsArray = null

        _bbForwardingPlayer?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_bbForwardingPlayer, "_bbForwardingPlayer was detached")
        _bbForwardingPlayer = null

        _forwardingPlayer = null

        _playHistoryManager?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_playHistoryManager, "_playHistoryManager was detached")
        _playHistoryManager = null

        _interactivityController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_interactivityController, "_interactivityController was detached")
        _interactivityController = null

        _interactivityView = null

        _fullScreenPlayerView?.player = null
        _fullScreenPlayerView = null

        modalAppCompatActivity = null

        _gmsMiniControlsView = null

        _consentInfo = null

        _api?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_api, "_api was detached")
        _api = null

        _programController?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_programController, "_programController was detached")
        _programController = null

        _eventBus?.removeEventlistener(this) // OBSOLETE
        _eventBus?.__destruct()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_eventBus, "_eventBus was detached")
        _eventBus = null

        this.removeAllViews()

        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_network, "_network was detached")
        _network = null

        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_delegate, "_delegate was detached")
        _delegate = null

        _settingsDialog?.__destruct()
        _settingsDialog = null
        _cleanupDoubleTapSeek()
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(leftDoubleTapSeekView, "leftDoubleTapSeekView was detached")
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(rightDoubleTapSeekView, "rightDoubleTapSeekView was detached")

        // this.context = null
        if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(this, "this was detached")

        this.keepScreenOn = false
    }

    /**
     * Recreate auxiliary player and view for fresh ad playback state
     */
    private fun _recreateAuxiliaryPlayer() {
        // Determine current parent container and index
        val currentParent = _auxiliaryPlayerView?.parent as? ViewGroup
        // println("**** _recreateAuxiliaryPlayer: currentParent = $currentParent")
        val currentIndex = currentParent?.indexOfChild(_auxiliaryPlayerView) ?: -1
        // println("**** _recreateAuxiliaryPlayer: currentIndex = $currentIndex")

        // Remove and clean up old instances
        _auxiliaryBBForwardingPlayer?.__destruct()
        if (_auxiliaryPlayerView != null) {
            currentParent?.removeView(_auxiliaryPlayerView)
            _auxiliaryPlayerView?.player = null
        }
        if (_auxiliaryPlayer != null) {
            _auxiliaryPlayer?.stop()
            _auxiliaryPlayer?.release()
        }

        // Create new auxiliary player view
        _auxiliaryPlayerView = LayoutInflater.from(this.context).inflate(R.layout.bb_exo_player_view, null, false) as PlayerView
        _auxiliaryPlayerView?.useController = false
        val auxiliaryPlayerLayoutParams = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        auxiliaryPlayerLayoutParams.gravity = Gravity.CLIP_HORIZONTAL or Gravity.CLIP_VERTICAL
        auxiliaryPlayerLayoutParams.setMargins(0, 0, 0, 0) // ltrb
        _auxiliaryPlayerView?.setLayoutParams(auxiliaryPlayerLayoutParams)

        // Create new auxiliary player
        val auxiliaryDataSourceFactory: DataSource.Factory = DefaultDataSource.Factory(this.context)
        val auxiliaryTrackSelector: TrackSelector = DefaultTrackSelector(this.context)
        val auxiliaryAdsLoaderProvider = AdsLoader.Provider { _adController?.adsLoader }
        val auxiliaryAdViewProvider = AdViewProvider { _auxiliaryPlayerView }
        val auxiliaryMediaSourceFactory: MediaSource.Factory = DefaultMediaSourceFactory(auxiliaryDataSourceFactory)
            .setAdsLoaderProvider(auxiliaryAdsLoaderProvider)
            .setAdViewProvider(auxiliaryAdViewProvider)
        _auxiliaryPlayer = ExoPlayer.Builder(this.context).setMediaSourceFactory(auxiliaryMediaSourceFactory).setTrackSelector(auxiliaryTrackSelector).build()
        _auxiliaryBBForwardingPlayer = BBForwardingPlayer(_auxiliaryPlayer, _auxiliaryPlayerView, _api)

        // Attach to AdController
        _adController?.setPlayer(_auxiliaryPlayer)

        // Add view back to the same parent at the same index to preserve z-order
        _auxiliaryPlayerView?.visibility = View.GONE
        if (currentIndex >= 0 && currentParent != null) {
            currentParent.addView(_auxiliaryPlayerView, currentIndex)
            // println("**** _recreateAuxiliaryPlayer: added at index $currentIndex")
        } else if (currentParent != null) {
            currentParent.addView(_auxiliaryPlayerView)
            // println("**** _recreateAuxiliaryPlayer: added at end")
        } else if (_swipeableListViewHasAux) { // NB this triggers "re-adoption"!
            _swipeableListView?.addView(_auxiliaryPlayerView)
            // println("**** _recreateAuxiliaryPlayer: added at end of _swipeableListView")
        }
    }

    /**
     * Initialize double-tap seek functionality
     */
    private fun _initializeDoubleTapSeek() {

        leftDoubleTapSeekView.direction = DoubleTapSeekView.SeekDirection.BACKWARD
        rightDoubleTapSeekView.direction = DoubleTapSeekView.SeekDirection.FORWARD

        leftDoubleTapSeekView.id = View.generateViewId()
        rightDoubleTapSeekView.id = View.generateViewId()

        leftDoubleTapSeekView.setBackgroundResource(R.drawable.double_tap_seek_left)
        rightDoubleTapSeekView.setBackgroundResource(R.drawable.double_tap_seek_right)

        val leftLayoutParams = FrameLayout.LayoutParams(
            0, // Will be set to 33% of parent width dynamically in "override fun onLayout(changed: Boolean..."
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        leftLayoutParams.gravity = Gravity.START or Gravity.CENTER_VERTICAL

        val rightLayoutParams = FrameLayout.LayoutParams(
            0, // Will be set to 33% of parent width dynamically in "override fun onLayout(changed: Boolean..."
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        rightLayoutParams.gravity = Gravity.END or Gravity.CENTER_VERTICAL

        leftDoubleTapSeekView.layoutParams = leftLayoutParams
        rightDoubleTapSeekView.layoutParams = rightLayoutParams

        leftDoubleTapSeekView.visibility = View.GONE
        rightDoubleTapSeekView.visibility = View.GONE

        // Create gesture detector for double-tap detection
        _gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                handleSeekDoubleTap(e.x, e.y)
                return true
            }

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                // Allow single tap to pass through to existing controls
                return false
            }
        })
    }

    /**
     * Handle double-tap events and determine seek direction based on RTL support
     */
    private fun handleSeekDoubleTap(x: Float, y: Float) {
        val width = this.width.toFloat()
        val isRTL = layoutDirection == View.LAYOUT_DIRECTION_RTL

        // Determine tap zones (33% on each side)
        val leftZoneEnd = width * 0.33f
        val rightZoneStart = width * 0.67f

        val direction = when {
            x <= leftZoneEnd -> if (isRTL) DoubleTapSeekView.SeekDirection.FORWARD else DoubleTapSeekView.SeekDirection.BACKWARD
            x >= rightZoneStart -> if (isRTL) DoubleTapSeekView.SeekDirection.BACKWARD else DoubleTapSeekView.SeekDirection.FORWARD
            else -> return // Center zone - no seek action
        }

        val seekView = when {
            x <= leftZoneEnd -> leftDoubleTapSeekView
            x >= rightZoneStart -> rightDoubleTapSeekView
            else -> return
        }

        _performSeekAccumulation(direction, seekView)
    }

    /**
     * Handle double-tap events in fullscreen mode
     * @suppress
     */
    internal fun _handleSeekDoubleTapFullScreen(x: Float, y: Float) {
        val width = _fullScreenPlayerView?.width?.toFloat() ?: return
        val isRTL = _fullScreenPlayerView?.layoutDirection == View.LAYOUT_DIRECTION_RTL

        // Determine tap zones (33% on each side)
        val leftZoneEnd = width * 0.33f
        val rightZoneStart = width * 0.67f

        val direction = when {
            x <= leftZoneEnd -> if (isRTL) DoubleTapSeekView.SeekDirection.FORWARD else DoubleTapSeekView.SeekDirection.BACKWARD
            x >= rightZoneStart -> if (isRTL) DoubleTapSeekView.SeekDirection.BACKWARD else DoubleTapSeekView.SeekDirection.FORWARD
            else -> return // Center zone - no seek action
        }

        val seekView = when {
            x <= leftZoneEnd -> leftDoubleTapSeekView
            x >= rightZoneStart -> rightDoubleTapSeekView
            else -> return
        }

        _performSeekAccumulation(direction, seekView)
    }

    /**
     * Accumulate seek operations with timer-based execution
     */
    private fun _performSeekAccumulation(direction: DoubleTapSeekView.SeekDirection, seekView: DoubleTapSeekView) {
        // If direction changed, execute pending seek and reset
        if (seekDirection != null && seekDirection != direction) {
            _executeAccumulatedSeek()
            _resetSeekAccumulation()
        }

        // Update accumulation
        seekDirection = direction
        seekAmount += SEEK_SECONDS_INCREMENT

        // Update seek time display (iOS-style updateSeekTime method)
        if (direction == DoubleTapSeekView.SeekDirection.BACKWARD) {
            leftDoubleTapSeekView.updateSeekTime(seekAmount)
        } else {
            rightDoubleTapSeekView.updateSeekTime(seekAmount)
        }

        // Hide the opposite view immediately and show the active one
        when (direction) {
            DoubleTapSeekView.SeekDirection.BACKWARD -> {
                rightDoubleTapSeekView.hideImmediate() // Hide right immediately when going left
                leftDoubleTapSeekView.show()
            }
            DoubleTapSeekView.SeekDirection.FORWARD -> {
                leftDoubleTapSeekView.hideImmediate() // Hide left immediately when going right
                rightDoubleTapSeekView.show()
            }
        }
        seekView.showRipple()

        // Cancel existing delayed execution and start new one
        seekDelayTimer?.let { _seekHandler.removeCallbacks(it) }
        seekDelayTimer = Runnable {
            _executeAccumulatedSeek()
            _hideAllSeekViews()
            _resetSeekAccumulation()
        }
        _seekHandler.postDelayed(seekDelayTimer!!, SEEK_ACCUMULATION_DELAY_MS)
    }

    /**
     * Execute the accumulated seek operation
     */
    private fun _executeAccumulatedSeek() {
        if (seekAmount > 0 && seekDirection != null) {
            val seekOffset = when (seekDirection) {
                DoubleTapSeekView.SeekDirection.FORWARD -> seekAmount.toDouble()
                DoubleTapSeekView.SeekDirection.BACKWARD -> -seekAmount.toDouble()
                else -> 0.0
            }

            if (seekOffset != 0.0) {
                _programController?.seek(seekOffset, true)
            }

            // Hide only the active seek view (like iOS implementation)
            when (seekDirection) {
                DoubleTapSeekView.SeekDirection.BACKWARD -> leftDoubleTapSeekView.hide()
                DoubleTapSeekView.SeekDirection.FORWARD -> rightDoubleTapSeekView.hide()
                else -> {}
            }
        }

        _resetSeekAccumulation()
    }

    /**
     * Reset seek accumulation state
     */
    private fun _resetSeekAccumulation() {
        seekAmount = 0
        seekDirection = null
        leftDoubleTapSeekView.accumulatedSeconds = 0
        rightDoubleTapSeekView.accumulatedSeconds = 0
        seekDelayTimer?.let { _seekHandler.removeCallbacks(it) }
        seekDelayTimer = null
    }

    /**
     * Hide all seek views
     */
    private fun _hideAllSeekViews() {
        leftDoubleTapSeekView.hide()
        rightDoubleTapSeekView.hide()
    }

    /**
     * Cleanup double-tap seek resources
     */
    private fun _cleanupDoubleTapSeek() {
        seekDelayTimer?.let { _seekHandler.removeCallbacks(it) }
        seekDelayTimer = null
        _hideAllSeekViews()
        _resetSeekAccumulation()
        _exoOverlayFrameLayout?.removeView(leftDoubleTapSeekView)
        _exoOverlayFrameLayout?.removeView(rightDoubleTapSeekView)
        _gestureDetector = null
    }

    /**
     * Update DoubleTapSeekView widths based on current overlay dimensions
     */
    private fun _updateDoubleTapSeekViewWidths(overlayFrameLayout: FrameLayout?) {
        overlayFrameLayout?.viewTreeObserver?.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                overlayFrameLayout.viewTreeObserver?.removeOnGlobalLayoutListener(this)

                val overlayWidth = overlayFrameLayout.width
                if (overlayWidth > 0) {
                    val seekViewWidth = (overlayWidth * 0.33f).toInt()

                    // Update left view width
                    val leftParams = leftDoubleTapSeekView.layoutParams as? FrameLayout.LayoutParams
                    leftParams?.width = seekViewWidth
                    leftDoubleTapSeekView.layoutParams = leftParams

                    // Update right view width
                    val rightParams = rightDoubleTapSeekView.layoutParams as? FrameLayout.LayoutParams
                    rightParams?.width = seekViewWidth
                    rightDoubleTapSeekView.layoutParams = rightParams
                }
            }
        })
    }

    // needed to grab a hold of the double-tap events for seeking
    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        // Always process touch events through our gesture detector
        _gestureDetector?.onTouchEvent(event)

        // Don't intercept - let child views handle the events too
        return false
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Handle gesture detection for double-tap seek
        val gestureHandled = _gestureDetector?.onTouchEvent(event) ?: false

        // Always consume touch events to ensure gesture detection works
        return gestureHandled || super.onTouchEvent(event)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)

        if (changed) {
            // Position double-tap seek zones (33% width on each side)
            val width = right - left
            val height = bottom - top
            val zoneWidth = (width * 0.33f).toInt()

            // Left zone layout
            leftDoubleTapSeekView.layout(0, 0, zoneWidth, height)

            // Right zone layout
            rightDoubleTapSeekView.layout(width - zoneWidth, 0, width, height)
        }
    }

    /**
     * Player API
     */
    val player: BBNativePlayerAPI?
        get() = _api

    /**
     * Delegate for handling API events
     */
    var delegate: BBNativePlayerViewDelegate?
        get() = _delegate
        set(value) { _delegate = value }

    /**
     * Play History Manager
     */
    val playHistoryManager: PlayHistoryManager?
        get() = _playHistoryManager

    /**
     * Setup with json URL
     * * jsonUrl: the json embed URL
     * * options: the options dictionary (optional), options recognized:
	 *	* adsystem_buid: app bundle id
	 *	* adsystem_rdid: resettable device identifier
	 *	* adsystem_idtype: identifier type ("idfa" for iOS, "adid" for Android)
	 *	* adsystem_is_lat: limit ad tracking (Boolean)
	 *	* adsystem_ppid: publisher-provided id
	 *	* allowCollapseExpand: honour collapse / expand requests (Boolean or String)
	 *	* waitForCmp: wait for Consent Management, then setup (Boolean or String)
	 *	* handleConsentManagement: handle Consent Management (Boolean or String) -- needs waitForCmp
	 *	* tagForUnderAgeOfConsent: (Boolean or String)
	 *	* consent_string: default consent string (String)
	 *	* consent_gdprApplies: default GDPR applies (Int)
	 *	* consent_cmpVersion: default CMP version (Int)
	 *	* autoPlay: auto play (Boolean or String), overrides playout setting
	 *	* showDescription: show description (Boolean)
	 *	* forceFullscreenLandscape: force fullscreen/landscape (Boolean)
     *	* overscanAd: overscan ads instead of fitting them in (Boolean)
	 *	* commercials: allow commercials (Boolean or String), overrides playout setting
	 *	* noChromeCast: no ChromeCast support (Boolean or String), overrides playout setting
	 *	* noStats: no stats logging (Boolean), overrides playout setting
     * @param jsonUrl the json embed URL
     * @param options the options dictionary (optional), options recognized:
     */
    fun setupWithJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
        if (options != null) {
            this._options = options
            if (options["noChromeCast"] is String) _noChromeCast = (options["noChromeCast"] as String == "true")
            if (options["noChromeCast"] is Boolean) _noChromeCast = options["noChromeCast"] as Boolean
            if (options["showChromeCastMiniControlsInPlayer"] is String) _showChromeCastMiniControls = (options["showChromeCastMiniControlsInPlayer"] as String == "true")
            if (options["showChromeCastMiniControlsInPlayer"] is Boolean) _showChromeCastMiniControls = options["showChromeCastMiniControlsInPlayer"] as Boolean
            if (_showChromeCastMiniControls) _showChromeCastMiniControls()
            if (options["allowCollapseExpand"] is String) _allowCollapseExpand = (options["allowCollapseExpand"] as String == "true")
            if (options["allowCollapseExpand"] is Boolean) _allowCollapseExpand = options["allowCollapseExpand"] as Boolean
            if (_allowCollapseExpand) _collapse() // NB trick to ensure proper working of startCollapsed!
			if (options["waitForCmp"] is String) _waitForCmp = (options["waitForCmp"] as String == "true")
			if (options["waitForCmp"] is Boolean) _waitForCmp = options["waitForCmp"] as Boolean
			if (options["handleConsentManagement"] is String) _handleConsentManagement = (options["handleConsentManagement"] as String == "true")
			if (options["handleConsentManagement"] is Boolean) _handleConsentManagement = options["handleConsentManagement"] as Boolean
			if (options["tagForUnderAgeOfConsent"] is String) _tagForUnderAgeOfConsent = (options["tagForUnderAgeOfConsent"] as String == "true")
            if (options["tagForUnderAgeOfConsent"] is Boolean) _tagForUnderAgeOfConsent = options["tagForUnderAgeOfConsent"] as Boolean
            if (options["indentTitleView"] == true) {
                val indentPx = (40 * resources.displayMetrics.density).toInt()
                _startScreenView.setTitleIndent(indentPx)
                _pauseScreenView.setTitleIndent(indentPx)
                _endScreenView.setTitleIndent(indentPx)
            }
            if (options["showDescription"] is Boolean) _showDescription = options["showDescription"] as Boolean
            if (options["forceFullscreenLandscape"] is Boolean) _forceFullscreenLandscape = options["forceFullscreenLandscape"] as Boolean
            if (options["overscanAd"] is Boolean) _overscanAd = options["overscanAd"] as Boolean

            if (_overscanAd) {
                if (_playerViewFitme == null) {
                    _playerViewFitme = FrameLayout(context)
                    _resetPlayerViewFitmeLayout()
                    this.removeView(_playerView)
                    _playerViewFitme?.addView(_playerView)
                    _playerViewFitme?.id = View.generateViewId()
                    this.addView(_playerViewFitme)
                }
            } else {
                if (_playerViewFitme != null) {
                    _playerViewFitme?.removeAllViews()
                    _playerViewFitme = null
                    this.addView(_playerView)
                }
            }
        }

		_consentInfo = UserMessagingPlatform.getConsentInformation(this.context)
		Logger.d("BBNativePlayerView", "consentStatus ${_consentInfo?.consentStatus}, privacyOptionsRequirementStatus: ${_consentInfo?.privacyOptionsRequirementStatus}, canRequestAds: ${_consentInfo?.canRequestAds()}")
		if (_consentInfo?.consentStatus == ConsentStatus.OBTAINED) {
			_canRequestAds = (_consentInfo?.canRequestAds() == true)
			_loadJsonUrl(jsonUrl, options)
		} else {
			val consentInfo = _consentInfo
			if (_waitForCmp && consentInfo != null && this.context is AppCompatActivity) {
				val myActivity = (this.context as AppCompatActivity)
				val params = ConsentRequestParameters
					.Builder()
					.setTagForUnderAgeOfConsent(_tagForUnderAgeOfConsent) // NB!
					.build()
				Logger.d("BBNativePlayerView", "going to request consent update")
				consentInfo.requestConsentInfoUpdate(
					myActivity,
					params,
					ConsentInformation.OnConsentInfoUpdateSuccessListener {
						Logger.d("BBNativePlayerView", "OnConsentInfoUpdateSuccessListener")
						Logger.d("BBNativePlayerView", "consentStatus ${consentInfo.consentStatus}, privacyOptionsRequirementStatus: ${consentInfo.privacyOptionsRequirementStatus}, canRequestAds: ${consentInfo.canRequestAds()}")
						if (consentInfo.consentStatus == ConsentStatus.OBTAINED ||
							consentInfo.consentStatus == ConsentStatus.NOT_REQUIRED) {
							_canRequestAds = (consentInfo.canRequestAds() == true)
							_loadJsonUrl(jsonUrl, options)
						} else { // UNKNOWN or REQUIRED
							if (_handleConsentManagement) { // handle CM via UMP Form
								UserMessagingPlatform.loadAndShowConsentFormIfRequired(
									myActivity, // this@MainActivity,
									ConsentForm.OnConsentFormDismissedListener {
											loadAndShowError ->
										Logger.d("BBNativePlayerView", "loadAndShowError ${loadAndShowError?.errorCode}: ${loadAndShowError?.message}")

										// Consent has been gathered.
										Logger.d("BBNativePlayerView", "consentStatus ${consentInfo.consentStatus}, privacyOptionsRequirementStatus: ${consentInfo.privacyOptionsRequirementStatus}, canRequestAds: ${consentInfo.canRequestAds()}")
										_canRequestAds = (consentInfo.canRequestAds() == true)
										_loadJsonUrl(jsonUrl, options)
									}
								)
							} else { // not handle CM (but hope someone else does;)
								val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.context.applicationContext)

								// timeout
								GlobalScope.launch(Dispatchers.Main) {
									val task = async(Dispatchers.IO) {
										sleep(10000)
										sharedPreferences.unregisterOnSharedPreferenceChangeListener(_onSharedPreferenceChangeListener)
										if (_onSharedPreferenceChangeListenerJsonUrl.isNotEmpty()) {
											_canRequestAds = true
											_loadJsonUrl(_onSharedPreferenceChangeListenerJsonUrl, _onSharedPreferenceChangeListenerOptions)
											_onSharedPreferenceChangeListenerJsonUrl = ""
											_onSharedPreferenceChangeListenerOptions = null
										}
									}
									task.await()
								}

								// listen
								_onSharedPreferenceChangeListenerJsonUrl = jsonUrl
								_onSharedPreferenceChangeListenerOptions = options
								sharedPreferences.registerOnSharedPreferenceChangeListener(_onSharedPreferenceChangeListener)
							}
						}
					},
					ConsentInformation.OnConsentInfoUpdateFailureListener {
							requestConsentError: FormError ->
						// Consent gathering failed.
						Logger.d("BBNativePlayerView", "${requestConsentError.errorCode}: ${requestConsentError.message}")
						_canRequestAds = (consentInfo.canRequestAds() == true)
						_loadJsonUrl(jsonUrl, options)
					})
			} else { // don't wait for consent
				_loadJsonUrl(jsonUrl, options)
			}
		}
	}

    fun update () {
        _swipeableListView?.update()
    }

    private fun _setPlayerViewFitmeLayout () {
        val playerViewFitme = _playerViewFitme
        if (playerViewFitme != null) {
            val viewAspectRatio = if (this.height > 0) this.width.toDouble() / this.height.toDouble() else 1.778
            Logger.d("BBNativePlayerView", "_setPlayerViewFitmeLayout viewAspectRatio: $viewAspectRatio")
            val playerViewFitmeLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            playerViewFitmeLayoutParams.gravity = Gravity.CENTER
            val mediaAspectRatio = if (_adMediaHeight > 0) _adMediaWidth.toDouble() / _adMediaHeight.toDouble() else 1.778
            Logger.d("BBNativePlayerView", "_setPlayerViewFitmeLayout mediaAspectRatio: $mediaAspectRatio")
            if (mediaAspectRatio >= viewAspectRatio) {
                val widthM = this.height.toDouble() * mediaAspectRatio
                val marginH = ((this.width.toDouble() - widthM) / 2.0).toInt()
                Logger.d("BBNativePlayerView", "_setPlayerViewFitmeLayout marginH: $marginH")
                playerViewFitmeLayoutParams.setMargins(marginH, 0, marginH, 0) // ltrb
            } else {
                val heightM = this.width.toDouble() / mediaAspectRatio
                val marginV = ((this.height.toDouble() - heightM) / 2.0).toInt()
                Logger.d("BBNativePlayerView", "_setPlayerViewFitmeLayout marginV: $marginV")
                playerViewFitmeLayoutParams.setMargins(0, marginV, 0, marginV) // ltrb
            }
            playerViewFitme.setLayoutParams(playerViewFitmeLayoutParams)
        }
    }

    private fun _resetPlayerViewFitmeLayout () {
        val playerViewFitme = _playerViewFitme
        if (playerViewFitme != null) {
            val playerViewFitmeLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            playerViewFitmeLayoutParams.gravity = Gravity.CENTER
            playerViewFitmeLayoutParams.setMargins(0, 0, 0, 0) // ltrb
            playerViewFitme.setLayoutParams(playerViewFitmeLayoutParams)
        }
    }

	private var _onSharedPreferenceChangeListener = SharedPreferences.OnSharedPreferenceChangeListener {
			prefs, key ->
		if (key == "IABTCF_TCString") {
			Logger.d("BBNativePlayerView", "shared preference consent_string: ${prefs.getString("IABTCF_TCString", "")}")
			_canRequestAds = true
			_loadJsonUrl(_onSharedPreferenceChangeListenerJsonUrl, _onSharedPreferenceChangeListenerOptions)
			_onSharedPreferenceChangeListenerJsonUrl = ""
			_onSharedPreferenceChangeListenerOptions = null
		}
	}

	private fun _loadJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
		val modifiedOptions: MutableMap<String, Any?> = options?.toMutableMap() ?: mutableMapOf()
		modifiedOptions["canRequestAds"] = _canRequestAds
		val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.context.applicationContext)

		val consentString = modifiedOptions["consent_string"] as String? ?: ""
		modifiedOptions["consent_string"] = sharedPreferences.getString("IABTCF_TCString", consentString)
		Logger.d("BBNativePlayerView", "consent_string: ${modifiedOptions["consent_string"]}")

        // see: https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20Consent%20string%20and%20vendor%20list%20formats%20v2.md
        val str = ("${modifiedOptions["consent_string"]}")
            .replace(Regex("""\..*$"""),"") // strip from "." onwards
            .replace("_", "/") // convert URL-safe to standard
            .replace("-", "+") // convert URL-safe to standard
        if (str.isNotEmpty()) {
            try {
                // val bytes: ByteArray = Base64.getDecoder().decode(str) // requires API level 26
                val bytes: ByteArray = android.util.Base64.decode(str, android.util.Base64.DEFAULT)
                val bitString = bytes.fold("") { accu: String, byte: Byte -> // NB byte is signed!
                    accu + (if (byte < 0) byte.toUInt().toString(2).substring(UInt.SIZE_BITS - 8, UInt.SIZE_BITS)
                            else byte.toUInt().toString(2).padStart(8, '0'))
                }
                val bitStringVersion = bitString.substring(0, 6)
                val bitStringPurposesConsent = if (bitStringVersion.toInt(2) >= 2) bitString.substring(152, 152 + 24) else bitString.substring(132, 132 + 24)
                Logger.d("BBNativePlayerView", "bitStringPurposesConsent: ${bitStringPurposesConsent}")
                val bitStringPurposesLITrans = if (bitStringVersion.toInt(2) >= 2) bitString.substring(176, 176 + 24) else bitString.substring(132, 132 + 24)
                Logger.d("BBNativePlayerView", "bitStringPurposesLITrans: ${bitStringPurposesLITrans}")
                // Purpose 7: Measure advertising performance
                modifiedOptions["noStats_commercial"] = bitStringPurposesConsent.get(6) != '1' && bitStringPurposesLITrans.get(6) != '1' // NB index starts at 0!
                Logger.d("BBNativePlayerView", "noStats_commercial: ${modifiedOptions["noStats_commercial"]}")
                // Purpose 8: Measure content performance
                modifiedOptions["noStats_content"] = bitStringPurposesConsent.get(7) != '1' && bitStringPurposesLITrans.get(7) != '1' // NB index starts at 0!
                Logger.d("BBNativePlayerView", "noStats_content: ${modifiedOptions["noStats_content"]}")
            } catch (_: Exception) {}
        }

        val consentGdprApplies = modifiedOptions["consent_gdprApplies"] as Int? ?: 0
		modifiedOptions["consent_gdprApplies"] = sharedPreferences.getInt("IABTCF_gdprApplies", consentGdprApplies)
		Logger.d("BBNativePlayerView", "consent_gdprApplies: ${modifiedOptions["consent_gdprApplies"]}")
		val consentCmpVersion = modifiedOptions["consent_cmpVersion"] as Int? ?: 0
		modifiedOptions["consent_cmpVersion"] = sharedPreferences.getInt("IABTCF_CmpSdkVersion", consentCmpVersion)
		Logger.d("BBNativePlayerView", "consent_cmpVersion: ${modifiedOptions["consent_cmpVersion"]}")

		_embedController?.load(jsonUrl, modifiedOptions)
	}

    /**
     * Call API method
     * * method: the method enumerated by ApiMethod (see: bbnativeshared)
     * * args: the arguments, if any
     * @param method the method enumerated by ApiMethod (see: bbnativeshared)
     * @param args the arguments, if any
     */
    fun callApiMethod(method: ApiMethod, args: Map<String, Any?>?) { // [, callback]
        when (method) {
            ApiMethod.load -> {
                _load(args)
            }
            ApiMethod.play -> {
                _play()
            }
            ApiMethod.pause -> {
                _pause()
            }
            ApiMethod.seek -> {
                _seek(args)
            }
            ApiMethod.updatePlayout -> {
                _updatePlayout(args)
            }
            ApiMethod.autoPlayNextCancel -> {
                _autoPlayNextCancel()
            }
            ApiMethod.expand -> {
                _expand()
            }
            ApiMethod.collapse -> {
                _collapse()
            }
            ApiMethod.enterFullScreen -> {
                _enterFullScreen()
            }
            ApiMethod.exitFullScreen -> {
                _exitFullScreen()
            }
            ApiMethod.handleWidgetEvent -> {
                _handleWidgetEvent(args)
            }
            else -> { }
        }
    }

    /**
     * Set API property
     * * property: the property enumerated by ApiProperty (see: bbnativeshared)
     * * value: the value (nullable)
     * @param property the property enumerated by ApiProperty (see: bbnativeshared)
     * @param value the value (nullable)
     */
    fun setApiProperty(property: ApiProperty, value: Any?) {
        when (property) {
            ApiProperty.volume -> {
                val volume = if (value is Double) value as Double else (if (value is Float) (value as Float).toDouble() else 1.0)
                _masterController?.volume = volume
            }
            ApiProperty.muted -> {
                val muted = if (value is Boolean) value as Boolean else true
                _masterController?.muted = muted // triggers bb_master_(un)mute
            }
            ApiProperty.inView -> {
                val inView = if (value is Boolean) value as Boolean else null
                _inViewController?.setInView(inView)
            }
            ApiProperty.controls -> {
                val controls = if (value is Boolean) value as Boolean else true
                setUseController(controls)
            }
            ApiProperty.relatedItems -> {
                val relatedItems = if (value is List<*>) value as List<ContentItemInterface> else null
                _programController?.relatedItems = relatedItems
            }
            else -> {
                // do nothing
            }
        }
    }

    /**
     * Get API property
     * * property: the property enumerated by ApiProperty (see: bbnativeshared)
     * * returns: the value (nullable)
     * @param property the property enumerated by ApiProperty (see: bbnativeshared)
     * @return value the value (nullable)
     */
    fun getApiProperty(property: ApiProperty): Any? {
        when (property) {
            ApiProperty.phase -> {
                return _phase // toString?
            }
            ApiProperty.state -> {
                return _state // toString?
            }
            ApiProperty.mode -> {
                return _mode
            }
            ApiProperty.playoutData -> {
                return _playout
            }
            ApiProperty.projectData -> {
                return _project
            }
            ApiProperty.clipData -> {
                return _clip
            }
            ApiProperty.volume -> {
                return _masterController?.volume
            }
            ApiProperty.muted -> {
                return _masterController?.muted
            }
            ApiProperty.inView -> { // OBSOLETE?
                return _inViewController?.getInView()
            }
            ApiProperty.isCasting -> {
                return "${_mediaController?.get("headType")}" == HeadType.CHROMECAST.toString()
            }
            ApiProperty.duration -> {
                return _duration // toString?
            }
            ApiProperty.adMediaWidth -> {
                return _adMediaWidth
            }
            ApiProperty.adMediaHeight -> {
                return _adMediaHeight
            }
            else -> {
                return null
            }
        }
    }

    /**
     * OBSOLETE
     */
    fun enable() { // OBSOLETE?
        _enabled = true
    }

    /**
     * OBSOLETE
     */
    fun disable() { // OBSOLETE?
        _enabled = false
    }

    /**
     * Destroy, freeing all memory allocated internally
     */
    fun destroy() {
        __destruct()
    }

    /**
     * Resume Google Cast session
     *   => meant to be called in onResume lifecycle hook
     */
    fun resumeCastSession (): Unit {
        if (_playout?.castButton == "Show" && !_noChromeCast) {
            _gmsCastSession = _gmsSessionManager.currentCastSession
            _mediaController?.setCastSession(_gmsCastSession, false)
            _gmsSessionManager.addSessionManagerListener(_gmsSessionManagerListener, CastSession::class.java)
        }
    }

    /**
     * Pause Google Cast session
     *   => meant to be called in onPause lifecycle hook
     */
    fun pauseCastSession () : Unit {
        if (_playout?.castButton == "Show" && !_noChromeCast) {
            _gmsSessionManager.removeSessionManagerListener(_gmsSessionManagerListener, CastSession::class.java)
            _gmsCastSession = null
            _mediaController?.setCastSession(_gmsCastSession, false)
        }
    }

    /**
     * Set up MediaRoute menu item as Google Cast item
     *
     * @param menu
     * @param mediaRouteMenuItemId
     */
	fun setupCastMenuItem(menu: Menu, mediaRouteMenuItemId: Int) {
        Logger.d("BBNativePlayerView", "setupCastMenuItem menu: ${menu}, menu item id: ${mediaRouteMenuItemId}")
		CastButtonFactory.setUpMediaRouteButton(
			this.context.applicationContext,
			menu,
			mediaRouteMenuItemId
		)
	}

    /**
     * Set up MediaRoute button as Google Cast button
     *
     * @param button
     */
    fun setupCastButton(button: MediaRouteButton?) {
        Logger.d("BBNativePlayerView", "setupCastButton ${button}")
        if (button != null) {
            button.setOnClickListener { view ->
                _mediaController?.set("gms.castButtonClicked", null)
            }
            CastButtonFactory.setUpMediaRouteButton(this.context.applicationContext, button)
        }
    }

    private fun _showChromeCastMiniControls() {
        val controls = _gmsMiniControlsView ?: BBNativePlayer.getChromecastMiniControlsView(this.context)
        _gmsMiniControlsView = controls

        _miniControlsContainerView.addView(controls)
        _miniControlsContainerView.visibility = View.VISIBLE
    }

    private fun _onPhaseChange(data: Map<String, Any?>?) {
        if (data != null && data["phase"] != null) _phase = data["phase"] as Phase
        Logger.d("BBNativePlayerView", "_onPhaseChange phase: ${_phase}")
        _delegate?.didTriggerPhaseChange(this, _phase)

        if (data != null && data["willAutoPlay"] != null) _expectPlaying = data["willAutoPlay"] as Boolean

        _updateScreenVisibility()
    }

    private fun _onModeChange(data: Map<String, Any?>?) {
        if (data != null && data["mode"] != null) _mode = data["mode"] as String
        Logger.d("BBNativePlayerView", "_onModeChange mode: ${_mode}")
        _delegate?.didTriggerModeChange(this, _mode)

        _updateScreenVisibility()
    }

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
    		_ingestPlayoutData(playoutData) // sets _playout
		}
//		Logger.d("BBNativePlayerView", "_onPlayoutChanged playout: ${_playout}")
//		_delegate?.didTriggerPlayoutChanged(this, _playout)

		_update()
	}

	private fun setUseController( value: Boolean ) {
        if ( _playerType != "shorts" ) {  // leave shorts player alone, we want to see the progressbar
            _playerView?.useController = value
        }
        if (!value) {
            this.backArrow?.visibility = View.GONE
        }
    }

    private fun _updateScreenVisibility() {
        Logger.d("BBNativePlayerView", "_updateScreenVisibility phase: ${_phase}, state: ${_state}, mode: ${_mode}, expectPlaying: ${_expectPlaying}, pendingPlay: ${_pendingPlay}")
        _startScreenView.visibility = View.GONE
        _pauseScreenView.visibility = View.GONE
        _endScreenView.visibility = View.GONE
        _commercialScreenView.visibility = View.GONE
        if (_mode == "commercial") {
            _shortsTopControls?.visibility = View.GONE
            _shortsBottomControls?.visibility = View.GONE
            _shortsRightControls?.visibility = View.GONE

            if (_phase == Phase.PRE) {
                _commercialScreenView.visibility = View.VISIBLE
                setUseController(false)
            } else if (_phase == Phase.MAIN) {
                _commercialScreenView.visibility = View.VISIBLE
                setUseController(false)
            } else if (_phase == Phase.POST) {
                _commercialScreenView.visibility = View.VISIBLE
                setUseController(false)
            } else if (_phase == Phase.EXIT) {
                setUseController(false)
            }
            _interactivityController?.hideView()
        } else { // normal
            _shortsTopControls?.visibility = View.VISIBLE
            _shortsBottomControls?.visibility = View.VISIBLE
            _shortsRightControls?.visibility = View.VISIBLE
            _interactivityController?.showView()

            // CHECK FOR EXIT PHASE FIRST - before setting general controller state
            if (_phase == Phase.EXIT) {
                _endScreenView.visibility = View.VISIBLE
                setUseController(true)
                _playerView?.showController()
            } else {
                // General controller state for non-EXIT phases
                setUseController(_showControlBar)
                if (_phase == Phase.INIT && !_expectPlaying && !_pendingPlay) {
                    _startScreenView.visibility = View.VISIBLE
                    // when there is no big playbutton, enable controls but hide them to be able to start the video
                    if (!_showBigPlayButton) {
                        _playerView?.controllerAutoShow = false
                        setUseController(true)
                        _playerView?.hideController()
                    } else {
                        setUseController(false)
                    }
                } else {
                    _playerView?.controllerAutoShow = true
                    if (_phase == Phase.MAIN && _state == State.PAUSED && !_expectPlaying && !_pendingPlay) {
                        _pauseScreenView.visibility = View.VISIBLE
                    } else if (_phase == Phase.MAIN && _state == State.IDLE && _expectPlaying) { // && !_pendingPlay) {
                        // fake start screen for ad-only auto features
                        _startScreenView.visibility = View.VISIBLE
                        setUseController(false)
                    }
                }
            }
        }
    }

    private fun _onStateChange(data: Map<String, Any?>?) {
        if (data != null && data["state"] != null) _state = data["state"] as State
        Logger.d("BBNativePlayerView", "_onStateChange state: ${_state}")
        _delegate?.didTriggerStateChange(this, _state)

        if (_state == State.ERROR) {
            _errorScreenView.visibility = View.VISIBLE
            var reason: String = ""
            if ( data != null && data["reason"] != null ) {
                reason = data["reason"] as String
            }
            // println("Reason: ${ reason }")
            // println("Reason: ${ reason }")
            _delegate?.didFailWithError(this, "Reason: ${ reason }")
        } else {
            _errorScreenView.visibility = View.GONE
        }

        _updateScreenVisibility()
    }

    private fun _onError(data: Map<String, Any?>?) {
        _errorScreenView.visibility = View.VISIBLE
        var reason: String = ""
        if ( data != null && data["msg"] != null ) {
            reason = data["msg"] as String
        }
        _delegate?.didFailWithError(this, "Reason: ${ reason }")
    }

    private fun _load(args: Map<String, Any?>?) {
        if (args != null) {
            var contentId: String? = null
            var contentIndicator = "c"
            var initiator = "external"
            var autoPlay = true
            var seekTo: Number? = null
            var context: Map<String, String?>? = null
            var listOffset: Int? = null
            if (args["clipId"] is String) { contentId = args["clipId"] as String; contentIndicator = "c" }
            if (args["cliplistId"] is String) { contentId = args["cliplistId"] as String; contentIndicator = "l" }
            if (args["projectId"] is String) { contentId = args["projectId"] as String; contentIndicator = "p" }
            if (args["initiator"] is String) initiator = args["initiator"] as String
            if (args["autoPlay"] is String) autoPlay = (args["autoPlay"] as String == "true")
            if (args["autoPlay"] is Boolean) autoPlay = args["autoPlay"] as Boolean
            if (args["seekTo"] is String) seekTo = (args["seekTo"] as String).toDoubleOrNull() // NB ensure something above 0, otherwise weird things happen with the Flash Head..
            if (args["seekTo"] is Number) seekTo = args["seekTo"] as Number // NB ensure something above 0, otherwise weird things happen with the Flash Head..
            if (args["listOffset"] is String) listOffset = (args["listOffset"] as String).toIntOrNull()
            if (args["listOffset"] is Int) listOffset = args["listOffset"] as Int
            if (args["contextCollectionId"] is String || args["contextEntityId"] is String) {
                context = mapOf(
                    "contextCollectionType" to args["contextCollectionType"] as? String,
                    "contextCollectionId" to args["contextCollectionId"] as? String,
                    "contextEntityType" to args["contextEntityType"] as? String,
                    "contextEntityId" to args["contextEntityId"] as? String
                )
            }
            if (contentId != null) {
                _programController?.loadContentById(contentId, contentIndicator, initiator, autoPlay, seekTo, context, listOffset)
            } else if (args["projectData"] != null) {
                mainScope.launch(Dispatchers.Main) {
                    _programController?.loadContent(args["projectData"] as Project, initiator, autoPlay, seekTo, context)
                }
            } else if (args["clipListData"] != null) {
                mainScope.launch(Dispatchers.Main) {
                    _programController?.loadContent(args["clipListData"] as MediaClipList, initiator, autoPlay, seekTo, context, listOffset)
                }
            } else if (args["clipData"] != null) {
                mainScope.launch(Dispatchers.Main) {
                    _programController?.loadContent(args["clipData"] as MediaClip, initiator, autoPlay, seekTo, context)
                }
            } else if (args["clipDataJsonString"] != null) {
                val dataString: String = args["clipDataJsonString"] as String
                if ( dataString != null ) {
                    val clip: MediaClip? = ContentLoader.parseMediaClip(dataString)
                    if ( clip != null ) {
                        mainScope.launch(Dispatchers.Main) {
                            _programController?.loadContent(clip, initiator, autoPlay, seekTo, context, null)
                        }
                    }
                }
            } else if (args["projectDataJsonString"] != null) {
                val project: Project? = ContentLoader.parseProject(args["projectDataJsonString"] as String)
                if ( project != null ) {
                    mainScope.launch(Dispatchers.Main) {
                        _programController?.loadContent(project, initiator, autoPlay, seekTo, context)
                    }
                }
            } else if (args["clipListDataJsonString"] != null) {
                val clipList: MediaClipList? = ContentLoader.parseMediaClipList(args["clipListDataJsonString"] as String)
                if ( clipList != null ) {
                    mainScope.launch(Dispatchers.Main) {
                        _programController?.loadContent(clipList, initiator, autoPlay, seekTo, context, listOffset)
                    }
                }
            } else if (args["adServicesData"] is List<*>) {
                _programController?.loadAdServicesData(args["adServicesData"] as List<AdUnit>, initiator, autoPlay, seekTo, context)
            }
        } else {
            //_programController?.unload()
        }
    }

    private fun _play() {
//        Logger.d("BBNativePlayerView", "_play")
        _expectPlaying = true
        if (_canPlay) {
            _programController?.play()
            _pendingPlay = false
        } else {
            _pendingPlay = true
        }
    }

    private fun _pause() {
//        Logger.d("BBNativePlayerView", "_pause")
        _expectPlaying = false
        _pendingPlay = false
        _programController?.pause()
    }

    private fun _seek(args: Map<String, Any?>?) {
        _expectPlaying = true
        var offsetInSeconds: Number? = null
        var relativeToCurrentTime: Boolean = false
        if (args != null) {
            if (args["offsetInSeconds"] is String) offsetInSeconds = (args["offsetInSeconds"] as String).toDoubleOrNull()
            if (args["offsetInSeconds"] is Number) offsetInSeconds = args["offsetInSeconds"] as Number
            if (args["relativeToCurrentTime"] is Boolean) relativeToCurrentTime = args["relativeToCurrentTime"] as Boolean
        }
        if (offsetInSeconds != null) _programController?.seek(offsetInSeconds, relativeToCurrentTime)
    }

    private fun _updatePlayout(args: Map<String, Any?>?) {
        val playoutDataJsonString = args?.get("playoutDataJsonString") as? String
        if (playoutDataJsonString != null) {
            _playout = ContentLoader.parsePlayout(playoutDataJsonString)
            _eventBus?.trigger(EventName.bb_playout_changed, mapOf("playoutData" to _playout))
        }
    }

    private fun _autoPlayNextCancel() {
        _programController?.autoPlayNextCancel()
    }

    private fun _expand() {
        Logger.d("BBNativePlayerView", "_expand")
        val layoutParams = this.layoutParams
        if (layoutParams != null) {
            Logger.d("BBNativePlayerView", "_expand found layout params")
            _skipOnMeasure = true
            layoutParams.height = if (_expandHeight > 1) _expandHeight else (this.width.toDouble() / _aspectRatio).toInt()
            this.layoutParams = layoutParams
        }
        _skipOnMeasure = false
    }

    private fun _collapse() {
        Logger.d("BBNativePlayerView", "_collapse")
        _expandHeight = height
        Logger.d("BBNativePlayerView", "_collapse stored height: $_expandHeight")

        val layoutParams = this.layoutParams
        if (layoutParams != null) {
            Logger.d("BBNativePlayerView", "_collapse found layout params")
            _skipOnMeasure = true
            layoutParams.height = _collapseHeight
            this.layoutParams = layoutParams
        }
    }

    internal fun _enterFullScreen(forceLandscape: Boolean = false) {
        Logger.d("BBNativePlayerView", "_enterFullScreen")
        val playerView = _playerView
        val fullScreenPlayerView = _fullScreenPlayerView

        if (playerView?.context is AppCompatActivity) {
            val ctx = playerView.context as AppCompatActivity
            // hide system UI
            ctx.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
            ctx.supportActionBar?.hide()
            _savedRequestedOrientation = ctx.getRequestedOrientation()

            // handle force orientation
            if (forceLandscape || _forceFullscreenLandscape) {
                // force-rotate to horizontal
                ctx.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)  //Would like to have the screen in landscape orientation, but can use the sensor to change which direction the screen is facing
            } else if( _mobileRotateOnFullScreenMismatch ) {
                var videoWidth: Float = 0f
                var videoHeight: Float = 0f
                val videoFormat: Format? = _player?.getVideoFormat()
                if (videoFormat != null) {
                    videoWidth = (videoFormat?.width ?: 0).toFloat()
                    videoHeight = (videoFormat?.height ?: 0).toFloat()
                }

                if (videoHeight != 0f && videoWidth != 0f && (videoHeight/videoWidth > 1.0f)) {
                    // force-rotate to vertical
                    ctx.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) // Would like to have the screen in portrait orientation, but can use the sensor to change which direction the screen is facing
                } else { // <= 1.0
                    // force-rotate to horizontal
                    ctx.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) // Would like to have the screen in landscape orientation, but can use the sensor to change which direction the screen is facing
                }
            } else {
                ctx.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR) // Full control to the sensor, also upside-down!
            }
        }

        // Switch Player to FullScreenPlayer variant (Android demands 2 players due to redrawing, which we don't want)
        if (playerView != null && fullScreenPlayerView != null) {
            playerView.visibility = View.GONE
            fullScreenPlayerView.visibility = View.VISIBLE
            if (_forwardingPlayer != null) {
                PlayerView.switchTargetView(_forwardingPlayer as Player, playerView, fullScreenPlayerView)
            }

            // move all views to other view (fullScreenPlayerView)
            _exoOverlayViewsArray.forEach {
                val parentView = it?.parent as ViewGroup
                parentView.removeView(it)
                fullScreenPlayerView.getOverlayFrameLayout()?.addView(it)
            }

            // Update DoubleTapSeekView widths for fullscreen dimensions
            _updateDoubleTapSeekViewWidths(fullScreenPlayerView.getOverlayFrameLayout())
        }

        // Reset chapters and highlights to force redraw
        val chapters = _timeBar?.chapters ?: emptyList<YouTubeChapter>()
        val highlights = _timeBar?.highlights ?: emptyList<YouTubeHighlight>()
        _timeBar = fullScreenPlayerView?.findViewById(R.id.exo_progress)
        _mediaController?.setTimeBar(_timeBar)
        val foregroundColor = _playout?.skin_foregroundColor
        if (foregroundColor is String) {
            try {
                _timeBar?.setPlayedColor(Color.parseColor("#" + foregroundColor as String))
            } catch (_: Exception) {}
        }
        _timeBar?.showScrubber()
        _timeBar?.timeBarPreview(_scrubberPreviewScreenView.timeBarPreview)
        _timeBar?.chapters = chapters
        _timeBar?.highlights = highlights

        _eventBus?.trigger(EventName.fullscreen)
        _eventBus?.trigger(EventName.bb_fullscreen_change, mapOf("fullscreen" to true))
    }

    internal fun _exitFullScreen(forceLandscape: Boolean = false) {
        Logger.d("BBNativePlayerView", "_exitFullScreen")
        val playerView = _playerView
        val fullScreenPlayerView = _fullScreenPlayerView

        if (playerView?.context is AppCompatActivity) {
            val ctx = playerView.context as AppCompatActivity
            ctx.window.decorView.systemUiVisibility = SYSTEM_UI_FLAG_VISIBLE
            ctx.supportActionBar?.show()

            // restore orientation
            val ori = if (_savedRequestedOrientation > -1) _savedRequestedOrientation else ActivityInfo.SCREEN_ORIENTATION_SENSOR
            if (forceLandscape || _forceFullscreenLandscape) {
                ctx.setRequestedOrientation(ori)
            } else if( _mobileRotateOnFullScreenMismatch ) {
                ctx.setRequestedOrientation(ori)
            } else {
                ctx.setRequestedOrientation(ori)
            }
        }

        if (playerView != null && fullScreenPlayerView != null) {
            playerView.visibility = View.VISIBLE
            fullScreenPlayerView.visibility = View.GONE
            if (_forwardingPlayer != null) {
                PlayerView.switchTargetView(_forwardingPlayer as Player, fullScreenPlayerView, playerView)
            }

            // move all views to other view (playerView)
            _exoOverlayViewsArray.forEach {
                val parentView = it?.parent as ViewGroup
                parentView.removeView(it)
                playerView.getOverlayFrameLayout()?.addView(it)
            }

            // Update DoubleTapSeekView widths for normal dimensions
            _updateDoubleTapSeekViewWidths(playerView.getOverlayFrameLayout())
        }

        // Reset chapters and highlights to force redraw
        val chapters = _timeBar?.chapters ?: emptyList<YouTubeChapter>()
        val highlights = _timeBar?.highlights ?: emptyList<YouTubeHighlight>()
        _timeBar = playerView?.findViewById(R.id.exo_progress)
        _mediaController?.setTimeBar(_timeBar)
        val foregroundColor = _playout?.skin_foregroundColor
        if (foregroundColor is String) {
            try {
                _timeBar?.setPlayedColor(Color.parseColor("#" + foregroundColor as String))
            } catch (_: Exception) {}
        }
        _timeBar?.showScrubber()
        _timeBar?.timeBarPreview(_scrubberPreviewScreenView.timeBarPreview)
        _timeBar?.chapters = chapters
        _timeBar?.highlights = highlights

        _endScreenView.setPadding(0,0,0, 0)

        _eventBus?.trigger(EventName.retractfullscreen)
        _eventBus?.trigger(EventName.bb_fullscreen_change, mapOf("fullscreen" to false))
    }

    private fun _handleWidgetEvent(args: Map<String, Any?>?) {
        // Logger.d("BBNativePlayerView", "_handleWidgetEvent")
        if (args != null && args["eventType"] is String) {
            var eventType: EventName? = null
            try {
                eventType = EventName.valueOf(args["eventType"] as String)
            } catch (er: Error) { }
            Logger.d("BBNativePlayerView", "_handleWidgetEvent eventType: $eventType")
            when (eventType) {
                EventName.bb_widget_shown,
                EventName.bb_widget_clicked,
                EventName.bb_widget_custom_analytics -> {
                    _eventBus?.trigger(eventType, args)
                }
                else -> {}
            }
        }
    }

	private fun _update () {
		_playerView?.useController = if (_playerType != "shorts") _showControlBar else false
//		if (_showControlBar) _playerView?.showController() else _playerView?.hideController()
		_auxiliaryPlayerView?.useController = _showControlBar
//		if (_showControlBar) _auxiliaryPlayerView?.showController() else _auxiliaryPlayerView?.hideController()

        val exoCastButton: MediaRouteButton? = _playerView?.findViewById<MediaRouteButton>(R.id.exo_cast_button)
        val exoCastButton2: MediaRouteButton? = _fullScreenPlayerView?.findViewById<MediaRouteButton>(R.id.exo_cast_button)
        if (_showCastButton && !_noChromeCast) {
            if (_gmsCastSession == null) {
                _gmsCastSession = _gmsSessionManager.currentCastSession
                _mediaController?.setCastSession(_gmsCastSession, false)
                _gmsSessionManager.addSessionManagerListener(_gmsSessionManagerListener, CastSession::class.java)
            }
			if (!_exoCastButtonsSetUp) {
				_exoCastButtonsSetUp = true
				this.setupCastButton(exoCastButton)
				this.setupCastButton(exoCastButton2)
			}
			exoCastButton?.visibility = View.VISIBLE
			exoCastButton2?.visibility = View.VISIBLE
		} else {
			exoCastButton?.visibility = View.GONE
			exoCastButton2?.visibility = View.GONE
		}

		// Handle timedisplay settings as normal
		handleTimeDisplaySetting()

		Logger.d("BBNativePlayerView", "playout: ${_playout}")
		Logger.d("BBNativePlayerView", "playout.fullScreen: ${_playout?.fullScreen}")
		Logger.d("BBNativePlayerView", "playout.shareButton: ${_playout?.shareButton}")
		val fullscreenButton: ImageView? = findViewById(R.id.exo_fullscreen_icon)
		var modal = false
		val options = _options
		if (options != null) {
			if (options["modalPlayer"] is Boolean) modal = options["modalPlayer"] as Boolean
		}
		if (!modal) {
			val bgColor = _playout?.bgColor
			if (bgColor is String) {
				try {
					_playerView?.setBackgroundColor(Color.parseColor("#" + bgColor as String))
				} catch (_: Exception) {}
			}
			if (fullscreenButton != null) {
				Logger.d("BBNativePlayerView", "going to set fullscreenButton visibility to: ${_playout?.fullScreen == "Show"}")
				fullscreenButton.visibility = if (_playout?.fullScreen == "Show") View.VISIBLE else View.GONE
			}
		} else {
			_playerView?.setBackgroundColor(Color.parseColor("#000000"))
			if (fullscreenButton != null) {
				fullscreenButton.visibility = View.GONE
			}
		}

		val foregroundColor = _playout?.skin_foregroundColor
		if (foregroundColor is String) {
			try {
				_timeBar?.setPlayedColor(Color.parseColor("#" + foregroundColor as String))
			} catch (_: Exception) {}
		}

		val shareButton: ImageView? = findViewById(R.id.exo_share_icon)
		if (shareButton != null) {
			Logger.d("BBNativePlayerView", "going to set shareButton visibility to: ${_playout?.shareButton == "Show"}")
			shareButton.visibility = View.GONE
			this.hideFullScreenShareButton()
			if (_playout?.shareButton == "Show") {
				shareButton.visibility = View.VISIBLE
				this.showFullScreenShareButton()
			}
		}

		if (_forwardingPlayer == null) {
			_forwardingPlayer = _playerView?.player as ForwardingPlayer?
		}
		_forwardingPlayer?.handlePlayoutSettings(_playerView!!, this)
		// TODO implemented 16x9 playout aspectratio, still need to look at the other responsive playout settings
	}

	private fun _ingestPlayoutData (playoutData: Playout) {
		_playout = playoutData

		if (_playout?.castButton != null) {
			_showCastButton = (_playout?.castButton == "Show")
		}

		if (_playout?.mobileRotateOnFullScreenMismatch != null && _playout?.mobileRotateOnFullScreenMismatch == "true") {
			_mobileRotateOnFullScreenMismatch = true
		}

		if (_playout?.controlBar != null) {
			_showControlBar = !(_playout?.controlBar == "Hide")
		}

		if (_playout?.showBigPlayButton != null) {
			_showBigPlayButton = _playout?.showBigPlayButton == "true"
		}
	}

	private fun _ingestOpts (opts: EmbedObject?) {
		if (opts != null) {
			// embed parameters
			_embedData = opts.embedData

			// playout settings
			if (opts.playoutData is Playout) {
				_ingestPlayoutData(opts.playoutData as Playout)
			}
		}

		_update()
	}

    private fun isViewOverlapping(firstView: View, secondView: View): Boolean {
        val firstPosition = IntArray(2)
        val secondPosition = IntArray(2)

        firstView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        firstView.getLocationOnScreen(firstPosition)
        secondView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        secondView.getLocationOnScreen(secondPosition)

        return firstPosition[0] < secondPosition[0] + secondView.measuredWidth && firstPosition[0] + firstView.measuredWidth > secondPosition[0] && firstPosition[1] < secondPosition[1] + secondView.measuredHeight && firstPosition[1] + firstView.measuredHeight > secondPosition[1]
    }


    private fun handleOverlappingUI(view:View?) {
        // get the two elements we might have to hide
        val timeDivider:TextView? = findViewById<TextView>(R.id.exo_time_devider)
        val durationTime:TextView? = findViewById<TextView>(R.id.exo_duration)

        // get rectangles to check for overlap
        val targetRect = Rect().apply { view?.getGlobalVisibleRect(this) }
        val durationTimeRect = Rect().apply { durationTime?.getGlobalVisibleRect(this) }

        if (targetRect.width() != 0 && durationTimeRect.width() != 0) {
            if (targetRect.intersect(durationTimeRect)) {
                // WE HAVE A OVERLAP
                mainScope.launch(Dispatchers.Main) {
                    timeDivider?.visibility = View.GONE
                    durationTime?.visibility = View.GONE
                }
            } else {
                handleTimeDisplaySetting()
            }
        }
    }

    private fun handleTimeDisplaySetting() {
        val positionTime:TextView? = findViewById<TextView>(R.id.exo_position)
        val timeDivider:TextView? = findViewById<TextView>(R.id.exo_time_devider)
        val durationTime:TextView? = findViewById<TextView>(R.id.exo_duration)
        when(_playout?.timeDisplay) {
            "Hide" -> {
                positionTime?.visibility = View.GONE
                timeDivider?.visibility = View.GONE
                durationTime?.visibility = View.GONE
            }
            "Show remaining time" -> {
                // TODO exo handles time text now
                positionTime?.visibility = View.VISIBLE
                durationTime?.visibility = View.GONE
                timeDivider?.visibility = View.GONE
            }
            "Show progress time" -> {
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.GONE
                durationTime?.visibility = View.GONE
            }
            "Show progress and total time" -> {
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.VISIBLE
                durationTime?.visibility = View.VISIBLE
            }
            else -> {
                // Default: show all time elements
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.VISIBLE
                durationTime?.visibility = View.VISIBLE
            }
        }
    }

    fun View.visibilityChanged(action: (View) -> Unit) {
        this.viewTreeObserver.addOnGlobalLayoutListener {
            val newVis: Int = this.visibility
            if (this.tag as Int? != newVis) {
                this.tag = this.visibility

                // visibility has changed
                action(this)
            }
        }
    }
}
