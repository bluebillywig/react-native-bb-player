package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*

/**
 * @suppress
 */
class InfoView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_project_loaded -> {
				_onProjectLoaded(data)
			}
			EventName.bb_mediaclip_loaded -> {
				_onMediaClipLoaded(data)
			}
			else -> {}
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _titleView: TextView = TextView(this.context)
	private var _titleShown = false
	private var _dateView: TextView = TextView(this.context)
	private var _dateShown = false
	private var _authorCopyrightView: TextView = TextView(this.context)
	private var _authorShown = false

	// settings
	private var _showTitle = false
	private var _showDate = false
	private var _showAuthorCopyright = false
	private var _authorCopyrightAlign = ""
	private var _foregroundColor = 0xFFFFFFFF.toInt()

	// data
	private var _projectData: Project? = null
	private var _copyright: String = ""


	init {
		this.setOrientation(LinearLayout.VERTICAL)
		this.setPadding(16, 16, 16, 32)
		this.setVerticalGravity(Gravity.TOP)
		this.setHorizontalGravity(Gravity.LEFT)

		var typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato_black)

		_titleView.setSingleLine()
		_titleView.textSize = 17F
		_titleView.setTypeface(typeface)
		// see: https://stackoverflow.com/questions/17410195/setshadowlayer-android-api-differences
		_titleView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

		_dateView.setTypeface(typeface)
		_dateView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

		typeface = ResourcesCompat.getFont(context, R.font.lato_bold)

		_authorCopyrightView.setSingleLine()
		_authorCopyrightView.setTypeface(typeface)
		_authorCopyrightView.textSize = 12F
		_authorCopyrightView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
	}

	fun __destruct() {
		this.removeView(_authorCopyrightView)
		this.removeView(_dateView)
		this.removeView(_titleView)
		_projectData = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["showTitle"] is Boolean) _showTitle = settings["showTitle"] as Boolean
		if (settings["showDate"] is Boolean) _showDate = settings["showDate"] as Boolean
		if (settings["showAuthorCopyright"] is Boolean) _showAuthorCopyright = settings["showAuthorCopyright"] as Boolean
		if (settings["authorCopyrightAlign"] is String) _authorCopyrightAlign = settings["authorCopyrightAlign"] as String
		if (settings["foregroundColor"] is Int) _foregroundColor = settings["foregroundColor"] as Int

		_update()
	}

	private fun _onProjectLoaded(data: Map<String, Any?>?) {
		_projectData = if (data != null && data["projectData"] is Project) data["projectData"] as Project else null
		if (_projectData != null) {
			_titleView.text = _projectData!!.title ?: ""
			_dateView.text = _projectData!!.publisheddate ?: ""
			_copyright = _projectData!!.copyright ?: ""
			_authorCopyrightView.text = _projectData!!.author ?: ""
			_authorCopyrightView.append(if (_copyright != "") " | " + _copyright else "")
		}
		_update()
	}

	private fun _onMediaClipLoaded(data: Map<String, Any?>?) {
		val clipData = if (data != null && data["clipData"] is MediaClip) data["clipData"] as MediaClip else null
		if (clipData != null && _projectData == null) {
			_titleView.text = clipData.title ?: ""
			_dateView.text = clipData.publisheddate ?: ""
			_copyright = clipData.copyright ?: ""
			_authorCopyrightView.text = clipData.author ?: ""
			_authorCopyrightView.append(if (_copyright != "") " | " + _copyright else "")
		}
		_update()
	}

	private fun _update() {
		// Always use black shadow since text is white
		val shadowColor = 0xFF000000.toInt()
		val shadowD = 2F

		_titleView.setTextColor(Color.parseColor("#ffffff"))
		_titleView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
		if (_showTitle && _titleView.text != "" && !_titleShown) {
			_titleShown = true
			_titleView.id = View.generateViewId()
			val layoutParams = LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT
			)
			layoutParams.leftMargin = 8
			_titleView.layoutParams = layoutParams
			this.addView(_titleView)
		}

		_dateView.setTextColor(Color.parseColor("#ffffff"))
		_dateView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
		if (_showDate && _dateView.text != "" && !_dateShown) {
			_dateShown = true
			_dateView.id = View.generateViewId()
			this.addView(_dateView)
		}

		_authorCopyrightView.setTextColor(Color.parseColor("#ffffff"))
		_authorCopyrightView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
		if (_showAuthorCopyright && _authorCopyrightView.text != "" && !_authorShown) {
			_authorShown = true
			_authorCopyrightView.id = View.generateViewId()
			val layoutParams = LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT
			)
			layoutParams.topMargin = 16
			layoutParams.leftMargin = 8
			_authorCopyrightView.layoutParams = layoutParams
			this.addView(_authorCopyrightView)
		}
	}
}
