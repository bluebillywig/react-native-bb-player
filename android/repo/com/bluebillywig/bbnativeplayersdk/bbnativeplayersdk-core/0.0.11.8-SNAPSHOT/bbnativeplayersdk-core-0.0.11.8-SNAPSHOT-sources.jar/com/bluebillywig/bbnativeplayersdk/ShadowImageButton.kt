package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.AppCompatImageButton

/**
 * Generic ImageButton with automatic drop shadow support.
 *
 * The shadow automatically matches the shape of whatever drawable is set as the image resource.
 * Works with any vector drawable or bitmap.
 *
 * Shadow appearance can be customized by overriding the shadow properties:
 * - shadowBlurRadius: Blur amount (default: 12f)
 * - shadowOffsetX: Horizontal offset (default: 0f)
 * - shadowOffsetY: Vertical offset (default: 8f)
 * - shadowColor: Shadow color (default: BLACK)
 * - shadowOpacity: Shadow opacity 0-255 (default: 120)
 *
 * @suppress
 */
open class ShadowImageButton @JvmOverloads constructor(
	context: Context,
	attrs: AttributeSet? = null,
	defStyleAttr: Int = 0
): AppCompatImageButton(context, attrs, defStyleAttr) {

	// Shadow configuration properties (can be overridden in subclasses)
	protected open val shadowBlurRadius: Float = 12f
	protected open val shadowOffsetX: Float = 0f
	protected open val shadowOffsetY: Float = 6f
	protected open val shadowColor: Int = Color.BLACK
	protected open val shadowOpacity: Int = 120 // 47% opacity

	private val shadowPaint by lazy {
		Paint().apply {
			isAntiAlias = true
			color = shadowColor
			alpha = shadowOpacity
			maskFilter = BlurMaskFilter(shadowBlurRadius, BlurMaskFilter.Blur.NORMAL)
		}
	}

	init {
		// Disable hardware acceleration for this view to enable blur mask filter
		this.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
	}

	override fun onDraw(canvas: Canvas) {
		// Get the current drawable
		val drawable = drawable ?: run {
			super.onDraw(canvas)
			return
		}

		// Save canvas state
		val saveCount = canvas.save()

		// Calculate drawable bounds accounting for padding
		val contentWidth = width - paddingLeft - paddingRight
		val contentHeight = height - paddingTop - paddingBottom
		val drawableWidth = drawable.intrinsicWidth
		val drawableHeight = drawable.intrinsicHeight

		// Calculate scale to fit drawable within content area while maintaining aspect ratio
		val scale = minOf(
			contentWidth.toFloat() / drawableWidth,
			contentHeight.toFloat() / drawableHeight
		)

		val scaledWidth = (drawableWidth * scale).toInt()
		val scaledHeight = (drawableHeight * scale).toInt()

		// Center the drawable
		val left = paddingLeft + (contentWidth - scaledWidth) / 2
		val top = paddingTop + (contentHeight - scaledHeight) / 2

		// Draw shadow: Create a copy of the drawable and draw it with shadow paint
		val shadowDrawable = drawable.constantState?.newDrawable()?.mutate()
		if (shadowDrawable != null) {
			// Apply shadow offset
			canvas.translate(shadowOffsetX, shadowOffsetY)

			// Set bounds for shadow drawable
			shadowDrawable.setBounds(left, top, left + scaledWidth, top + scaledHeight)

			// Set the color filter to render in shadow color
			shadowDrawable.colorFilter = PorterDuffColorFilter(
				shadowPaint.color,
				PorterDuff.Mode.SRC_IN
			)

			// Draw the shadow drawable with blur
			shadowDrawable.alpha = shadowPaint.alpha
			shadowDrawable.draw(canvas)

			// Reset translation
			canvas.translate(-shadowOffsetX, -shadowOffsetY)
		}

		canvas.restoreToCount(saveCount)

		// Draw the actual drawable (default ImageButton behavior)
		super.onDraw(canvas)
	}
}
