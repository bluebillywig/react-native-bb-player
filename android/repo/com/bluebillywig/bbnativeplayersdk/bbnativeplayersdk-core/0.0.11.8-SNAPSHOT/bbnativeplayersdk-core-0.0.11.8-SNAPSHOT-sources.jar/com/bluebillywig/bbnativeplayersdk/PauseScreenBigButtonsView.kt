package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.controller.ProgramController

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/**
 * @suppress
 */
class PauseScreenBigButtonsView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {

	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	// Note: Forward and backward buttons removed for double-tap seek functionality
	// private var _bigBackwardButtonView = BigButtonView(this.context)
	private var _bigPlayButtonView = BigButtonView(this.context)
	// private var _bigForwardButtonView = BigButtonView(this.context)

	init {
		this.setOrientation(LinearLayout.HORIZONTAL)
		this.setPadding(32, 32, 32, 32)
		this.setVerticalGravity(Gravity.CENTER_VERTICAL)
		this.setHorizontalGravity(Gravity.CENTER)
		this.showDividers = SHOW_DIVIDER_MIDDLE

		val bigButtonLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		// Removed margins since we only have the play button now

		// Forward and backward buttons removed - double-tap seek handles this functionality
		// _bigBackwardButtonView.type = "BACKWARD"
		// _bigBackwardButtonView.setOnClickListener { view -> _programController?.seek(-15.0, true) }

		_bigPlayButtonView.type = "PLAY"
		_bigPlayButtonView.minimumWidth = 180
		_bigPlayButtonView.minimumHeight = 180
		_bigPlayButtonView.layoutParams = bigButtonLayoutParams
		_bigPlayButtonView.setOnClickListener { view -> _programController?.play() }

		// _bigForwardButtonView.type = "FORWARD"
		// _bigForwardButtonView.setOnClickListener { view -> _programController?.seek(15.0, true) }

		// Only add the play button - forward/backward handled by double-tap seek
		_bigPlayButtonView.id = View.generateViewId()
		this.addView(_bigPlayButtonView)
	}

	fun __destruct() {
		// Only remove play button now
		this.removeView(_bigPlayButtonView)
		// this.removeView(_bigForwardButtonView) - removed
		// this.removeView(_bigBackwardButtonView) - removed

		_programController = null
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus = value
			// _bigBackwardButtonView.eventBus = _eventBus - removed
			_bigPlayButtonView.eventBus = _eventBus
			// _bigForwardButtonView.eventBus = _eventBus - removed
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
		}
}
