package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.res.ResourcesCompat
import kotlin.math.floor

//	title & author
//	logo
//	big play button
//	auto play next iface

/**
 * @suppress
 */
class StartScreenView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_media_duration_change -> {
				val duration = if (data != null && data["duration"] is Double) data["duration"] as Double else 0.0
				if ( duration > 0 ) {  // gets thrown in deep negative
					_durationView.text = _formatDuration(duration)
					if (_showStartDuration) {
						_durationView.visibility = View.VISIBLE
					} else {
						_durationView.visibility = View.GONE
					}
				}
			}
			EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
			EventName.bb_softembargotimer_started,
			EventName.bb_softembargotimer_tick -> {
				val embargoActive = _embargoActive
				_embargoActive = true
				if (_embargoActive != embargoActive) _update()
			}
			EventName.bb_softembargotimer_cancelled,
			EventName.bb_softembargotimer_finished -> {
				_embargoActive = false
				_update()
			}
			else -> {}
		}
	}

	/**
	 * @suppress
	 */
	companion object {
//		private fun formatRemainingTime(seconds: Number): String {
//			val parts: string[] = [];
//			val seconds_ = Math.max(Math.ceil(seconds), 0);
//			val { translate } = getContext(contextKey) as SkinStores;
//			val day = translate('day');
//			val days = translate('days');
//			var part: Number
//			part = Math.floor(seconds_ / (3600 * 24)); if (part > 0) { return part + ' ' + (part > 1 ? days : day); }
//			part = Math.floor(seconds_ / 3600) % 24; if (part > 0) { parts.push(("00" + part).slice(-2)); }
//			part = Math.floor(seconds_ / 60) % 60; parts.push(("00" + part).slice(-2))
//			part = Math.floor(seconds_ % 60); parts.push(("00" + part).slice(-2..-1))
//
//			return parts.join(':');
//		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	internal var _bbNativePlayerView: BBNativePlayerView? = null
	private var _logoView: LogoView = LogoView(this.context)
	private var _infoView: InfoView = InfoView(this.context)
	private var _bigButtonsView = StartScreenBigButtonsView(this.context)
	private var _durationView: TextView = TextView(this.context)
	private var _embargoVariantView: EmbargoVariantView = EmbargoVariantView(this.context)
	private var _shareButton: ImageButtonBBAnimated = ImageButtonBBAnimated(this.context)

	// layout
	private var _titleIndentPx: Int = 0

	// settings
	private var _baseUrl = ""
	private var _logoId = ""
	private var _logoAlign = ""
	private var _logoClickUrl = ""
	private var _showTitle = false
	private var _showDate = false
	private var _showAuthorCopyright = false
	private var _authorCopyrightAlign = ""
	private var _copyrightPrefixText = ""
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0xFF000000.toInt()
	private var _showBigPlayButton = true
	private var _showRelatedItems = false // default true?
	private var _useDeeplinkForRelatedItems = false
	private var _showStartDuration = true
	private var _showShareButton = true
	private var _softEmbargoFontColor = 0xFFFFFFFF.toInt()  // white
	private var _softEmbargoText = "Live in"
	private var _softEmbargoTimerHidden = false

	// data
	private var _projectData: Project? = null

	// state
	private var _embargoActive: Boolean = false
	private var _softEmbargoTime: Long = 8L

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!

			_infoView.eventBus = _eventBus
			_bigButtonsView.eventBus = _eventBus
			_embargoVariantView.eventBus = _eventBus
		}

	init {
		val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
		this.layoutParams = layoutParams

		_logoView.minimumHeight = 150
		_logoView.id = View.generateViewId()
		this.addView(_logoView)
		_infoView.id = View.generateViewId()
		this.addView(_infoView)
		_bigButtonsView.visibility = View.GONE
		_bigButtonsView.id = View.generateViewId()
		this.addView(_bigButtonsView)
		_embargoVariantView.id = View.generateViewId()
		this.addView(_embargoVariantView)

		_durationView.visibility = View.GONE
		_durationView.setGravity(Gravity.CENTER)
		_durationView.setTextDirection(TEXT_DIRECTION_RTL)
		_durationView.setPadding(0, 0, 0, 0)
		_durationView.textSize = 14F
		_durationView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_durationView.id = View.generateViewId()

		_durationView.setBackgroundResource(R.drawable.duration_rounded_corners)
		val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato_black)
		_durationView.setTypeface(typeface)
		_durationView.text = "00:00"

		val r: Int = Color.red(_foregroundColor)
		val g: Int = Color.green(_foregroundColor)
		val b: Int = Color.blue(_foregroundColor)
		val shadowColor = if (r + g + b < 384) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
		val shadowD = if (r + g + b < 384) -2F else 2F

		_durationView.setTextColor(_foregroundColor)
		_durationView.setShadowLayer(2F, shadowD, shadowD, shadowColor)

		this.addView(_durationView)

		// Setup share button (matching ExoPlayer share button)
		_shareButton.visibility = View.GONE
		_shareButton.setImageResource(R.drawable.bb_icon_share)
		_shareButton.setBackgroundResource(R.drawable.bb_button)
		_shareButton.id = View.generateViewId()
		_shareButton.setOnClickListener {
			_bbNativePlayerView?._handleShareButton()
		}
		this.addView(_shareButton)

		// Set up constraints once
		post {
			_setupConstraints()
		}
	}

	private fun _setupConstraints() {
		val constraintSet = ConstraintSet()
		constraintSet.clone(this)

		// Position info view (top left, with indent)
		constraintSet.constrainWidth(_infoView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.constrainHeight(_infoView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_infoView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, _titleIndentPx)
		constraintSet.connect(_infoView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 128)
		constraintSet.connect(_infoView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)

		// Position logo view (top left)
		constraintSet.constrainWidth(_logoView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.constrainHeight(_logoView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_logoView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_logoView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)

		// Position big buttons view (centered)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)

		// Position embargo variant view (centered)
		constraintSet.connect(_embargoVariantView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_embargoVariantView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
		constraintSet.connect(_embargoVariantView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_embargoVariantView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)

		// Position duration view (centered, offset below big buttons when visible)
		constraintSet.constrainWidth(_durationView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.constrainHeight(_durationView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_durationView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, 20)
		constraintSet.connect(_durationView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 20)
		constraintSet.connect(_durationView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_durationView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)
		val verticalBias = if (!_showBigPlayButton && _showStartDuration) 0.5f else 0.65f
		constraintSet.setVerticalBias(_durationView.id, verticalBias)

		// Position share button (top right)
		constraintSet.constrainWidth(_shareButton.id, 40.dpToPx(context))
		constraintSet.constrainHeight(_shareButton.id, 40.dpToPx(context))
		constraintSet.connect(_shareButton.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 5.dpToPx(context))
		constraintSet.connect(_shareButton.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 5.dpToPx(context))

		constraintSet.applyTo(this)
	}

	private fun Int.dpToPx(context: Context): Int {
		return (this * context.resources.displayMetrics.density).toInt()
	}

	fun setTitleIndent(px: Int) {
		_titleIndentPx = px
		post { _setupConstraints() }
	}

	fun __destruct() {
		this.removeView(_bigButtonsView)
		this.removeView(_infoView)
		this.removeView(_logoView)
		_projectData = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
			_bigButtonsView.programController = _programController
		}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
		_update()
	}

	private fun _update() {
		// logo
		if (_baseUrl != "" && _logoId != "") {
			_logoView.url =
				_baseUrl + "/mediaclip/" + _logoId + "/pthumbnail/64/64.png?scalingMode=cover"
			_logoView.visibility = View.VISIBLE
		} else {
			_logoView.visibility = View.INVISIBLE
		}

		// info view
		_infoView.updateSettings(mapOf(
			"showTitle" to _showTitle,
			"showDate" to _showDate,
			"showAuthorCopyright" to _showAuthorCopyright,
			"authorCopyrightAlign" to _authorCopyrightAlign,
			"copyrightPrefixText" to _copyrightPrefixText,
			"foregroundColor" to _foregroundColor
		))

		if (_embargoActive) {
			_embargoVariantView.updateSettings(mapOf(
				"fontColor" to _softEmbargoFontColor,
				"text" to _softEmbargoText,
				"timerHidden" to _softEmbargoTimerHidden
			))
			_embargoVariantView.visibility = View.VISIBLE
			_bigButtonsView.visibility = View.GONE
		} else {
			_embargoVariantView.visibility = View.GONE
			// big button
			if (_showBigPlayButton) {
				_bigButtonsView.visibility = View.VISIBLE
			} else {
				_bigButtonsView.visibility = View.GONE
			}
		}

		// Update duration label position based on big play button visibility
		_updateDurationLabelPosition()

		// share button
		if (_showShareButton) {
			_shareButton.visibility = View.VISIBLE
		} else {
			_shareButton.visibility = View.GONE
		}
	}

	private fun _updateDurationLabelPosition() {
		post { _setupConstraints() }
	}

	private fun _ingestPlayoutData (playout: Playout) {
		if (playout.logoId != null) _logoId = playout.logoId as String
		if (playout.logoAlign != null) _logoAlign = playout.logoAlign as String
		if (playout.logoClickUrl != null) _logoClickUrl = playout.logoClickUrl as String

		if (playout.title != null) _showTitle = playout.title.equals("Show", true)
		if (playout.date != null) _showDate = playout.date.equals("Show", true)
		if (playout.authorCopyright != null) _showAuthorCopyright = playout.authorCopyright.equals("Show", true)
		if (playout.authorCopyrightAlign != null) _authorCopyrightAlign = playout.authorCopyrightAlign as String
		if (playout.authorCopyrightPrefixText != null) _copyrightPrefixText = playout.authorCopyrightPrefixText as String
		try {
			if (playout.skin_foregroundColor != null) _foregroundColor = Color.parseColor("#" + playout.skin_foregroundColor as String)
			if (playout.skin_backgroundColor != null) _backgroundColor = Color.parseColor("#" + playout.skin_backgroundColor as String)
		} catch (er: Exception) {}

		if (playout.showBigPlayButton != null) _showBigPlayButton = playout.showBigPlayButton == "true"
		if (playout.relatedItems != null) _showRelatedItems = playout.relatedItems == "Show"
		if (playout.useDeeplinkForRelatedItems != null) _useDeeplinkForRelatedItems = playout.useDeeplinkForRelatedItems == "true"

		if (playout.showStartDuration != null) _showStartDuration = playout.showStartDuration.equals("true", true)
		if (playout.shareButton != null) _showShareButton = playout.shareButton == "Show"

		try {
			if (playout.softEmbargoFontColor != null) _softEmbargoFontColor = Color.parseColor("#" + playout.softEmbargoFontColor as String)
		} catch (er: Exception) {}
		if (playout.softEmbargoText != null) _softEmbargoText = playout.softEmbargoText as String
		if (playout.softEmbargoTimerHidden != null) _softEmbargoTimerHidden = playout.softEmbargoTimerHidden == "true"
	}

	private fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			if (opts.publicationData != null) {
				val publication = opts.publicationData as Publication // Smart cast is impossible...
				if (!publication.baseurl.isNullOrEmpty()) _baseUrl = publication.baseurl as String
			}

			// embed parameters
			if (opts.embedData != null) {
				val embedData = opts.embedData as EmbedData // Smart cast is impossible...
				if (!embedData.baseurl.isNullOrEmpty()) _baseUrl = embedData.baseurl as String
			}

			// playout settings
			if (opts.playoutData is Playout) {
				_ingestPlayoutData(opts.playoutData as Playout)
			}
			_update()
		}
	}

	private fun _formatDuration(value: Any): String {
		var res = "00:00"

		var duration: Double? = null
		try {
			if (value is Int) duration = value.toDouble()
			if (value is Long) duration = value.toDouble()
			if (value is Float) duration = value.toDouble()
			if (value is Double) duration = value
			if (value is String) duration = value.toDouble()
		} catch (er: Exception) {}

		if (duration != null) {
			val hh = (floor(duration / 3600)).toInt(); duration %= 3600
			val mm = (floor(duration / 60)).toInt(); duration %= 60
			val ss = (floor(duration)).toInt()
			res = if (hh > 0) ("%02d:%02d:%02d").format(hh, mm, ss) else ("%02d:%02d").format(mm, ss)
		}

		return res
	}
}
