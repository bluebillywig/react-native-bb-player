package com.bluebillywig.bbnativeplayersdk

// import com.bluebillywig.bbnativeshared.controller.ProgramController

import android.content.Context
import android.graphics.*
import android.os.AsyncTask
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import java.net.URL
import coil3.*
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.util.CoilUtils

/**
 * @suppress
 */
class SwipeableListItemView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) {
	internal var _posterView: ImageView = ImageView(this.context)

	// resources
	private var _listView: SwipeableListView? = null

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0x33000000.toInt()

	// state
	internal var pos: Int = -1

	init {
		val layoutPs = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		this.layoutParams = layoutPs
		//this.setBackgroundColor(_backgroundColor)

		_posterView.setBackgroundResource(R.drawable.rounded_thumbnail)
		_posterView.clipToOutline = true
		_posterView.isClickable = false
		_posterView.id = View.generateViewId()
		this.addView(_posterView)

		this.isClickable = true
		this.setOnClickListener {
			_listView?.togglePlayPause()
		}

		_update()
	}

	fun __destruct() {
		this.removeAllViews()
	}

	var listView: SwipeableListView?
		get() = _listView
		set(value) {
			_listView = value
		}

	fun updateSettings(settings: Map<String, Any?>) {
		val useThumbnailsInFullscreen = settings["useThumbnailsInFullscreen"] as? Boolean ?: false
		if (useThumbnailsInFullscreen) {
			_posterView.scaleType = ImageView.ScaleType.CENTER_CROP
		}

		_update()
	}

	fun updateContent(content: Map<String, Any?>) {
		if (content["posterUrl"] is String) {
			DownLoadImageTask(_posterView)
				.execute(content["posterUrl"] as String)
		} else if (content["posterUrl"] == null) {
			_posterView.setImageDrawable(null)
		}

		_update() // OBSOLETE?!?
	}

	private fun _update() {
		// nothing
	}
}
