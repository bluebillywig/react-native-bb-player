package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.bluebillywig.bbnativeshared.KMMTimer
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.State
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import com.google.ads.interactivemedia.v3.api.FriendlyObstruction
import com.google.ads.interactivemedia.v3.api.FriendlyObstructionPurpose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/**
 * @suppress
 */
class CommercialScreenView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface, FriendlyObstruction {
	// EventListenerInterface::onEvent
	@RequiresApi(Build.VERSION_CODES.N)
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
			EventName.bb_adunit_initialized -> {
				if (data != null && data["adUnitSettings"] is MutableMap<*,*>) {
					val adUnitSettings = data["adUnitSettings"] as MutableMap<String, String?>
					if (adUnitSettings["commercialMuteButton"] != null) _commercialMuteButton = adUnitSettings["commercialMuteButton"]
					if (adUnitSettings["commercialPauseButton"] != null) _commercialPauseButton = adUnitSettings["commercialPauseButton"]
					if (adUnitSettings["commercialAdIcon"] != null) _commercialAdIcon = adUnitSettings["commercialAdIcon"]
					if (adUnitSettings["commercialProgressBar"] != null) _commercialProgressBar = adUnitSettings["commercialProgressBar"]
					try {
						if (adUnitSettings["commercialProgressBarColor"] != null) _foregroundColor = Color.parseColor("#" + adUnitSettings["commercialProgressBarColor"] as String)
					} catch (er: Exception) {}
					_update()
				}
			}
			EventName.bb_state_change -> {
				if (data != null && data["state"] is State) {
					if (data["state"] == State.PLAYING) {
						_pauseButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_pause))
						// fallback commercial controls
						if (_commercialPauseButton != "true") {
							_pauseButtonView.visibility = View.GONE
						}
					} else {
						_pauseButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_play))
						// fallback commercial controls
						if (_commercialPauseButton != "true" && _adStarted) {
							_pauseButtonView.visibility = View.VISIBLE
						}
					}
				}
			}
			EventName.bb_master_mute -> {
				_muteButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeoff))
				// fallback commercial controls
				if (_commercialMuteButton != "true" && _adStarted) {
					_muteButtonView.visibility = View.VISIBLE
				}
			}
			EventName.bb_master_unmute -> {
				_muteButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeon))
				// fallback commercial controls
				if (_commercialMuteButton != "true") {
					_muteButtonView.visibility = View.GONE
				}
			}
			EventName.adStarted -> {
				_adStarted = true
				if (data != null && data["adPodInfo"] is Map<*,*>) {
					val adPodInfo = data["adPodInfo"] as Map<String,Any?>
					if (adPodInfo["adPosition"] is Int && adPodInfo["totalAds"] is Int) {
						val adPosition = adPodInfo["adPosition"] as Int
						val totalAds = adPodInfo["totalAds"] as Int
						val dot = "&#00B7"
						//U+00B7
						if (totalAds > 0) {
							_adNOfMView.text = "$adPosition of $totalAds"
							_adNOfMView.visibility = View.GONE
						} else {
							_adNOfMView.text = ""
							_adNOfMView.visibility = View.GONE
						}
						_dotView.visibility = if (totalAds > 0) View.GONE else View.GONE
					}
				}
			}
			EventName.adLoaded -> {
				println("***** CommercialScreenView - EventName.adLoaded")
				_pauseButtonView.visibility = if (_commercialPauseButton == "true") View.VISIBLE else View.GONE
				_muteButtonView.visibility = if (_commercialMuteButton == "true") View.VISIBLE else View.GONE
				_progressBarView.visibility = if (_commercialProgressBar == "true") View.VISIBLE else View.GONE
				_progressBarBGView.visibility = if (_commercialProgressBar == "true") View.VISIBLE else View.GONE
				_adIndicatorView.visibility = if (_commercialAdIcon == "true") View.VISIBLE else View.GONE
				_bgGradientView.visibility = View.VISIBLE
			}
			EventName.adSkipped, EventName.adComplete, EventName.allAdsCompleted -> {
				_adStarted = false
				_skipButtonView.visibility = View.GONE
				_currentAdProgressSeconds = -1.0
			}
			EventName.adContentPauseReq -> {
				_wasMuted = _playerAPI?.muted
			}
			EventName.adContentResumeReq -> {
				_playerAPI?.muted = _wasMuted
			}
			EventName.adProgress -> {
				if (data != null && data["adPosition"] != null && data["adDuration"] != null) {
					val position = data["adPosition"].toString().toDouble()
					val duration = data["adDuration"].toString().toDouble()
					_adCountDown.text = _formatDuration((duration - position) / 1000)

					if (this._skipOffset >= 0) {
						this._currentAdProgressSeconds = position / 1000
						this._updateSkipOffset()
					}
					val constraintSet = ConstraintSet()
					constraintSet.clone(this)
					val w = (this.width * (position/duration))
					constraintSet.constrainWidth(_progressBarView.getId(), w.toInt() )
					constraintSet.applyTo(this)
					this.requestLayout()
				}
			}
			EventName.bb_adsystem_initialized -> {
				if (data != null) {
					if (data["skipOffset"] != null) {
						this._skipOffset = (data["skipOffset"] as String).toDouble()
					}
					if (data["skipCounterText"] != null) {
						this._skipCounterText = data["skipCounterText"] as String
					}
					if (data["skipButtonText"] != null) {
						this._skipButtonText = data["skipButtonText"] as String
					}
				}
			}
			else -> {}
		}
	}

	// FriendlyObstruction::getView
	override fun getView(): View {
		return this
	}
	// FriendlyObstruction::getPurpose
	override fun getPurpose(): FriendlyObstructionPurpose {
		return FriendlyObstructionPurpose.VIDEO_CONTROLS
	}
	// FriendlyObstruction::getDetailedReason
	override fun getDetailedReason(): String {
		return "mute unmute play pause skip buttons"
	}

	private var _eventBus: EventBusInterface? = null
	private var _playerAPI: BBNativePlayerAPI? = null

	private val _controls = LinearLayout(this.context)
	private val _innerControls = LinearLayout(this.context)

	private var _muteButtonView = ImageButton(this.context)
	private var _pauseButtonView = ImageButton(this.context)
	private var _adIndicatorView = ImageView(this.context)
	private var _adNOfMView = TextView(this.context)
	private var _dotView = ImageView(this.context)
	private var _adCountDown = TextView(this.context)
	private val _bgGradientView = View(this.context)
	private val _progressBarView = View(this.context)
	private val _progressBarBGView = View(this.context)

	// settings
	private var _commercialMuteButton: String? = null
	private var _commercialPauseButton: String? = null
	private var _commercialAdIcon: String? = null
	private var _commercialProgressBar: String? = null
	private var _foregroundColor: Int = 0xFFFFFFFF.toInt()

	// state
	private var _wasMuted: Boolean? = null
	private var _adStarted: Boolean = false

	//custom ad skip
	private var _skipButtonView = Button(this.context)
	private var _skipOffset: Double = -1.0
	private var _skipCounterText:String = ""
	private var _skipButtonText:String = ""
	private val _mainScope = MainScope()
	private var _programController: ProgramController? = null
	private var _currentAdProgressSeconds: Double = -1.0

	init {
		val set = ConstraintSet()

		_controls.setId(View.generateViewId())
		_controls.setOrientation(LinearLayout.HORIZONTAL)
		_controls.setVerticalGravity(Gravity.CENTER_VERTICAL)
		_controls.setHorizontalGravity(Gravity.LEFT)
		_controls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
		this.addView(_controls)

		_innerControls.setId(View.generateViewId())
		_innerControls.setPadding(24, 0, 24, 0)
		_innerControls.setOrientation(LinearLayout.HORIZONTAL)
		_innerControls.setVerticalGravity(Gravity.CENTER)
		_innerControls.setHorizontalGravity(Gravity.LEFT)
		_innerControls.showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
//		_innerControls.setBackgroundResource(R.drawable.ad_controls_round_corners)
//		_innerControls.clipToOutline = true
//		_innerControls.setBackgroundColor(Color.parseColor("#99000000"))

		set.clone(this)

		set.constrainHeight(_controls.id, 60)
		set.connect(_controls.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 50)
		set.connect(_controls.id, ConstraintSet.LEFT, ConstraintSet.PARENT_ID, ConstraintSet.LEFT, 24)

		val buttonLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		buttonLayoutParams.leftMargin = 0
		buttonLayoutParams.rightMargin = 25
		buttonLayoutParams.topMargin = 0
		buttonLayoutParams.bottomMargin = 0
		val textLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		textLayoutParams.leftMargin = 0
		textLayoutParams.rightMargin = 16
		textLayoutParams.topMargin = 0
		textLayoutParams.bottomMargin = 14

		_pauseButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_pause))
		_pauseButtonView.minimumWidth = 96
		_pauseButtonView.minimumHeight = 80
		_pauseButtonView.layoutParams = buttonLayoutParams
		_pauseButtonView.setOnClickListener { view ->
			if (_playerAPI?.state == State.PLAYING) {
				_playerAPI?.pause()
			} else {
				_playerAPI?.play()
			}
		}
		_pauseButtonView.visibility = View.GONE
		_pauseButtonView.id = View.generateViewId()
		_controls.addView(_pauseButtonView)

		_muteButtonView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_volumeon))
		_muteButtonView.minimumWidth = 96
		_muteButtonView.minimumHeight = 80
		_muteButtonView.layoutParams = buttonLayoutParams
		_muteButtonView.setOnClickListener { view ->
			if (_playerAPI?.muted == true) {
				_playerAPI?.muted = false
			} else {
				_playerAPI?.muted = true
			}
		}
		_muteButtonView.visibility = View.GONE
		_muteButtonView.id = View.generateViewId()
		_controls.addView(_muteButtonView)
		_controls.addView(_innerControls)


		_adIndicatorView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_ad))
		_adIndicatorView.minimumWidth = 80
		_adIndicatorView.minimumHeight = 80
		_adIndicatorView.layoutParams = buttonLayoutParams
		_adIndicatorView.visibility = View.GONE
		_adIndicatorView.id = View.generateViewId()
		_innerControls.addView(_adIndicatorView)

		_adNOfMView.text = ""
		_adNOfMView.minimumWidth = 80
		_adNOfMView.minimumHeight = 80
		_adNOfMView.textSize = 14F
		_adNOfMView.setTypeface(ResourcesCompat.getFont(context, R.font.lato))
		_adNOfMView.layoutParams = textLayoutParams
		_adNOfMView.setGravity(Gravity.BOTTOM)
		_adNOfMView.id = View.generateViewId()
		_innerControls.addView(_adNOfMView)

		val dotLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		dotLayoutParams.leftMargin = 0
		dotLayoutParams.rightMargin = 16
		dotLayoutParams.topMargin = 0
		dotLayoutParams.bottomMargin = 3

		_dotView.setImageDrawable(ContextCompat.getDrawable(this.context, R.drawable.bb_icon_dot))
		_dotView.minimumWidth = 10
		_dotView.minimumHeight = 10
		_dotView.layoutParams = dotLayoutParams
		_dotView.visibility = View.GONE
		_dotView.id = View.generateViewId()
		_innerControls.addView(_dotView)

		_adCountDown.text = ""
		_adCountDown.minimumWidth = 80
		_adCountDown.minimumHeight = 80
		_adCountDown.textSize = 14F
		_adCountDown.setTypeface(ResourcesCompat.getFont(context, R.font.lato))
		_adCountDown.layoutParams = textLayoutParams
		_adCountDown.setGravity(Gravity.BOTTOM)
		_adCountDown.visibility = View.GONE
		_adCountDown.id = View.generateViewId()
		_innerControls.addView(_adCountDown)

		_progressBarBGView.setId(View.generateViewId())
		_progressBarBGView.setBackgroundColor(Color.parseColor("#80ffffff"))
		_progressBarBGView.visibility = View.GONE
		this.addView(_progressBarBGView)

		set.constrainHeight(_progressBarBGView.getId(), 8)
		set.constrainWidth(_progressBarBGView.getId(), ConstraintSet.MATCH_CONSTRAINT_SPREAD)
		set.connect(_progressBarBGView.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0)

		_progressBarView.setId(View.generateViewId())
		_progressBarView.setBackgroundColor(Color.parseColor("#ffff0000"))
		_progressBarView.visibility = View.GONE
		this.addView(_progressBarView)

		set.constrainHeight(_progressBarView.getId(), 8)
		set.constrainWidth(_progressBarView.getId(), 1)
		set.connect(_progressBarView.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0)

		val colors = intArrayOf(Color.parseColor("#00000000"), Color.parseColor("#80000000"))
		val gd = GradientDrawable(
			GradientDrawable.Orientation.TOP_BOTTOM, colors
		)
		gd.setCornerRadius(0f)
		_bgGradientView.background = gd


		_bgGradientView.setId(View.generateViewId())
		//_bgGradientView.setBackgroundColor(Color.parseColor("#80ffffff"))
		_bgGradientView.visibility = View.GONE
		addView(_bgGradientView, 0)

		set.constrainHeight(_bgGradientView.getId(), 180)
		set.constrainWidth(_bgGradientView.getId(), ConstraintSet.MATCH_CONSTRAINT_SPREAD)
		set.connect(_bgGradientView.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0)

		// Custom ad skip button
		val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato)
		val foregroundColor = 0xFFFFFFFF.toInt()

		_skipButtonView?.setId(View.generateViewId())
		_skipButtonView?.setTextColor(foregroundColor)
		_skipButtonView?.setTypeface(typeface, Typeface.BOLD)
		_skipButtonView?.isAllCaps = false
		_skipButtonView?.maxLines = 1
		_skipButtonView?.ellipsize = TextUtils.TruncateAt.END
		_skipButtonView?.setBackgroundResource(R.drawable.ad_skip_round_corners)
		_skipButtonView.text = _skipCounterText
		_skipButtonView.setOnClickListener { view ->
			_handleSkipButton()
		}
		this.addView(_skipButtonView)


		set.constrainHeight(_skipButtonView.getId(), 70)
		set.connect(_skipButtonView.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 150)
		set.connect(_skipButtonView.id, ConstraintSet.RIGHT, ConstraintSet.PARENT_ID, ConstraintSet.RIGHT, 10)

		set.applyTo(this)
		_skipButtonView.visibility = View.GONE

		_update()
	}

	internal fun setProgramcontroller(programController: ProgramController?) {
		this._programController = programController
	}

	private fun _handleSkipButton() {
		if (this._skipOffset >= 0 && this._currentAdProgressSeconds >= this._skipOffset) {
			this._programController?.skipAd()
		}
	}

	private fun _updateSkipOffset() {
		_skipButtonView.visibility = View.VISIBLE
		val skipDiff = _skipOffset - _currentAdProgressSeconds
		val skipText = max(0, ceil(skipDiff).toInt())
		_skipButtonView.text = "$_skipCounterText $skipText"

		if (skipDiff <= 0) {
			_skipButtonView.text = _skipButtonText
		}
	}

	fun __destruct() {
		this.removeView(_muteButtonView)
		this.removeView(_pauseButtonView)
		_playerAPI = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
		_programController = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var playerAPI: BBNativePlayerAPI?
		get() = _playerAPI
		set(value) {
			_playerAPI = value
		}

	override fun getVisibility (): Int {
		return super.getVisibility()
	}

	override fun setVisibility (value: Int) {
		super.setVisibility(value)
		_playerAPI?.controls = (value != View.VISIBLE) // NB!
	}
	private fun _update() {
		_pauseButtonView.setBackgroundColor(0x00000000)

		_muteButtonView.setBackgroundColor(0x00000000)

		_progressBarView.setBackgroundColor(_foregroundColor)

		_adIndicatorView.setColorFilter(_foregroundColor)

		_adNOfMView.setTextColor(0xFFFFFFFF.toInt())
		_adNOfMView.setShadowLayer(2F, 2F, 2F, 0xFF000000.toInt())

		_adCountDown.setTextColor(0xFFFFFFFF.toInt())
		_adCountDown.setShadowLayer(2F, 2F, 2F, 0xFF000000.toInt())
	}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
		_update()
	}

	private fun _ingestPlayoutData(playout: Playout) {
		if (playout.commercialMuteButton != null) _commercialMuteButton = playout.commercialMuteButton
		if (playout.commercialPauseButton != null) _commercialPauseButton = playout.commercialPauseButton
		if (playout.commercialAdIcon != null) _commercialAdIcon = playout.commercialAdIcon
		try {
			if (playout.skin_foregroundColor != null) _foregroundColor = Color.parseColor("#" + playout.skin_foregroundColor as String)
			if (playout.commercialProgressBarColor != null) _foregroundColor = Color.parseColor("#" + playout.commercialProgressBarColor as String)
		} catch (er: Exception) {}
		if (playout.commercialProgressBar != null) _commercialProgressBar = playout.commercialProgressBar
	}

	private fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			// playout settings
			if (opts.playoutData is Playout) {
				_ingestPlayoutData(opts.playoutData as Playout)
			}
			_update()
		}
	}

	private fun _formatDuration(value: Any): String {
		var res = "00:00"

		var duration: Double? = null
		try {
			if (value is Int) duration = value.toDouble()
			if (value is Long) duration = value.toDouble()
			if (value is Float) duration = value.toDouble()
			if (value is Double) duration = value
			if (value is String) duration = value.toDouble()
		} catch (er: Exception) {}

		if (duration != null) {
			val hh = (floor(duration / 3600)).toInt(); duration %= 3600
			val mm = (floor(duration / 60)).toInt(); duration %= 60
			val ss = (ceil(duration)).toInt()
			res = if (hh > 0) ("%02d:%02d:%02d").format(hh, mm, ss) else ("%02d:%02d").format(mm, ss)
		}

		return res
	}
}
