package com.bluebillywig.bbnativeplayersdk

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

/**
 * @suppress
 */
class SettingsBottomSheetDialog : BottomSheetDialogFragment(), EventListenerInterface  {

    private var _eventBus: EventBusInterface? = null
    private var _programController: ProgramController? = null

    private var _chapters: List<Chapter>? = null
    private var _highlights: List<Highlight>? = null
    private var _audioTracks: List<Audiotrack>? = null
    private var _subtitles: List<Subtitle>? = null
    private var _qualities: List<Quality>? = null
    private var _videoTracks: List<VideoTrack>? = null

    private var _currentTime: String = "0.0"
    private var _currentChapterLabel: String = "..."
    private var _currentSubtitleLabel: String = "off"
    private var _currentAudiotrackLabel: String = "original"
    private var _currentQualityLabel: String = "auto"
    private var _currentVideoTrackLabel: String = "off"
    private var _currentQualityIndex: Int = -1

    private var _isFullcreen: Boolean = false

    var eventBus: EventBusInterface?
        get() = _eventBus
        set(value) {
            _eventBus?.removeEventlistener(this)
            _eventBus = value
            _eventBus?.addEventlistener(this)
        }

    var programController: ProgramController?
        get() = _programController
        set(value) {
            _programController = value
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.settings_bottom_sheet_dialog, container, false)
    }

    override fun onStart() {
        val holdingLinearLayoutView: LinearLayout? = this.dialog?.findViewById<LinearLayout>(R.id.cl_holder)
        val btnChapters:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_chapters)
        val btnHighlights:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_highlights)
        val btnSpeed:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_speed)
        val btnSubtitles:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_subtitles)
        val btnAudiotracks:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_audiotracks)
        val btnQuality:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_quality)
        val btnVideoTracks:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_videotracks)
        val btnClose:RelativeLayout? = dialog?.findViewById<RelativeLayout>(R.id.rl_close)

        val valueSpeed: TextView? = dialog?.findViewById<TextView>(R.id.tv_speed_value)
        val currentSpeed: Float? = _programController?.getPlaybackRate()
        if ( currentSpeed != null ) {
            if ( currentSpeed ==  1f ) {
                valueSpeed?.text = "normal"
            } else {
                valueSpeed?.text = currentSpeed.toString()
            }
        }

        //hide items that are not there (subs/audiotracks/etc)
        val chapters = _chapters
        if (chapters == null || chapters.count() == 0) {
            holdingLinearLayoutView?.removeView(btnChapters)
        } else {
            val currentTimeFloat = _currentTime.toFloatOrNull() ?: 0F
            for (chapter: Chapter in chapters) { // NB assume ordered by time offset!
                val chapterTimeOffset: Float = chapter.timeOffset ?: 0F
                if (chapterTimeOffset <= currentTimeFloat) {
                    _currentChapterLabel = if (!chapter.title.isNullOrEmpty()) "${chapter.title}" else "?"
                }
            }
            if (_currentChapterLabel != "") {
                val valueChapter: TextView? = dialog?.findViewById<TextView>(R.id.tv_chapters_value)
                valueChapter?.text = _currentChapterLabel
            }
        }

        val highlights = _highlights
        if (highlights == null || highlights.count() == 0) {
            holdingLinearLayoutView?.removeView(btnHighlights)
        }

        val subtitles = _subtitles
        if (subtitles == null || subtitles.count() == 0) {
            holdingLinearLayoutView?.removeView(btnSubtitles)
        } else {
            if (_currentSubtitleLabel != "") {
                val valueSubtitle: TextView? = dialog?.findViewById<TextView>(R.id.tv_subtitles_value)
                valueSubtitle?.text = _currentSubtitleLabel
            }
        }

        val audioTracks = _audioTracks
        if (audioTracks != null && audioTracks.count() > 1) {
            if (_currentAudiotrackLabel != "") {
                val valueAudiotrack: TextView? = dialog?.findViewById<TextView>(R.id.tv_audiotracks_value)
                valueAudiotrack?.text = _currentAudiotrackLabel
            }
        } else {
            holdingLinearLayoutView?.removeView(btnAudiotracks)
        }

        val qualities = _qualities
        if (qualities == null || qualities.count() == 0) {
            holdingLinearLayoutView?.removeView(btnQuality)
        } else {
            if (_currentQualityLabel != "" && _currentQualityIndex > -1) {
                val valueQuality: TextView? = dialog?.findViewById<TextView>(R.id.tv_quality_value)
                valueQuality?.text = _currentQualityLabel
            }
        }

        val videoTracks = _videoTracks
        if (videoTracks == null || videoTracks.count() == 0) {
            holdingLinearLayoutView?.removeView(btnVideoTracks)
        } else {
            if (_currentVideoTrackLabel != "") {
                val valueVideoTrack: TextView? = dialog?.findViewById<TextView>(R.id.tv_videotracks_value)
                valueVideoTrack?.text = _currentVideoTrackLabel
            }
        }

        var fragmentManager = this.activity?.supportFragmentManager

        // CHAPTERS
        btnChapters?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val chapters = _chapters
            if (chapters != null) {
                for (chapter: Chapter in chapters) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    title.text = if (!chapter.title.isNullOrEmpty()) "${chapter.title}" else "?"

                    newView.setOnClickListener {
                        val index = it.tag as Int
                        if (index != null && index < chapters.count()) {
                            val chapter: Chapter? = chapters[index]
                            if (chapter != null && chapter.id != null) {
                                _currentChapterLabel = if (!chapter.title.isNullOrEmpty()) "${chapter.title}" else "?"
                                _programController?.seek(chapter.timeOffset ?: 0)
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
            }
        }

        // HIGHLIGHTS
        btnHighlights?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val highlights = _highlights
            if (highlights != null) {
                for (highlight: Highlight in highlights) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    title.text = if (!highlight.title.isNullOrEmpty()) "${highlight.title}" else "?"

                    newView.setOnClickListener {
                        val index = it.tag as Int
                        if (index != null && index < highlights.count()) {
                            val highlight: Highlight? = highlights[index]
                            if (highlight != null && highlight.id != null) {
                                _programController?.seek(highlight.timeOffset ?: 0)
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
            }
        }

        // PLAYBACK SPEED
        btnSpeed?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()

            var speeds: Array<String> = arrayOf<String>("0.25","0.50","0.75","normal","1.5","2.0")

            var position: Int = 0
            for (speed in speeds) {
                val newView: RelativeLayout = LayoutInflater.from(this.context).inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                newView.id = View.generateViewId()
                newView.tag = position

                val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                title.text = speed
                newView?.setOnClickListener {
                    val index = it.tag as Int
                    if ( index != null && index < speeds.count() ) {
                        val speed: String? = speeds[index]

                        if ( speed != null && speed != "" ) {
                            if ( speed == "normal" ) {
                                _programController?.setPlaybackRate(1f)
                            } else {
                                _programController?.setPlaybackRate(speed.toFloat())
                            }
                        }
                    }
                    this.dialog?.dismiss()
                }
                if ( holdingLinearLayoutView != null ) {
                    holdingLinearLayoutView?.addView(newView)
                }
                position++
            }
        }


        // SUBTITLES
        btnSubtitles?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val subtitles = _subtitles
            if (subtitles != null) {
                for (subtitle: Subtitle in subtitles) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    title.text = if (!subtitle.languagename.isNullOrEmpty()) "${subtitle.languagename}" else subtitle.isocode ?: "?"

                    newView?.setOnClickListener {
                        val index = it.tag as Int
                        if (index != null && index < subtitles.count()) {
                            val subtitle: Subtitle? = subtitles[index]

                            if (subtitle != null && subtitle.id != null) {
                                _currentSubtitleLabel = if (!subtitle.languagename.isNullOrEmpty()) "${subtitle.languagename}" else subtitle.isocode ?: "?"
                                _programController?.setSubtitle(subtitle.id ?: "")
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
                val newView: RelativeLayout = LayoutInflater.from(this.context)
                    .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                newView.id = View.generateViewId()
                val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                title.text = "off"

                newView?.setOnClickListener {
                    _currentSubtitleLabel = "off"
                    _programController?.setSubtitle("off")
                    this.dialog?.dismiss()
                }
                if ( holdingLinearLayoutView != null ) {
                    holdingLinearLayoutView?.addView(newView)
                }
            }
        }
        // AUDIOTRACKS
        btnAudiotracks?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val audioTracks = _audioTracks
            if (audioTracks != null) {
                for (audiotrack: Audiotrack in audioTracks) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    title.text = if (!audiotrack.label.isNullOrEmpty()) "${audiotrack.label}" else "?"

                    newView?.setOnClickListener {
                        val index = it.tag as Int
                        if ( index != null && index < audioTracks.count() ) {
                            val audiotrack: Audiotrack? = audioTracks[index]

                            if (audiotrack != null && audiotrack.id != null) {
                                _currentAudiotrackLabel = if (!audiotrack.label.isNullOrEmpty()) "${audiotrack.label}" else "?"
                                _programController?.setAudiotrack(audiotrack.id ?: "")
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
            }
        }

        btnQuality?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val qualities = _qualities
            if (qualities != null) {
                for (asset: Quality in qualities) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    title.text = if (!asset.label.isNullOrEmpty()) "${asset.label}" else "?"

                    newView?.setOnClickListener {
                        val index = it.tag as Int
                        if (index >= 0 && index < qualities.count()) {
                            val quality: Quality? = qualities[index]
                            if (quality != null && quality.index != null) {
                                _currentQualityIndex = quality.index ?: 0
                                _currentQualityLabel = if (!quality.label.isNullOrEmpty()) "${quality.label}" else "?"
                                _programController?.setQuality(quality.index ?: 0)
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
                val newView: RelativeLayout = LayoutInflater.from(this.context)
                    .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                newView.id = View.generateViewId()
                newView.tag = position

                val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                title.text = "auto"

                newView?.setOnClickListener {
                    _currentQualityIndex = -1
                    _currentQualityLabel = "auto"
                    _programController?.setQuality(-1)
                    this.dialog?.dismiss()
                }
                if ( holdingLinearLayoutView != null ) {
                    holdingLinearLayoutView?.addView(newView)
                }
            }
        }

        // VIDEOTRACKS
        btnVideoTracks?.setOnClickListener {
            holdingLinearLayoutView?.removeAllViews()
            var position: Int = 0
            val videoTracks = _videoTracks
            if (videoTracks != null) {
                for (videoTrack: VideoTrack in videoTracks) {
                    val newView: RelativeLayout = LayoutInflater.from(this.context)
                        .inflate(R.layout.bottom_sheet_element, null) as RelativeLayout

                    newView.id = View.generateViewId()
                    newView.tag = position

                    val title = newView.findViewById<TextView>(R.id.tv_menu_item_title)
                    var label = if (!videoTrack.label.isNullOrEmpty()) "${videoTrack.label}" else "?"
                    if (label == "-- *") label = "off"
                    title.text = label

                    newView?.setOnClickListener {
                        val index = it.tag as Int
                        if (index >= 0 && index < videoTracks.count()) {
                            val videoTrack: VideoTrack = videoTracks[index]
                            if (videoTrack.id != null) {
                                _currentVideoTrackLabel = if (!videoTrack.label.isNullOrEmpty()) "${videoTrack.label}" else "?"
                                _programController?.setVideoTrack(videoTrack.id ?: "")
                            }
                            this.dialog?.dismiss()
                        }
                    }
                    if ( holdingLinearLayoutView != null ) {
                        holdingLinearLayoutView?.addView(newView)
                    }
                    position++
                }
            }
        }

        btnClose?.setOnClickListener {
            dialog?.dismiss()
        }
        super.onStart()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)

        if (_isFullcreen) {
            var act: Activity? = getActivity(context)
            act?.window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
        }
    }

    fun getActivity(context: Context?): Activity? {
        if (context == null) return null
        if (context is Activity) return context as Activity?
        return if (context is ContextWrapper) getActivity((context as ContextWrapper).getBaseContext()) else null
    }
    fun buildSubMenuSpeed(  ) {

    }

    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_mediaclip_loaded -> { // chaptersChanged
                val clipData: MediaClip? = if (data != null && data["clipData"] is MediaClip) data["clipData"] as MediaClip else null
                if (clipData != null) {
                    _chapters = clipData.chapters
                    _highlights = clipData.highlights
                }
            }
            EventName.bb_media_timeupdate -> {
                if (data != null && data["currentTime"] is String) {
                    _currentTime = data["currentTime"] as String
                }
            }
            EventName.bb_media_seeked -> {
                if (data != null && data["seekOffset"] is String) {
                    _currentTime = data["seekOffset"] as String
                }
            }
            EventName.audioTracksChanged -> {
                if (data != null && data["audioTracks"] != null) {
                    _audioTracks = data["audioTracks"] as List<Audiotrack>
                }
            }
            EventName.subtitleTracksChanged -> {
                if (data != null && data["subtitles"] != null) {
                    _subtitles = data["subtitles"] as List<Subtitle>
                }
            }
            EventName.qualityTracksChanged -> {
                if (data != null && data["assets"] is List<*>) {
                    val qualities = (data["assets"] as List<Quality>).toMutableList()

                    // handle duplicates
                    if (qualities.count() > 0) {
                        var lowestHeight = qualities.fold(qualities[0].height) { accu: Int, item: Quality -> if (item.height < accu) item.height else accu }
                        if (lowestHeight == -1) lowestHeight = 1
                        for (j in qualities.indices.reversed()) {
                            val quality = qualities[j]
                            val namesakes = qualities.filter { item: Quality -> item.label == quality.label }
                            if (namesakes.count() > 1) {
                                if (quality.mimeType == "audio/mpeg") { // improbable, since qualities are TRACK_TYPE_VIDEO
                                    qualities[j].label = quality.label + " low"
                                } else if (quality.mimeType == "audio/aac") { // improbable, since qualities are TRACK_TYPE_VIDEO
                                    qualities[j].label = quality.label + " high"
                                } else { // video/avc
                                    val qualityCanStay = _qualityCanStay(quality, namesakes, quality.height == lowestHeight)
                                    if (!qualityCanStay) qualities.removeAt(j)
                                }
                            }
                        }
                    }

                    _qualities = if (qualities.count() > 1) qualities else null // NB avoids single-quality selector!
                    if (qualities != null) {
                        val quality = qualities.find { it.isSelected == true }
                        if (quality != null) {
                            _currentQualityLabel = quality.label ?: "?"
                        }
                        if (_currentQualityLabel != "" && _currentQualityIndex > -1) {
                            val valueQuality: TextView? = dialog?.findViewById<TextView>(R.id.tv_quality_value)
                            valueQuality?.text = _currentQualityLabel
                        }
                    }
                }
            }
            EventName.bb_assets_changed -> {
                if (data != null && data["videoTracks"] is List<*>) {
                    val videoTracks = data["videoTracks"] as List<VideoTrack>
                    _videoTracks = if (videoTracks.count() > 1) videoTracks else null // NB avoids single-track selector!
                    if (_videoTracks != null) {
                        val videoTrack = videoTracks.find { it.isSelected == true }
                        if (videoTrack != null) {
                            _currentVideoTrackLabel = videoTrack.label ?: "?"
                            if (_currentVideoTrackLabel == "-- *") _currentVideoTrackLabel = "off"
                        }
                        if (_currentVideoTrackLabel != "") {
                            val valueVideoTrack: TextView? = dialog?.findViewById<TextView>(R.id.tv_videotracks_value)
                            valueVideoTrack?.text = _currentVideoTrackLabel
                        }
                    } else {
                        // holdingLinearLayoutView?.removeView(btnVideoTracks)
                    }
                }
            }
            EventName.subtitleTrackChanged -> {
                if (data != null && data["id"] is String) {
                    val id = data["id"] as String
                    if (id == "off") {
                        _currentSubtitleLabel = "off"
                    } else {
                        val subtitles = _subtitles
                        if (subtitles != null) {
                            for (subtitle: Subtitle in subtitles) {
                                if (subtitle.id == id) {
                                    _currentSubtitleLabel = if (!subtitle.languagename.isNullOrEmpty()) "${subtitle.languagename}" else subtitle.isocode ?: "?"
                                }
                            }
                        }
                    }
                }
            }
            EventName.fullscreen -> {
                _isFullcreen = true
            }
            EventName.retractfullscreen -> {
                _isFullcreen = false
            }
            else -> {}
        }
    }

    fun __destruct() {
        _programController = null
        _eventBus?.removeEventlistener(this)
        _eventBus = null
    }

    private fun _qualityCanStay (quality: Quality, qualities: List<Quality>, isLowest: Boolean = false): Boolean {
        var ret = false
        if (qualities.count() <= 1) return true // bail out

        if (isLowest) {
            val lowestBitrate = qualities.fold(qualities[0].bitrate) { accu: Int, item: Quality -> if (item.bitrate < accu) item.bitrate else accu }
            val qualitiesLowestBitrate = qualities.filter { item: Quality -> item.bitrate == lowestBitrate }
            ret = (quality.bitrate == lowestBitrate && quality.origId == qualitiesLowestBitrate[0].origId)
        } else {
            val highestBitrate = qualities.fold(qualities[0].bitrate) { accu: Int, item: Quality -> if (item.bitrate > accu) item.bitrate else accu }
            val qualitiesHighestBitrate = qualities.filter { item: Quality -> item.bitrate == highestBitrate }
            ret = (quality.bitrate == highestBitrate && quality.origId == qualitiesHighestBitrate[0].origId)
        }

        return ret;
    };


}
