package com.bluebillywig.bbnativeplayersdk

import androidx.annotation.OptIn
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView

/**
 * @suppress
 */
class BBForwardingPlayer {
    @OptIn(UnstableApi::class)
    constructor(player: ExoPlayer?, playerView: PlayerView?, api: BBNativePlayerAPI?) {
        _api = api
        _playerView = playerView
        _player = player

        if (_player != null) {
            val forwardingPlayer: ForwardingPlayer = object : ForwardingPlayer(_player!!) {
                override fun play(): Unit {
                    if (_api != null) {
                        _api?.play()
                    } else {
                        super.play()
                    }
                }
                override fun pause(): Unit {
                    if (_api != null ) {
                        _api?.pause()
                    } else {
                        super.pause()
                    }
                }

                override fun seekTo(positionMs: Long) {
                    if (_api != null ) {
                        val positionInSeconds: Number = positionMs.toDouble() / 1000.0
                        _api?.seek(positionInSeconds)
                    } else {
                        super.seekTo(positionMs)
                    }
                }

                override fun seekTo(windowIndex: Int, positionMs: Long) {
                    if (_api != null ) {
                        val positionInSeconds: Number = positionMs.toDouble() / 1000.0
                        _api?.seek(positionInSeconds)
                    } else {
                        super.seekTo(windowIndex, positionMs)
                    }
                }
            }
            _playerView?.setPlayer(forwardingPlayer)
        }
    }

    private var _api: BBNativePlayerAPI? = null
    private var _playerView: PlayerView? = null
    private var _player: ExoPlayer? = null


    fun __destruct() {
        _api = null
        _playerView = null
        _player = null
    }
}
