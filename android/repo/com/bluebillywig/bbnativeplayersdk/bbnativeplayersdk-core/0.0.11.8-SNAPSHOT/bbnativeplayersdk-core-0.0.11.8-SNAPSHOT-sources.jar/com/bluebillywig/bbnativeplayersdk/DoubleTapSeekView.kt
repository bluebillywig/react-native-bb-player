package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.view.animation.AlphaAnimation
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import kotlin.math.min

/**
 * DoubleTapSeekView - Custom animated overlay view for double-tap seek functionality
 * Provides visual feedback with ripple effects, directional arrows, and time display
 */
class DoubleTapSeekView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {

    enum class SeekDirection {
        FORWARD, BACKWARD
    }

    companion object {
        // Animation durations
        const val FADE_IN_DURATION = 150L
        const val FADE_OUT_DURATION = 200L
        const val RIPPLE_DURATION = 300L

        // Layout constants
        const val ARROW_TEXT_SIZE = 20f
        const val TIME_TEXT_SIZE = 18f

    }

    var direction: SeekDirection = SeekDirection.FORWARD
        set(value) {
            field = value
            updateArrowText()
        }

    var accumulatedSeconds: Int = 0
        set(value) {
            field = value
            updateTimeText()
        }

    private var rippleAnimation: AnimationSet? = null
    private var isAnimating = false

    private val arrowTextView: TextView
    private val timeTextView: TextView

    // Animation properties
    private var rippleRadius = 0f
    private var rippleAlpha = 0f

    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#40000000")
        style = Paint.Style.FILL
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        visibility = GONE
        alpha = 0f

        // Create arrow TextView
        arrowTextView = TextView(context).apply {
            textSize = ARROW_TEXT_SIZE
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = ResourcesCompat.getFont(context, R.font.lato)
        }
        addView(arrowTextView)

        // Create time TextView
        timeTextView = TextView(context).apply {
            textSize = TIME_TEXT_SIZE
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
            typeface = ResourcesCompat.getFont(context, R.font.lato)
        }
        addView(timeTextView)

        updateArrowText()
        updateTimeText()
    }

    override fun dispatchDraw(canvas: Canvas) {
        // Draw ripple effect if animating
        if (isAnimating && rippleRadius > 0) {
            val width = width.toFloat()
            val height = height.toFloat()
            val centerX = width / 2f
            val centerY = height / 2f

            // Reuse existing paint and temporarily modify alpha
            val originalAlpha = ripplePaint.alpha
            ripplePaint.alpha = (255 * rippleAlpha).toInt()
            canvas.drawCircle(centerX, centerY, rippleRadius, ripplePaint)
            ripplePaint.alpha = originalAlpha
        }

        super.dispatchDraw(canvas)
    }

    private fun updateArrowText() {
        arrowTextView.text = if (direction == SeekDirection.FORWARD) {
            ">>>" // Unicode forward arrows
        } else {
            "<<<" // Unicode backward arrows
        }
    }

    private fun updateTimeText() {
        timeTextView.text = if (accumulatedSeconds > 0) {
            "${accumulatedSeconds}s"
        } else {
            ""
        }
    }


    /**
     * Show the seek view with animation
     */
    fun show() {
        visibility = VISIBLE

        // Fade in animation
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = FADE_IN_DURATION
            interpolator = AccelerateDecelerateInterpolator()
        }

        // Scale animation for emphasis
        val scaleIn = ScaleAnimation(
            0.8f, 1f, 0.8f, 1f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = FADE_IN_DURATION
            interpolator = AccelerateDecelerateInterpolator()
        }

        val animationSet = AnimationSet(true).apply {
            addAnimation(fadeIn)
            addAnimation(scaleIn)
        }

        // Set initial alpha to ensure view is visible during animation
        alpha = 1f
        startAnimation(animationSet)
    }

    /**
     * Hide the seek view with animation
     */
    fun hide() {
        val fadeOut = AlphaAnimation(1f, 0f).apply {
            duration = FADE_OUT_DURATION
            interpolator = AccelerateDecelerateInterpolator()
            setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation?) {}
                override fun onAnimationRepeat(animation: Animation?) {}
                override fun onAnimationEnd(animation: Animation?) {
                    visibility = GONE
                    accumulatedSeconds = 0
                }
            })
        }
        startAnimation(fadeOut)
    }

    /**
     * Hide the seek view immediately without animation (for direction switching)
     */
    fun hideImmediate() {
        clearAnimation()
        visibility = GONE
        alpha = 0f
        accumulatedSeconds = 0
    }

    /**
     * Update seek time display (iOS naming convention)
     */
    fun updateSeekTime(seekTime: Int) {
        accumulatedSeconds = seekTime
        showRipple()
    }

    /**
     * Show ripple effect animation for visual feedback
     */
    fun showRipple() {
        isAnimating = true

        val maxRadius = min(width, height) / 1.4f

        // Ripple expansion animation
        val radiusAnimation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: android.view.animation.Transformation?) {
                rippleRadius = maxRadius * interpolatedTime
                invalidate()
            }
        }.apply {
            duration = RIPPLE_DURATION
            interpolator = AccelerateDecelerateInterpolator()
        }

        // Ripple fade animation
        val alphaAnimation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: android.view.animation.Transformation?) {
                rippleAlpha = 0.5f * (1f - interpolatedTime)
                invalidate()
            }
        }.apply {
            duration = RIPPLE_DURATION
            interpolator = AccelerateDecelerateInterpolator()
            setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation?) {}
                override fun onAnimationRepeat(animation: Animation?) {}
                override fun onAnimationEnd(animation: Animation?) {
                    isAnimating = false
                    rippleRadius = 0f
                    rippleAlpha = 0f
                    invalidate()
                }
            })
        }

        rippleAnimation = AnimationSet(true).apply {
            addAnimation(radiusAnimation)
            addAnimation(alphaAnimation)
        }

        startAnimation(rippleAnimation)
    }

    /**
     * Reset the view state
     */
    fun reset() {
        clearAnimation()
        visibility = GONE
        accumulatedSeconds = 0
        isAnimating = false
        rippleRadius = 0f
        rippleAlpha = 0f
        invalidate()
    }
}
