package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout


/**
 * @suppress
 */
class CommercialPlaceholderView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] is EmbedObject) {
					val embedObject = data["embedObject"] as EmbedObject
					if (embedObject.clipData != null) {
						val clipData = embedObject.clipData as MediaClip
						_isOutstream = (clipData.mediatype == "mainroll")
					}
				}
				if (data != null && data["options"] != null && data["options"] is Map<*,*>) {
					val options = data["options"] as Map<String, Any?>
					if (options.get("playerType") == "shorts") {
						_isShorts = true
					}
				}
			}
			EventName.bb_adunit_initialized -> {
				if (data != null && data["adPosition"] is String) {
					if (data["adPosition"] as String == "INARTICLE") _isOutstream = true
				}

				_bgColor = 0xFF000000.toInt() // Color.BLACK
				_ctaUrl = null
				_ctaText = "LEARN MORE"
				_ctaTextColor = 0xFFFFFFFF.toInt() // Color.WHITE
				_placeholderText = "advertisement placeholder"
				if (data != null && data["adUnitSettings"] is Map<*,*>) {
					val adUnitSettings = data["adUnitSettings"] as Map<String, Any?>

					// background color
					if (adUnitSettings["bgColor"] is String) {
						try {
							_bgColor = Color.parseColor("#" + adUnitSettings["bgColor"] as String)
						} catch (er: Exception) {}
					}
					if (adUnitSettings["ctaBackgroundColor"] is String) {
						try {
							_bgColor = Color.parseColor("#" + adUnitSettings["ctaBackgroundColor"] as String)
						} catch (er: Exception) {}
					}

					var showCtaExitScreen = false
					if (adUnitSettings["ctaExitScreen"] is String) {
						showCtaExitScreen = ("""^show""").toRegex().containsMatchIn(adUnitSettings["ctaExitScreen"] as String)
					}

					// text
					if (adUnitSettings["placeholderText"] is String) {
						_placeholderText = adUnitSettings["placeholderText"] as String
					}
					if (showCtaExitScreen && adUnitSettings["ctaText"] is String) {
						_ctaText = adUnitSettings["ctaText"] as String
					} else if (adUnitSettings["placeholderText"] is String) {
						_ctaText = adUnitSettings["placeholderText"] as String
					}

					// text color
					val colorStr: String
					if (showCtaExitScreen && adUnitSettings["ctaTextColor"] is String) { // NB stuck at 'ffffff'!
						try {
							_ctaTextColor = Color.parseColor("#" + adUnitSettings["ctaTextColor"] as String)
						} catch (er: Exception) {}
					} else if (adUnitSettings["placeholderTextColor"] is String) {
						try {
							_ctaTextColor = Color.parseColor("#" + adUnitSettings["placeholderTextColor"] as String)
						} catch (er: Exception) {}
					} else {
						// Calculate relative luminance using WCAG 2.0 formula for proper contrast
						val luminance = calculateRelativeLuminance(_bgColor)
						_ctaTextColor = if (luminance > 0.179) Color.BLACK else Color.WHITE
					}
				}
				this.setBackgroundColor(_bgColor)
				if (!_ctaUrl.isNullOrEmpty()) _ctaButton.text = _ctaText else _ctaButton.text = _placeholderText
				_ctaButton.setTextColor(_ctaTextColor)
			}
			EventName.bb_adsystem_started, EventName.bb_as_started -> {
				this.visibility = View.GONE // View.INVISIBLE

				_ctaUrl = null
				if (data != null && data["adProperties"] is Map<*,*>) {
					val adProperties = data["adProperties"] as Map<String, Any?>
					_ctaUrl = adProperties["clickThroughUrl"] as String?
					Logger.d("CommercialScreenView", "onEvent ${eventType} _ctaUrl: ${_ctaUrl}")
					if (adProperties["adSurveyUrl"] is String) {
						_ctaUrl = adProperties["adSurveyUrl"] as String
						Logger.d("CommercialScreenView", "onEvent ${eventType} _ctaUrl 3: ${_ctaUrl}")
					}
				}
				Logger.d("CommercialPlaceholderView", "onEvent ${eventType} _ctaUrl: ${_ctaUrl}")
				if (!_ctaUrl.isNullOrEmpty()) _ctaButton.text = _ctaText else _ctaButton.text = _placeholderText
			}
			EventName.bb_adsystem_noad, EventName.bb_as_item_noad,
			EventName.bb_adsystem_failed, EventName.bb_as_item_failed -> {
				Logger.d("CommercialPlaceholderView", "onEvent ${eventType} _isOutstream: ${_isOutstream}")
				this.visibility = if (_isOutstream && !_isShorts) View.VISIBLE else View.GONE // View.INVISIBLE
			}
			EventName.bb_adsystem_skipped, EventName.bb_as_item_skipped -> {
				Logger.d("CommercialPlaceholderView", "onEvent ${eventType} _isOutstream: ${_isOutstream}")
				this.visibility = if (_isOutstream && !_isShorts) View.VISIBLE else View.GONE // View.INVISIBLE
			}
			EventName.bb_adsystem_finished, EventName.bb_as_finished -> {
				Logger.d("CommercialPlaceholderView", "onEvent ${eventType} _isOutstream: ${_isOutstream}")
				this.visibility = if (_isOutstream && !_isShorts) View.VISIBLE else View.GONE // View.INVISIBLE
			}
			else -> {}
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _bgColor = 0xFF000000.toInt() // Color.BLACK
	private var _isOutstream: Boolean = false
	private var _isShorts: Boolean = false
	private var _bgLayer: ViewGroup = LinearLayout(this.context)
	private var _ctaButton = Button(this.context)
	private var _ctaUrl: String? = null
	private var _ctaText = "LEARN MORE"
	private var _ctaTextColor = 0xFFFFFFFF.toInt() // Color.WHITE
	private var _placeholderText = "advertisement placeholder"

	init {
		this.visibility = View.GONE // View.INVISIBLE
		this.setId(View.generateViewId())
		this.setPadding(0,0,0,0)
		this.setBackgroundColor(_bgColor)

		// bg layer
		val bgLayerLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		bgLayerLayoutParams.gravity = Gravity.CENTER
		_bgLayer.layoutParams = bgLayerLayoutParams
		_bgLayer.setBackgroundColor(Color.TRANSPARENT)
		_bgLayer.id = View.generateViewId()
		this.addView(_bgLayer)

		// cta
		_ctaButton.setId(View.generateViewId())
		_ctaButton.text = "advertisement placeholder"
		_ctaButton.textSize = 22F
		_ctaButton.setPadding(32, 8, 32, 8)
		val ctaButtonLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		ctaButtonLayoutParams.gravity = Gravity.CENTER
		_ctaButton.layoutParams = ctaButtonLayoutParams
		_ctaButton.setBackgroundColor(0x00000000.toInt())
		_ctaButton.setTextColor(0xFFFFFFFF.toInt()) // Color.WHITE
		_ctaButton.setOnClickListener { view ->
			var ctaUrl = _ctaUrl
			if (!ctaUrl.isNullOrEmpty()) {
				if (!("""^(\w+:|)\/\/""").toRegex().containsMatchIn(ctaUrl)) ctaUrl = "http://${ctaUrl}"
				try {
					val intent = Intent(Intent.ACTION_VIEW, Uri.parse(ctaUrl))
					this.context.startActivity(intent)
				} catch (er: Exception) {
					_eventBus?.trigger(EventName.requestOpenUrl, mapOf("url" to ctaUrl))
				}
			}
		}
		this.addView(_ctaButton)
	}

	fun __destruct() {
		_eventBus?.removeEventlistener(this)
		_eventBus = null
		this.removeView(_ctaButton)
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var bgLayer: ViewGroup? = null
		get() = _bgLayer
}
