package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.util.AttributeSet
import android.view.Surface
import android.view.TextureView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * A view that behaves like ImageView but can also play video in a loop.
 * Uses Android's built-in MediaPlayer for minimal dependencies.
 *
 * When used as an ImageView (via Coil's .load()), it displays images normally.
 * When _loadVideo() is called, it plays video in a loop.
 */
class VideoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : TextureView(context, attrs, defStyleAttr), TextureView.SurfaceTextureListener {

    private var _mediaPlayer: MediaPlayer? = null
    private var _videoUrl: String? = null
    private var _surface: Surface? = null
    private var _isPrepared = false

    // ImageView-like properties
    var adjustViewBounds: Boolean = false

    var scaleType: ScaleType = ScaleType.CENTER_CROP
        set(value) {
            field = value
            _updateVideoTransform()
        }

    enum class ScaleType {
        CENTER_CROP,
        FIT_CENTER,
        FIT_XY
    }

    private var _maxWidth: Int = Int.MAX_VALUE
    private var _maxHeight: Int = Int.MAX_VALUE
    private var _contentWidth: Int = 0
    private var _contentHeight: Int = 0

    // For image loading fallback
    private var _posterBitmap: Bitmap? = null
    private val _scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    init {
        surfaceTextureListener = this
    }

    /**
     * Load content from URL - automatically detects video vs image.
     * Mimics Coil's ImageView.load() API for compatibility.
     *
     * @param url URL to load (video or image)
     * @param builder Optional configuration block (for API compatibility, limited support)
     */
    fun load(url: String, builder: (LoadRequest.() -> Unit)? = null) {
        val request = LoadRequest()
        builder?.invoke(request)

        // Detect if URL is a video based on extension or content type hint
        val isVideo = url.contains(".mp4", ignoreCase = true) ||
                url.contains(".webm", ignoreCase = true) ||
                url.contains(".m3u8", ignoreCase = true) ||
                url.contains("video", ignoreCase = true) ||
                true

        if (isVideo) {
            _loadVideo(url)
        } else {
            _loadImage(url, request.crossfadeDuration)
        }
    }

    /**
     * Unload content
     */
    fun unload() {
        _loadVideo(null)
        _posterBitmap?.recycle()
        _posterBitmap = null
    }

    /**
     * Load an image as a poster/thumbnail.
     */
    private fun _loadImage(url: String, crossfadeDuration: Int) {
        _scope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    URL(url).openStream().use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }
                }
                _posterBitmap = bitmap
                if (bitmap != null) {
                    _contentWidth = bitmap.width
                    _contentHeight = bitmap.height
                    if (this@VideoView.adjustViewBounds) {
                        requestLayout()
                    }
                }
                _drawPosterBitmap()
            } catch (e: Exception) {
                android.util.Log.e("VideoView", "Error loading image", e)
            }
        }
    }

    private fun _drawPosterBitmap() {
        // Draw poster bitmap if no video is playing
        _posterBitmap?.let { bitmap ->
            if (_mediaPlayer == null || !_isPrepared) {
                if (!isAvailable) return
                val canvas = lockCanvas() ?: return
                try {
                    val matrix = Matrix()
                    when (this.scaleType) {
                        ScaleType.CENTER_CROP -> {
                            val scale = maxOf(
                                width.toFloat() / bitmap.width,
                                height.toFloat() / bitmap.height
                            )
                            val dx = (width - bitmap.width * scale) / 2f
                            val dy = (height - bitmap.height * scale) / 2f
                            matrix.setScale(scale, scale)
                            matrix.postTranslate(dx, dy)
                        }
                        ScaleType.FIT_CENTER -> {
                            val scale = minOf(
                                width.toFloat() / bitmap.width,
                                height.toFloat() / bitmap.height
                            )
                            val dx = (width - bitmap.width * scale) / 2f
                            val dy = (height - bitmap.height * scale) / 2f
                            matrix.setScale(scale, scale)
                            matrix.postTranslate(dx, dy)
                        }
                        ScaleType.FIT_XY -> {
                            matrix.setScale(
                                width.toFloat() / bitmap.width,
                                height.toFloat() / bitmap.height
                            )
                        }
                    }
                    canvas.drawBitmap(bitmap, matrix, null)
                } finally {
                    unlockCanvasAndPost(canvas)
                }
            }
        }
    }

    /**
     * Configuration for load requests (Coil-like API compatibility).
     */
    class LoadRequest {
        var crossfadeDuration: Int = 0
            private set

        fun crossfade(duration: Int) {
            crossfadeDuration = duration
        }

        // Size is handled automatically by the view
        fun size(resolver: Any) {
            // No-op for API compatibility
        }
    }

    fun setMaxWidth(maxWidth: Int) {
        _maxWidth = maxWidth
        requestLayout()
    }

    fun setMaxHeight(maxHeight: Int) {
        _maxHeight = maxHeight
        requestLayout()
    }

    /**
     * Override to prevent UnsupportedOperationException.
     * TextureView doesn't support background drawables, but we can use
     * the drawable's outline for clipping via clipToOutline.
     */
    override fun setBackgroundResource(resId: Int) {
        // TextureView doesn't support background drawables, but we can
        // use the resource to set up an outline provider for clipping
        if (resId != 0) {
            val drawable = context.getDrawable(resId)
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                    drawable?.let {
                        it.setBounds(0, 0, view.width, view.height)
                        it.getOutline(outline)
                    } ?: outline.setRect(0, 0, view.width, view.height)
                }
            }
        }
    }

    override fun setBackground(background: android.graphics.drawable.Drawable?) {
        // TextureView doesn't support background drawables - ignore
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var measuredWidth = MeasureSpec.getSize(widthMeasureSpec)
        var measuredHeight = MeasureSpec.getSize(heightMeasureSpec)

        // Apply max constraints
        if (measuredWidth > _maxWidth) measuredWidth = _maxWidth
        if (measuredHeight > _maxHeight) measuredHeight = _maxHeight

        // If we have video dimensions and adjustViewBounds is true, maintain aspect ratio
        // But only for FIT scale types - CENTER_CROP should fill the container
        if (this.adjustViewBounds && _contentWidth > 0 && _contentHeight > 0 && this.scaleType != ScaleType.CENTER_CROP) {
            val aspectRatio = _contentWidth.toFloat() / _contentHeight.toFloat()
            val viewAspectRatio = measuredWidth.toFloat() / measuredHeight.toFloat()

            if (viewAspectRatio > aspectRatio) {
                measuredWidth = (measuredHeight * aspectRatio).toInt()
            } else {
                measuredHeight = (measuredWidth / aspectRatio).toInt()
            }
        }

        setMeasuredDimension(measuredWidth, measuredHeight)
    }

    /**
     * Load and play a video from URL in a loop.
     */
    fun _loadVideo(url: String?) {
        _videoUrl = url

        _releaseMediaPlayer() // unsets _mediaPlayer, _surface, _isPrepared

        if (this.isAvailable && _videoUrl != null) {
            _initializeMediaPlayer(_videoUrl!!) // sets _mediaPlayer, _surface, and ... _isPrepared
        }
    }

    private fun _initializeMediaPlayer(url: String) {
        try {
            _mediaPlayer = MediaPlayer().apply {
                setDataSource(url)

                val surfaceTexture = this@VideoView.surfaceTexture ?: return
                _surface = Surface(surfaceTexture)
                setSurface(_surface)

                isLooping = true
                setVolume(0f, 0f)

                setOnPreparedListener { mp ->
                    _isPrepared = true
                    _contentWidth = mp.videoWidth
                    _contentHeight = mp.videoHeight

                    if (this@VideoView.adjustViewBounds) {
                        requestLayout()
                    }
                    _updateVideoTransform()

                    mp.start()
                }

                setOnErrorListener { _, what, extra ->
                    android.util.Log.e("VideoView", "MediaPlayer error: what=$what, extra=$extra")
                    true
                }

                prepareAsync()
            }
        } catch (e: Exception) {
            android.util.Log.e("VideoView", "Error initializing MediaPlayer", e)
        }
    }

    private fun _updateVideoTransform() {
        if (_contentWidth == 0 || _contentHeight == 0 || width == 0 || height == 0) return

        val matrix = Matrix()
        val viewWidth = width.toFloat()
        val viewHeight = height.toFloat()

        // TextureView stretches video to fill view by default (like FIT_XY)
        // The transform corrects from that stretched state
        when (this.scaleType) {
            ScaleType.CENTER_CROP -> {
                // Calculate scale factors for each dimension
                val sx = viewWidth / _contentWidth.toFloat()
                val sy = viewHeight / _contentHeight.toFloat()
                // Use max scale to fill the view completely (crop the excess)
                val maxScale = maxOf(sx, sy)

                val scaledWidth = _contentWidth * maxScale
                val scaledHeight = _contentHeight * maxScale

                // Scale factors relative to the default stretched view
                val scaleX = scaledWidth / viewWidth
                val scaleY = scaledHeight / viewHeight

                val dx = (viewWidth - scaledWidth) / 2f
                val dy = (viewHeight - scaledHeight) / 2f

                matrix.setScale(scaleX, scaleY)
                matrix.postTranslate(dx, dy)
            }
            ScaleType.FIT_CENTER -> {
                // Calculate scale factors for each dimension
                val sx = viewWidth / _contentWidth.toFloat()
                val sy = viewHeight / _contentHeight.toFloat()
                // Use min scale to fit within the view (letterbox the rest)
                val minScale = minOf(sx, sy)

                val scaledWidth = _contentWidth * minScale
                val scaledHeight = _contentHeight * minScale

                // Scale factors relative to the default stretched view
                val scaleX = scaledWidth / viewWidth
                val scaleY = scaledHeight / viewHeight

                val dx = (viewWidth - scaledWidth) / 2f
                val dy = (viewHeight - scaledHeight) / 2f

                matrix.setScale(scaleX, scaleY)
                matrix.postTranslate(dx, dy)
            }
            ScaleType.FIT_XY -> {
                // Default TextureView behavior - no transform needed
                matrix.reset()
            }
        }

        setTransform(matrix)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        _updateVideoTransform()
    }

    // TextureView.SurfaceTextureListener implementation
    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (_videoUrl != null && _mediaPlayer == null) {
            _initializeMediaPlayer(_videoUrl!!) // sets _mediaPlayer, _surface, and ... _isPrepared
        }
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        _updateVideoTransform()
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        _releaseMediaPlayer() // unsets _mediaPlayer, _surface, _isPrepared
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {
        // No-op
    }

    private fun _releaseMediaPlayer() {
        if (_isPrepared) _mediaPlayer?.stop()
        _mediaPlayer?.release()

        _mediaPlayer = null
        _surface?.release()
        _surface = null
        _isPrepared = false
    }

    fun pause() {
        _mediaPlayer?.takeIf { it.isPlaying }?.pause()
    }

    fun resume() {
        _mediaPlayer?.takeIf { _isPrepared && !it.isPlaying }?.start()
    }

    fun release() {
        _releaseMediaPlayer() // unsets _mediaPlayer, _surface, _isPrepared
        _videoUrl = null
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        _releaseMediaPlayer() // unsets _mediaPlayer, _surface, _isPrepared
        _scope.cancel()
        _posterBitmap?.recycle()
        _posterBitmap = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // If we had a video URL but lost the surface, restart
        if (_videoUrl != null && _mediaPlayer == null) {
            if (this.isAvailable) {
                _initializeMediaPlayer(_videoUrl!!) // sets _mediaPlayer, _surface, and ... _isPrepared
            }
        }
    }
}
