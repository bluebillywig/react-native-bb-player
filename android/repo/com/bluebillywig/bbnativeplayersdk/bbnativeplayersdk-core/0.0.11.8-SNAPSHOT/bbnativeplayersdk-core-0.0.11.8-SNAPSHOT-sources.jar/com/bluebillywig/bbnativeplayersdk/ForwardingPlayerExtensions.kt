package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.enums.EventName
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.view.OrientationEventListener
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.mediarouter.app.MediaRouteButton
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView

/**
 * @suppress
 */
@OptIn(UnstableApi::class)
@SuppressLint("SourceLockedOrientationActivity")
fun ForwardingPlayer.preparePlayerForFullScreen(playerView: PlayerView, forceLandscape:Boolean = false, exoOverlayViewsArray: MutableList<View?>, eventBus: EventBus? = null, bbNativePlayerView: BBNativePlayerView) {
    if (!(playerView.context is AppCompatActivity)) return // bail out

    (playerView.context as AppCompatActivity).apply {
        val fullScreenPlayerView = LayoutInflater.from(this).inflate(R.layout.bb_exo_player_view, null, false) as PlayerView
        bbNativePlayerView._fullScreenPlayerView = fullScreenPlayerView
        val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        fullScreenPlayerView.layoutParams = layoutParams
        fullScreenPlayerView.visibility = View.GONE
        fullScreenPlayerView.setBackgroundColor(Color.BLACK)

        val rootViewGroup = findViewById<View>(android.R.id.content).getRootView() as ViewGroup
        rootViewGroup.addView(fullScreenPlayerView, rootViewGroup.childCount)

        val fullScreenButton: ImageView = playerView.findViewById(R.id.exo_fullscreen_icon)
        val normalScreenButton: ImageView = fullScreenPlayerView.findViewById(R.id.exo_fullscreen_icon)
        fullScreenButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.bb_icon_fullscreenmodeoff))
        fullScreenButton.contentDescription = bbNativePlayerView.accessibilityTranslate("Fullscreen")
        normalScreenButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.bb_icon_fullscreenmodeon))
        normalScreenButton.contentDescription = bbNativePlayerView.accessibilityTranslate("Exited fullscreen")

        fullScreenButton.setOnClickListener {
            bbNativePlayerView._enterFullScreen(forceLandscape) // NB internal!
        }
        normalScreenButton.setOnClickListener {
            bbNativePlayerView._exitFullScreen(forceLandscape) // NB internal!
        }

        val settingsButton: ImageView = fullScreenPlayerView.findViewById(R.id.exo_settings_icon)
        settingsButton.contentDescription = bbNativePlayerView.accessibilityTranslate("Settings")
        settingsButton.setOnClickListener {
            bbNativePlayerView._showSettingsDialog() // NB internal!
        }

        val muteButton: ImageView = fullScreenPlayerView.findViewById(R.id.exo_mute)
        muteButton.contentDescription = bbNativePlayerView.accessibilityTranslate(if (bbNativePlayerView._masterMuted) "Volume Off" else "Volume On")
        muteButton.setOnClickListener() {
            bbNativePlayerView._muteUnmute(muteButton) // NB internal!
        }

        val subtitlesButton: ImageView = fullScreenPlayerView.findViewById(R.id.exo_subtitles_icon)
        subtitlesButton.contentDescription = bbNativePlayerView.accessibilityTranslate(if (bbNativePlayerView._subtitlesOn) "Subtitles on" else "Subtitles off")
        subtitlesButton.setOnClickListener {
            bbNativePlayerView._enableDisableSubtitles(subtitlesButton) // NB internal!
        }

        val shareButton: ImageView = fullScreenPlayerView.findViewById(R.id.exo_share_icon)
        shareButton.contentDescription = bbNativePlayerView.accessibilityTranslate("Share")
        shareButton.setOnClickListener {
            bbNativePlayerView._handleShareButton()
        }

        // Set up gesture detector for double-tap seek in fullscreen
        bbNativePlayerView._gestureDetectorFullScreen = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                bbNativePlayerView._handleSeekDoubleTapFullScreen(e.x, e.y)
                return true
            }

            override fun onSingleTapUp(e: android.view.MotionEvent): Boolean {
                // Allow single tap to pass through to existing controls
                return false
            }
        })

        // Set touch listener on fullscreen player view to intercept gestures
        fullScreenPlayerView.setOnTouchListener { _, event ->
            bbNativePlayerView._gestureDetectorFullScreen?.onTouchEvent(event) ?: false
        }

        playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        playerView.player = this@preparePlayerForFullScreen
    }
}

/**
 * @suppress
 */
fun ForwardingPlayer.handlePlayoutSettings(playerView: PlayerView, bbNativePlayerView: BBNativePlayerView) {
    if (!(playerView.context is AppCompatActivity)) return // bail out

    (playerView.context as AppCompatActivity).apply {
        // TIME DISPLAY
        val positionTime: TextView? = bbNativePlayerView._fullScreenPlayerView?.findViewById<TextView>(R.id.exo_position)
        val timeDivider: TextView? = bbNativePlayerView._fullScreenPlayerView?.findViewById<TextView>(R.id.exo_time_devider)
        val durationTime: TextView? = bbNativePlayerView._fullScreenPlayerView?.findViewById<TextView>(R.id.exo_duration)
        when(bbNativePlayerView._playout?.timeDisplay) {
            "Hide" -> {
                positionTime?.visibility = View.GONE
                timeDivider?.visibility = View.GONE
                durationTime?.visibility = View.GONE
            }
            "Show remaining time" -> {
                // TODO exo handles time text now
                positionTime?.visibility = View.VISIBLE
                durationTime?.visibility = View.GONE
                timeDivider?.visibility = View.GONE
            }
            "Show progress time" -> {
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.GONE
                durationTime?.visibility = View.GONE
            }
            "Show progress and total time" -> {
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.VISIBLE
                durationTime?.visibility = View.VISIBLE
            }
            else -> {
                // Default: show all time elements
                positionTime?.visibility = View.VISIBLE
                timeDivider?.visibility = View.VISIBLE
                durationTime?.visibility = View.VISIBLE
            }
        }

        //  CAST BUTTON
        val exoCastButton: MediaRouteButton? = bbNativePlayerView._fullScreenPlayerView?.findViewById<MediaRouteButton>(R.id.exo_cast_button)
        if ( exoCastButton != null ) {
            exoCastButton.visibility = View.GONE
            if (bbNativePlayerView._playout?.castButton == "Show" && !bbNativePlayerView._noChromeCast) {
                exoCastButton.visibility = View.VISIBLE
            }
        }

        //SHARE BUTTON - startup
        val shareButton: ImageView? = bbNativePlayerView._fullScreenPlayerView?.findViewById(R.id.exo_share_icon)
        if ( shareButton != null ) {
            shareButton.visibility = View.GONE
            if (bbNativePlayerView._playout?.shareButton == "Show") {
                shareButton.visibility = View.VISIBLE
            }
        }

        // FULLSCREEN BUTTON
        val fullscreenButton: ImageView? = bbNativePlayerView._fullScreenPlayerView?.findViewById(R.id.exo_fullscreen_icon)
        if ( fullscreenButton != null ) {
            fullscreenButton.visibility = if (bbNativePlayerView._playout?.fullScreen == "Show") View.VISIBLE else View.GONE
        }
    }
}

/**
 * @suppress
 */
fun ForwardingPlayer.handleShareButton(playerView: PlayerView, bbNativePlayerView: BBNativePlayerView, show: Boolean) {
    if (!(playerView.context is AppCompatActivity)) return // bail out

    (playerView.context as AppCompatActivity).apply {
        //SHARE BUTTON - player states
        val shareButton: ImageView? = bbNativePlayerView._fullScreenPlayerView?.findViewById(R.id.exo_share_icon)
        if ( shareButton != null ) {
            shareButton.visibility = View.GONE
            if (show) {
                shareButton.visibility = View.VISIBLE
            }
        }
    }
}
