package com.bluebillywig.bbnativeplayersdk // JK: was package com.github.vkay94.timebar

/**
 * YouTubeSegment adapted from https://github.com/vkay94/YouTubeTimeBar
 * @suppress
 */
interface YouTubeSegment {
    val startTimeMs: Long
    val endTimeMs: Long
    var color: Int
}

/**
 * YouTubeChapter adapted from https://github.com/vkay94/YouTubeTimeBar
 * @suppress
 */
interface YouTubeChapter {
    val startTimeMs: Long
    var title: String?
}

/**
 * YouTubeHighLight adapted from https://github.com/vkay94/YouTubeTimeBar
 * @suppress
 */
interface YouTubeHighlight {
    val timeMs: Long
    var title: String?
}
