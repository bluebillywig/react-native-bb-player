package com.bluebillywig.bbnativeplayersdk

import android.util.TypedValue
import android.util.TypedValue.COMPLEX_UNIT_DIP
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.ceil
import kotlin.math.floor

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.model.*

/**
 * @suppress
 */
class ShelfAdapter (
	private var _data: MutableList<ContentItemInterface>
): RecyclerView.Adapter<ShelfAdapter.ViewHolder>() {
	private var _shelfView: ShelfView? = null

	private var _viewedClipBehaviour: String = ""
	private var _showThumbnailDuration: Boolean = false
	private var _showThumbnailTitle: Boolean = false
	private var _thumbWidthDp: Float = 202f
	private var _thumbHeightDp: Float = 360f
	private var _dpm: Float = 5.0f
	private var _durationBackgroundColor: String = ""
	private var _showOutlineForUnwatchedClips: Boolean = false
	private var _outlineColor: String = ""
	private var _showPlayIconInTimestamp: Boolean = true
	private var _movingThumbnail: Boolean = false

	fun __destruct() {
		_shelfView = null
	}

	override fun onCreateViewHolder(
		parent: ViewGroup,
		viewType: Int
	): ShelfAdapter.ViewHolder {
		val itemView = ShelfItemView(parent.context)
		itemView.minimumWidth = _thumbWidthDp.toInt()
		itemView.minimumHeight = _thumbHeightDp.toInt()
		itemView.listView = _shelfView
		itemView.updateSettings(mapOf(
			"showThumbnailDuration" to _showThumbnailDuration,
			"showThumbnailTitle" to _showThumbnailTitle,
			"thumbWidthDp" to _thumbWidthDp,
			"thumbHeightDp" to _thumbHeightDp,
			"durationBackgroundColor" to _durationBackgroundColor,
			"showOutlineForUnwatchedClips" to _showOutlineForUnwatchedClips,
			"outlineColor" to _outlineColor,
			"showPlayIconInTimestamp" to _showPlayIconInTimestamp
		)) // Map<String, Any?>

		return ViewHolder(itemView)
	}

	override fun onBindViewHolder(holder: ShelfAdapter.ViewHolder, position: Int) {
		val item: ContentItemInterface? = if (position >= 0 && position < _data.size) _data[position] else null
		if (item != null) {
			// generic
			val itemProps: MutableMap<String, Any?> = mutableMapOf("id" to item.id, "title" to item.title, "description" to "", "duration" to "")
			val posterUrl = _shelfView?.getPosterUrl(item, false) ?: ""
			val posterHeight = (_thumbHeightDp * _dpm).toInt() // exact pixel height for device DPI
			itemProps["posterUrl"] = posterUrl.replace("/default/default", "/default/${posterHeight}")
			// Only show poster video for the leftmost item (position 0) if enabled
			if (_movingThumbnail && (position == 0)) {
				val videoPosterAspectRatio = if (_thumbHeightDp > 0) _thumbWidthDp / _thumbHeightDp else 1.0F
				val videoPosterHeight = (posterHeight / 120) * 120 // 360, 480, 600, 720, etc.
				val videoPosterWidth = (videoPosterAspectRatio * videoPosterHeight).toInt()
				itemProps["posterVideoUrl"] = posterUrl
					.replace("/default/default", "/${videoPosterWidth}/${videoPosterHeight}")
					.replace("pthumbnail", "movingthumbnail") // NB not pmovingthumbnail!
					.replace(".jpg", "")
				// println("[ShelfAdapter] onBindViewHolder position: ${position}, posterVideoUrl: ${itemProps["posterVideoUrl"]}")
			}
			// type-specific
			val mark = Regex("""mark""", RegexOption.IGNORE_CASE).containsMatchIn(_viewedClipBehaviour)
			if (item is Project) {
				val count = item.chapters?.count()
				itemProps["duration"] = if (count != null) "${count} ⌥" else "⌥"
				itemProps["description"] = if (item.description is String) item.description as String else ""
				itemProps["markPlayed"] = mark && item.isPlayed
			} else if (item is MediaClipList) {
				val count = item.items?.count()
				itemProps["duration"] = if (count != null) "${count} ⧉" else "⧉"
				itemProps["description"] = ""
				itemProps["markPlayed"] = mark && item.isPlayed
			} else if (item is MediaClip) {
				itemProps["duration"] = if (item.length is String) _formatDuration(item.length as String) else ""
				itemProps["description"] = if (item.description is String) item.description as String else ""
				itemProps["markPlayed"] = mark && item.isPlayed
			}
			holder.heldView.updateContent(itemProps.toMap())
			holder.heldView.setOnClickListener { _handleItemClick(item) }
		}
	}

	override fun getItemCount(): Int {
		return _data.size
	}

	inner class ViewHolder
	internal constructor(
		itemView: View
	): RecyclerView.ViewHolder(itemView) {
		val heldView = itemView as ShelfItemView
	}

	var shelfView: ShelfView?
		get() = _shelfView
		set(value) {
			_shelfView = value
		}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["viewedClipBehaviour"] is String) _viewedClipBehaviour = settings["viewedClipBehaviour"] as String
		if (settings["showThumbnailDuration"] is Boolean) _showThumbnailDuration = settings["showThumbnailDuration"] as Boolean
		if (settings["showThumbnailTitle"] is Boolean) _showThumbnailTitle = settings["showThumbnailTitle"] as Boolean
		if (settings["thumbWidthDp"] is Float) _thumbWidthDp = settings["thumbWidthDp"] as Float
		if (settings["thumbHeightDp"] is Float) _thumbHeightDp = settings["thumbHeightDp"] as Float
		if (settings["dpm"] is Float) _dpm = settings["dpm"] as Float
		if (settings["durationBackgroundColor"] is String) _durationBackgroundColor = settings["durationBackgroundColor"] as String
		if (settings["showOutlineForUnwatchedClips"] is Boolean) _showOutlineForUnwatchedClips = settings["showOutlineForUnwatchedClips"] as Boolean
		if (settings["outlineColor"] is String) _outlineColor = settings["outlineColor"] as String
		if (settings["showPlayIconInTimestamp"] is Boolean) _showPlayIconInTimestamp = settings["showPlayIconInTimestamp"] as Boolean
		if (settings["movingThumbnail"] is Boolean) _movingThumbnail = settings["movingThumbnail"] as Boolean
	}

	internal fun updateData (data: MutableList<ContentItemInterface>?) {
		if (data != null) {
			_data = data
			this.notifyDataSetChanged()
		}
	}

	// add onclick listener to viewholder
	private fun _handleItemClick(item: ContentItemInterface) {
		Logger.d("ShelfAdapter", "_handleItemClick going to load item: ${item}")
		_shelfView?.openPlayerWithContentItem(item)
	}

	private fun _formatDuration(value: Any): String {
		var res = "00:00"

		var duration: Double? = null
		try {
			if (value is Int) duration = value.toDouble()
			if (value is Long) duration = value.toDouble()
			if (value is Float) duration = value.toDouble()
			if (value is Double) duration = value
			if (value is String) duration = value.toDouble()
		} catch (er: Exception) {}

		if (duration != null) {
			val hh = (floor(duration / 3600)).toInt(); duration %= 3600
			val mm = (floor(duration / 60)).toInt(); duration %= 60
			val ss = (ceil(duration)).toInt()
			res = if (hh > 0) ("%02d:%02d:%02d").format(hh, mm, ss) else ("%02d:%02d").format(mm, ss)
		}

		// Prepend play icon if showPlayIconInTimestamp is true
		if (_showPlayIconInTimestamp) {
			res = "▶ $res"
		}

		return res
	}
}
