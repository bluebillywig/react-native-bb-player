package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.AttributeSet
import android.util.TypedValue
import android.util.TypedValue.COMPLEX_UNIT_DIP
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import coil3.load
import coil3.request.crossfade
import coil3.size.Size
import coil3.size.ViewSizeResolver

/**
 * @suppress
 */
class ShelfItemView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) {
	private val _dpm: Float

	// resources
	private var _spanningView: View = View(this.context)
	private var _posterVideoView: VideoView = VideoView(this.context)
	private var _posterView: ImageView = ImageView(this.context)
	private var _titleView: TextView = TextView(this.context)
	private var _durationView: TextView = TextView(this.context)
	private var _playedView: ShelfItemPlayedView = ShelfItemPlayedView(this.context)
	private var _listView: ShelfView? = null

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0x33000000.toInt()
	private var _durationBackgroundColor: String = ""
	private var _showOutlineForUnwatchedClips: Boolean = false
	private var _outlineColor: String = ""

	// state

	init {
		_dpm = TypedValue.applyDimension(COMPLEX_UNIT_DIP, 1.0f, this.resources.displayMetrics)
		val pad = (6f * _dpm).toInt()

		// val layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		// this.layoutParams = layoutParams
		this.setPadding(0, 0, 0, 0)
		this.setBackgroundColor(_backgroundColor)
		this.setBackgroundResource(R.drawable.rounded_thumbnail)

		_spanningView.setBackgroundResource(R.drawable.played_rounded_corners)
		val spanningViewLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		spanningViewLayoutParams.gravity = Gravity.CENTER or Gravity.CENTER_VERTICAL
		spanningViewLayoutParams.setMargins(0, 0, 0, 0)
		_spanningView.layoutParams = spanningViewLayoutParams

//		_posterView.setMaxWidth(202)
//		_posterView.setMaxHeight(360)
		_posterView.adjustViewBounds = true
		_posterView.setBackgroundResource(R.drawable.rounded_thumbnail)
		_posterView.clipToOutline = true
		_posterView.scaleType = ImageView.ScaleType.CENTER_CROP  //Scale the image uniformly (maintain the image's aspect ratio) so that both dimensions (width and height) of the image will be equal to or larger than the corresponding dimension of the view (minus padding).

//		_posterVideoView.setMaxWidth(202)
//		_posterVideoView.setMaxHeight(360)
		_posterVideoView.adjustViewBounds = true
		_posterVideoView.setBackgroundResource(R.drawable.rounded_thumbnail)
		_posterVideoView.clipToOutline = true
		_posterVideoView.scaleType = VideoView.ScaleType.CENTER_CROP  //Scale the image uniformly (maintain the image's aspect ratio) so that both dimensions (width and height) of the image will be equal to or larger than the corresponding dimension of the view (minus padding).

		val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato)
		_titleView.setTypeface(typeface, Typeface.BOLD)
		_titleView.setGravity(Gravity.BOTTOM)
		_titleView.setPadding(pad, pad, pad, pad)
		_titleView.textSize = 11F
		_titleView.maxLines = 2
		_titleView.ellipsize = TextUtils.TruncateAt.END
		_titleView.setTextColor(_foregroundColor)
		// see: https://stackoverflow.com/questions/17410195/setshadowlayer-android-api-differences
		_titleView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_titleView.setMaxWidth(170)

		val durationTypeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato_black)
		_durationView.setTypeface(durationTypeface)
		_durationView.setGravity(Gravity.TOP)
		_durationView.setTextDirection(TEXT_DIRECTION_LTR)
		// _durationView.setPadding(20, 20, 0, 0)
		_durationView.textSize = 11F
		_durationView.setTextColor(_foregroundColor)
		_durationView.setMaxWidth(170)
		val durationViewLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		durationViewLayoutParams.gravity = Gravity.TOP or Gravity.LEFT
		durationViewLayoutParams.setMargins(pad, pad, pad, pad)
		_durationView.layoutParams = durationViewLayoutParams
		_durationView.setBackgroundResource(R.drawable.duration_rounded_corners)

		_playedView.setBackgroundResource(R.drawable.played_rounded_corners)
		val playedViewLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		playedViewLayoutParams.gravity = Gravity.CENTER or Gravity.CENTER_VERTICAL
		playedViewLayoutParams.setMargins(0, 0, 0, 0)
		_playedView.layoutParams = playedViewLayoutParams
		_playedView.visibility = View.GONE

		_spanningView.id = View.generateViewId()
		this.addView(_spanningView)
		_posterView.id = View.generateViewId()
		this.addView(_posterView)
		_posterVideoView.id = View.generateViewId()
		_posterVideoView.visibility = View.GONE
		this.addView(_posterVideoView)
		_titleView.id = View.generateViewId()
		this.addView(_titleView)
		_durationView.id = View.generateViewId()
		this.addView(_durationView)
		_playedView.id = View.generateViewId()
		this.addView(_playedView)

		_update()
	}

	fun __destruct() {
		this.removeAllViews()
	}

	var listView: ShelfView?
		get() = _listView
		set(value) {
			_listView = value
		}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["showThumbnailDuration"] is Boolean) {
			val showThumbnailDuration = settings["showThumbnailDuration"] as Boolean
			_durationView.visibility = if (showThumbnailDuration) View.VISIBLE else View.GONE
		}
		if (settings["showThumbnailTitle"] is Boolean) {
			val showThumbnailTitle = settings["showThumbnailTitle"] as Boolean
			_titleView.visibility = if (showThumbnailTitle) View.VISIBLE else View.GONE
		}
		if (settings["thumbWidthDp"] is Float) {
			val thumbWidthDp = settings["thumbWidthDp"] as Float
			val thumbWidth = (thumbWidthDp * _dpm).toInt() // TypedValue.applyDimension(COMPLEX_UNIT_DIP, thumbWidthDp, resources.displayMetrics).toInt()
			_spanningView.minimumWidth = thumbWidth  // prevent seeing small cells before thumbnail is loaded
			_posterVideoView.setMaxWidth(thumbWidth)
			_posterView.setMaxWidth(thumbWidth)
			_titleView.setMaxWidth(thumbWidth)
			_durationView.setMaxWidth(thumbWidth)
		}
		if (settings["thumbHeightDp"] is Float) {
			val thumbHeightDp = settings["thumbHeightDp"] as Float
			val thumbHeight = (thumbHeightDp * _dpm).toInt() // TypedValue.applyDimension(COMPLEX_UNIT_DIP, thumbHeightDp, resources.displayMetrics).toInt()
			_posterVideoView.setMaxHeight(thumbHeight)
			_posterView.setMaxHeight(thumbHeight)
		}
		if (settings["durationBackgroundColor"] is String) {
			_durationBackgroundColor = settings["durationBackgroundColor"] as String
			if (_durationBackgroundColor.isNotEmpty()) {
				try {
					var color = android.graphics.Color.parseColor(_durationBackgroundColor)
					// Force the color to be fully opaque (solid) by setting alpha to 0xFF
					color = color or 0xFF000000.toInt()
					// Keep the drawable but tint it with the solid custom color
					_durationView.background?.setTint(color)

					// Calculate relative luminance using WCAG 2.0 formula
					val luminance = calculateRelativeLuminance(color)

					if (luminance > 0.179) {
						_durationView.setTextColor(android.graphics.Color.BLACK)
					} else {
						_durationView.setTextColor(_foregroundColor)
					}
				} catch (e: Exception) {
					// If color parsing fails, clear any tint to use default drawable color
					_durationView.background?.setTintList(null)
					_durationView.setTextColor(_foregroundColor)
				}
			} else {
				// If no color specified, clear any tint to use default drawable color
				_durationView.background?.setTintList(null)
				_durationView.setTextColor(_foregroundColor)
			}
		}
		if (settings["showOutlineForUnwatchedClips"] is Boolean) _showOutlineForUnwatchedClips = settings["showOutlineForUnwatchedClips"] as Boolean
		if (settings["outlineColor"] is String) _outlineColor = settings["outlineColor"] as String

		_update() // OBSOLETE?!?
	}

	fun updateContent(content: Map<String, Any?>) {
		if (content["posterVideoUrl"] is String) {
			_posterVideoView.load(content["posterVideoUrl"] as String) {
				crossfade(100)
				size(ViewSizeResolver(_posterVideoView)) // takes device screen dpi into account
			}
			_posterVideoView.visibility = View.VISIBLE
		} else {
			_posterVideoView.unload()
			_posterVideoView.visibility = View.GONE
		}

		if (content["posterUrl"] is String) {
			val imageLoader = _listView?._imageLoader
			if (imageLoader != null) {
				_posterView.load(content["posterUrl"] as String, imageLoader) {
					crossfade(100)
					size(ViewSizeResolver(_posterView)) // takes device screen dpi into account
				}
			} else {
				_posterView.load(content["posterUrl"] as String) {
					crossfade(100)
					size(ViewSizeResolver(_posterView)) // takes device screen dpi into account
				}
			}
		}
		if (content["title"] is String) {
			_titleView.text = content["title"] as String
		}
		if (content["duration"] is String) {
			_durationView.text = content["duration"] as String
		}
		if (content["markPlayed"] is Boolean) {
			val markPlayed = content["markPlayed"] as Boolean
			_playedView.visibility = if (markPlayed) View.VISIBLE else View.GONE

			// Apply outline if showOutlineForUnwatchedClips is true and clip is not watched
			if (_showOutlineForUnwatchedClips && !markPlayed && _outlineColor.isNotEmpty()) {
				val colorWithAlpha = _outlineColor.replaceFirst("#", "#ff")
				val outlineColorInt = Color.parseColor(colorWithAlpha)
				val outlineWidthPx = (3f * _dpm).toInt() // 3dp converted to pixels

				// Match the exact corner radius of rounded_thumbnail (8dp)
				val cornerRadius = 8f * _dpm

				// Add padding to parent to make room for outline, then draw on parent background
				this.setPadding(outlineWidthPx, outlineWidthPx, outlineWidthPx, outlineWidthPx)

				// Create a drawable with stroke for the outline
				val drawable = GradientDrawable()
				drawable.setColor(Color.TRANSPARENT) // transparent fill
				drawable.setStroke(outlineWidthPx, outlineColorInt)
				drawable.cornerRadius = cornerRadius

				// Apply the outline drawable to parent background (with padding, posterView won't cover it)
				this.background = drawable
			} else {
				// Reset padding and background when no outline needed
				this.setPadding(0, 0, 0, 0)
				this.setBackgroundResource(R.drawable.rounded_thumbnail)
			}
		}

		_update() // OBSOLETE?!?
	}

	private fun _update() {
		// nothing
	}
}
