package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import coil3.ImageLoader
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.memory.MemoryCache
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Player
import org.json.JSONArray
import org.json.JSONObject
import java.util.*
import kotlin.math.abs


/**
 * @suppress
 */
class ScrollEnabledLayoutManager(context: Context?, orientation: Int,
								 reverseLayout: Boolean) : LinearLayoutManager(context, orientation,
	reverseLayout) {
	private var _scrollEnabled: Boolean = true

	var isScrollEnabled: Boolean
		get() = _scrollEnabled
		set(value) {
			_scrollEnabled = value
		}

	override fun canScrollVertically(): Boolean {
		return _scrollEnabled && super.canScrollVertically()
	}
	override fun canScrollHorizontally(): Boolean {
		return _scrollEnabled && super.canScrollHorizontally()
	}
	override fun getExtraLayoutSpace(state: RecyclerView.State?) = 600 // results in pre-rendering next items
}

/**
 * @suppress
 */
class SwipeableListView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface, Player.Listener {
	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	private var _playHistoryManager: PlayHistoryManager? = null
	private val _layoutManagerH = ScrollEnabledLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
	private val _layoutManagerV = ScrollEnabledLayoutManager(context, LinearLayoutManager.VERTICAL, false)
	private val _snapHelperH = PagerSnapHelper()
	private val _snapHelperV = PagerSnapHelper()
	private var _adapter: SwipeableListAdapter? = null
	private val _recy = RecyclerView(context, attrs, defStyleAttr)
	private var _playPauseIcon: BigIconView? = null

	internal var exoPlayer: ExoPlayer? = null // WMY internal?

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _autoPlay = true
	private var _scrollThreshold: Int = 288
	private var _settings: Map<String, Any?> = mapOf()
	private var _viewedClipBehaviour: String = ""
	private var _ctaUrlField: String? = "deeplink"
	private var _ctaButtonLabelField: String? = null
	private var _skipShortsAdOnSwipe: Boolean = false
	private var _skipOffset: Double = -1.0

	// data
	private var _clipListItemsOrig: MutableList<ContentItemInterface>? = null
	private var _clipListItems: MutableList<ContentItemInterface>? = null
	private var _clip: MediaClip? = null
	private var _ctaUrls: MutableMap<String, String>? = mutableMapOf()
	private var _ctaLabels: MutableMap<String, String>? = mutableMapOf()

	// state
	private var _previousPos: Int = -1
	private var _currentPos: Int = 0
	private var _actualPos: Int = -1
	private var _x: Int = 0
	private var _y: Int = 0
	private var _playing: Boolean = false
	private var _swipingDisabled: Boolean = false
	private var _onRenderedFirstFrameOnce: Boolean = false
	internal var _imageLoader: ImageLoader? = null

	override fun onRenderedFirstFrame() {
		_onRenderedFirstFrameOnce = true
		_adapter?.hidePosterForPos(_currentPos)
	}

	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
//			EventName.bb_embed_loaded -> {
//				if (data != null) {
//					println("*** *** data not null")
//					if (data["embedObject"] is EmbedObject) {
//						println("*** *** embedObject exists")
//						val embedObject = data["embedObject"] as EmbedObject
//						_setClipListData(embedObject.clipListData)
//					}
//				}
//			}
			EventName.bb_cliplist_loaded -> {
				if (data != null) {
					if (data["clipListData"] is MediaClipList) {
						_setClipListItems(_clipListItemsFromData(data["clipListData"] as MediaClipList))
					} else {
						_setClipListItems(null)
					}
				}
			}
			EventName.bb_cliplist_changed -> {
				if (data != null) {
					if (data["clipListItems"] is MutableList<*>) {
						_updateClipListItems(data["clipListItems"] as MutableList<ContentItemInterface>)
					}
				}
			}
			EventName.bb_mediaclip_loaded -> {
				_playing = false

				if (data != null && data["clipData"] is MediaClip) {
					_clip = data["clipData"] as MediaClip
					_actualPos = _currentPos
					val clipListItems = _clipListItems
					if (clipListItems != null) {
						for (i in 0 until clipListItems.count()) {
							val item = clipListItems[i]
							if (item.id == _clip?.id) {
								_actualPos = i
								break
							}
						}
					}
					if (_currentPos != _actualPos) {
						_currentPos = _actualPos
						println("onEvent bb_mediaclip_loaded going to scroll to _currentPos: ${_currentPos} (_previousPos: ${_previousPos})")
						_recy.layoutManager?.scrollToPosition(_currentPos)
					}
				}
				if (!_autoPlay) {
					// move adopted views to current position
					if (_previousPos != _currentPos || true) {
						if (_adapter?.updateFromPosToPos(_previousPos, _currentPos) == true) {
							_previousPos = _currentPos
						}
					}
				} else {
					// move adopted views to invisible position until playing
					if (_previousPos != _currentPos) {
						if (_adapter?.updateFromPosToPos(_previousPos, -1) == true) {
							_previousPos = -1
						}
					}
				}

				if (_clip?.mediatype == "mainroll") {
					// disable swiping
					_swipingDisabled = true
				} else {
					// re-enable swiping
					_swipingDisabled = false
					_layoutManagerH.isScrollEnabled = true
					_layoutManagerV.isScrollEnabled = true
				}
			}
			EventName.bb_media_playing -> {
				_playing = true

				// move adopted views to current position
				if (_previousPos != _currentPos || true) {
					if (_adapter?.updateFromPosToPos(_previousPos, _currentPos, 0) == true) {
						_previousPos = _currentPos
					}
				}

				// hide poster if not (yet) optimized
				if (!_onRenderedFirstFrameOnce) {
					_adapter?.hidePosterForPos(_currentPos)
				}

				// re-enable swiping
				_swipingDisabled = false
				_layoutManagerH.isScrollEnabled = true
				_layoutManagerV.isScrollEnabled = true
			}
			EventName.bb_adsystem_initialized -> {
				if (data != null) {
					if (data["skipOffset"] != null) {
						_skipOffset = (data["skipOffset"] as String).toDouble()
					}
				}
			}
			EventName.bb_adsystem_started -> {
				_playing = true

				// move adopted views to current position
				if (_previousPos != _currentPos || true) {
					if (_adapter?.updateFromPosToPos(_previousPos, _currentPos, 1) == true) {
						_previousPos = _currentPos
					}
				}

				if (!_skipShortsAdOnSwipe) {
					// disable swiping
					_swipingDisabled = true
				} else {
					_updateSkippability(0.0)
				}
			}
			EventName.adProgress -> {
				if (_skipShortsAdOnSwipe) {
					if (data != null && data["adPosition"] != null && data["adDuration"] != null) {
						val position = data["adPosition"].toString().toDouble()
						_updateSkippability(position / 1000)
					}
				}
			}
			EventName.bb_adsystem_finished, EventName.bb_adsystem_skipped, EventName.bb_adsystem_failed -> {
				// re-enable swiping
				_swipingDisabled = false
				_layoutManagerH.isScrollEnabled = true
				_layoutManagerV.isScrollEnabled = true
			}
			EventName.pause -> {
				_playing = false
			}
			else -> {}
		}
	}

	override fun onViewAdded(view: View?) {
		super.onViewAdded(view)
		if (!(view is RecyclerView)) {
			this.removeView(view)
			_adapter?.adoptView(view)
		}
	}

//	override fun onViewRemoved(view: View?) {
//		super.onViewRemoved(view)
//	}

	companion object {
		fun getFromJsonObject (path: String, obj: JSONObject): Any? {
			// println("[SwipeableListView] getFromJsonObject path: ${path}")
			val rex = ("""^\/[^\/]*""").toRegex()
			val result = rex.find(path)
			if (result != null) {
				val key = result.value.replace("/", "")
				// println("[SwipeableListView] getFromJsonObject key: ${key}")
				try {
					val value = obj.get(key)
					// println("[SwipeableListView] getFromJsonObject value: ${value}")
					val newPath = path.replace(rex, "")
					if (!newPath.isEmpty()) { // recursion condition
						if (value is JSONArray) {
							return getFromJsonArray(newPath, value)
						} else if (value is JSONObject) {
							return getFromJsonObject(newPath, value)
						}
					} else { // recursion stop condition
						return value // String, Number, Boolean, null
					}
				} catch (e: Exception) { }
			}
			return null
		}

		fun getFromJsonArray (path: String, arr: JSONArray): Any? {
			// println("[SwipeableListView] getFromJsonArray path: ${path}")
			val rex = ("""^\/[^\/]*""").toRegex()
			val result = rex.find(path)
			if (result != null) {
				val key = result.value.replace("/", "")
				var idx = key.toIntOrNull() ?: -1
				if (key.contains(":")) {
					val parts = (""":""").toRegex().split(key, 2)
					idx = 0
					while (idx < arr.length()) {
						try {
							val item = arr.get(idx)
							if (item is JSONObject) {
								if ("" == parts[0] && item.get("id") == parts[1]) break
								if (item.get("type") == parts[0] && "" == parts[1]) break
								if (item.get("type") == parts[0] && item.get("id") == parts[1]) break
							}
						} catch (_: Exception) { }
						idx++
					}
				}
				// println("[SwipeableListView] getFromJsonArray idx: ${idx}")
				try {
					val value = arr.get(idx)
					// println("[SwipeableListView] getFromJsonArray value: ${value}")
					val newPath = path.replace(rex, "")
					if (!newPath.isEmpty()) { // recursion condition
						if (value is JSONArray) {
							return getFromJsonArray(newPath, value)
						} else if (value is JSONObject) {
							return getFromJsonObject(newPath, value)
						}
					} else { // recursion stop condition
						return value // String, Number, Boolean, null
					}
				} catch (_: Exception) { }
			}
			return null
		}

	}

	init {
		val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
		this.layoutParams = layoutParams

		this.setBackgroundColor(Color.parseColor("#99000000")) // acc. Deniz

		this.setId(View.generateViewId())
		this.setPadding(0, 0, 0, 0)

		val r: Int = Color.red(_foregroundColor)
		val g: Int = Color.green(_foregroundColor)
		val b: Int = Color.blue(_foregroundColor)
		val shadowColor = if (r + g + b < 384) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
		val shadowD = if (r + g + b < 384) -2F else 2F

		val set = ConstraintSet()
		set.clone(this)

		_clipListItems = mutableListOf(MediaClip("0", "-"))
		val clipListItems = _clipListItems
		if (clipListItems != null) {
			_adapter = SwipeableListAdapter(clipListItems)
		}

		_recy.setId(View.generateViewId())
		_recy.layoutManager = _layoutManagerV
		_snapHelperV.attachToRecyclerView(_recy)
//		_recy.setHasFixedSize(true)
		_recy.adapter = _adapter
		set.connect(_recy.getId(), ConstraintSet.TOP, this.getId(), ConstraintSet.TOP, 0)
		set.connect(_recy.getId(), ConstraintSet.BOTTOM, this.getId(), ConstraintSet.BOTTOM, 0)
		set.connect(_recy.getId(), ConstraintSet.LEFT, this.getId(), ConstraintSet.LEFT, 0)
		set.connect(_recy.getId(), ConstraintSet.RIGHT, this.getId(), ConstraintSet.RIGHT, 0)
		this.addView(_recy)

		_recy.addOnScrollListener(object : RecyclerView.OnScrollListener() {
			override fun onScrolled(recy: RecyclerView, dx: Int, dy: Int) {
				super.onScrolled(recy, dx, dy)
				if (recy.layoutManager is LinearLayoutManager) {
					val layoutManager = recy.layoutManager as LinearLayoutManager
					val firstVisibleItemPos = layoutManager.findFirstVisibleItemPosition()
					val lastVisibleItemPos = layoutManager.findLastVisibleItemPosition()
					if (firstVisibleItemPos == lastVisibleItemPos) {
						_x = 0
						_y = 0
						if (_swipingDisabled) {
							_layoutManagerH.isScrollEnabled = false
							_layoutManagerV.isScrollEnabled = false
						} else {
							_layoutManagerH.isScrollEnabled = true
							_layoutManagerV.isScrollEnabled = true
						}
					}
					_x += dx
					_y += dy
					val pos = if (_x + _y >= 0) lastVisibleItemPos else firstVisibleItemPos
					if (pos >= 0 && pos != _currentPos && (abs(_x + _y) > _scrollThreshold || firstVisibleItemPos == lastVisibleItemPos)) { // new position
						val realPreviousPos = _currentPos
						_currentPos = pos
						println("onScrolled updated _currentPos: ${_currentPos} (_previousPos: ${_previousPos})")
						val clipListItems = _clipListItems
						var fromItemId = ""
						var toItemId = ""
						var fromContentType = ""
						var toContentType = ""

						if (clipListItems != null) {
							if (_clip?.mediatype == "mainroll" && !_swipingDisabled) {
								_programController?.skipAd()
								return
							}

							val toItem = clipListItems[pos]
							if (toItem is MediaClip) {
								toContentType = "MediaClip"
								if (toItem.assets != null || toItem.isPrefetch == true) {
									println("onScrolled going to load content: ${toItem.title}")
									_programController?.loadContent(toItem as ContentItemInterface, "Shorts", _autoPlay, 0)
								} else {
									println("onScrolled going to load clip content by id: ${toItem.id}")
									_programController?.loadContentById("${toItem.id}", "c", "Shorts", _autoPlay, 0)
								}
							} else if (toItem is MediaClipList) {
								toContentType = "MediaClipList"
								if (toItem.items != null || toItem.isPrefetch == true) {
									println("onScrolled going to load content: ${toItem.title}")
									_programController?.loadContent(toItem as ContentItemInterface, "Shorts", _autoPlay, 0)
								} else {
									println("onScrolled going to load cliplist content by id: ${toItem.id}")
									_programController?.loadContentById("${toItem.id}", "l", "Shorts", _autoPlay, 0)
								}
							} else if (toItem is Project) {
								toContentType = "Project"
								if (toItem.chapters != null || toItem.isPrefetch == true) {
									println("onScrolled going to load content: ${toItem.title}")
									_programController?.loadContent(toItem as ContentItemInterface, "Shorts", _autoPlay, 0)
								} else {
									println("onScrolled going to load project content by id: ${toItem.id}")
									_programController?.loadContentById("${toItem.id}", "p", "Shorts", _autoPlay, 0)
								}
							} else {
								println("onScrolled going to load content: ${toItem.id}")
								_programController?.loadContent(toItem as ContentItemInterface, "Shorts", _autoPlay, 0)
							}
							toItemId = toItem.id ?: ""

							if (realPreviousPos >= 0 && realPreviousPos < clipListItems.count()) {
								val fromItem = clipListItems[realPreviousPos]
								if (fromItem is MediaClip) {
									fromContentType = "MediaClip"
								} else if (fromItem is MediaClipList) {
									fromContentType = "MediaClipList"
								} else if (fromItem is Project) {
									fromContentType = "Project"
								}
								fromItemId = fromItem.id ?: ""
							}

							var method = "shortsNext"
							if (_currentPos < realPreviousPos) {
								method = "shortsPrev"
							}
							if (fromItemId != "" && fromContentType != "" && toItemId != "" && toContentType != "") {
								_eventBus?.trigger(EventName.bb_api_called, mapOf(
									"method" to method,
									"from" to fromContentType + ":" + fromItemId,
									"to" to toContentType + ":" + toItemId))
							}
						}
					}
				}
			}

			override fun onScrollStateChanged(recy: RecyclerView, newState: Int) {
				super.onScrollStateChanged(recy, newState)
			}
		})
//		_recy.addOnFlingListener(object : RecyclerView.OnFlingListener() {
//		}

		_recy.addItemDecoration(
			MarginItemDecoration2(0)
		)
		set.applyTo(this)
	}

	internal fun setExoPLayer( player:ExoPlayer? ) {
		this.exoPlayer?.removeListener(this)
		this.exoPlayer = player
		this.exoPlayer?.addListener(this)
	}

	fun __destruct() {
		_recy.adapter = null
		_adapter?.__destruct()
		_adapter = null

		this.removeAllViews()
		_eventBus?.removeEventlistener(this)
		_eventBus = null

		_clipListItems?.clear()
		_clipListItems = null
		_clipListItemsOrig?.clear()
		_clipListItemsOrig = null
		_playHistoryManager = null
		_playPauseIcon = null
		_programController = null
		this.exoPlayer?.removeListener(this)
		this.exoPlayer = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_adapter?.programController = null
			_programController = value
			_adapter?.programController = _programController
		}

	var playHistoryManager: PlayHistoryManager?
		get() = _playHistoryManager
		set(value) {
			_playHistoryManager = value
		}

	var playPauseIcon: BigIconView?
		get() = _playPauseIcon
		set(value) {
			_playPauseIcon = value
		}
	fun togglePlayPause() {
		if (_playing) {
			_programController?.pause()
			animatePauseIcon()
		} else {
			_programController?.play()
			animatePlayIcon()
		}
	}

	fun animatePauseIcon() {
		_playPauseIcon?.type = "PAUSE_ANIM"
	}

	fun animatePlayIcon() {
		_playPauseIcon?.type = "PLAY_ANIM"
	}

	fun getCtaUrlForItem (item: ContentItemInterface): String? {
		var contentId = "${item.id}"
		if (item is MediaClip) {
			contentId = "MediaClip:${item.id}"
		} else if (item is Project) {
			contentId = "Project:${item.id}"
		} else if (item is MediaClipList) {
			contentId = "MediaClipList:${item.id}"
		}
		var url = _ctaUrls?.get(contentId) // cached
		if (url == null) {
			val urlAny = _getFromRawJson("/clipListData/items/${contentId}/${_ctaUrlField}")
			if (urlAny is String) { url = urlAny; _ctaUrls?.put(contentId, url) }
		}
		if (url == null) {
			val urlAny = _getFromRawJson("/items/${contentId}/${_ctaUrlField}")
			if (urlAny is String) { url = urlAny; _ctaUrls?.put(contentId, url) }
		}

		// println("[SwipeableListView] getCtaUrlForItem url: ${url}")
		return url
	}

	fun getCtaLabelForItem (item: ContentItemInterface): String? {
		// If ctaButtonLabelField is not set, return null to use default
		if (_ctaButtonLabelField.isNullOrEmpty()) {
			return null
		}

		var contentId = "${item.id}"
		if (item is MediaClip) {
			contentId = "MediaClip:${item.id}"
		} else if (item is Project) {
			contentId = "Project:${item.id}"
		} else if (item is MediaClipList) {
			contentId = "MediaClipList:${item.id}"
		}
		var label = _ctaLabels?.get(contentId) // cached
		if (label == null) {
			val labelAny = _getFromRawJson("/clipListData/items/${contentId}/${_ctaButtonLabelField}")
			if (labelAny is String) { label = labelAny; _ctaLabels?.put(contentId, label) }
		}
		if (label == null) {
			val labelAny = _getFromRawJson("/items/${contentId}/${_ctaButtonLabelField}")
			if (labelAny is String) { label = labelAny; _ctaLabels?.put(contentId, label) }
		}

		// println("[SwipeableListView] getCtaLabelForItem label: ${label}")
		return label
	}

	// path e.g.: "/clipListData/items/MediaClip:1234567/deeplink" or "/clipListData/items/3/deeplink"
	private fun _getFromRawJson (path: String): Any? {
		val rawJsonString = _programController?.getRawJsonString()
		if (rawJsonString != null) {
			try {
				return getFromJsonObject(path, JSONObject(rawJsonString))
			} catch (_: Exception) { }
			try {
				return getFromJsonArray(path, JSONArray(rawJsonString))
			} catch (_: Exception) { }
		}
		return null
	}

	fun update() {
		// println("[SwipeableListView] update")
		_clipListItems = _getClipListItems(true)
		_adapter?.updateData(_clipListItems)

//		_previousPos = -1
//		_currentPos = 0
//		_actualPos = -1
	}

	private fun _clipListItemsFromData (clipListData: MediaClipList?): MutableList<ContentItemInterface>? {
		var clipListItems: MutableList<ContentItemInterface>? = null

		if (clipListData?.items is List<*>) {
			println("[SwipeableListView] _clipListItemsFromData clipListData.items is List<*>")
			val items = clipListData.items as List<ContentItem>
			clipListItems = mutableListOf()
			for (item in items) {
				println("[SwipeableListView] _clipListItemsFromData item: ${item.id}")
				clipListItems.add(item as ContentItemInterface)
			}
		}

		return clipListItems
	}

	private fun _getClipListItems (allowMove: Boolean = false): MutableList<ContentItemInterface>? {
		var clipListItems: MutableList<ContentItemInterface>? = null

		val clipListItemsOrig = _clipListItemsOrig
		if (clipListItemsOrig != null) {
			println("[SwipeableListView] _getClipListItems clipListItems is not null")
			val move = allowMove && Regex("""move""", RegexOption.IGNORE_CASE).containsMatchIn(_viewedClipBehaviour)
			clipListItems = mutableListOf()
			val clipListItemsPlayed: MutableList<ContentItemInterface> = mutableListOf()
			for (item in clipListItemsOrig) {
				println("[SwipeableListView] _getClipListItems item: ${item.id}")
				if (item is Project && !item.isPlayed) {
					val entry = _playHistoryManager?.getProjectEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				} else if (item is MediaClipList && !item.isPlayed) {
					val entry = _playHistoryManager?.getMediaClipListEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				} else if (item is MediaClip && !item.isPlayed) {
					val entry = _playHistoryManager?.getMediaClipEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				}
				if (move && (item as ContentItem).isPlayed) {
					clipListItemsPlayed.add(item)
				} else {
					println("[SwipeableListView] _getClipListItems add item ${item.id}")
					clipListItems.add(item)
				}
			}
			for (item in clipListItemsPlayed) {
				println("[SwipeableListView] _getClipListItems add played item ${item.id}")
				clipListItems.add(item)
			}
		}

		return clipListItems
	}

	private fun _updateClipListItems(items: MutableList<ContentItemInterface>?) {
		// println("[SwipeableListView] _updateClipListItems items: ${items}")
		_clipListItemsOrig = items
		_clipListItems = _getClipListItems(false) // perhaps with played items moved

		_adapter?.updateData(_clipListItems)
	}

	private fun _setClipListItems(items: MutableList<ContentItemInterface>?) {
		// println("[SwipeableListView] _setClipListItems items: ${items}")
		_clipListItemsOrig = items
		_clipListItems = _getClipListItems(true) // perhaps with played items moved

		_recy.adapter = null
		val adapterOld = _adapter
		_adapter = null

		val clipListItems = _clipListItems
		if (clipListItems != null) {
			println("*** *** clipListItems not null")
			_adapter = SwipeableListAdapter(clipListItems)
			_adapter?.listView = this
			_adapter?.programController = _programController
			_adapter?.adoptFromAdapter(adapterOld)
			_adapter?.updateSettings(_settings)
			_recy.adapter = _adapter
			_recy.layoutManager?.scrollToPosition(_currentPos)
			_recy.requestLayout()

			adapterOld?.__destruct()
		}

		if (_playing) {
			if (_previousPos != _currentPos || true) {
				if (_adapter?.updateFromPosToPos(_previousPos, _currentPos) == true) {
					_previousPos = _currentPos
				}
			}
		}
	}

	private fun _updateSkippability(adProgressInSeconds: Double = 0.0) {
		if (_skipOffset >= 0) { // otherwise never skippable
			if (adProgressInSeconds >= _skipOffset && _skipShortsAdOnSwipe)	{
				// re-enable swiping
				_swipingDisabled = false
				_layoutManagerH.isScrollEnabled = true
				_layoutManagerV.isScrollEnabled = true
			} else if (!_skipShortsAdOnSwipe) {
				// disable swiping
				_swipingDisabled = true
			}
		}
	}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["swipeDirection"] == "horizontal") {
			_recy.layoutManager = _layoutManagerH
			_snapHelperV.attachToRecyclerView(null)
			_snapHelperH.attachToRecyclerView(_recy)
			_scrollThreshold = 320 // IMPROVE ME
		} else {
			_recy.layoutManager = _layoutManagerV
			_snapHelperH.attachToRecyclerView(null)
			_snapHelperV.attachToRecyclerView(_recy)
			_scrollThreshold = 640 // IMPROVE ME
		}
		if (settings["viewedClipBehaviour"] is String) _viewedClipBehaviour = settings["viewedClipBehaviour"] as String
		if (settings["ctaUrlField"] is String) _ctaUrlField = settings["ctaUrlField"] as String
		if (settings["ctaButtonLabelField"] is String) _ctaButtonLabelField = settings["ctaButtonLabelField"] as String
		if (settings["skipShortsAdOnSwipe"] is Boolean) _skipShortsAdOnSwipe = settings["skipShortsAdOnSwipe"] as Boolean

		_settings = settings
		_adapter?.updateSettings(_settings)
	}
}

/**
 * @suppress
 */
class MarginItemDecoration2(private val spaceSize: Int) : RecyclerView.ItemDecoration() {
	override fun getItemOffsets(
		outRect: Rect, view: View,
		parent: RecyclerView,
		state: RecyclerView.State
	) {
		with(outRect) {
			left = spaceSize
			right = spaceSize
		}
	}
}