package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.data.Languages
import java.util.*
import kotlin.math.floor

/**
 * @suppress
 */
class EmbargoVariantView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_softembargotimer_started,
			EventName.bb_softembargotimer_tick -> {
				_onTimerTick(data)
			}
			EventName.bb_softembargotimer_cancelled,
			EventName.bb_softembargotimer_finished -> {
				_timeView.text = "" // avoid flashing previous end time
			}
			else -> {}
		}
	}
	/**
	 * @suppress
	 */
	companion object {
		private fun formatRemainingTime(seconds: Number): String {
			val parts: MutableList<String> = mutableListOf() // string[] = [];
			val seconds_ = Math.max(Math.ceil(seconds.toDouble()), 0.0)
			val day = Languages.translate(Locale.getDefault().getLanguage(), "day")
			val days = Languages.translate(Locale.getDefault().getLanguage(), "days")
			var part: Number
			part = floor(seconds_ / (3600 * 24)).toInt(); if (part > 0) { return part.toInt().toString() + " " + if (part > 1) days else day }
			part = floor(seconds_ / 3600).toInt() % 24; if (part > 0) { parts.add(("00$part").takeLast(2)) }
			part = floor(seconds_ / 60).toInt() % 60; parts.add(("00$part").takeLast(2))
			part = floor(seconds_).toInt() % 60; parts.add(("00$part").takeLast(2))

			return parts.joinToString(":")
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _timeView: TextView
	private var _textView: TextView

	// settings
	private var _fontColor = 0xFFFFFFFF.toInt()
	private var _timerHidden = false

	// state
	private var _softEmbargoTime: Long = 0L

	init {
		val inflater = LayoutInflater.from(getContext())
		inflater.inflate(R.layout.embargo_variant_view, this)

		_timeView = findViewById(R.id.embargo_time)
		_textView = findViewById(R.id.embargo_text)
		_textView.text = Languages.translate(Locale.getDefault().getLanguage(), _textView.text.toString())

		_update()
	}

	fun __destruct() {
		// this.removeView(_textView)
		// this.removeView(_timeView)
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["text"] is String) _textView.text = Languages.translate(Locale.getDefault().getLanguage(), settings["text"] as String)
		if (settings["fontColor"] is Int) _fontColor = settings["fontColor"] as Int
		if (settings["timerHidden"] is Boolean) _timerHidden = settings["timerHidden"] as Boolean

		_update()
	}

	private fun _onTimerTick(data: Map<String, Any?>?) {
		// data: { ticks, remainingTime }
		if (data != null && data["remainingTime"] is Double) {
			_softEmbargoTime = Math.round(data["remainingTime"] as Double)
			// Logger.d("EmbargoScreenView", "_onTimerTick time: ${_softEmbargoTime}")
			_timeView.text = formatRemainingTime(_softEmbargoTime)
		}
	}

	private fun _update() {
		val fr: Int = Color.red(_fontColor)
		val fg: Int = Color.green(_fontColor)
		val fb: Int = Color.blue(_fontColor)
		val shadowColor = if (fr + fg + fb < 384) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
		val shadowD = if (fr + fg + fb < 384) -2F else 2F

		_timeView.setTextColor(_fontColor)
		_timeView.setShadowLayer(4F, 2 * shadowD, 2 * shadowD, shadowColor)
		_textView.setTextColor(_fontColor)
		_textView.setShadowLayer(2F, shadowD, shadowD, shadowColor)

		if (_timerHidden) {
			_timeView.visibility = View.GONE
			_textView.visibility = View.GONE
		} else {
			_timeView.visibility = View.VISIBLE
			_textView.visibility = View.VISIBLE
		}

	}
}
