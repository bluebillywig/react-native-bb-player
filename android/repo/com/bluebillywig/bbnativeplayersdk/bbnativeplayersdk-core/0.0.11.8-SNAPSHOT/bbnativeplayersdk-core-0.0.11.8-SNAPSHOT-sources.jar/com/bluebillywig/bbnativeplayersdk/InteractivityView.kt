package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.Logger

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.roundToInt

/**
 * @suppress
 */
class InteractivityView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.bb_media_canplay -> {
                val mediaWidth = if (data != null && data["mediaWidth"] is Int) data["mediaWidth"] as Int else 0
                val mediaHeight = if (data != null && data["mediaHeight"] is Int) data["mediaHeight"] as Int else 0
                Logger.d("InteractivityView", "onEvent bb_media_canplay ${mediaWidth}x${mediaHeight}")
                _mediaAspectRatio = if (mediaHeight > 0) mediaWidth.toDouble() / mediaHeight.toDouble() else 1.0
                _updateWebLayout()
            }
            else -> {}
        }
    }
    private var _eventBus: EventBusInterface? = null
    private var _webView = WebView(this.context)
    private var _viewWidth: Int = 0
    private var _viewHeight: Int = 0
    private var _viewAspectRatio: Double = 1.777
    private var _mediaAspectRatio: Double = 1.777

    // settings

    // data

    var eventBus: EventBusInterface?
        get() = _eventBus
        set(value) {
            _eventBus?.removeEventlistener(this)
            _eventBus = value
            _eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
        }

    init {
        val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        this.layoutParams = layoutParams

        this.setOrientation(LinearLayout.VERTICAL) // default
        this.setPadding(0, 0, 0, 0)
        this.setVerticalGravity(Gravity.CENTER_VERTICAL)
        this.setHorizontalGravity(Gravity.CENTER)

        _viewWidth = this.width
        _viewHeight = this.height
        _viewAspectRatio = if (_viewHeight > 0) _viewWidth.toDouble() / _viewHeight.toDouble() else 1.0
        _updateWebLayout()

        _webView.setBackgroundColor(0)
        _webView.getSettings()?.setJavaScriptEnabled(true)
        _webView.getSettings()?.setMediaPlaybackRequiresUserGesture(false) // requires Build.VERSION.SDK_INT > 16
        _webView.getSettings()?.setDomStorageEnabled(true)
        // _webView.getSettings()?.setAppCacheEnabled(true)
        // _webView.getSettings()?.setDatabaseEnabled(true)
        _webView.id = View.generateViewId()
        this.addView(_webView)
        // this.clipChildren
    }

    fun __destruct() {
        this.removeView(_webView)
        _webView.destroy()
        _eventBus?.removeEventlistener(this)
        _eventBus = null
    }

    val webView: WebView
        get() = _webView

    fun addJavascriptInterface(iface: BBNativeWebBridge, name: String) {
        _webView.addJavascriptInterface(iface, name)
    }

    fun removeJavascriptInterface(name: String) {
        _webView.removeJavascriptInterface(name)
    }

    fun loadUrl(url: String) {
        _webView.loadUrl(url)
    }

    fun stopLoading() {
        _webView.stopLoading()
    }

    fun goBack() {
        _webView.goBack()
    }

    fun clearHistory() {
        _webView.clearHistory()
    }

    /**
     * @suppress
     */
    public override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val wmsSize = MeasureSpec.getSize(widthMeasureSpec)
        val hmsSize = MeasureSpec.getSize(heightMeasureSpec)
        _viewWidth = wmsSize.toInt()
        _viewHeight = hmsSize.toInt()
        _viewAspectRatio = if (_viewHeight > 0) _viewWidth.toDouble() / _viewHeight.toDouble() else 1.0
        _updateWebLayout()

        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    fun _updateWebLayout() {
        var webWidth = _viewWidth
        var webHeight = _viewHeight
        if (_viewAspectRatio > _mediaAspectRatio) {
            // this.setOrientation(LinearLayout.HORIZONTAL) // obsolete?
            webWidth = (_viewHeight.toDouble() * _mediaAspectRatio).roundToInt()
        } else {
            // this.setOrientation(LinearLayout.VERTICAL) // obsolete?
            webHeight = (_viewWidth.toDouble() / _mediaAspectRatio).roundToInt()
        }
        if (webWidth > 0 && webHeight > 0) {
            val webLayoutParams = _webView?.layoutParams ?: ViewGroup.MarginLayoutParams(webWidth, webHeight)
            webLayoutParams.width = webWidth
            webLayoutParams.height = webHeight
            _webView?.layoutParams = webLayoutParams
        }
    }
}
