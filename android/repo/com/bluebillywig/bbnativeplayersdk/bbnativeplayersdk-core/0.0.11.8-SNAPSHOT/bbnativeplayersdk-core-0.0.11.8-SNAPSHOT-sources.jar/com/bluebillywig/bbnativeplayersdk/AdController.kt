package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import androidx.annotation.OptIn
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.enums.PosType
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.AdControllerInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.google.ads.interactivemedia.v3.api.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ima.ImaAdsLoader
import androidx.media3.common.util.Util

/**
 * @suppress
 */
class AdController(context: Context, eventBus: EventBusInterface?) : AdEvent.AdEventListener, Player.Listener, AdControllerInterface, EventListenerInterface {
	@OptIn(UnstableApi::class)
	override fun onAdEvent(p0: AdEvent) {
		when (p0.type) {
			AdEvent.AdEventType.LOADED -> {
				Logger.d("AdController", "ad loaded")
				_loaded = true
				_ad = p0.ad
				_eventBus?.trigger(EventName.adLoaded, _getAdEventData())

				val adDisplayContainer = adsLoader?.getAdDisplayContainer()
				if (adDisplayContainer != null) {
					_friendlyObstructions.forEach {
						adDisplayContainer.registerFriendlyObstruction(it)
					}
				}
			}
			AdEvent.AdEventType.STARTED -> {
				Logger.d("AdController", "ad started")
				if (_loaded) {
					if (!_canplay) {
						_canplay = true
						_eventBus?.trigger(EventName.adCanPlay, _getAdEventData())
					}
					if (_pendingPlay) {
						_pendingPlay = false
						_player?.play()
					}
				}
				_eventBus?.trigger(EventName.adStarted, _getAdEventData())
			}
			AdEvent.AdEventType.FIRST_QUARTILE -> {
				Logger.d("AdController", "ad reached first quartile")
				_eventBus?.trigger(EventName.adFirstQuartile, _getAdEventData())
			}
			AdEvent.AdEventType.MIDPOINT -> {
				Logger.d("AdController", "ad reached second quartile")
				_eventBus?.trigger(EventName.adMidPoint, _getAdEventData())
			}
			AdEvent.AdEventType.THIRD_QUARTILE -> {
				Logger.d("AdController", "ad reached third quartile")
				_eventBus?.trigger(EventName.adThirdQuartile, _getAdEventData())
			}
			AdEvent.AdEventType.COMPLETED -> {
				Logger.d("AdController", "ad completed")
				_loaded = false
				_canplay = false
				_eventBus?.trigger(EventName.adComplete, _getAdEventData())
			}
			AdEvent.AdEventType.ALL_ADS_COMPLETED -> {
				Logger.d("AdController", "all ads completed")
				_loaded = false
				_canplay = false
				_eventBus?.trigger(EventName.allAdsCompleted)
			}
			AdEvent.AdEventType.CLICKED, AdEvent.AdEventType.TAPPED -> {
				Logger.d("AdController", "ad clicked")
				_eventBus?.trigger(EventName.adClicked, _getAdEventData())
			}
			AdEvent.AdEventType.SKIPPED -> {
				Logger.d("AdController", "ad skipped")
				_loaded = false
				_canplay = false
				_eventBus?.trigger(EventName.adSkipped, _getAdEventData())
			}
			AdEvent.AdEventType.CONTENT_PAUSE_REQUESTED -> {
				Logger.d("AdController", "content pause requested")
				if (_mode != "SHORTS") _eventBus?.trigger(EventName.adContentPauseReq)
			}
			AdEvent.AdEventType.CONTENT_RESUME_REQUESTED -> {
				Logger.d("AdController", "content resume requested")
				if (_mode != "SHORTS") _eventBus?.trigger(EventName.adContentResumeReq)
			}
			AdEvent.AdEventType.PAUSED -> {
				Logger.d("AdController", "ad paused")
				_eventBus?.trigger(EventName.adPaused)
			}
			AdEvent.AdEventType.RESUMED -> {
				Logger.d("AdController", "ad resumed")
				_eventBus?.trigger(EventName.adResumed)
			}
			AdEvent.AdEventType.AD_PROGRESS -> {
				_eventBus?.trigger(EventName.adProgress, mapOf("adPosition" to _player?.currentPosition, "adDuration" to _player?.duration))
			}
			else -> return
		}
	}

	override fun skipAd() {
		if (_ad?.isSkippable == true) {
			Logger.d("AdController", "skipAd ad is skippable")
			adsLoader?.skipAd()
		} else {
			Logger.d("AdController", "skipAd ad is *not* skippable")
			pause()

			_resetAdsLoader()

			Logger.d("AdController", "FAKE ad skipped")
			_loaded = false
			_canplay = false
			_eventBus?.trigger(EventName.adSkipped, _getAdEventData())
//			Logger.d("AdController", "FAKE content resume requested")
//			if (_mode != "SHORTS") _eventBus?.trigger(EventName.adContentResumeReq)
		}
	}

	override fun onPlaybackStateChanged(state: Int) {
		Logger.d("AdController", "onPlaybackStateChanged $state")
		when (state) {
			Player.STATE_IDLE -> {
				// nothing
			}
			Player.STATE_BUFFERING -> {
				// nothing
			}
			Player.STATE_READY -> {
				if (_loaded) {
					if (!_canplay) {
						_canplay = true
						_eventBus?.trigger(EventName.adCanPlay, _getAdEventData())
					}
					if (_pendingPlay) {
						_pendingPlay = false
						_player?.play()
					}
				}
			}
			Player.STATE_ENDED -> {
				// nothing
			}
		}
	}

	internal var adsLoader: ImaAdsLoader? = null
	internal var adsManager: AdsManager? = null

	private var _eventBus: EventBusInterface? = eventBus
	private var _sdkFactory: ImaSdkFactory
	private var _companionAdSlot: CompanionAdSlot
	private var _companionAdSlots: ArrayList<CompanionAdSlot>
	private var _player: ExoPlayer? = null
	private var _emptyMediaItem: MediaItem = MediaItem.Builder().setUri("asset:///blank.mp3").build()
	private var _friendlyObstructions: MutableList<FriendlyObstruction> = mutableListOf()

	// settings
	private var _ppid: String? = null

	// state
	private var _mode: String = ""
	private var _posString: String = ""
	private var _loaded = false
	private var _canplay = false
	private var _pendingPlay = false
	private var _volume = 1.0
	private var _masterMuted = false
	private var _masterVolume = 1.0

	private var _context: Context? = null

	// data
	private var _ad: Ad? = null

	init {
		Logger.d("AdController", "init")
		_context = context
		_sdkFactory = ImaSdkFactory.getInstance()
		_eventBus?.addEventlistener(this)
		_companionAdSlot = _sdkFactory.createCompanionAdSlot()
		_companionAdSlot.setSize(300, 250)
		_companionAdSlots = ArrayList<CompanionAdSlot>()
		_companionAdSlots.add(_companionAdSlot)
		adsLoader = ImaAdsLoader.Builder(_context!!)
			.setAdEventListener(this)
			.setAdUiElements(setOf<UiElement>())
			.setCompanionAdSlots(_companionAdSlots)
			.setAdErrorListener {
				Logger.d("AdController", "init: Found IMA ad error: ${it.error.message}")
				_eventBus?.trigger(EventName.adFailed)
			}
			.build()
	}

	fun __destruct() {
		Logger.d("AdController", "__destruct")
		adsLoader?.setPlayer(null)
		adsLoader?.release()
		adsLoader = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	fun setPlayer(player: ExoPlayer?) {
		Logger.d("AdController", "attaching player $player")
		_player?.removeListener(this)
		_player = player
		_player?.addListener(this)
		adsLoader?.setPlayer(_player)
	}

	fun setCompanionAdSlotContainer(companionAdSlotViewGroup: ViewGroup?) {
		Logger.d("AdController", "attaching companion ad slot view $companionAdSlotViewGroup")
		if (companionAdSlotViewGroup != null) {
			_companionAdSlot.container = companionAdSlotViewGroup
		}
	}

	fun registerFriendlyObstruction(obstruction: FriendlyObstruction) {
		_friendlyObstructions.add(obstruction)

		val adDisplayContainer = adsLoader?.getAdDisplayContainer()
		if (adDisplayContainer != null) {
			_friendlyObstructions.forEach {
				adDisplayContainer.registerFriendlyObstruction(it)
			}
		}
	}

	fun unregisterAllFriendlyObstructions() {
		val adDisplayContainer = adsLoader?.getAdDisplayContainer()
		if (adDisplayContainer != null) {
			adDisplayContainer.unregisterAllFriendlyObstructions()
		}

		_friendlyObstructions.clear()
	}

	override fun set(propertyName: String, propertyValue: Any?): Boolean {
		if (propertyName == "mode" && propertyValue is String) {
			_mode = propertyValue as String
		}
		return false
	}

	override fun get(propertyName: String): Any? {
		return false
	}

	private fun _load (vastUrl: String?, pos: PosType): Boolean {
		Logger.d("AdController", "_load: url = $vastUrl position = $pos")
		_loaded = false
		_canplay = false
		_posString = pos.toString()
		if (vastUrl !== null) {
			val vastXml = vastUrl.trim()
			val isVastXml = vastXml.startsWith("<") // quick test
			val adsConfiguration = if (isVastXml) {
				MediaItem.AdsConfiguration.Builder(Util.getDataUriForString("text/xml", vastXml)).build()
			} else {
				MediaItem.AdsConfiguration.Builder(Uri.parse(vastUrl)).build()
			}

			val mediaItem: MediaItem
			var mediaItemCount = _player?.mediaItemCount ?: 0
			val mediaItemList = mutableListOf<MediaItem>()
			val addToMediaItem: Boolean

			when(pos) {
				PosType.PREROLL,
				PosType.LEADER -> {
					addToMediaItem = true
				}
				PosType.INARTICLE -> {
					mediaItemCount = 0
					addToMediaItem = true
				}
				PosType.VMAP,
				PosType.MIDROLL,
				PosType.OVERLAY -> {
					addToMediaItem = true
				}
				PosType.POSTROLL,
				PosType.EXITSCREEN -> {
					addToMediaItem = false
				}
				else -> addToMediaItem = false
			}

			if (mediaItemCount > 0) {
				var firstItem: MediaItem? = null
				var nextPlayableItem = 0
				for (i in 0..mediaItemCount.minus(1)) {
					val item = _player?.getMediaItemAt(i)
					if (item !== null) {
						firstItem = item
						nextPlayableItem = i + 1
						break
					}
				}

				for (i in nextPlayableItem..mediaItemCount.minus(1)) {
					val item = _player?.getMediaItemAt(i)
					if (item !== null) {
						mediaItemList.add(item)
					}
				}

				if (firstItem !== null) {
					if (addToMediaItem) {
						mediaItem = firstItem.buildUpon().setAdsConfiguration(adsConfiguration).build() // setAdTagUri(vastUrl).build()
					} else {
						mediaItem = firstItem
						mediaItemList.add(
							0,
							_emptyMediaItem.buildUpon().setAdsConfiguration(adsConfiguration).build() // setAdTagUri(vastUrl).build()
						)
					}
				} else {
					mediaItem = _emptyMediaItem.buildUpon().setAdsConfiguration(adsConfiguration).build() // setAdTagUri(vastUrl).build()
				}
			} else {
				mediaItem = _emptyMediaItem.buildUpon().setAdsConfiguration(adsConfiguration).build() // setAdTagUri(vastUrl).build()
			}

			_player?.setMediaItem(mediaItem)
			if (mediaItemList.size > 0) {
				_player?.addMediaItems(mediaItemList)
			}
			_player?.playWhenReady = false
			_player?.prepare()
			_eventBus?.trigger(EventName.adInitialized)
		} else {
			_resetAdsLoader()

			_loaded = false
			_canplay = false
			_eventBus?.trigger(EventName.adNoAd)
		}

		return false
	}

	override fun loadAdTagUrl(vastUrl: String?, pos: PosType): Boolean {
		Logger.d("AdController", "loadAdTagUrl: url = $vastUrl position = $pos")
		return _load(vastUrl, pos)
	}

	override fun loadAdsResponse(vastXml: String?, pos: PosType): Boolean {
		Logger.d("AdController", "loadAdsResponse: xml = $vastXml position = $pos")
		return _load(vastXml, pos)
	}

	override fun play(): Boolean {
		Logger.d("AdController", "play while loaded = ${_loaded} and canPlay = ${_canplay}")
		if (_loaded) {
			if (_canplay) {
				_pendingPlay = false
				Logger.d("AdController", "going to play player")
				_player?.play()
			} else {
				_pendingPlay = true
			}
		}
		return true
	}

	override fun pause(): Boolean {
		Logger.d("AdController", "pause while loaded = ${_loaded} and canPlay = ${_canplay}")
		if (_loaded) {
			if (_canplay) {
				_pendingPlay = false
				Logger.d("AdController", "going to pause player")
				_player?.pause()
			} else {
				_pendingPlay = false
			}
		}
		return true
	}

	override fun onEvent(eventType: EventName, data: Map<String,Any?>?) {
		// Logger.d("AdController", "onEvent: event = $eventType")
		when(eventType) {
			EventName.bb_embed_loaded -> {
				val imaSettings = ImaSdkFactory.getInstance().createImaSdkSettings()
				if (data != null && data["options"] != null && data["options"] is Map<*,*>) {
					val options = data["options"] as Map<String,Any?>
					if (options["adsystem_ppid"] is String) {
						_ppid = options["adsystem_ppid"] as String
						Logger.d("AdController", "Got ppid from options: ${_ppid}")

						_resetAdsLoader()
					}
				}
			}
			EventName.bb_master_mute -> {
				val volume = _player?.getVolume() ?: 0F
				if (volume > 0F && _masterVolume > 0.0) _volume = volume.toDouble() / _masterVolume
				_masterMuted = true
				// will be effectuated by MediaController
			}
			EventName.bb_master_unmute -> {
				val volume = _player?.getVolume() ?: 0F
				if (volume > 0F && _masterVolume > 0.0) _volume = volume.toDouble() / _masterVolume
				_masterMuted = false
				// will be effectuated by MediaController
			}
			EventName.bb_master_volume -> {
				val volume = _player?.getVolume() ?: 0F
				if (volume > 0F && _masterVolume > 0.0) _volume = volume.toDouble() / _masterVolume
				_masterVolume = if (data?.get("volume") is Double) data?.get("volume") as Double else 1.0
				// will be effectuated by MediaController
			}
			else -> return
		}
	}

	private fun _resetAdsLoader() {
		val imaSettings = ImaSdkFactory.getInstance().createImaSdkSettings()
		val ppid = _ppid
		if (ppid != null) imaSettings.ppid = ppid

		adsLoader?.setPlayer(null)
		adsLoader?.release()
		adsLoader = ImaAdsLoader.Builder(_context!!)
			.setAdEventListener(this)
			.setImaSdkSettings(imaSettings)
			.setAdUiElements(setOf<UiElement>())
			.setCompanionAdSlots(_companionAdSlots)
			.setAdErrorListener {
				Logger.d("AdController", "onEvent: Found IMA ad error: ${it.error.message}")
				_eventBus?.trigger(EventName.adFailed)
			}
			.build()
		adsLoader?.setPlayer(_player)
	}

	private fun _getAdEventData(): Map<String, Any?> {
		val data: MutableMap<String, Any?> = mutableMapOf(
			"adId" to _ad?.adId,
			"adSystem" to _ad?.adSystem,
			"adTitle" to _ad?.title,
			"adLinear" to _ad?.isLinear,
			"adContentType" to _ad?.contentType,
			"duration" to _ad?.duration,
			"pos" to _posString,
			"sdk" to "GOOGLE_IMA")
		if (_ad?.vastMediaWidth != null) data["vastMediaWidth"] = _ad?.vastMediaWidth
		if (_ad?.vastMediaHeight != null) data["vastMediaHeight"] = _ad?.vastMediaHeight
		if (_ad?.adWrapperCreativeIds != null) data["adWrapperAdIds"] = _ad?.adWrapperCreativeIds
		if (_ad?.adWrapperIds != null) data["adWrapperAdIds"] = _ad?.adWrapperIds
		if (_ad?.adPodInfo != null) {
			data["adPodInfo"] = mapOf(
				"adPosition" to _ad?.adPodInfo?.adPosition,
				"isBumper" to _ad?.adPodInfo?.isBumper,
				"maxDuration" to _ad?.adPodInfo?.maxDuration,
				"podIndex" to _ad?.adPodInfo?.podIndex,
				"timeOffset" to _ad?.adPodInfo?.timeOffset,
				"totalAds" to _ad?.adPodInfo?.totalAds
			)
		}
		if (_ad?.surveyUrl != null) data["adSurveyUrl"] = _ad?.surveyUrl
		if (_ad?.traffickingParameters != null) data["traffickingParameters"] = _ad?.traffickingParameters
		if (_ad?.advertiserName != null) data["advertiserName"] = _ad?.advertiserName
		if (_ad?.isSkippable != null) data["isSkippable"] = _ad?.isSkippable
		if (_ad?.skipTimeOffset != null) data["skipTimeOffset"] = _ad?.skipTimeOffset
		// _ad?.companionAds throws NullPointerException; see: https://groups.google.com/g/ima-sdk/c/ccoWV9pDwFQ

		val ad = _ad
		if (ad != null) {
			try {
				val getClickThruUrl = ad.javaClass.getDeclaredMethod("getClickThruUrl")
				data["clickThroughUrl"] = getClickThruUrl.invoke(ad)
			} catch (er: Exception) {}
		}

		return data.toMap()
	}
}
