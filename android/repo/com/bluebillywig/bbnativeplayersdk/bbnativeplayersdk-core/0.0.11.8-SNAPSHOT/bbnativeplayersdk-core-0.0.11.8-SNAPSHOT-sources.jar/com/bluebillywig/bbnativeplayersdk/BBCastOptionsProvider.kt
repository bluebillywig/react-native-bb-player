package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

/**
 * @suppress
 */
class BBCastOptionsProvider : OptionsProvider {
	override fun getCastOptions(context: Context): CastOptions {
		return CastOptions.Builder()
			.setReceiverApplicationId("1F61A3A5") // Blue Billywig Cast Receiver (was: F1035086)
			.setEnableReconnectionService(true)
			.build()
	}

	override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? {
		return null
	}
}
