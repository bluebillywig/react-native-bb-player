package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebView
import android.widget.LinearLayout
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface


/**
 * @suppress
 */
class ErrorDisplayView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			else -> {}
		}
	}
	private var _eventBus: EventBusInterface? = null
	private var _webView = WebView(this.context)

	// settings
	private var _publicationName: String? = null
	private var _violation: String? = null
	private var _baseUrl: String? = null
	private var _cpp: String? = null
	private var _jwt: String = ""
	private var _rpcToken: String = ""
	private var _bbCpJwtCookieString: String = ""

	// data

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	init {
		this.setOrientation(LinearLayout.VERTICAL) // default
		this.setPadding(0, 0, 0, 0)
		this.setVerticalGravity(Gravity.CENTER_VERTICAL)
		this.setHorizontalGravity(Gravity.CENTER)

		_webView.setBackgroundColor(0)
		_webView.getSettings()?.setJavaScriptEnabled(true) // needed for web components
		_webView.getSettings()?.setDomStorageEnabled(true) // sometimes needed for web components
//		val userAgent = webView.settings.userAgentString
//		println("$$$$ WebView User agent: $userAgent")
		val webLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		_webView.layoutParams = webLayoutParams
		_webView.visibility = View.VISIBLE
		_webView.id = View.generateViewId()
		this.addView(_webView)
	}

	fun __destruct() {
		_webView.stopLoading()
		this.removeView(_webView)
		_webView.destroy()
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	val webView: WebView
		get() = _webView

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["publicationName"] is String) _publicationName = settings["publicationName"] as String
		if (settings["violation"] is String) _violation = settings["violation"] as String
		if (settings["baseUrl"] is String) _baseUrl = settings["baseUrl"] as String
		if (settings["cpp"] is String) _cpp = settings["cpp"] as String
		if (settings["jwt"] is String) _jwt = settings["jwt"] as String
		if (settings["rpcToken"] is String) _rpcToken = settings["rpcToken"] as String
		if (settings["bbCpJwtCookieString"] is String) _bbCpJwtCookieString = settings["bbCpJwtCookieString"] as String

		_updateWebview()
	}

	fun stopLoading() {
		_webView.stopLoading()
	}

	fun goBack() {
		_webView.goBack()
	}

	fun clearHistory() {
		_webView.clearHistory()
	}

	private fun _updateWebview() {
		var wcUrl = "https://cdn.bluebillywig.com/apps/bb-components/latest/lib/bb-cp-overlay.wc.js"
		val env = _publicationName?.split(".")?.get(1) ?: "prod"
		if (arrayOf("dev", "acc", "test").contains(env)) wcUrl = wcUrl.replace("//cdn.", "//cdn-${env}.")

		val html = """<!DOCTYPE html>
			<html style="height: 100%; margin: 0;">
			<head><script type="module" src="$wcUrl"></script></head>
			<body style="height: 100%; margin: 0;">
			<bb-cp-overlay id="myComponent" style="width: 100%; height: 100%;"></bb-cp-overlay>
			<script type="text/javascript"><!-- // hide
				if ('${_jwt}') window.localStorage.setItem('bbtl_jwt', '${_jwt}');
				if ('${_rpcToken}') window.localStorage.setItem('bbtl_rpctoken', '${_rpcToken}');
				const myComponent = document.getElementById('myComponent');
				myComponent.violations = ['${_violation}'];
				myComponent.cpConfigID = '${_cpp}';
				myComponent.baseurl = '${_baseUrl}';
			// --></script>
			</body></html>""".trimMargin()
		if (_bbCpJwtCookieString != "") CookieManager.getInstance().setCookie(_baseUrl, _bbCpJwtCookieString) // "BB_CP_JWT=<jwt>; path=/cpp/<cpp>"
		_webView.loadDataWithBaseURL(_baseUrl, html, "text/html", "UTF-8", "")
	}
}
