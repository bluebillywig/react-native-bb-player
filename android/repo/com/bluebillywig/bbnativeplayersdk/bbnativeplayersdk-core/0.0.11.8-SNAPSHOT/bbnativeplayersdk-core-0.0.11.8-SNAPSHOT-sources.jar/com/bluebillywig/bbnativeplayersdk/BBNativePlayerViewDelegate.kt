package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.State

import com.bluebillywig.bbnativeshared.model.Project
import com.bluebillywig.bbnativeshared.model.MediaClip

/**
 * BBNativePlayerViewDelegate
 *   is what you implement to act as BBNativePlayerView's delegate.
 */
interface BBNativePlayerViewDelegate {
    fun didSetupWithJsonUrl(playerView: BBNativePlayerView, url: String?) { /* optional */ }
    fun didFailWithError(playerView: BBNativePlayerView, error: String?) { /* optional */ }
    fun didTriggerApiReady(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAutoPause(playerView: BBNativePlayerView, why: String?) { /* optional */ }
    fun didTriggerAutoPausePlay(playerView: BBNativePlayerView, why: String?) { /* optional */ }
    fun didTriggerPlay(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerProjectLoaded(playerView: BBNativePlayerView, projectData: Project?) { /* optional */ }
    fun didTriggerMediaClipLoaded(playerView: BBNativePlayerView, clipData: MediaClip?) { /* optional */ }
    fun didTriggerMediaClipFailed(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerViewStarted(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerViewFinished(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerCanPlay(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerDurationChange(playerView: BBNativePlayerView, duration: Double?) { /* optional */ }
    fun didTriggerVolumeChange(playerView: BBNativePlayerView, volume: Double?) { /* optional */ }
    fun didTriggerPlaying(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerPause(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerEnded(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerSeeking(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerSeeked(playerView: BBNativePlayerView, seekOffset: Double?) { /* optional */ }
    fun didTriggerPhaseChange(playerView: BBNativePlayerView, phase: Phase?) { /* optional */ }
    fun didTriggerStateChange(playerView: BBNativePlayerView, state: State?) { /* optional */ }
    fun didTriggerModeChange(playerView: BBNativePlayerView, mode: String?) { /* optional */ }
    fun didTriggerStall(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerFullscreen(playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerRetractFullscreen(playerView: BBNativePlayerView) { /* optional */ }

    fun didRequestCollapse(playerView: BBNativePlayerView) { /* optional */ }
    fun didRequestExpand(playerView: BBNativePlayerView) { /* optional */ }
    fun didRequestOpenUrl(playerView: BBNativePlayerView, url: String?) { /* optional */ }


    fun didTriggerAdLoadStart( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdLoaded( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdNotFound( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdError(playerView: BBNativePlayerView, error: String?) { /* optional */ }
    fun didTriggerAdStarted( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdQuartile1( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdQuartile2( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdQuartile3( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAdFinished( playerView: BBNativePlayerView) { /* optional */ }
    fun didTriggerAllAdsCompleted( playerView: BBNativePlayerView) { /* optional */ }

    fun didTriggerCustomStatistics( playerView: BBNativePlayerView, ident: String, ev: String, aux: Map<String,String>) { /* optional */ }

    fun didCloseModalPlayer(playerView: BBNativePlayerView) { /* optional */ }
}
