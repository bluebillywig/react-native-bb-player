package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.LinearLayout

/**
 * @suppress
 */
class ScrubberPreviewScreenView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {
    private var _timeBarPreview = YouTubeTimeBarPreview(context, attrs)

    // settings

    // state

    init {
        this.setOrientation(LinearLayout.VERTICAL)
        this.setPadding(16, 16, 16, 16)
        this.setVerticalGravity(Gravity.BOTTOM)
        this.showDividers = SHOW_DIVIDER_MIDDLE

        val childLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        childLayoutParams.bottomMargin = 204

        _timeBarPreview.layoutParams = childLayoutParams
        this.addView(_timeBarPreview)
    }

    fun __destruct() {
        this.removeView(_timeBarPreview)
    }

    val timeBarPreview: YouTubeTimeBarPreview
        get() = _timeBarPreview

}
