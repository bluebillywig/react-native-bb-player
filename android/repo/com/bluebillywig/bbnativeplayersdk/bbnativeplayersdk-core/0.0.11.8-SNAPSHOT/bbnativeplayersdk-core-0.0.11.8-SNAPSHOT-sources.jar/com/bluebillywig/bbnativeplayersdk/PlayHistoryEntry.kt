package com.bluebillywig.bbnativeplayersdk

import java.util.Date

class PlayHistoryEntry {
	var lastTimeOffset: Int = -1
	var maxTimeOffset: Int = -1
	var lastPlayedTS: Long = -1
	var firstPlayedTS: Long = -1
	var lastFinishedTS: Long = -1
	var title: String = ""
}
