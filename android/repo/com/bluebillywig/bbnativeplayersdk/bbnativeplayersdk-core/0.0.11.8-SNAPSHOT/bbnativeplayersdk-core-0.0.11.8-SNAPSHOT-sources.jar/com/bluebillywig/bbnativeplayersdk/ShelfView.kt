package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.util.AttributeSet
import android.util.TypedValue
import android.util.TypedValue.COMPLEX_UNIT_DIP
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.OrientationHelper
import androidx.recyclerview.widget.RecyclerView
import coil3.ImageLoader
import coil3.memory.MemoryCache
import coil3.request.crossfade
import coil3.request.ImageRequest
import coil3.size.Size
import com.benasher44.uuid.uuid4
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.data.ContentLoader
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import com.bluebillywig.bbnativeshared.model.ContentItem
import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.MediaClipList
import com.bluebillywig.bbnativeshared.model.Project
import com.bluebillywig.bbnativeshared.model.Thumbnail
import io.ktor.http.encodeURLParameter


/**
 * @suppress
 */
class ShelfView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr) {
	private val _layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
	private var _adapter: ShelfAdapter? = null
	private val _recy = RecyclerView(context, attrs, defStyleAttr)
	private var _recyShelfItemDecoration: ShelfItemDecoration
	private var _recyConstraints: ConstraintSet
	private val _contentLoader: ContentLoader = ContentLoader()
	private var _jsonUrl: String = ""
	private var _playerOptions: Map<String, Any?> = mapOf()
	private var _playerView: BBNativePlayerView? = null
	private var _playerViewDelegate: BBNativePlayerViewDelegate? = null
	private val _dpm: Float

	// resources
	internal var _imageLoader: ImageLoader = ImageLoader.Builder(context)
		.memoryCache {
			MemoryCache.Builder()
				.maxSizePercent(context, 0.1)
				.build()
		}
		.crossfade(100)
		.build()
	private var _activity: ComponentActivity? = null
	private var _intent: Intent? = null

	// settings
	private var _baseUrl: String = ""
	private var _defaultMediaAssetPath: String = ""
	private var _useThumbsFromMetadata: Boolean = false
	private var _viewedClipBehaviour: String = ""
	private var _showThumbnailDuration: Boolean = false
	private var _showThumbnailTitle: Boolean = false
	private var _useThumbnailsInFullscreen: Boolean = false
	private var _listThumbnailHeight: Int = 302
	private var _listThumbnailHeightResponsive: Boolean = false
	private var _listThumbnailGap: Int = 16
	private var _thumbWidthDp: Float = 170f
	private var _thumbHeightDp: Float = 302f
	private var _shelfItemPadding: Float = 8f
	private var _shelfStartSpacing: Float = 0f
	private var _shelfEndSpacing: Float = 0f
	private var _durationBackgroundColor: String = ""
	private var _showOutlineForUnwatchedClips: Boolean = false
	private var _outlineColor: String = ""
	private var _showPlayIconInTimestamp: Boolean = true
	private var _movingThumbnail: Boolean = false

	// data
	private var _clipListData: MediaClipList? = null

	init {
		_dpm = TypedValue.applyDimension(COMPLEX_UNIT_DIP, 1.0f, this.resources.displayMetrics)

		this.setBackgroundColor(Color.TRANSPARENT)
		this.setId(View.generateViewId())

		val pad = (_shelfItemPadding * _dpm).toInt() // TypedValue.applyDimension(COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt()
		val startPad = (_shelfStartSpacing * _dpm).toInt()
		val endPad = (_shelfEndSpacing * _dpm).toInt()

		_recy.setId(View.generateViewId())
		_recy.layoutManager = _layoutManager
		_recy.setHasFixedSize(true)
		_recy.setBackgroundColor(Color.TRANSPARENT)
		_recy.isNestedScrollingEnabled = true // doesnt hurt and possibly needed when client puts shelf in its own scrolling parent
		_recy.adapter = _adapter

		_recyShelfItemDecoration = ShelfItemDecoration(startPad, endPad, pad)
		_recy.addItemDecoration(_recyShelfItemDecoration)

		// Add scroll listener for preloading thumbnails
		_recy.addOnScrollListener(object : RecyclerView.OnScrollListener() {
			override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
				super.onScrollStateChanged(recyclerView, newState)
				if (newState == RecyclerView.SCROLL_STATE_IDLE) {
					_preloadSurroundingThumbnails()
				}
			}
		})

		this.addView(_recy)

		_recyConstraints = ConstraintSet()
		_recyConstraints.clone(this)
		_recyConstraints.connect(_recy.getId(), ConstraintSet.BOTTOM, this.getId(), ConstraintSet.BOTTOM, 0) // was: 200
		_recyConstraints.connect(_recy.getId(), ConstraintSet.LEFT, this.getId(), ConstraintSet.LEFT, 0) // was: 60
		_recyConstraints.connect(_recy.getId(), ConstraintSet.RIGHT, this.getId(), ConstraintSet.RIGHT, 0) // was: 50
		val thumbHeight = (_thumbHeightDp * _dpm).toInt() // TypedValue.applyDimension(COMPLEX_UNIT_DIP, _thumbHeightDp, resources.displayMetrics).toInt()
		_recyConstraints.constrainHeight(_recy.getId(), thumbHeight)
		_recyConstraints.applyTo(this) // NB!
	}

	fun __destruct() {
		_recy.adapter = null
		_adapter?.__destruct()
		_adapter = null

		// Clear Coil image cache
		_imageLoader.memoryCache?.clear()

		this.removeAllViews()
	}

	var network: NetworkInterface?
		get() = _contentLoader?.network
		set(value) {
			_contentLoader?.network = value
		}

	var jsonUrl: String
		get() = _jsonUrl
		set(value) {
			_jsonUrl = value
			Logger.d("ShelfView", "loading: " + _jsonUrl)
			_contentLoader.getObjectFromJsonUrl<EmbedObject>(_jsonUrl, { _loadObjectSuccess(it) }, { _loadObjectFailure(it) })

			val modifiedPlayerOptions = _playerOptions.toMutableMap()
			modifiedPlayerOptions["initiator"] = "Shorts Shelf" // obsolete, since listOffset -1
			modifiedPlayerOptions["listOffset"] = -1
			modifiedPlayerOptions["autoPlay"] = true
			_playerView = BBNativePlayer.createPlayerView(context, _jsonUrl, modifiedPlayerOptions)
			_playerView?.delegate = _playerViewDelegate
		}

	var playerOptions: Map<String, Any?>
		get() = _playerOptions
		set(value) {
			_playerOptions = value
		}

	var playerViewDelegate: BBNativePlayerViewDelegate?
		get() = _playerViewDelegate
		set(value) {
			_playerView?.delegate = null
			_playerViewDelegate = value
			_playerView?.delegate = _playerViewDelegate
		}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["baseUrl"] is String) _baseUrl = settings["baseUrl"] as String
		if (settings["defaultMediaAssetPath"] is String) _defaultMediaAssetPath = settings["defaultMediaAssetPath"] as String
		if (settings["useThumbsFromMetadata"] is Boolean) _useThumbsFromMetadata = settings["useThumbsFromMetadata"] as Boolean
		if (settings["viewedClipBehaviour"] is String) _viewedClipBehaviour = settings["viewedClipBehaviour"] as String
		if (settings["showThumbnailDuration"] is Boolean) _showThumbnailDuration = settings["showThumbnailDuration"] as Boolean
		if (settings["showThumbnailTitle"] is Boolean) _showThumbnailTitle = settings["showThumbnailTitle"] as Boolean
		if (settings["useThumbnailsInFullscreen"] is Boolean) _useThumbnailsInFullscreen = settings["useThumbnailsInFullscreen"] as Boolean
		if (settings["durationBackgroundColor"] is String) _durationBackgroundColor = settings["durationBackgroundColor"] as String
		if (settings["showOutlineForUnwatchedClips"] is Boolean) _showOutlineForUnwatchedClips = settings["showOutlineForUnwatchedClips"] as Boolean
		if (settings["outlineColor"] is String) _outlineColor = settings["outlineColor"] as String
		if (settings["showPlayIconInTimestamp"] is Boolean) _showPlayIconInTimestamp = settings["showPlayIconInTimestamp"] as Boolean
		if (settings["movingThumbnail"] is Boolean) _movingThumbnail = settings["movingThumbnail"] as Boolean

		if (settings["listThumbnailGap"] is Int) {
			_listThumbnailGap = settings["listThumbnailGap"] as Int
			_shelfItemPadding = _listThumbnailGap.toFloat() / 2F
		}
		if (settings["shelfStartSpacing"] is Int) {
			_shelfStartSpacing = (settings["shelfStartSpacing"] as Int).toFloat()
		}
		if (settings["shelfEndSpacing"] is Int) {
			_shelfEndSpacing = (settings["shelfEndSpacing"] as Int).toFloat()
		}
		
		val pad = (_shelfItemPadding * _dpm).toInt()
		val startPad = (_shelfStartSpacing * _dpm).toInt()
		val endPad = (_shelfEndSpacing * _dpm).toInt()

		_recy.removeItemDecoration(_recyShelfItemDecoration)
		_recyShelfItemDecoration = ShelfItemDecoration(startPad, endPad, pad)
		_recy.addItemDecoration(_recyShelfItemDecoration)

		if (settings["listThumbnailHeight"] is Int) _listThumbnailHeight = settings["listThumbnailHeight"] as Int
		if (settings["listThumbnailHeightResponsive"] is Boolean) _listThumbnailHeightResponsive = settings["listThumbnailHeightResponsive"] as Boolean
		_thumbHeightDp = _listThumbnailHeight.toFloat()
		_thumbWidthDp = ((_thumbHeightDp / 16.0f) * 9.0f)
		var shelfViewHeight = this.height
		if (shelfViewHeight <= 0) shelfViewHeight = (this.parent as ViewGroup).height
		// println("[ShelfView] updateSettings shelfViewHeight: ${shelfViewHeight}")
		if (shelfViewHeight > 0 && _listThumbnailHeightResponsive) {
			_thumbHeightDp = (shelfViewHeight.toFloat() / _dpm) //  - 32f
			_thumbWidthDp = ((_thumbHeightDp / 16.0f) * 9.0f)
		}
		// println("[ShelfView] updateSettings calculated thumbWidthDp: ${_thumbWidthDp}")
		// println("[ShelfView] updateSettings calculated thumbHeightDp: ${_thumbHeightDp}")

		val thumbHeight = (_thumbHeightDp * _dpm).toInt() // TypedValue.applyDimension(COMPLEX_UNIT_DIP, _thumbHeightDp, resources.displayMetrics).toInt()
		_recyConstraints.constrainHeight(_recy.getId(), thumbHeight)
		_recyConstraints.applyTo(this) // NB!

		_adapter?.updateSettings(mapOf(
			"viewedClipBehaviour" to _viewedClipBehaviour,
			"showThumbnailDuration" to _showThumbnailDuration,
			"showThumbnailTitle" to _showThumbnailTitle,
			"thumbWidthDp" to _thumbWidthDp,
			"thumbHeightDp" to _thumbHeightDp,
			"dpm" to _dpm,
			"durationBackgroundColor" to _durationBackgroundColor,
			"showOutlineForUnwatchedClips" to _showOutlineForUnwatchedClips,
			"outlineColor" to _outlineColor,
			"showPlayIconInTimestamp" to _showPlayIconInTimestamp,
			"movingThumbnail" to _movingThumbnail
		)) // Map<String, Any?>

		// _update()
	}

	private fun _loadObjectSuccess(data: EmbedObject?): Unit {
		println("[ShelfView] _loadObjectSuccess")
		_clipListData = data?.clipListData
		val clipListItems = _itemsFromClipListData()

		_recy.adapter = null
		_adapter?.__destruct()
		_adapter = null
		if (clipListItems != null) {
			_adapter = ShelfAdapter(clipListItems)
			_adapter?.shelfView = this
			_adapter?.updateSettings(mapOf(
				"viewedClipBehaviour" to _viewedClipBehaviour,
				"showThumbnailDuration" to _showThumbnailDuration,
				"showThumbnailTitle" to _showThumbnailTitle,
				"thumbWidthDp" to _thumbWidthDp,
				"thumbHeightDp" to _thumbHeightDp,
				"dpm" to _dpm,
				"durationBackgroundColor" to _durationBackgroundColor,
				"showOutlineForUnwatchedClips" to _showOutlineForUnwatchedClips,
				"outlineColor" to _outlineColor,
				"showPlayIconInTimestamp" to _showPlayIconInTimestamp,
				"movingThumbnail" to _movingThumbnail
			)) // Map<String, Any?>
			_recy.adapter = _adapter
		}
	}

	private fun _loadObjectFailure(error: Exception?): Unit {
		println("[ShelfView] _loadObjectFailure")
		_recy.adapter = null
		_adapter?.__destruct()
		_adapter = null
	}

	private fun _itemsFromClipListData (): MutableList<ContentItemInterface>? {
		var clipListItems: MutableList<ContentItemInterface>? = null

		if (_clipListData?.items is List<*>) {
			// println("[ShelfView] _itemsFromClipListData clipListData is MediaClipList && clipListData.items is List<*>")
			val move = Regex("""move""", RegexOption.IGNORE_CASE).containsMatchIn(_viewedClipBehaviour)
			val items = _clipListData?.items as List<ContentItem>
			clipListItems = mutableListOf()
			val clipListItemsPlayed: MutableList<ContentItemInterface> = mutableListOf()
			for (item in items) {
				println("[ShelfView] _itemsFromClipListData item: ${item.id}")
				if (item is Project) {
					val entry = _playerView?.playHistoryManager?.getProjectEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				} else if (item is MediaClipList) {
					val entry = _playerView?.playHistoryManager?.getMediaClipListEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				} else if (item is MediaClip) {
					val entry = _playerView?.playHistoryManager?.getMediaClipEntry(item.id ?: "0")
					item.isPlayed = (entry != null && entry.lastPlayedTS != -1L)
				}
				if (move && item.isPlayed) {
					clipListItemsPlayed.add(item as ContentItemInterface)
				} else {
					clipListItems.add(item as ContentItemInterface)
				}
			}
			for (item in clipListItemsPlayed) {
				clipListItems.add(item)
			}
		}

		return clipListItems
	}

	// NB copied from ProgramController!
	internal fun getPosterUrl(content: ContentItemInterface?, firstFrame: Boolean = false): String? {
		var url: String? = null
		if (content is Project) {
			val useThumbsFromMetadata =
				if (content.useThumbsFromMetadata != null) (content.useThumbsFromMetadata == "true")
				else _useThumbsFromMetadata
			val thumbnails = content.thumbnails
			if (useThumbsFromMetadata && thumbnails != null) {
				url = _getMainThumbnailUrl(thumbnails)
			} else {
				url = _baseUrl + "/project/" + content.id + "/pthumbnail/default/default.jpg"
			}
		} else if (content is MediaClip) {
			val useThumbsFromMetadata =
				if (content.useThumbsFromMetadata != null) (content.useThumbsFromMetadata == "true")
				else _useThumbsFromMetadata
			val thumbnails = content.thumbnails
			if (useThumbsFromMetadata && thumbnails != null) {
				url = _getMainThumbnailUrl(thumbnails)
			} else if (content.mediatype != "mainroll") {
				url = _baseUrl + "/mediaclip/" + content.id + "/pthumbnail/default/default.jpg"
				if (firstFrame) {
					url += "?frame0"
				}
			}
		} else if (content is MediaClipList) {
			url = _baseUrl + "/mediacliplist/" + content.id + "/pthumbnail/default/default.jpg"
		} else {
			Logger.d("ShelfAdapter", "getPosterUrl warning: no content")
		}

		return url
	}

	// NB copied from ProgramController!
	private fun _getMainThumbnailUrl(items: List<Thumbnail>): String? {
		var url: String? = null

		var selectedThumb: Thumbnail? = null;
		for (item in items) {
			if (item.main == true) { // found
				selectedThumb = item
				break // one is enough
			}
		}
		if (selectedThumb != null && selectedThumb.src != null) {
			url = _fixRelativeUrl("${selectedThumb.src}")
		} else {
			Logger.d("ShelfAdapter", "_getMainThumbnailUrl warning: no thumbnail")
		}

		return url
	}

	// NB copied from ProgramController!
	private fun _fixRelativeUrl(url: String, map: String = _defaultMediaAssetPath): String {
		var fixedUrl = url

		// fix relative url; prepend map
		val re2 = Regex("""^(\w+:|)//.*""", RegexOption.IGNORE_CASE)
		if (!re2.matches(fixedUrl)) {
			val re3 = Regex("""\?.*=$""", RegexOption.IGNORE_CASE) // matches ...?...=
			if (re3.containsMatchIn(map)) {
				fixedUrl = map + fixedUrl.encodeURLParameter()
			} else {
				fixedUrl = map + fixedUrl
			}
		}

		// fix protocol-relative url; prepend https:
		val re1 = Regex("""^//.*""", RegexOption.IGNORE_CASE)
		if (re1.matches(fixedUrl)) {
			fixedUrl = "https:" + fixedUrl
		}

		return fixedUrl
	}

	internal fun openPlayerWithContentItem(item: ContentItemInterface) {
		// create or load player
		if (_playerView == null) {
			// determine offset
			var offset: Int? = null
			val items = _clipListData?.items
			if (items is List<*>) {
				offset = 0
				for (it in items as List<ContentItem>) {
					if (it.id == item.id) { break }
					offset++
				}
				if (offset >= items.count()) offset = null
			}

			val modifiedPlayerOptions = _playerOptions.toMutableMap()
			modifiedPlayerOptions["initiator"] = "Shorts Shelf"
			modifiedPlayerOptions["listOffset"] = offset
			modifiedPlayerOptions["autoPlay"] = true
			_playerView = BBNativePlayer.createPlayerView(context, _jsonUrl, modifiedPlayerOptions)
			_playerView?.delegate = _playerViewDelegate
			// no need to add view
		} else {
			val contentId: String? = item.id
			if (item is MediaClip) {
				if (item.assets.isNullOrEmpty() && contentId != null) {
					_playerView?.player?.loadWithClipId(contentId, "Shorts Shelf", true)
				} else {
					_playerView?.player?.loadWithClip(item, "Shorts Shelf", true)
				}
			} else if (item is Project) {
				if (item.chapters.isNullOrEmpty() && contentId != null) {
					_playerView?.player?.loadWithProjectId(contentId, "Shorts Shelf", true)
				} else {
					_playerView?.player?.loadWithProject(item, "Shorts Shelf", true)
				}
			} else if (item is MediaClipList) {
				if (item.items.isNullOrEmpty() && contentId != null) {
					_playerView?.player?.loadWithClipListId(contentId, "Shorts Shelf", true)
				} else {
					_playerView?.player?.loadWithClipList(item, "Shorts Shelf", true)
				}
			}
		}

		// present player
		val playerView = _playerView
		if (playerView != null) {
			// create intent
			if (_activity == null) {
				val ctx = context
				_activity = when (ctx) {
					is AppCompatActivity -> ctx
					is ComponentActivity -> ctx
					else -> throw IllegalStateException("Context must be a ComponentActivity or AppCompatActivity")
				}
			}
			if (_intent == null) {
				_intent = Intent(_activity, ModalActivity::class.java)
			}

			// store playerView in Holder to be used in ModalActivity (built to be able to return the reference while using the activity intent to start the modal)
			val playerInstanceId = uuid4().toString()
			val modalPlayerViewHolder = ModalPlayerViewHolder.instance
			modalPlayerViewHolder.setBBPlayerView(playerInstanceId, playerView)
			_intent?.putExtra("PlayerInstanceId", playerInstanceId)

			// store this (ShelfView) in instanceService to be used in ModalActivity (built to be able to return the reference while using the activity intent to start the modal)
			val shelfViewInstanceId = uuid4().toString()
			val instanceService = ModalPlayerViewHolder.instance
			instanceService.setInstance(shelfViewInstanceId, this)
			_intent?.putExtra("shelfViewInstanceId", shelfViewInstanceId)

			// start intent
			_intent?.putExtra("keep", true)
			_activity?.startActivity(_intent)
		}
	}

	internal fun closePlayer() {
		// TODO
	}

	fun update () {
		println("[ShelfView] update")
		_adapter?.updateData(_itemsFromClipListData())
	}

	private fun _preloadSurroundingThumbnails() {
		val firstVisiblePosition = _layoutManager.findFirstVisibleItemPosition()
		val lastVisiblePosition = _layoutManager.findLastVisibleItemPosition()

		if (firstVisiblePosition == RecyclerView.NO_POSITION || lastVisiblePosition == RecyclerView.NO_POSITION) {
			return
		}

		val items = _clipListData?.items
		if (items == null || items.isEmpty()) {
			return
		}

		val totalItemCount = items.size
		val preloadRange = 10

		// Calculate preload range
		val preloadStart = (firstVisiblePosition - preloadRange).coerceAtLeast(0)
		val preloadEnd = (lastVisiblePosition + preloadRange).coerceAtMost(totalItemCount - 1)

		// Preload thumbnails for items in the range
		for (position in preloadStart..preloadEnd) {
			// Skip visible items (they're already loading/loaded)
			if (position in firstVisiblePosition..lastVisiblePosition) {
				continue
			}

			val item = items.getOrNull(position) as? ContentItemInterface ?: continue
			val posterUrl = getPosterUrl(item, false) ?: continue

			// Calculate the actual pixel height for the thumbnail
			val posterHeight = (_thumbHeightDp * _dpm).toInt()
			val finalPosterUrl = posterUrl.replace("/default/default", "/default/${posterHeight}")
			
			// Only preload if not already in cache
			val cacheKey = MemoryCache.Key(finalPosterUrl)
			if (_imageLoader.memoryCache?.get(cacheKey) == null) {
				// Preload the image using Coil's enqueue (non-blocking, low priority)
				val request = ImageRequest.Builder(context)
					.data(finalPosterUrl)
					.size(Size.ORIGINAL)
					.build()
				_imageLoader.enqueue(request)
			}
		}
	}
}

class ShelfItemDecoration(private val _startPadding: Int, private val _endPadding: Int, private val _pad: Int) : RecyclerView.ItemDecoration() {
	override fun getItemOffsets(
		outRect: Rect,
		view: View,
		parent: RecyclerView,
		state: RecyclerView.State
	) {
		val itemPosition = parent.getChildAdapterPosition(view)
		if (itemPosition == RecyclerView.NO_POSITION) {
			return
		}

		outRect.left = _pad
		outRect.right = _pad

		if (itemPosition == 0) {
			outRect.left = _startPadding
		}

		val adapter = parent.adapter
		if ((adapter != null) && (itemPosition == adapter.itemCount - 1)) {
			outRect.right = _endPadding
		}
	}
}
