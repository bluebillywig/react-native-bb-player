package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import com.bluebillywig.bbnativeshared.data.Languages
import java.util.Locale

/**
 * @suppress
 */
class BigButtonView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ShadowImageButton(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
			else -> {}
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _url: String? = null
	private var _type: String = "PLAY"

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt() // white
	private var _backgroundColor = 0x99000000.toInt() // 60% black

	init {
		this.setPadding(32, 32, 32, 32)

		this.setBackgroundColor(0)
		this.setImageResource(R.drawable.bb_icon_play);
		this.contentDescription = accessibilityTranslate("Play")
		this.elevation = 4F
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var url: String?
		get() = _url
		set(value) {
			_url = value
		}

	var type: String
		get() = _type
		set(value) {
			if (value == "BACKWARD") {
				_type = value
				this.setImageResource(R.drawable.bb_icon_fastrewind);
				this.contentDescription = accessibilityTranslate("tooltip-rewindVideo")
			} else if (value == "FORWARD") {
				_type = value
				this.setImageResource(R.drawable.bb_icon_fastforward);
				this.contentDescription = accessibilityTranslate("tooltip-forwardVideo")
			} else if (value == "REPLAY") {
				_type = value
				this.setImageResource(R.drawable.bb_icon_replay);
				this.contentDescription = accessibilityTranslate("Replay")
			} else { // PLAY
				_type = "PLAY"
				this.setImageResource(R.drawable.bb_icon_play);
				this.contentDescription = accessibilityTranslate("Play")
			}
		}

	private fun accessibilityTranslate(key: String): String {
		return Languages.translate(Locale.getDefault().getLanguage(), key)
	}

	private fun _update() {
		val fr: Int = Color.red(_foregroundColor)
		val fg: Int = Color.green(_foregroundColor)
		val fb: Int = Color.blue(_foregroundColor)
		val foregroundPaint = Paint().apply { setARGB(255, fr, fg, fb) }

		val br: Int = Color.red(_backgroundColor)
		val bg: Int = Color.green(_backgroundColor)
		val bb: Int = Color.blue(_backgroundColor)
		val backgroundPaintLight = Paint().apply { setARGB(153, br, bg, bb) }

		// TODO: use these paints somehow
	}

	private fun _ingestPlayoutData(playout: Playout) {
		try {
			if (playout.skin_foregroundColor != null) _foregroundColor = Color.parseColor("#" + playout.skin_foregroundColor as String)
			if (playout.skin_backgroundColor != null) _backgroundColor = Color.parseColor("#" + playout.skin_backgroundColor as String)
		} catch (er: Exception) {}
	}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
		_update()
	}

	private fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			// playout settings
			if (opts.playoutData is Playout) {
				_ingestPlayoutData(opts.playoutData as Playout)
			}
			_update()
		}
	}
}
