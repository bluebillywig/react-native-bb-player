package com.bluebillywig.bbnativeplayersdk

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.ceil
import kotlin.math.floor

import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.model.*

/**
 * @suppress
 */
class SwipeableListAdapter (
	private var _data: MutableList<ContentItemInterface>
): RecyclerView.Adapter<SwipeableListAdapter.ViewHolder>() {
	private var _listView: SwipeableListView? = null
	private var _programController: ProgramController? = null

	private var _itemViews: MutableList<SwipeableListItemView> = mutableListOf()
	private var _adoptedViews: MutableList<View> = mutableListOf()

	// settings
	private var _settings: Map<String, Any?> = mapOf()

	// state
	private var _fullScreen: Boolean = false
	private var _toPos: Int = -1

	init {
		this.setHasStableIds(true)
	}

	fun __destruct() {
		var itemView: SwipeableListItemView? = _itemViews.removeFirstOrNull()
		while (itemView != null) {
			itemView.__destruct()
			itemView = _itemViews.removeFirstOrNull()
		}
		_adoptedViews.clear()
	}

	override fun onViewRecycled(holder: ViewHolder) {
		super.onViewRecycled(holder)
		println("[SwipeableListAdapter] onViewRecycled holder: ${holder}")
		holder.heldView.pos = -1
		holder.heldView.updateContent(mapOf("posterUrl" to null, "posterVideoUrl" to null))
	}
	override fun onCreateViewHolder(
		parent: ViewGroup,
		viewType: Int
	): SwipeableListAdapter.ViewHolder {
		println("[SwipeableListAdapter] onCreateViewHolder going to create itemView")
		val itemView = SwipeableListItemView(parent.context)
		itemView.minimumWidth = 536
		itemView.minimumHeight = 302
		itemView.listView = _listView
		itemView.updateSettings(_settings)
		_itemViews.add(itemView)

		println("[SwipeableListAdapter] onCreateViewHolder going to return ViewHolder(itemView)")
		return ViewHolder(itemView)
	}

	override fun onBindViewHolder(holder: SwipeableListAdapter.ViewHolder, position: Int) {
		// println("[SwipeableListAdapter] onBindViewHolder called for holder: ${holder}, position: ${position}")
		val item: ContentItemInterface = _data[position]
		if (item != null) {
			holder.heldView.pos = position
			// generic
			val itemProps: MutableMap<String, Any?> = mutableMapOf("id" to item.id, "title" to item.title, "description" to "", "duration" to "")

			var useNormalPoster: Boolean = false
			if (_settings["useThumbnailsInFullscreen"] is Boolean) {
				useNormalPoster = _settings["useThumbnailsInFullscreen"] as Boolean
			}

			if (useNormalPoster) {
				itemProps["posterUrl"] = _programController?.getPosterUrl(item) ?: ""
			} else {
				itemProps["posterUrl"] = _programController?.getFirstFrameUrl(item) ?: ""
			}
			holder.heldView.updateContent(itemProps.toMap())
			holder.heldView.updateSettings(_settings)

			if (_toPos == position) this.updateFromPosToPos(-1, _toPos) // NB tiny hack!
		}
	}

	// Used in conjuction with this.setHasStableIds(true) - to prevent the adapter to update views that down't need it (prevent flickering)
	override fun getItemId(position: Int): Long {
		val item: ContentItemInterface = _data[position]
		if (item != null) {
			val pos = item.id?.toLongOrNull()	// use ContentItemInterface id when possible
			if (pos != null) {
				return pos
			}
		}
		return super.getItemId(position)		// fall back on default position index
	}

	override fun getItemCount(): Int {
		return _data.size
	}

	internal fun updateData( data: MutableList<ContentItemInterface>? ) {
		if ( data != null ) {
			_data = data
			this.notifyDataSetChanged()
		}
	}

	inner class ViewHolder
	internal constructor(
		itemView: View
	): RecyclerView.ViewHolder(itemView) {
		val heldView = itemView as SwipeableListItemView
	}

	var listView: SwipeableListView?
		get() = _listView
		set(value) {
			_listView = value
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
		}

	fun updateSettings(settings: Map<String, Any?>) {
		_settings = settings
		_itemViews.forEach {
			it.updateSettings(_settings)
		}
	}

	fun adoptView(view: View?) {
		if (view != null) {
			_adoptedViews.add(view)
		}
	}

	fun adoptFromAdapter(adapter: SwipeableListAdapter?) {
		val adoptedViews = adapter?._adoptedViews
		if (adoptedViews != null) {
			var view: View? = adoptedViews.removeFirstOrNull()
			while (view != null) {
				_adoptedViews.add(view)
				view = adoptedViews.removeFirstOrNull()
			}
		}
	}

	fun updateFromPosToPos(fromPos: Int, toPos: Int, showIndex: Int = -1): Boolean {
		var ret = false
		_toPos = toPos

		for (i in 0 until _adoptedViews.count()) {
			val view = _adoptedViews[i]
			ret = _moveViewFromPosToPos(view, fromPos, toPos) || ret
			if (showIndex > -1) {
				view.visibility = if (i == showIndex) View.VISIBLE else View.GONE
			}
		}

		return ret
	}

	private fun _moveViewFromPosToPos(view: View?, fromPos: Int, toPos: Int): Boolean {
		var fromHost: SwipeableListItemView? = null
		if (fromPos >= 0) {
			_itemViews.forEach {
				if (it.pos == fromPos) fromHost = it
			}
			fromHost?._posterView?.visibility = View.VISIBLE
			fromHost?.removeView(view)
		}
		// just in case
		val viewParent = view?.parent
		if (viewParent is ViewGroup) {
			println("[SwipeableListAdapter] _moveViewFromPosToPos viewParent: ${viewParent}")
			viewParent.removeView(view)
		}

		var toHost: SwipeableListItemView? = null
		if (toPos >= 0) {
			_itemViews.forEach {
				if (it.pos == toPos) toHost = it
			}
			view?.isClickable = false // ensure host can be clickable
			toHost?.addView(view, 0) // set player below thumbnail (z-index)
		}

		return toHost != null || toPos < 0 // found toPos
	}

	internal fun hidePosterForPos(pos: Int) {
		var host: SwipeableListItemView? = null
		if (pos >= 0) {
			_itemViews.forEach {
				if (it.pos == pos) host = it
			}
			host?._posterView?.visibility = View.GONE
		}
	}

	private fun _formatDuration(value: Any): String {
		var res = "00:00"

		var duration: Double? = null
		try {
			if (value is Int) duration = value.toDouble()
			if (value is Long) duration = value.toDouble()
			if (value is Float) duration = value.toDouble()
			if (value is Double) duration = value
			if (value is String) duration = value.toDouble()
		} catch (er: Exception) {}

		if (duration != null) {
			val hh = (floor(duration / 3600)).toInt(); duration %= 3600
			val mm = (floor(duration / 60)).toInt(); duration %= 60
			val ss = (ceil(duration)).toInt()
			res = if (hh > 0) ("%02d:%02d:%02d").format(hh, mm, ss) else ("%02d:%02d").format(mm, ss)
		}

		return res
	}
}
