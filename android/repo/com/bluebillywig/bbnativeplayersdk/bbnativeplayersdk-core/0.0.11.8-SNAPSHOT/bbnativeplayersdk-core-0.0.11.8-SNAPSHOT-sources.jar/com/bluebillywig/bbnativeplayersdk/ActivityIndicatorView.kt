package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout

import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.ProgressBar
import io.ktor.http.HttpStatusCode.Companion.Gone

/**
 * @suppress
 */
class ActivityIndicatorView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.loadstart -> {
				spinner?.visibility = View.VISIBLE
			}
			EventName.bb_embed_loaded -> {
				spinner?.visibility = View.GONE
			}

			EventName.bb_mediaclip_loaded -> {
				spinner?.visibility = View.GONE
			}
			EventName.bb_project_loaded -> {
				spinner?.visibility = View.GONE
			}
			EventName.bb_media_duration_change -> {
			}
			EventName.bb_media_canplay -> {
			}
			EventName.bb_media_playing -> {
			}
			EventName.bb_media_paused -> {
			}
			EventName.bb_media_finished -> {
			}
			EventName.bb_media_failed -> {
				spinner?.visibility = View.GONE
			}
			EventName.bb_mediaclip_failed -> {
				spinner?.visibility = View.GONE
			}
			EventName.bb_adsystem_canplay -> {
			}
			EventName.bb_adsystem_started -> { // bb_commercial_playing
			}
			EventName.bb_adsystem_finished, // bb_commercial_finished
			EventName.bb_adsystem_skipped,
			EventName.bb_adsystem_failed -> {
			}
			EventName.bb_msas_pre_finished -> {
			}
			EventName.bb_msas_main_finished -> {
			}
			EventName.bb_msas_post_finished -> {
			}
			EventName.adContentPauseReq -> {
			}
			EventName.adContentResumeReq -> {
			}
			EventName.bb_related_clips_changed -> {
			}
			EventName.bb_phase_change -> {
			}
			EventName.bb_asset_selected -> {
			}
			else -> { return }
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var spinner: ProgressBar? = null
	
	companion object {
		const val TAG = "ActivityIndicatorView"
	}

	init {
		val inflater = LayoutInflater.from(getContext())
		inflater.inflate(R.layout.activity_indicator, this)


		_eventBus?.addEventlistener(this)
		spinner = findViewById(R.id.progressBar1) as ProgressBar;
		spinner?.visibility = View.GONE
	}

	fun __destruct() {
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}
}
