package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.FrameLayout
import java.net.URL

/**
 * @suppress
 */
class LogoView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {
	private var _imageView = ImageView(this.context)
	private var _url: String? = null

	init {
		this.setPadding(32, 32, 32, 32)
		this.setVerticalGravity(Gravity.TOP)
		this.setHorizontalGravity(Gravity.RIGHT)
		_imageView.id = View.generateViewId()
		this.addView(_imageView)
	}

	var url: String?
		get() = _url
		set(value) {
			_url = value
			DownLoadImageTask2(_imageView)
				.execute(_url)
		}
}

// Class to download an image from url and display it into an image view
private class DownLoadImageTask2(internal val imageView: ImageView) : AsyncTask<String, Void, Bitmap?>() {
	override fun doInBackground(vararg urls: String): Bitmap? {
		val urlOfImage = urls[0]
		return try {
			val inputStream = URL(urlOfImage).openStream()
			BitmapFactory.decodeStream(inputStream)
		} catch (e: Exception) { // Catch the download exception
			e.printStackTrace()
			null
		}
	}
	override fun onPostExecute(result: Bitmap?) {
		if (result != null) {
			// Display the downloaded image into image view
			imageView.setImageBitmap(result)
		} else {
			imageView.setImageDrawable(null)
		}
	}
}