package com.bluebillywig.bbnativeplayersdk

/**
 * BBNativeShortsViewDelegate
 *   is what you implement to act as BBNativeShortsView's delegate.
 */
interface BBNativeShortsViewDelegate {
	fun didSetupWithJsonUrl(shortsView: BBNativeShortsView, url: String?) { /* optional */ }
	fun didFailWithError(shortsView: BBNativeShortsView, error: String?) { /* optional */ }
}
