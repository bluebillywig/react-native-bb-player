package com.bluebillywig.bbnativeplayersdk

import android.graphics.Color

/**
 * Color utility functions for the BB Native Player SDK
 * @suppress
 */

/**
 * Calculates relative luminance per WCAG 2.0 specification
 * Uses sRGB colorspace with proper gamma correction
 *
 * Formula: L = 0.2126 * R + 0.7152 * G + 0.0722 * B
 * Where R, G, B are gamma-corrected values
 *
 * @param color The Android Color int value
 * @return Luminance value between 0.0 (darkest) and 1.0 (lightest)
 * @see <a href="https://www.w3.org/TR/WCAG20/#relativeluminancedef">WCAG 2.0 Relative Luminance</a>
 */
fun calculateRelativeLuminance(color: Int): Double {
	// Extract RGB components and convert to 0-1 range
	val r = Color.red(color) / 255.0
	val g = Color.green(color) / 255.0
	val b = Color.blue(color) / 255.0

	// Apply gamma correction (sRGB to linear RGB)
	val rLinear = if (r <= 0.03928) r / 12.92 else Math.pow((r + 0.055) / 1.055, 2.4)
	val gLinear = if (g <= 0.03928) g / 12.92 else Math.pow((g + 0.055) / 1.055, 2.4)
	val bLinear = if (b <= 0.03928) b / 12.92 else Math.pow((b + 0.055) / 1.055, 2.4)

	// Calculate relative luminance using WCAG coefficients
	return 0.2126 * rLinear + 0.7152 * gLinear + 0.0722 * bLinear
}
