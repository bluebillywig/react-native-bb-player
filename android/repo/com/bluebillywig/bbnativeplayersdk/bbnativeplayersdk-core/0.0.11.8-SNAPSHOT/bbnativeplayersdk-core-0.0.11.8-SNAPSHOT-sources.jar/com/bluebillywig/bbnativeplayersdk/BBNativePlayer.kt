package com.bluebillywig.bbnativeplayersdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.app.MediaRouteButton
import com.bluebillywig.bbnativeshared.controller.EmbedController
import com.bluebillywig.bbnativeplayersdk.ModalPlayerViewHolder
import com.benasher44.uuid.uuid4
import com.google.android.gms.cast.framework.CastButtonFactory

/**
 * BBNativePlayer
 *   offers static factory functions for creating the views that do the actual work
 *
 */
class BBNativePlayer {
    companion object { // this is Kotlin's way to support static class methods; don't ask...
        /**
         * @suppress
         */
		var _chromecastMiniControlsView: ChromecastMiniControlsView? = null

        /**
         * Create a player view
         * * context: the view context. Should be of type AppCompatActivity for fullscreen functionality
         * * jsonUrl: the json embed URL (nullable)
         * * options: the options dictionary (optional), options recognized:
		 *	* adsystem_buid: app bundle id
		 *	* adsystem_rdid: resettable device identifier
		 *	* adsystem_idtype: identifier type ("idfa" for iOS, "adid" for Android)
		 *	* adsystem_is_lat: limit ad tracking (Boolean)
		 *	* adsystem_ppid: publisher-provided id
		 *	* allowCollapseExpand: honour collapse / expand requests (Boolean or String)
		 *	* waitForCmp: wait for Consent Management, then setup (Boolean or String)
		 *	* handleConsentManagement: handle Consent Management (Boolean or String) -- needs waitForCmp
		 *	* tagForUnderAgeOfConsent: (Boolean or String)
		 *	* consent_string: default consent string (String)
		 *	* consent_gdprApplies: default GDPR applies (Int)
		 *	* consent_cmpVersion: default CMP version (Int)
		 *	* autoPlay: auto play (Boolean or String), overrides playout setting
		 *	* commercials: allow commercials (Boolean or String), overrides playout setting
		 *	* noChromeCast: no ChromeCast support (Boolean or String), overrides playout setting
		 *	* noStats: no stats logging (Boolean), overrides playout setting
		 *	* forceFullscreenLandscape: rotated the video to landscape when the video goes fullscreen
		 *	* adTagUrlParam_[key]: Custom parameters to add to ad tag URLs. Multiple parameters supported with different keys (e.g., "adTagUrlParam_userId": "12345")
         * @param context the view context
         * @param jsonUrl the json embed URL (nullable)
         * @param options the options dictionary (optional)
         * @return the player view
         */
        fun createPlayerView(context: Context, jsonUrl: String?,  options: Map<String, Any?>? = null): BBNativePlayerView {
            val nativePlayerView = BBNativePlayerView(context)
            if (jsonUrl != null) nativePlayerView.setupWithJsonUrl(jsonUrl, options)
            return nativePlayerView
        }

        /**
         * Create a json embed URL
         * * baseUrl: the base URL, e.g. "https://demo.bbvms.com"
         * * appIndicator: the application indicator, e.g. "p" for player
         * * appId: the application config id, e.g. the playout code
         * * contentIndicator: the content indicator (optional), e.g. "c" for clip
         * * contentId: the content id, e.g. "7654321"
         * @param baseUrl the base URL, e.g. "https://demo.bbvms.com"
         * @param appIndicator the application indicator, e.g. "p" for player
         * @param appId the application config id, e.g. the playout code
         * @param contentIndicator the content indicator (optional), e.g. "c" for clip
         * @param contentId the content id, e.g. "7654321"
         * @return the json embed URL
         */
        fun createJsonEmbedUrl(baseUrl: String, appIndicator: String, appId: String, contentIndicator: String? = null, contentId: String? = null): String {
            return EmbedController.createJsonEmbedUrl(baseUrl, appIndicator, appId, contentIndicator, contentId)
        }

        /**
         * Create a modal player view
         * * activity: the app activity
         * * jsonUrl: the json embed URL
         * * options: the options dictionary (optional), options recognized:
		 *	* adsystem_buid: app bundle id
		 *	* adsystem_rdid: resettable device identifier
		 *	* adsystem_idtype: identifier type ("idfa" for iOS, "adid" for Android)
		 *	* adsystem_is_lat: limit ad tracking (Boolean)
		 *	* adsystem_ppid: publisher-provided id
		 *	* waitForCmp: wait for Consent Management, then setup (Boolean or String)
		 *	* handleConsentManagement: handle Consent Management (Boolean or String) -- needs waitForCmp
		 *	* tagForUnderAgeOfConsent: (Boolean or String)
		 *	* consent_string: default consent string (String)
		 *	* consent_gdprApplies: default GDPR applies (Int)
		 *	* consent_cmpVersion: default CMP version (Int)
		 *	* autoPlay: auto play (Boolean or String), overrides playout setting
		 *	* commercials: allow commercials (Boolean or String), overrides playout setting
		 *	* noChromeCast: no ChromeCast support (Boolean or String), overrides playout setting
		 *	* noStats: no stats logging (Boolean), overrides playout setting
		 *	* adTagUrlParam_[key]: Custom parameters to add to ad tag URLs. Multiple parameters supported with different keys (e.g., "adTagUrlParam_userId": "12345")
         * @param activity the app activity
         * @param jsonUrl the json embed URL
         * @param options the options dictionary (optional)
         * @return the modal player view
         */
        fun createModalPlayerView(activity: AppCompatActivity, jsonUrl: String,  options: Map<String, Any?>? = null): BBNativePlayerView {
            val intent = Intent(activity, ModalActivity::class.java)

            // rebuilding options because we need a MutableMap to add autoPlay
            val newOptions = if (options != null) options.toMutableMap() else mutableMapOf()
            if (newOptions["autoPlay"] == null) newOptions["autoPlay"] = true
			newOptions["modalPlayer"] = true

            // Create playerView and store in Holder to be used in ModalActivity (built to be able to return the reference while using the activity intent to start the modal)
            val playerInstanceId = uuid4().toString()
            intent.putExtra("PlayerInstanceId",playerInstanceId)
			intent.putExtra("keep", true) // is needed now to not close it immediately !?

			if (newOptions["showBackArrow"] == true) {
				intent.putExtra("showBackArrow", true)
				newOptions["indentTitleView"] = true
			}

			val bbNativePlayerView =  BBNativePlayer.createPlayerView(activity, jsonUrl, newOptions)
            val modalPlayerViewHolder = ModalPlayerViewHolder.instance
            modalPlayerViewHolder.setBBPlayerView(playerInstanceId, bbNativePlayerView)

            // start activity
            activity.startActivity(intent)

            return bbNativePlayerView
        }
 
		/**
		 * Create Chromecast button
		 * @param context the view context
		 * @return the button
		 */
		fun createChromecastButton(context: Context): MediaRouteButton {
			val button = MediaRouteButton(context)
			CastButtonFactory.setUpMediaRouteButton(context.applicationContext, button)

            return button
		}

		/**
		 * Get Chromecast mini controls view (singleton)
		 * @param context the view context
		 * @return the mini controls view
		 */
		fun getChromecastMiniControlsView(context: Context): ChromecastMiniControlsView {
			val view = _chromecastMiniControlsView ?: ChromecastMiniControlsView(context)
			_chromecastMiniControlsView = view

			if (view.parent is ViewGroup) (view.parent as ViewGroup).removeView(view)

			return view
		}
    }
}
