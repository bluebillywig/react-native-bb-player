package com.bluebillywig.bbnativeplayersdk

/**
 * BBNativeRendererViewDelegate
 *   is what you implement to act as BBNativeRendererView's delegate.
 */
interface BBNativeRendererViewDelegate {
	fun didSetupWithJsonUrl(rendererView: BBNativeRendererView, url: String?) { /* optional */ }
	fun didFailWithError(rendererView: BBNativeRendererView, error: String?) { /* optional */ }
}
