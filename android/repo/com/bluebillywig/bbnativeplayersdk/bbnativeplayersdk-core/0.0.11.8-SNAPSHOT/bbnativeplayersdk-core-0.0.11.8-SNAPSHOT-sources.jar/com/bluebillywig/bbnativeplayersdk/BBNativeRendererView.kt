package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.model.*
import com.bluebillywig.bbnativeshared.controller.EmbedController

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.bluebillywig.bbnativeshared.enums.ApiMethod

/**
 * @suppress
 */
// Check to see if references are garbage collected after pressing "destroy player"
// var USE_LEAKCANARY = false

/**
 * BBNativeRendererView
 *   is what you place in your layout.
 *   It extends the platform’s core UI View class (more specifically: FrameLayout)
 *
 * @constructor
 *   no need to call this directly; use BBNativeRenderer's createRendererView factory function
 *
 * @param context should be of type AppCompatActivity for fullscreen functionality
 * @param attrs (optional, default: null)
 * @param defStyleAttr (optional, default: 0)
 */

// see: https://antonioleiva.com/custom-views-android-kotlin/
class BBNativeRendererView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) , EventListenerInterface, BBNativePlayerViewDelegate {
	// EventListenerInterface::onEvent
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				val url = if (data != null && data["url"] is String) data["url"] as String else null
				val options: Map<String, Any?>? = if (data != null && data["options"] is Map<*, *>) data["options"] as Map<String, Any?> else null
				if (data != null) {
					if (data["embedObject"] is EmbedObject) {
						val embedObject = data["embedObject"] as EmbedObject

						// embed data
						_appId = "_"
						_baseUrl = "https://bbvms.com"
						_embedData = embedObject.embedData
						val embedData = _embedData
						if (embedData != null) {
							_appId = embedData.appId ?: "_"
							_baseUrl = embedData.baseurl ?: "https://bb.bbvms.com" // NB mind lowercase 'u'!
							_contentId = embedData.contentId ?: "_"
						}
						var publicationName = "bb"
						val match = """^[\w:]*\/\/([^/]+)\.(?:bbvms|mainroll|bbovp)\.com""".toRegex().matchEntire(_baseUrl)
						if (match?.destructured?.component1() is String) publicationName = match.destructured.component1() as String
						_id = "${publicationName}-${_appId}" // NB convention, publicationName e.g. "testsuite.acc"!

						// publication data
						var defaultMediaAssetPath = ""
						var useThumbsFromMetadata = false
						val publicationData = embedObject.publicationData
						if (publicationData != null) {
							defaultMediaAssetPath = publicationData.defaultMediaAssetPath ?: ""
							useThumbsFromMetadata = (publicationData.useThumbsFromMetadata == "true")
						}

						// app config
						_appConfig = embedObject.appConfig
						val appConfig: AppConfig? = _appConfig
						if (appConfig != null) {
							// settings
							// if (appConfig.playerPath != null) { _playerPath = appConfig.playerPath ?: "" }
							// if (appConfig.bbcb != null) { _bbcb = appConfig.bbcb ?: "" }
							// if (appConfig.userLanguage != null) { _userLanguage = appConfig.userLanguage ?: "" }
							// if (appConfig.userDeviceType != null) { _userDeviceType = appConfig.userDeviceType ?: "" }
							if (appConfig.playout?.logoId != null) { _logoUrlString = "${_baseUrl}/mediaclip/${appConfig.playout?.logoId}/pthumbnail/200/default.png" ?: "" }

							val playerOptions: MutableMap<String, Any?> = mutableMapOf(
								"initiator" to "Renderer",
								"name" to "renderer",
								"label" to "renderer",
								"publication" to publicationName,
								"playerType" to "renderer", // NB! was: outstream
								"autoPlay" to false,
								"skin_backgroundColor" to "ffffff",
								"skin_foregroundColor" to (_skin_foregroundColor ?: "3578bb"),
								"skin_widgetColor" to "6caedf",
								"bgColor" to "000000",
								"cornerRadius" to _cornerRadius,
								"rendererId" to _rendererId // renderer-specific
							)

							_playout = appConfig.playout
							val playout: Playout? = _playout
							if (playout != null) {
								if (playout.label != null) { playerOptions["label"] = playout.label ?: "" }
								if (playout.title != null) { playerOptions["title"] = playout.title ?: "" }
								if (playout.skin_foregroundColor != null) { playerOptions["skin_foregroundColor"] = playout.skin_foregroundColor ?: "" }
								if (playout.autoPlay != null) { _autoPlay = playout.autoPlay == "true" } // NB!
								if (playout.ctaUrlField != null) { playerOptions["ctaUrlField"] = playout.ctaUrlField ?: "" }
								if (playout.ctaButtonPosition != null) { playerOptions["ctaButtonPosition"] = playout.ctaButtonPosition ?: "" }
								if (playout.ctaButtonText != null) { playerOptions["ctaButtonText"] = playout.ctaButtonText ?: "" }
								if (playout.ctaButtonUseAccentColor != null) { playerOptions["ctaButtonUseAccentColor"] = playout.ctaButtonUseAccentColor == "true" }
							}
							// all embed options override player options
							options?.forEach { // it
								playerOptions[it.key] = it.value
							}
							_playerOptions = playerOptions

							// create player view
							_placePlayer();
						}
					}
				}
				_delegate?.didSetupWithJsonUrl(this, url)
			}
			EventName.bb_embed_failed -> {
				val error = if (data != null && data["error"] is String) data["error"] as String else null
				_delegate?.didFailWithError(this, "Embed failed - $error")
			}
			else -> {}
		}
	}

	// BBNativePlayerViewDelegate::didSetupWithJsonUrl
	override fun didSetupWithJsonUrl(playerView: BBNativePlayerView, url: String?) {
		println("[BBNativeRendererView] didSetupWithJsonUrl url: ${url}")
	}
	// BBNativePlayerViewDelegate::didFailWithError
	override fun didFailWithError(playerView: BBNativePlayerView, error: String?) {
		println("[BBNativeRendererView] didFailWithError error: ${error}")
	}

	private var _eventBus: EventBus? = null
	private var _network: Network? = null
	private var _embedController: EmbedController? = null

	private var _playerOptions: MutableMap<String, Any?>? = null
	private var _playerView: BBNativePlayerView? = null
	private var _playerViewDelegate: BBNativePlayerViewDelegate? = null

	private var _delegate: BBNativeRendererViewDelegate? = null

	// settings
	private var _id: String = "bb-_"
	private var _appId: String = "_"
	private var _baseUrl: String = "https://bbvms.com"
	private var _contentId: String = "_"
	private var _autoPlay: Boolean = false
	private var _cornerRadius: Int = 0
	private var _rendererId: String = "0"
	private var _skin_foregroundColor: String = "ffffff"
	private var _logoUrlString: String = ""

	// data
	private var _embedData: EmbedData? = null
	private var _appConfig: AppConfig? = null
	private var _playout: Playout? = null

	init {
		_eventBus = EventBus()
		_eventBus?.addEventlistener(this)

		_network = Network()

		_embedController = EmbedController(_eventBus, null)
		_embedController!!.network = _network

		val layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		this.layoutParams = layoutParams
	}

	fun __destruct () {
		_eventBus?.removeEventlistener(this) // OBSOLETE
		_eventBus?.__destruct()
		// if (USE_LEAKCANARY) Leakcanary.expectWeaklyReachable(_eventBus, "_eventBus was detached")
		_eventBus = null

		this.removeAllViews()
		_playerView?.__destruct()
		_playerView = null

		_playerViewDelegate = null
		_delegate = null

		_embedData = null
		_appConfig = null
		_playout = null
	}

	/**
	 * @suppress
	 */
	public override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec)
	}

	/**
	 * Delegate for handling API events
	 */
	var delegate: BBNativeRendererViewDelegate?
		get() = _delegate
		set(value) { _delegate = value }

	/**
	 * Delegate for handling Player API events
	 */
	var playerViewDelegate: BBNativePlayerViewDelegate?
		get() = _playerViewDelegate
		set(value) {
			_playerView?.delegate = null
			_playerViewDelegate = value
			_playerView?.delegate = _playerViewDelegate
		}

	/**
	 * Setup with json URL
	 * * jsonUrl: the json embed URL
	 * * options: the options dictionary (optional), options recognized:
	 *	* autoPlay: auto play (Boolean or String), overrides playout setting
	 * @param jsonUrl the json embed URL
	 * @param options the options dictionary (optional), options recognized:
	 */
	fun setupWithJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
		if (options != null) {
			// if (options["autoPlay"] is String) _autoPlay = (options["autoPlay"] as String == "true")
			// if (options["autoPlay"] is Boolean) _autoPlay = options["autoPlay"] as Boolean
			// if (_autoPlay) _play() // NB!
		}

		_loadJsonUrl(jsonUrl, options)
	}

	private fun _loadJsonUrl(jsonUrl: String, options: Map<String, Any?>?) {
		val modifiedOptions: MutableMap<String, Any?> = options?.toMutableMap() ?: mutableMapOf()
		_embedController?.load(jsonUrl, modifiedOptions)
	}

	/**
	 * Bootstrap
	 * @param config
	 * @param element optional target element (reserved for future use)
	 * @param playoutOverrides optional overrides for playout settings
	 */
	fun bootstrap (config: Map<String, String?>, element: View? = null, playoutOverrides: Map<String, Any?>? = mapOf()) {
		if (config["code"].isNullOrEmpty() || (config["vastUrl"].isNullOrEmpty() && config["vastXml"].isNullOrEmpty())) return

		// create ad services data
		val configCode = ("""-""").toRegex().replace("${config["code"]}", "_") // sanitizes code for Solr...
		val rendererCode = ("""-""").toRegex().replace(_contentId ?: "", "_") // sanitizes code for Solr...

		// postfix with _vast_renderer(_1) to detect this as a faked renderer ad unit in the harvester
		val adUnitCode = "${configCode}_${rendererCode}_vast_renderer"
		val lineItemCode = "${adUnitCode}_1"

		val lineItemPlayout: Map<String, String?> = mapOf()
		val lineItem = LineItem_("-1", lineItemPlayout, lineItemCode, config["vastUrl"], config["vastXml"], config["vastSubtype"])

		val adUnitPlayout = _playout
		val adUnit = AdUnit("-1", adUnitPlayout, "inarticle", adUnitCode, listOf(lineItem))

		val adServicesData = listOf(adUnit)

		// re-create player view
		// _placePlayer()

		_playerView?.callApiMethod(ApiMethod.load, mapOf("adServicesData" to adServicesData, "initiator" to "Renderer", "autoPlay" to _autoPlay)) // was: autoPlay false
	}

	/**
	 * Destroy, freeing all memory allocated internally
	 */
	fun destroy() {
		__destruct()
	}

	private fun _placePlayer() {
		if (_playerView != null) this.removeView(_playerView)
		_playerView?.__destruct()
		val playerViewJsonUrl = BBNativePlayer.createJsonEmbedUrl(_baseUrl, "a", _appId) // Outstream Player
		println("[BBNativeRendererView] _placePlayer bb_embed_loaded playerViewJsonUrl: ${playerViewJsonUrl}")
		_playerView = BBNativePlayer.createPlayerView(this.context, playerViewJsonUrl, _playerOptions)
		_playerView?.delegate = _playerViewDelegate
		_playerView?.id = View.generateViewId()
		if (_playerView != null) this.addView(_playerView)
	}
}
