package com.bluebillywig.bbnativeplayersdk

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.ceil
import kotlin.math.floor
//import kotlin.time.ExperimentalTime
//import kotlin.time.Duration
//import kotlin.time.DurationUnit
//import kotlin.time.toDuration

import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.model.*

/**
 * @suppress
 */
class RelatedItemsAdapter (
    private val _data: List<ContentItemInterface>
): RecyclerView.Adapter<RelatedItemsAdapter.ViewHolder>() {
    private var _eventBus: EventBusInterface? = null
    private var _programController: ProgramController? = null

    // settings
    private var _useDeeplink = false
    private var _avoidAssets = false

    init {
    }

    fun __destruct() {
        _programController = null
        _eventBus = null
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RelatedItemsAdapter.ViewHolder {
        val itemView = ItemView(parent.context)
        itemView.layoutParams = ViewGroup.LayoutParams(426, 240)

        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: RelatedItemsAdapter.ViewHolder, position: Int) {
        val item: ContentItemInterface? = _data[position]
        if (item != null) {
            // generic
            val itemProps: MutableMap<String, Any?> = mutableMapOf("id" to item.id, "title" to item.title, "description" to "", "duration" to "")
            val posterUrl = _programController?.getPosterUrl(item) ?: ""

            // Determine if video is vertical based on width and height
            val isVertical = if (item is MediaClip) {
                val width = item.width ?: 0
                val height = item.height ?: 0
                height >= width
            } else {
                false
            }

            // Use vertical thumbnail size for vertical videos, horizontal for others
            itemProps["thumbnailUrl"] = if (isVertical) {
                posterUrl.replace("/default/default", "/default/536")
            } else {
                posterUrl.replace("/default/default", "/536/default")
            }

            // Pass isVertical flag to ItemView for proper image scaling
            itemProps["isVertical"] = isVertical

            // Logger.d("RelatedItemsAdapter", "onBindViewHolder thumb: ${itemProps["thumbnailUrl"]}")
            // type-specific
            if (item is Project) {
                val count = item.chapters?.count()
                itemProps["duration"] = if (count != null) "${count} ⌥" else "⌥"
                itemProps["description"] = if (item.description is String) item.description as String else ""
            } else if (item is MediaClipList) {
                val count = item.items?.count()
                itemProps["duration"] = if (count != null) "${count} ⧉" else "⧉"
                itemProps["description"] = ""
            } else if (item is MediaClip) {
                itemProps["duration"] = if (item.length is String) _formatDuration(item.length as String) else ""
                itemProps["description"] = if (item.description is String) item.description as String else ""
            }
            holder.heldView.updateContent(itemProps.toMap())
            holder.heldView.setOnClickListener { _handleItemClick(item) }
        }
    }

    override fun getItemCount(): Int {
        return _data.size
    }

    inner class ViewHolder
    internal constructor(
        itemView: View
    ): RecyclerView.ViewHolder(itemView) {
        val heldView = itemView as ItemView
    }

    var eventBus: EventBusInterface?
        get() = _eventBus
        set(value) {
            _eventBus = value
        }

    var programController: ProgramController?
        get() = _programController
        set(value) {
            _programController = value
        }

    fun updateSettings(settings: Map<String, Any?>) {
        if (settings["useDeeplink"] is Boolean) _useDeeplink = settings["useDeeplink"] as Boolean
        if (settings["avoidAssets"] is Boolean) _avoidAssets = settings["avoidAssets"] as Boolean
    }

    // add onclick listener to viewholder
    private fun _handleItemClick(item: ContentItemInterface) {
        Logger.d("RelatedItemsAdapter", "_handleItemClick")
        var gendeeplink_: String? = null
        var deeplink_: String? = null
        var contentIndicator: String? = null
        if (item is MediaClip) {
            gendeeplink_= item.gendeeplink
            deeplink_= item.deeplink
            if (item.assets.isNullOrEmpty() || _avoidAssets) {
                contentIndicator = "c"
            }
        } else if (item is Project) {
            // no gendeeplink
            deeplink_ = item.deeplink
            if (item.chapters.isNullOrEmpty()) {
                contentIndicator = "p"
            }
        } else if (item is MediaClipList) {
            // no gendeeplink
            deeplink_ = item.deeplink
            if (item.items.isNullOrEmpty()) {
                contentIndicator = "l"
            }
        }
        val deeplink: String? = if (!deeplink_.isNullOrEmpty()) deeplink_ else gendeeplink_
        if (_useDeeplink && !deeplink.isNullOrEmpty() && _eventBus != null) {
            _eventBus?.trigger(EventName.requestOpenUrl, mapOf("url" to deeplink!!))
        }
        if (contentIndicator != null) {
            Logger.d("RelatedItemsAdapter", "_handleItemClick going to loadContentById item: ${item}")
            _programController?.loadContentById(item.id ?: "", contentIndicator, "RelatedItem", true, null)
        } else {
            Logger.d("RelatedItemsAdapter", "_handleItemClick going to loadContent item: ${item}")
            _programController?.loadContent(item, "RelatedItem", true, null)
        }
    }

    //	@ExperimentalTime
//	private fun _formatDuration(value: Any): String {
//		var duration: Duration? = null
//
//		try {
//			if (value is Int) duration = value.toDuration(DurationUnit.SECONDS)
//			if (value is Long) duration = value.toDuration(DurationUnit.SECONDS)
//			if (value is Double) duration = value.toDuration(DurationUnit.SECONDS)
//			if (value is String) duration = (value.toDouble()).toDuration(DurationUnit.SECONDS)
//			if (value is Duration) duration = value
//		} catch (er: Exception) {}
//
//		return (duration?.toIsoString() ?: "00:00")
//	}
    private fun _formatDuration(value: Any): String {
        var res = "00:00"

        var duration: Double? = null
        try {
            if (value is Int) duration = value.toDouble()
            if (value is Long) duration = value.toDouble()
            if (value is Float) duration = value.toDouble()
            if (value is Double) duration = value
            if (value is String) duration = value.toDouble()
        } catch (er: Exception) {}

        if (duration != null) {
            val hh = (floor(duration / 3600)).toInt(); duration %= 3600
            val mm = (floor(duration / 60)).toInt(); duration %= 60
            val ss = (ceil(duration)).toInt()
            res = if (hh > 0) ("%02d:%02d:%02d").format(hh, mm, ss) else ("%02d:%02d").format(mm, ss)
        }

        return res
    }
}
