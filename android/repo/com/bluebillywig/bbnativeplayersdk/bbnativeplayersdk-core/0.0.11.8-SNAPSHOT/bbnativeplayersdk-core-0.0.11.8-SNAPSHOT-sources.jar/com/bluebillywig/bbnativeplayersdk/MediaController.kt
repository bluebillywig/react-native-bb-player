package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.preference.PreferenceManager
import com.bluebillywig.bbnativeshared.Logger
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.interfaces.MediaControllerInterface
import com.bluebillywig.bbnativeshared.model.Audiotrack
import com.bluebillywig.bbnativeshared.model.Quality
import com.bluebillywig.bbnativeshared.model.VideoTrack
import com.bluebillywig.bbnativeshared.model.Subtitle
import com.bluebillywig.bbnativeshared.model.EmbedObject
import com.bluebillywig.bbnativeshared.model.EmbedData
import com.bluebillywig.bbnativeshared.model.Playout
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.TimeBar
import com.google.android.gms.cast.*
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.gms.common.images.WebImage
import org.json.JSONException
import org.json.JSONObject
import java.util.*
import kotlin.math.ceil


/**
 * @suppress
 */
enum class HeadType {
	EXOPLAYER,
	CHROMECAST
}

/**
 * @suppress
 */
class ProgressTracker constructor(
	private var _player: Player?,
	private var _eventBus: EventBusInterface?
) :Runnable {
	private var _handler: Handler?

	override fun run() {
		val currentTime: String = ((_player?.currentPosition?.toDouble() ?: 0.0) / 1000).toString()
		_eventBus?.trigger(EventName.bb_media_timeupdate, mapOf("currentTime" to currentTime))

		_handler?.postDelayed(this, 200)
	}

	fun stop() {
		_handler?.removeCallbacks(this)
	}

	init {
		_handler = Handler(Looper.getMainLooper())
	}

	fun __destruct() {
		_handler?.removeCallbacks(this)
		_handler = null
		_player = null
		_eventBus = null
	}
}
/**
 * @suppress
 */
class MediaController(eventBus: EventBusInterface?, player: ExoPlayer?): MediaControllerInterface, EventListenerInterface, Player.Listener,
	RemoteMediaClient.Callback() {
	/**
	 * @suppress
	 */
	companion object {
		fun languageFromIsoCode(isoCode: String? = null): String {
			val isoCode_ = isoCode?.toLowerCase() ?: "--"
			val languages = mapOf("dk" to "Dansk", "de" to "Deutsch", "en" to "English", "sgn-en" to "English", "es" to "Español", "fr" to "Français", "fy" to "Frysk", "ga" to "Irish", "it" to "Italiano", "nl" to "Nederlands", "sgn-nl" to "Nederlands", "pl" to "Polski", "sv" to "Svenska", "fi" to "Suomi", "zh" to "中文" )
			return languages[isoCode_] ?: isoCode_
		}

		fun stripHtmlTags(richText: String): String {
			return ("""<[^>]*>""").toRegex().replace(richText, "")
		}
	}

    override fun set(propertyName: String, propertyValue: Any?): Boolean {
        var res: Boolean = false

        if (propertyName == "currentTime" && propertyValue is Number) {
            var positionMs = 0L
            if (propertyValue is Double) positionMs = ((propertyValue as Double) * 1000).toLong()
            else if (propertyValue is Int) positionMs = (propertyValue as Int).toLong() * 1000
			when (_headType) {
				HeadType.CHROMECAST -> {
					_gmsRemoteMediaClient?.seek(positionMs) // IMPROVE ME: avoid deprecated prototype
				}
				else -> { // EXOPLAYER
					_exoPlayer?.seekTo(positionMs)
				}
			}
            res = true
        } else if (propertyName == "volume" && propertyValue is Double) {
            _volume = propertyValue as Double
			_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())
			_gmsRemoteMediaClient?.setStreamVolume(_volume)
            res = true
        } else if (propertyName == "muted" && propertyValue is Boolean) {
            _muted = propertyValue as Boolean
			_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())
			_gmsRemoteMediaClient?.setStreamMute(_muted)
            res = true
		} else if (propertyName == "gms.castButtonClicked") {
			_putCastButtonPlayerId()
			res = true
//        } else if (propertyName == "deviceVolume" && propertyValue is Double) {
//            _exoPlayer?.setDeviceVolume(((propertyValue as Double) * 100).toInt())
//            res = true
//        } else if (propertyName == "deviceMuted" && propertyValue is Boolean) {
//            _exoPlayer?.setDeviceMuted(propertyValue as Boolean)
//            res = true
        }

        return res
    }

    override fun get(propertyName: String): Any? {
        var res: Any? = null

        if (propertyName == "currentTime") {
			when (_headType) {
				HeadType.CHROMECAST -> {
					var streamPosition: Long = _gmsRemoteMediaClient?.approximateStreamPosition ?: 0L
					if (streamPosition == 0L) streamPosition = _gmsStreamPosition ?: 0L
					res = (streamPosition).toDouble() / 1000
				}
				else -> { // EXOPLAYER
					res = (_exoPlayer?.getCurrentPosition() ?: 0L).toDouble() / 1000
				}
			}
        } else if (propertyName == "duration") {
			when (_headType) {
				HeadType.CHROMECAST -> {
					res = (_gmsRemoteMediaClient?.streamDuration ?: 0L).toDouble() / 1000
				}
				else -> { // EXOPLAYER
					res = (_exoPlayer?.getDuration() ?: 0L).toDouble() / 1000
				}
			}
        } else if (propertyName == "volume") {
        	var headVolume = 0.0
			when (_headType) {
				HeadType.CHROMECAST -> {
					headVolume = _volume // _gmsRemoteMediaClient?.streamVolume ?: 0F
				}
				else -> { // EXOPLAYER
					headVolume = (_exoPlayer?.getVolume() ?: 0F).toDouble()
				}
			}
            res = if (_masterMuted || _muted) _volume else headVolume
        } else if (propertyName == "muted") {
            res = _muted
//        } else if (propertyName == "deviceVolume") {
//            res = (_exoPlayer?.getDeviceVolume() ?: 0).toDouble() / 100
//        } else if (propertyName == "deviceMuted") {
//            res = _exoPlayer?.isDeviceMuted()
		} else if (propertyName == "headType") {
			res = _headType.toString()
        }

        return res
    }

    /**
     * Load media URL
     * @param String mediaUrl, null to unload
     * @param Mixed seekPosition in seconds (Int or Double or null)
     * @param Map<String, String?> metadata (optional)
     * @return Boolean success
     */
    override fun load(mediaUrl: String?, seekPosition: Number?, metadata: Map<String, String?>?): Boolean {
		Logger.d("MediaController", "load mediaUrl: ${mediaUrl}, seekPosition: ${seekPosition}")
		if (_gmsCastSession != null) {
			if (_gmsRemoteMediaClient != null) {
				try {
					_gmsMediaUrl = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbMediaUrl") as String?
					_gmsPlayerId = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbPlayerId") as String?
					_gmsIsPlaying = _gmsRemoteMediaClient?.isPlaying == true || _gmsRemoteMediaClient?.mediaStatus?.playerState == MediaStatus.PLAYER_STATE_PLAYING
				} catch (err: Exception) {}
			}
		}
		Logger.d("MediaController", "load *** cur media url: ${_mediaUrl}")
		Logger.d("MediaController", "load *** gms media url: ${_gmsMediaUrl}")
		Logger.d("MediaController", "load *** gms player id: ${_gmsPlayerId}")
		Logger.d("MediaController", "load *** gms is playing: ${_gmsIsPlaying}")

		_mediaUrl = mediaUrl
		var seekPositionMs: Long? = null
		if (seekPosition != null) {
			seekPositionMs = 0L
			if (seekPosition is Double) seekPositionMs = ((seekPosition as Double) * 1000).toLong()
			else if (seekPosition is Int) seekPositionMs = (seekPosition as Int).toLong() * 1000
		}
		Logger.d("MediaController", "load seekPosition (ms): $seekPositionMs")
		_metadata = metadata
		Logger.d("MediaController", "load title: ${_metadata?.get("title")}")
		_playerId = metadata?.get("playerId")
		_defaultAudioGroupIndex = -1 // reset in order to capture the default in onTracksChanged

		val headType = _headType
		Logger.d("MediaController", "load current headType: ${headType}")
		val playing = if (_headType == HeadType.CHROMECAST) _gmsIsPlaying else _exoPlayer?.isPlaying ?: false
		Logger.d("MediaController", "load currently playing: ${playing}")
		val shouldPlay = _gmsHijackAllowed
		if (_castButtonPlayerId == _playerId) { _gmsHijackAllowed = true } // NB!

        if (mediaUrl != null) {
            _started = false

            if (_gmsCastSession?.castDevice != null && (_gmsHijackAllowed || _gmsPlayerId == _playerId)) {
				_gmsHijackAllowed = false
				_headType = HeadType.CHROMECAST
				Logger.d("MediaController", "load headType: ${_headType}")

				if (_gmsMediaUrlEnded) {
					_gmsMediaUrlEnded = false
					_gmsMediaUrl = null
				}
				Logger.d("MediaController", "load current mediaUrl: ${_gmsMediaUrl}")
				if (_mediaUrl != _gmsMediaUrl || _playerId != _gmsPlayerId) {
					_gmsMediaUrl = _mediaUrl
					_gmsPlayerId = _playerId

					val movieMetadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE)
					val title = stripHtmlTags(metadata?.get("title") ?: "[untitled]")
					movieMetadata.putString(MediaMetadata.KEY_TITLE, title)
					val description = stripHtmlTags(metadata?.get("description") ?: "")
					movieMetadata.putString(MediaMetadata.KEY_SUBTITLE, description)
					if (metadata?.get("thumbnailUrl") != null) movieMetadata.addImage(WebImage(Uri.parse(metadata?.get("thumbnailUrl"))))

					val customData = JSONObject()
					customData.put("bbMediaUrl", _mediaUrl)
					customData.put("bbPlayerId", _playerId)
					val mediaInfo = MediaInfo.Builder(mediaUrl)
						.setStreamType(if (metadata?.get("isLive") == "true") MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
						.setContentType(metadata?.get("contentType") ?: "video/mp4")
						.setMetadata(movieMetadata)
						.setStreamDuration(((metadata?.get("duration") ?: "0").toDouble() * 1000).toLong())
						.setCustomData(customData)
						.build()

					if (_gmsRemoteMediaClient == null) {
						Logger.d("MediaController", "load WTF just-in-time getting remote media client")
						_gmsRemoteMediaClient = _gmsCastSession?.getRemoteMediaClient()
						_gmsRemoteMediaClient?.registerCallback(this)
					}
					val mlrdBuilder = MediaLoadRequestData.Builder()
					mlrdBuilder.setMediaInfo(mediaInfo)
					mlrdBuilder.setCustomData(customData)
					mlrdBuilder.setAutoplay((_headType != headType && playing) || shouldPlay)
					if (seekPositionMs != null) {
						mlrdBuilder.setCurrentTime(seekPositionMs)
						// seekPositionMs = null
					}
					if (_gmsRemoteMediaClient != null) {
						_putCastButtonPlayerId()
						_gmsRemoteMediaClient?.load(mlrdBuilder.build())
					}
				} else { // both _gmsMediaUrl AND _gmsPlayerId match
					if (seekPositionMs != null) {
						Logger.d("MediaController", "chromecast going to seek to $seekPositionMs")
						_gmsRemoteMediaClient?.seek(seekPositionMs) // IMPROVE ME: avoid deprecated prototype
					} else {
						Logger.d("MediaController", "chromecast going to seek to 0")
						_gmsRemoteMediaClient?.seek(0L) // IMPROVE ME: avoid deprecated prototype
					}
					if (_headType != headType && playing || shouldPlay) { // rolling head switch
						Logger.d("MediaController", "chromecast going to play")
						_gmsRemoteMediaClient?.play()
					}
				}

				// sync exo player for still
				if (_mediaUrl != _exoMediaUrl) {
					_exoMediaUrl = _mediaUrl
					val builder = MediaItem.Builder()
					if (metadata?.get("contentType") == "application/vnd.apple.mpegurl") builder.setMimeType(MimeTypes.APPLICATION_M3U8)
					val mediaItem: MediaItem = builder.setUri(mediaUrl).build()
					_exoPlayer?.setMediaItem(mediaItem)
					_exoPlayer?.playWhenReady = (_headType != headType && playing || shouldPlay)
					if (seekPositionMs != null) {
						_exoPlayer?.seekTo(seekPositionMs)
						// seekPositionMs = null
					}
					_exoPlayer?.prepare() // actual load
				} else { // _exoMediaUrl matches
					_exoPlayer?.pause()
				}
            } else {
				_gmsHijackAllowed = false
				_headType = HeadType.EXOPLAYER
				Logger.d("MediaController", "load headType: ${_headType}")

				Logger.d("MediaController", "load current mediaUrl: ${_exoMediaUrl}")
				if (_mediaUrl != _exoMediaUrl) {
					_exoMediaUrl = _mediaUrl
					val builder = MediaItem.Builder()
					if (metadata?.get("contentType") == "application/vnd.apple.mpegurl") builder.setMimeType(MimeTypes.APPLICATION_M3U8)
					val mediaItem: MediaItem = builder.setUri(mediaUrl).build()
					_exoPlayer?.setMediaItem(mediaItem)
					_exoPlayer?.playWhenReady = (_headType != headType && playing || shouldPlay)
					if (seekPositionMs != null) {
						_exoPlayer?.seekTo(seekPositionMs)
						// seekPositionMs = null
					}
					_exoPlayer?.prepare() // actual load
				} else { // _exoMediaUrl matches
					if (seekPositionMs != null) {
						_exoPlayer?.seekTo(seekPositionMs)
					} else {
						_exoPlayer?.seekTo(0L)
					}
					if (_headType != headType && playing || shouldPlay) { // rolling head switch
						_exoPlayer?.play()
					}
				}
				// _gmsRemoteMediaClient?.pause()
            }
        } else {
            _exoPlayer?.removeMediaItem(0)
        }

		val ytTimeBar = if (_exoTimeBar is YouTubeTimeBar) _exoTimeBar as YouTubeTimeBar else null
		val chapters = mutableListOf<YouTubeChapter>()
		val chaptersJson: String? = metadata?.get("chaptersJson")
		// println("[MediaController] load chaptersJson: ${chaptersJson}")
		if (chaptersJson != null) {
			// parse chaptersJson into chapters
			if (chaptersJson != null) {
				try {
					val chaptersJsonObject = JSONObject(chaptersJson)
					chaptersJsonObject.keys().forEach {
						// println("[MediaController] load it: ${it}")
						val value = if (chaptersJsonObject.isNull(it)) null else chaptersJsonObject.get(it)
						if (value is String) {
							// println("[MediaController] load value: ${value}")
							val ytc = object: YouTubeChapter {
								override val startTimeMs: Long = (it.toFloat() * 1000).toLong()
								override var title: String? = value as String
							}
							chapters.add(ytc)
						}
					}
				} catch (er: JSONException) { }
			}
		}
		if (ytTimeBar != null) {
			ytTimeBar.chapters = chapters.toList()
		}
		val highlights = mutableListOf<YouTubeHighlight>()
		val highlightsJson: String? = metadata?.get("highlightsJson")
		// println("[MediaController] load highlightsJson: ${highlightsJson}")
		if (highlightsJson != null) {
			// parse highlightsJson into highlights
			try {
				val highlightsJsonObject = JSONObject(highlightsJson)
				highlightsJsonObject.keys().forEach {
					val value = if (highlightsJsonObject.isNull(it)) null else highlightsJsonObject.get(it)
					if (value is String) {
						val yth = object: YouTubeHighlight {
							override val timeMs: Long = (it.toFloat() * 1000).toLong()
							override var title: String? = value as String
						}
						highlights.add(yth)
					}
				}
			} catch (_: JSONException) { }
		}
		if (ytTimeBar != null) {
			ytTimeBar.highlights = highlights.toList()
		}

        return true
    }

	private fun _putCastButtonPlayerId() {
		val sharedPreferences = _sharedPreferences
		if (sharedPreferences != null) {
			println("[MediaController] going to put bb.castButtonPlayerId: ${_playerId}")
			with(sharedPreferences.edit()) {
				putString("bb.castButtonPlayerId", _playerId)
				apply()
			}
		}
	}

	private var _onSharedPreferenceChangeListener = SharedPreferences.OnSharedPreferenceChangeListener {
			prefs, key ->
		if (key == "bb.castButtonPlayerId") {
			println("[MediaController] going to get bb.castButtonPlayerId")
			_castButtonPlayerId = prefs.getString("bb.castButtonPlayerId", null)
			println("[MediaController] got bb.castButtonPlayerId: ${_castButtonPlayerId}")
		}
	}

	override fun play(userAction: Boolean, requested: Boolean): Boolean {
        Logger.d("MediaController", "play userAction: $userAction, requested: $requested")
		Logger.d("MediaController", "play _headType: $_headType")
		Logger.d("MediaController", "play _exoIsPlaying: $_exoIsPlaying")
		when (_headType) {
			HeadType.CHROMECAST -> {
				if (_gmsCastSession?.castDevice != null && _gmsPlayerId != _playerId && userAction && !_exoIsPlaying) {
					_showPlayAlert()
				} else {
					_playSelectedItemRemotely()
				}
            }
            else -> { // EXOPLAYER
				if (!requested) {
					if (_gmsCastSession?.castDevice != null && _gmsPlayerId != _playerId && userAction && !_exoIsPlaying) {
						_showPlayAlert()
					} else {
						_playSelectedItemLocaly()
					}
				} else {
					_suspended = false
				}
			}
		}

        return true
    }

	private var _audioTracks: List<Audiotrack> = mutableListOf<Audiotrack>()
	private var _qualities: List<Quality> = mutableListOf<Quality>()
	private var _videoTracks: List<VideoTrack> = mutableListOf<VideoTrack>()
	private var _subtitles: List<Subtitle> = mutableListOf<Subtitle>()
	internal var _currentSubtitleId: String = "off"
	private var _currentSubtitleIso: String? = null
	private var _defaultAudioGroupIndex: Int = -1
	private var _currentAudioTrackIso: String? = null
	private var _isPlayingWhileSuspended: Boolean = false
	private var _defaultSubtitle: String? = null
	private var _mediaClipJustLoaded: Boolean = false

	@OptIn(UnstableApi::class)
	override fun onTracksChanged(
		tracks: Tracks
	) {
		val audioTracks: MutableList<Audiotrack> = mutableListOf<Audiotrack>()
		val qualities: MutableList<Quality> = mutableListOf<Quality>()
		val videoTracks: MutableList<VideoTrack> = mutableListOf<VideoTrack>()
		val subtitles: MutableList<Subtitle> = mutableListOf<Subtitle>()

		tracks.groups.forEachIndexed { groupIndex, trackGroup ->
			when (trackGroup.type) {
				C.TRACK_TYPE_AUDIO -> {
					if (trackGroup.isSelected()) {
						_activeAudioId = groupIndex // just bookkeeping
						if (_defaultAudioGroupIndex == -1) _defaultAudioGroupIndex = groupIndex // assume first selected is default
					}
					for (i in 0 until trackGroup.length) {
						if ( trackGroup.isTrackSupported(i) ) {
							val isSelected = trackGroup.isTrackSelected(i)
							val trackFormat: Format = trackGroup.getTrackFormat(i)

							val bbARoles = _getBBAudioRoles(trackFormat.roleFlags)
							val audioTrack = Audiotrack()
							audioTrack.id = trackFormat.language + "_" + (if (bbARoles.isNotEmpty()) bbARoles.reduce { acc, str -> acc + "+" + str } else "")
							audioTrack.audioId = groupIndex // NB!
							audioTrack.isocode = trackFormat.language
							audioTrack.roleFlags = trackFormat.roleFlags
							audioTrack.label = trackFormat.label ?: languageFromIsoCode(trackFormat.language)
							val primary = bbARoles.isEmpty() && groupIndex == _defaultAudioGroupIndex // NB!
							if (primary) {
								audioTrack.id = "-1"
								audioTrack.label += " *"
							}
							audioTrack.isSelected = isSelected
							audioTrack.origId = trackFormat.id
							audioTracks.add(audioTrack)
						}
					}
				}
				C.TRACK_TYPE_VIDEO -> {
					if (trackGroup.isSelected()) { _activeVideoId = groupIndex } // NB!
					for (i in 0 until trackGroup.length) {
						if ( trackGroup.isTrackSupported(i) ) {
							val isSelected = trackGroup.isTrackSelected(i)
							val trackFormat: Format = trackGroup.getTrackFormat(i)

							val bbVRoles = _getBBVideoRoles(trackFormat.roleFlags)
							val videoTrack = VideoTrack()
							videoTrack.id = "${trackFormat.language}_" + (if (bbVRoles.isNotEmpty()) bbVRoles.reduce { acc, str -> acc + "+" + str } else "")
							videoTrack.videoId = groupIndex // NB!
							videoTrack.isocode = trackFormat.language
							videoTrack.roleFlags = trackFormat.roleFlags
							videoTrack.label = trackFormat.label ?: languageFromIsoCode(trackFormat.language)
							val primary = bbVRoles.isEmpty() // NB!
							if (primary) {
								videoTrack.id = "-1"
								videoTrack.label += " *"
							}
							videoTrack.isSelected = isSelected
							videoTrack.origId = trackFormat.id
							videoTracks.add(videoTrack)
						}
					}
				}
				C.TRACK_TYPE_TEXT -> {
					for (i in 0 until trackGroup.length) {
						if ( trackGroup.isTrackSupported(i) ) {
							val isSelected = trackGroup.isTrackSelected(i)
							val trackFormat: Format = trackGroup.getTrackFormat(i)

							val subtitle: Subtitle = com.bluebillywig.bbnativeshared.model.Subtitle()
							subtitle.id = trackFormat.id
							subtitle.languagename = trackFormat.label
							subtitle.isocode = trackFormat.language
							subtitle.roleFlags = trackFormat.roleFlags
							subtitle.isSelected = isSelected

							subtitles.add(subtitle)
						}
					}
				} else -> {}
			}
		}
		tracks.groups.forEachIndexed { groupIndex, trackGroup ->
			when (trackGroup.type) {
				C.TRACK_TYPE_VIDEO -> {
					if (groupIndex == _activeVideoId || _activeVideoId == -1) {
						for (i in 0 until trackGroup.length) {
							if ( trackGroup.isTrackSupported(i) ) {
								val isSelected = trackGroup.isTrackSelected(i)
								val trackFormat: Format = trackGroup.getTrackFormat(i)

								val heightStr = (ceil(trackFormat.height.toDouble() / 120) * 120).toInt().toString() // 272 -> 360, 400/404/432 -> 480
								val quality: Quality = Quality()
								quality.id = trackFormat.height.toString() + trackFormat.averageBitrate.toString()
								quality.index = i
								quality.label = if (trackFormat.height > -1) "${heightStr}p" else "${trackFormat.averageBitrate}kbps"
								quality.isSelected = isSelected
								quality.origId = trackFormat.id
								quality.bitrate = trackFormat.averageBitrate
								quality.height = trackFormat.height
								quality.mimeType = trackFormat.sampleMimeType
								qualities.add(quality)
							}
						}
					}
				} else -> {}
			}
		}
		_audioTracks = audioTracks.distinctBy { it.id }
		_qualities = qualities.toList()
		_videoTracks = videoTracks.distinctBy { it.id }
		_subtitles = subtitles.toList()

		_eventBus?.trigger(EventName.audioTracksChanged, mapOf("audioTracks" to _audioTracks))
		_eventBus?.trigger(EventName.qualityTracksChanged, mapOf("assets" to _qualities))
		_eventBus?.trigger(EventName.subtitleTracksChanged, mapOf("subtitles" to _subtitles))
		_eventBus?.trigger(EventName.bb_assets_changed, mapOf("qualities" to _qualities, "audioTracks" to _audioTracks, "videoTracks" to _videoTracks, "subtitles" to _subtitles))

		super.onTracksChanged(tracks)

		if (_mediaClipJustLoaded && _subtitles != null && _subtitles.count() > 0) {
			_mediaClipJustLoaded = false
			// handle default language stuff only once per clip. this method is called after ANY track change in the exoplayer
			when (_defaultSubtitle) {
				null, "None" -> {
					setSubtitle("off")
					return
				}
				"Default Language" -> {
					for (subtitle in _subtitles) {
						if (subtitle.default == "true") {
							// found default language
							this.setSubtitle(subtitle.id!!)
							return
						}
					}
					// look for sub using system language
					val systemLanguage = Locale.getDefault().language
					if (systemLanguage != null) {
						for (subtitle in _subtitles) {
							if (subtitle.isocode == systemLanguage) {
								this.setSubtitle(subtitle.id!!)
								return
							}
						}
					}
				}
				"First Available Subtitle" -> {
					if (_subtitles != null && _subtitles.count() > 0) {
						this.setSubtitle(_subtitles[0].id!!)
					}
				}
			}
		}
	}


    override fun pause(requested: Boolean): Boolean {
        Logger.d("MediaController", "pause requested: $requested")
		when (_headType) {
			HeadType.CHROMECAST -> {
		    	_gmsRemoteMediaClient?.pause()
		    }
            else -> { // EXPOLAYER
				if (!requested) _exoPlayer?.pause() else _suspended = true
			}
		}

        return true
    }

	override fun setSubtitle(id: String): Boolean {
		if (id == "off") {
			return (_subtitlesOff() != "err")
		} else { // on
			if (id != "on") { // actual subtitle id
				_currentSubtitleId = id
			}
			return (_subtitlesOn() != "err")
		}
	}
	
	override fun subtitlesOff() {
		_subtitlesOff()
	}

	private fun _getBBAudioRoles (roleFlags: Int): List<String> {
		val audioRoleMap: List<Pair<Int, String>> = listOf(Pair(C.ROLE_FLAG_MAIN, ""), Pair(C.ROLE_FLAG_DESCRIBES_VIDEO, "audiodescription"), Pair(C.ROLE_FLAG_TRANSCRIBES_DIALOG, "audiotranscript"))
		return (audioRoleMap.filter { (it.first and roleFlags) > 0 && it.second != "" }).map { it.second }
	}

	private fun _getBBVideoRoles(roleFlags: Int): List<String> {
		val videoRoleMap: List<Pair<Int, String>> = listOf(Pair(C.ROLE_FLAG_MAIN, ""), Pair(C.ROLE_FLAG_SIGN, "sign"))
		return (videoRoleMap.filter { (it.first and roleFlags) > 0 && it.second != "" }).map { it.second }
	}

	private fun _gmsRemoteUpdateActiveTracks() {
		val remote = _gmsRemoteMediaClient
		if (remote != null) {
			val trackIds: MutableList<Long> = mutableListOf()
			if (_gmsTracks == null) _gmsTracks = remote.mediaInfo?.mediaTracks
			_gmsTracks?.forEach {
				if (it.type == MediaTrack.TYPE_TEXT && it.language == _currentSubtitleIso) {
					trackIds.add(it.id)
				} // && SUBTYPE_SUBTITLES?
				if (it.type == MediaTrack.TYPE_AUDIO && it.language == _currentAudioTrackIso) {
					trackIds.add(it.id)
				}
			}
			println("[MediaController] _gmsRemoteUpdateActiveTracks trackIds: ${trackIds}")
			remote.setActiveMediaTracks(trackIds.toLongArray())
		}
	}

	private fun _subtitlesOff(): String {
		var id = "err"

		val player = _exoPlayer
		if (player != null) {
			_currentSubtitleIso = null
			id = "off"
			player.setTrackSelectionParameters(
				player.getTrackSelectionParameters()
					.buildUpon()
					.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
					.build())
			_eventBus?.trigger(EventName.subtitleTrackChanged, mapOf("id" to id))
		}

		_gmsRemoteUpdateActiveTracks()

		return id
	}
	override fun subtitlesOn() {
		_subtitlesOn()
	}
	private fun _subtitlesOn(): String {
		var id = "err"

		val player = _exoPlayer
		if (player != null) {
			_currentSubtitleIso = null
			for (subtitle in _subtitles) {
				if (subtitle.id == _currentSubtitleId) {
					_currentSubtitleIso = subtitle.isocode
					id = subtitle.id ?: "on"
					player.setTrackSelectionParameters(
						player.getTrackSelectionParameters()
							.buildUpon()
							.setPreferredTextLanguage(subtitle.isocode)
							.setSelectUndeterminedTextLanguage(true)
							.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
							.setPreferredTextRoleFlags(C.ROLE_FLAG_SUBTITLE)
							.build()
					)
					_eventBus?.trigger(EventName.subtitleTrackChanged, mapOf("id" to id))
				}
			}
		}

		_gmsRemoteUpdateActiveTracks()

		return id
	}

	override fun setAudiotrack(id: String): Boolean {
		var ret = false

		val player = _exoPlayer
		if (player != null) {
			_currentAudioTrackIso = null
			for (i in 0 until _audioTracks.count()) {
				val audiotrack = _audioTracks[i]
				if (audiotrack.id == id) { // found
					_activeAudioId = audiotrack.audioId ?: -1 // just bookkeeping
					_currentAudioTrackIso = audiotrack.isocode
					player.setTrackSelectionParameters(
						player.getTrackSelectionParameters()
							.buildUpon()
							.setPreferredAudioLanguage(audiotrack.isocode)
							.setPreferredAudioRoleFlags(audiotrack.roleFlags ?: 0)
							.build()
					);
					ret = true
				}
			}
		}

		_gmsRemoteUpdateActiveTracks()

		return ret
	}

	override fun setQuality(index: Int): Boolean {
		val player = _exoPlayer
		if (player != null) {
			val tracks = player.currentTracks
			if (index == -1) {
				for (trackGroup in tracks.groups) {
					when (trackGroup.type) {
						C.TRACK_TYPE_VIDEO -> {
							player.setTrackSelectionParameters(
								player.getTrackSelectionParameters()
									.buildUpon()
									.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
									.build()
							)
							return true
						} else -> {}
					}
				}
			} else {
				tracks.groups.forEachIndexed { groupIndex, trackGroup ->
					if (groupIndex == _activeVideoId || _activeVideoId == -1) {
						when (trackGroup.type) {
							C.TRACK_TYPE_VIDEO -> {
								val mediaTrackGroup = trackGroup.getMediaTrackGroup() // does *not* contain runtime information such as which tracks are supported and currently selected
								player.setTrackSelectionParameters(
									player.getTrackSelectionParameters()
										.buildUpon()
										.setOverrideForType(TrackSelectionOverride(mediaTrackGroup, index))
										.build()
								)
								return true
							}
							else -> {}
						}
					}
				}
			}
		}

		return false
	}

	override fun setVideoTrack(videoTrackId: String): Boolean {
		var ret = false

		val player = _exoPlayer
		if (player != null) {
			for (i in 0 until _videoTracks.count()) {
				val videoTrack = _videoTracks[i]
				if (videoTrack.id == videoTrackId) { // found
					_activeVideoId = videoTrack.videoId ?: -1 // NB!
					player.setTrackSelectionParameters(
						player.getTrackSelectionParameters()
							.buildUpon()
							.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
							.setPreferredVideoRoleFlags(videoTrack.roleFlags ?: 0)
							.build()
					)
					ret = true
				}
			}
		}

		_gmsRemoteUpdateActiveTracks()

		if (player != null) {
			this.onTracksChanged(player.currentTracks) // re-triggers bb_assets_changed etc.
		}

		return ret
	}

    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null) {
					if (data["embedObject"] != null) {
						val embedObject = data["embedObject"] as EmbedObject
						val embedData: EmbedData? = embedObject.embedData
						val playout: Playout? = embedObject?.playoutData
						if (playout?.defaultSubtitle != null) {
							_defaultSubtitle = playout?.defaultSubtitle
						}
					}
				}
			}
			EventName.bb_mediaclip_loaded -> {
				_mediaClipJustLoaded = true
			}
            EventName.bb_master_mute -> {
                _masterMuted = true
				_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())
            }
            EventName.bb_master_unmute -> {
                _masterMuted = false
				_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())
            }
			EventName.bb_master_volume -> {
				_masterVolume = if (data?.get("volume") is Double) data?.get("volume") as Double else 1.0
				_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())
			}
            EventName.adContentPauseReq -> {
                _suspended = true
            }
            EventName.adContentResumeReq, EventName.adSkipped -> {
                _suspended = false
				if (_isPlayingWhileSuspended && _headType == HeadType.EXOPLAYER) onIsPlayingChanged(true) // NB hack exo!
            }
            else -> { return }
        }
        Logger.d("MediaController", "Processed event: $eventType")
    }

	// Player.EventListener::onPlaybackStateChanged
    override fun onPlaybackStateChanged(state: Int) {
        Logger.d("MediaController", "onPlaybackStateChanged $state while suspended: ${_suspended}")
        if (!_suspended || true) { // NB check disabled, otherwise would miss ended event!
            when (state) {
                Player.STATE_IDLE -> {
                    // nothing
                }
                Player.STATE_BUFFERING -> {
                    _eventBus?.trigger(EventName.bb_media_stalled)
                }
                Player.STATE_READY -> {
					val size = _exoPlayer?.videoSize
                    _eventBus?.trigger(EventName.bb_media_canplay, mapOf("mediaWidth" to (size?.width ?: 0L), "mediaHeight" to (size?.height ?: 0L)))
                }
                Player.STATE_ENDED -> {
                    _started = false
                    Logger.d("MediaController", "onPlaybackStateChanged going to trigger bb_media_finished")
                    _eventBus?.trigger(EventName.bb_media_finished)
                }
            }
        }
    }

	// Player.EventListener::onPlayerError
    override fun onPlayerError(error: PlaybackException) {
        Logger.d("MediaController", "onPlayerError $error while suspended: ${_suspended}")
        if (!_suspended) {
            _eventBus?.trigger(EventName.bb_media_failed)
        }
    }

	// Player.EventListener::onIsPlayingChanged
    override fun onIsPlayingChanged(isPlaying: Boolean) {
        Logger.d("MediaController", "onIsPlayingChanged $isPlaying while suspended: ${_suspended}")
        if (!_suspended) {
			_isPlayingWhileSuspended = false
            if (isPlaying) {
            	_exoIsPlaying = true
                _eventBus?.trigger(EventName.bb_media_playing)
				_progressTracker?.run()
                if (!_started)  {
                    _started = true
                    _eventBus?.trigger(EventName.bb_media_started) // for stats
                } else {
                    _eventBus?.trigger(EventName.bb_media_resumed) // for stats
                }
            } else {
				_exoIsPlaying = false
				_progressTracker?.stop()
                _eventBus?.trigger(EventName.bb_media_paused)
            }
        } else {
			_isPlayingWhileSuspended = isPlaying
		}
    }

//	// Player.EventListener::onSeekStarted
//    override fun onSeekStarted() { // NB only if using an AnalyticsListener!
//        if (!_suspended) {
//            _eventBus?.trigger(EventName.bb_media_seeking)
//        }
//    }

	// Player.EventListener::onPositionDiscontinuity
    override fun onPositionDiscontinuity(reason: Int) {
        Logger.d("MediaController", "onPositionDiscontinuity $reason while suspended: ${_suspended}")
        if (!_suspended) {
            when (reason) {
                Player.DISCONTINUITY_REASON_SEEK, Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT -> {
                    val seekOffset = ((_exoPlayer?.getCurrentPosition() ?: 0L).toDouble() / 1000).toString()
                    _eventBus?.trigger(EventName.bb_media_seeked, mapOf("seekOffset" to seekOffset)) // NB no seeking?!?
                }
                Player.DISCONTINUITY_REASON_INTERNAL -> {
                }
            }
        }
    }

	// Player.EventListener::onPlaybackParametersChanged
    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
        // playbackParameters.pitch
        // playbackParameters.speed
    }

	// Player.EventListener::onTimelineChanged
    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
        Logger.d("MediaController", "onTimelineChanged $reason while suspended: ${_suspended}")
        if (!_suspended) {
            when (reason) {
                Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED, Player.TIMELINE_CHANGE_REASON_SOURCE_UPDATE -> {
                    val duration = (_exoPlayer?.getDuration() ?: 0L).toDouble() / 1000
                    _eventBus?.trigger(EventName.bb_media_duration_change, mapOf("duration" to duration))
                }
            }
        }
    }

//	// Player.Listener::onVideoSizeChanged
//	override fun onVideoSizeChanged(size: VideoSize) {
//		Logger.d("MediaController", "onVideoSizeChanged size: ${size.width}x${size.height}")
//		Logger.d("MediaController", "onVideoSizeChanged video format: ${_exoPlayer?.videoFormat}")
//		Logger.d("MediaController", "onVideoSizeChanged video scaling mode: ${_exoPlayer?.videoScalingMode}")
//	}

	// RemoteMediaClient.Callback::onAdBreakStatusUpdated
	override fun onAdBreakStatusUpdated(): Unit {}

	// RemoteMediaClient.Callback::onMetadataUpdated
	override fun onMetadataUpdated(): Unit {}

	// RemoteMediaClient.Callback::onPreloadStatusUpdated
	override fun onPreloadStatusUpdated(): Unit {}

	// RemoteMediaClient.Callback::onQueueStatusUpdated
	override fun onQueueStatusUpdated(): Unit {}

	// RemoteMediaClient.Callback::onSendingRemoteMediaRequest
	override fun onSendingRemoteMediaRequest(): Unit {}

	// RemoteMediaClient.Callback::onStatusUpdated
	override fun onStatusUpdated(): Unit {
		if (_gmsCastSession != null) {
			if (_gmsRemoteMediaClient != null) {
				try {
					_gmsPlayerId = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbPlayerId") as String?
					if (_gmsPlayerId != null && _gmsPlayerId != _playerId) {
						_headType = HeadType.EXOPLAYER
					}
					_gmsTracks = _gmsRemoteMediaClient?.mediaInfo?.mediaTracks
				} catch (err: Exception) {}
			}
		}

		val mediaStatus: MediaStatus? = _gmsRemoteMediaClient?.mediaStatus
		if (mediaStatus?.streamPosition != _gmsStreamPosition && _gmsPlayerId == _playerId) {
			_gmsStreamPosition = mediaStatus?.streamPosition
			if (_gmsIsPlaying) {
				val currentTime: String = ((_gmsStreamPosition?.toDouble() ?: 0.0) / 1000).toString()
				_eventBus?.trigger(EventName.bb_media_timeupdate, mapOf("currentTime" to currentTime))
			}
		}
		if (mediaStatus?.streamVolume != _gmsStreamVolume) {
			_gmsStreamVolume = mediaStatus?.streamVolume
		}
		if (mediaStatus?.isMute != _gmsIsMute) {
			_gmsIsMute = mediaStatus?.isMute
		}
		if (mediaStatus?.isPlayingAd != _gmsIsPlayingAd) {
			_gmsIsPlayingAd = mediaStatus?.isPlayingAd
		}
		if (mediaStatus?.playerState != _gmsPlayerState && _gmsPlayerId == _playerId) {
			_gmsPlayerState = mediaStatus?.playerState
			when (mediaStatus?.playerState) {
				MediaStatus.PLAYER_STATE_LOADING -> {
					_eventBus?.trigger(EventName.bb_media_canplay) // ~
					val deviceName = _gmsCastSession?.castDevice?.friendlyName ?: "Chromecast"
					Logger.d("MediaController", "onStatusUpdated loading going to trigger bb_media_cast_info for device name: ${deviceName}")
					_eventBus?.trigger(EventName.bb_media_cast_info, mapOf("deviceName" to deviceName, "ours" to (_gmsPlayerId == _playerId)))
				}
				MediaStatus.PLAYER_STATE_BUFFERING -> {
					_eventBus?.trigger(EventName.bb_media_stalled)
				}
				MediaStatus.PLAYER_STATE_PLAYING -> {
					_gmsIsPlaying = true
					_eventBus?.trigger(EventName.bb_media_playing)
					val deviceName = _gmsCastSession?.castDevice?.friendlyName ?: "Chromecast"
					Logger.d("MediaController", "onStatusUpdated playing going to trigger bb_media_cast_info for device name: ${deviceName}")
					_eventBus?.trigger(EventName.bb_media_cast_info, mapOf("deviceName" to deviceName, "ours" to (_gmsPlayerId == _playerId)))
					if (!_started) {
						_started = true
						_eventBus?.trigger(EventName.bb_media_started) // for stats
					} else {
						_eventBus?.trigger(EventName.bb_media_resumed) // for stats
					}

					_gmsRemoteUpdateActiveTracks() // because in PLAYER_STATE_LOADING is too early
				}
				MediaStatus.PLAYER_STATE_PAUSED -> {
					_gmsIsPlaying = false
					_eventBus?.trigger(EventName.bb_media_paused)
					val deviceName = _gmsCastSession?.castDevice?.friendlyName ?: "Chromecast"
					Logger.d("MediaController", "onStatusUpdated paused going to trigger bb_media_cast_info for device name: ${deviceName}")
					_eventBus?.trigger(EventName.bb_media_cast_info, mapOf("deviceName" to deviceName, "ours" to (_gmsPlayerId == _playerId)))

					_gmsRemoteUpdateActiveTracks() // because in PLAYER_STATE_LOADING is too early
				}
				MediaStatus.PLAYER_STATE_IDLE -> {
					_gmsIsPlaying = false
					when (mediaStatus?.idleReason) {
						MediaStatus.IDLE_REASON_ERROR -> {
							_eventBus?.trigger(EventName.bb_media_failed)
							_gmsMediaUrlEnded = true // NB!
						}
						MediaStatus.IDLE_REASON_FINISHED -> {
							_eventBus?.trigger(EventName.bb_media_finished)
							_gmsMediaUrlEnded = true // NB!
						}
						MediaStatus.IDLE_REASON_CANCELED -> {
						}
						MediaStatus.IDLE_REASON_INTERRUPTED -> {
						}
						else -> {
						}
					}
				}
				else -> {
				}
			}
		}
	}

//	// RemoteMediaClient.ProgressListener::onProgressUpdated
//	override fun onProgressUpdated(p0: Long, p1: Long): Unit {
//		val currentTime: String = (p0).toString()
//		_eventBus?.trigger(EventName.bb_media_timeupdate, mapOf("currentTime" to currentTime))
//	}

	private var _eventBus: EventBusInterface? = eventBus
	private var _context: Context? = null
	private var _mediaUrl: String? = null
	private var _metadata: Map<String, String?>? = null
	private var _playerId: String? = null
	private var _sharedPreferences: SharedPreferences? = null

	private var _volume: Double = 1.0
    private var _muted: Boolean = false
	private var _masterVolume: Double = 1.0
    private var _masterMuted: Boolean = false
    private var _suspended: Boolean = false
    private var _started: Boolean = false
	private var _headType: HeadType = HeadType.EXOPLAYER

	// ExoPlayer
	private var _exoPlayer: ExoPlayer? = player
	private var _exoMediaUrl: String? = null
	private var _exoIsPlaying: Boolean = false
	private var _exoTimeBar: TimeBar? = null

    // ChromeCast
    private var _gmsCastSession: CastSession? = null
	private var _gmsRemoteMediaClient: RemoteMediaClient? = null
	private var _gmsMediaUrl: String? = null
	private var _gmsMediaUrlEnded: Boolean = false
	private var _gmsPlayerState: Int? = null
	private var _gmsIsPlaying: Boolean = false
	private var _gmsStreamPosition: Long? = null
	private var _gmsStreamVolume: Double? = null
	private var _gmsIsMute: Boolean? = null
	private var _gmsIsPlayingAd: Boolean? = null
	private var _gmsPlayerId: String? = null
	private var _gmsTracks: List<MediaTrack>? = null
	private var _gmsHijackAllowed: Boolean = false
	private var _progressTracker: ProgressTracker?

	// state
	private var _activeVideoId: Int = -1
	private var _activeAudioId: Int = -1
	private var _castButtonPlayerId: String? = null

    init {
		_exoPlayer?.setVolume(if (_masterMuted || _muted) 0F else (_masterVolume * _volume).toFloat())

        _exoPlayer?.addListener(this)
        _eventBus?.addEventlistener(this)

		_progressTracker = ProgressTracker(_exoPlayer as Player, _eventBus)
		setSubtitle("off")
	}

    fun __destruct() {
		_sharedPreferences?.unregisterOnSharedPreferenceChangeListener(_onSharedPreferenceChangeListener)
		_sharedPreferences = null

		_gmsRemoteMediaClient = null
		_gmsCastSession = null
        _exoPlayer?.removeListener(this)
        _exoPlayer = null
        _eventBus?.removeEventlistener(this)
        _eventBus = null
		_progressTracker?.__destruct()
		_progressTracker = null
    }

	fun setContext (context: Context) {
		_sharedPreferences?.unregisterOnSharedPreferenceChangeListener(_onSharedPreferenceChangeListener)
		_sharedPreferences = null
		_context = context
		_sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
		_sharedPreferences?.registerOnSharedPreferenceChangeListener(_onSharedPreferenceChangeListener)

		println("[MediaController] setContext going to get bb.castButtonPlayerId")
		_castButtonPlayerId = _sharedPreferences?.getString("bb.castButtonPlayerId", null)
		println("[MediaController] setContext got bb.castButtonPlayerId: ${_castButtonPlayerId}")
	}

	fun setTimeBar (timeBar: TimeBar?) {
		_exoTimeBar = timeBar
	}

    fun setCastSession (castSession: CastSession?, autoLoad: Boolean = false): Unit {
		Logger.d("MediaController", "setCastSession autoLoad: ${autoLoad}")
		Logger.d("MediaController", "setCastSession cast device: ${castSession?.castDevice}")
		if (castSession != _gmsCastSession) {
			val currentTime = get("currentTime")
			val seekOffset: Double = if (currentTime is Double) currentTime else 0.0
			Logger.d("MediaController", "setCastSession seekOffset: ${seekOffset}")

			if (_gmsCastSession != null) {
				if (_gmsRemoteMediaClient != null) {
					try {
						_gmsMediaUrl = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbMediaUrl") as String?
						_gmsPlayerId = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbPlayerId") as String?
						_gmsIsPlaying = _gmsRemoteMediaClient?.isPlaying == true || _gmsRemoteMediaClient?.mediaStatus?.playerState == MediaStatus.PLAYER_STATE_PLAYING
					} catch (err: Exception) {}
				}
				// hack
				if (_gmsPlayerId != _playerId && !_exoIsPlaying) {
					_progressTracker?.stop()
					_eventBus?.trigger(EventName.bb_media_paused)
				}
			}

			_gmsCastSession = castSession
			_gmsRemoteMediaClient?.unregisterCallback(this)
			_gmsRemoteMediaClient = _gmsCastSession?.getRemoteMediaClient()
			_gmsRemoteMediaClient?.registerCallback(this)
			// _gmsRemoteMediaClient?.addListener(this)
			// _gmsRemoteMediaClient?.addProgressListener(this, 1000L)

			if (_gmsCastSession != null) {
				if (_gmsRemoteMediaClient != null) {
					try {
						_gmsMediaUrl = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbMediaUrl") as String?
						_gmsPlayerId = _gmsRemoteMediaClient?.mediaInfo?.customData?.get("bbPlayerId") as String?
						_gmsIsPlaying = _gmsRemoteMediaClient?.isPlaying == true || _gmsRemoteMediaClient?.mediaStatus?.playerState == MediaStatus.PLAYER_STATE_PLAYING
					} catch (err: Exception) {}
				}
				// hack
				if (_gmsPlayerId != _playerId && !_exoIsPlaying) {
					_progressTracker?.stop()
					_eventBus?.trigger(EventName.bb_media_paused)
				}
			}

			val deviceName = if (_gmsCastSession != null) _gmsCastSession?.castDevice?.friendlyName ?: "Chromecast" else null
			Logger.d("MediaController", "setCastSession going to trigger bb_media_cast_start for device name: ${deviceName}")
			_eventBus?.trigger(EventName.bb_media_cast_start, mapOf("sessionId" to (castSession?.sessionId ?: ""), "deviceName" to deviceName, "ours" to (_gmsPlayerId == _playerId)))

			_gmsHijackAllowed = false
			if (autoLoad) load(_mediaUrl, seekOffset, _metadata)
		}
    }

	private fun _showPlayAlert () {
		val context = _context
		if (context != null) {
			// setup the alert builder
			val builder: AlertDialog.Builder = AlertDialog.Builder(context)
			builder.setTitle("Cast session detected")
			builder.setMessage("Play this item on: ") // Where to play?

			// add the buttons
			builder.setPositiveButton(
				"Play on Chromecast"
			) { dialog, which -> // do something like...
				_playSelectedItemRemotely()
			}
			builder.setNegativeButton(
				"Play on device"
			) { dialog, which -> // do something like...
				_playSelectedItemLocaly()
			}

			// create and show the alert dialog
			val dialog: AlertDialog = builder.create()
			dialog.show()
		}
	}

	private fun _playSelectedItemLocaly() {
		val currentTime = get("currentTime")
		val seekOffset: Double = if (currentTime is Double) currentTime else 0.0
		Logger.d("MediaController", "_playSelectedItemLocaly seekOffset: ${seekOffset}")

		_gmsHijackAllowed = false
//		this.load(_mediaUrl, seekOffset, _metadata)

		_headType = HeadType.EXOPLAYER
		_exoPlayer?.play()
	}

	private fun _playSelectedItemRemotely() {
		val currentTime = get("currentTime")
		val seekOffset: Double = if (currentTime is Double) currentTime else 0.0
		Logger.d("MediaController", "_playSelectedItemRemotely seekOffset: ${seekOffset}")

		_gmsHijackAllowed = true
		this.load(_mediaUrl, seekOffset, _metadata)

		_headType = HeadType.CHROMECAST // OBSOLETE; done in load
		_gmsRemoteMediaClient?.play()
	}
}
