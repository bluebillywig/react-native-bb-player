package com.bluebillywig.bbnativeplayersdk

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import androidx.annotation.RequiresApi
import coil3.size.Size
import coil3.transform.Transformation
import kotlin.math.roundToInt

/**
 * Coil transformation that applies blur effect to images for vertical video backgrounds
 */
class BlurTransformation(
    private val radius: Float = 25f,
    private val sampling: Float = 0.4f
) : Transformation() {

    override val cacheKey: String = "blur_${radius}_$sampling"

    override suspend fun transform(input: Bitmap, size: Size): Bitmap {
        // Scale down for better performance
        val width = (input.width * sampling).roundToInt()
        val height = (input.height * sampling).roundToInt()
        val scaledBitmap = Bitmap.createScaledBitmap(input, width, height, false)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurWithRenderEffect(scaledBitmap, radius)
        } else {
            blurWithBoxBlur(scaledBitmap, radius.toInt())
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun blurWithRenderEffect(bitmap: Bitmap, radius: Float): Bitmap {
        // For API 31+, just fall back to box blur since RenderEffect doesn't work well with Bitmap
        // RenderEffect is primarily for Views, not direct Bitmap manipulation
        return blurWithBoxBlur(bitmap, radius.toInt())
    }

    private fun blurWithBoxBlur(bitmap: Bitmap, radius: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        // Simple box blur - horizontal then vertical pass
        boxBlurHorizontal(pixels, w, h, radius)
        boxBlurVertical(pixels, w, h, radius)

        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, w, 0, 0, w, h)
        return output
    }

    private fun boxBlurHorizontal(pixels: IntArray, w: Int, h: Int, radius: Int) {
        val newPixels = pixels.clone()
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0
                var g = 0
                var b = 0
                var a = 0
                var count = 0

                for (dx in -radius..radius) {
                    val nx = (x + dx).coerceIn(0, w - 1)
                    val pixel = newPixels[y * w + nx]
                    a += (pixel shr 24) and 0xFF
                    r += (pixel shr 16) and 0xFF
                    g += (pixel shr 8) and 0xFF
                    b += pixel and 0xFF
                    count++
                }

                pixels[y * w + x] = (a / count shl 24) or (r / count shl 16) or (g / count shl 8) or (b / count)
            }
        }
    }

    private fun boxBlurVertical(pixels: IntArray, w: Int, h: Int, radius: Int) {
        val newPixels = pixels.clone()
        for (x in 0 until w) {
            for (y in 0 until h) {
                var r = 0
                var g = 0
                var b = 0
                var a = 0
                var count = 0

                for (dy in -radius..radius) {
                    val ny = (y + dy).coerceIn(0, h - 1)
                    val pixel = newPixels[ny * w + x]
                    a += (pixel shr 24) and 0xFF
                    r += (pixel shr 16) and 0xFF
                    g += (pixel shr 8) and 0xFF
                    b += pixel and 0xFF
                    count++
                }

                pixels[y * w + x] = (a / count shl 24) or (r / count shl 16) or (g / count shl 8) or (b / count)
            }
        }
    }

    override fun equals(other: Any?) = other is BlurTransformation && other.radius == radius && other.sampling == sampling
    override fun hashCode() = radius.hashCode() * 31 + sampling.hashCode()
}
