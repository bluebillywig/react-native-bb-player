package com.bluebillywig.bbnativeplayersdk

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.media3.ui.AspectRatioFrameLayout
import android.view.ViewGroup
import android.widget.FrameLayout.LayoutParams
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface


/**
 * @suppress
 */
class ModalPlayerViewHolder {
    private val list = mutableMapOf<String, BBNativePlayerView>()
    private val _instances = mutableMapOf<String, Any?>()

    companion object {
        val instance = ModalPlayerViewHolder()
    }

    public fun setBBPlayerView( identifier: String, bbNativePlayerView: BBNativePlayerView ) {
        list.put(identifier, bbNativePlayerView)
    }
    public fun getBBPlayerView( identifier: String ): BBNativePlayerView? {
        if ( list[identifier] != null ) {
            val ret = list[identifier]
            list.remove(identifier)
            return ret
        }
        return null
    }

    public fun setInstance(key: String, instance: Any?) {
        _instances[key] = instance
    }
    public fun getInstance(key: String): Any? {
        return _instances[key]
    }
    public fun clear() {
        _instances.clear()
    }
}

/**
 * @suppress
 */
class ModalActivity : AppCompatActivity(), EventListenerInterface {
    override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
        when (eventType) {
            EventName.adStarted -> {
                this._closeButton?.visibility = View.GONE
            }
            EventName.adFailed, EventName.adComplete, EventName.allAdsCompleted, EventName.bb_media_playing -> { // NB added bb_media_playing for safety
                this._closeButton?.visibility = View.VISIBLE
            }
            else -> {}
        }
    }
    private lateinit var playerContainer: FrameLayout
    private var _closeButton: ImageButton? = null
    private var _backArrow: ImageButton? = null
    private var _playerView: BBNativePlayerView? = null
    private var _shelfView: ShelfView? = null
    private var _orientationEventListener: OrientationEventListener? = null
    private var _eventBus: EventBusInterface? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modal)

        playerContainer = findViewById<FrameLayout>(R.id.frame_layout_player_container)

        val instanceService = ModalPlayerViewHolder.instance

        // get playerView
        val playerInstanceId = intent.getStringExtra("PlayerInstanceId")
        if ( playerInstanceId == null || playerInstanceId == "" ) {
            return
        }
        _playerView = instanceService.getBBPlayerView(playerInstanceId)
        val playerView = _playerView

        // get eventBus from playerView: BBNativePlayerView
        var eventBus = playerView?._eventBus
        if (eventBus != null) {
            this._eventBus = eventBus
            this._eventBus?.addEventlistener(this)
        }

        // get shelfView
        val shelfViewInstanceId = intent.getStringExtra("shelfViewInstanceId")
        val shelfViewInstance: Any? = if (shelfViewInstanceId != null) instanceService.getInstance(shelfViewInstanceId) else null
        _shelfView = if (shelfViewInstance is ShelfView) shelfViewInstance as ShelfView else null

        _orientationEventListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                when {
                    isWithinOrientationRange(orientation, 0) -> {
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    }
                    isWithinOrientationRange(orientation, 270) -> {
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    }
                    isWithinOrientationRange(orientation, 180) -> {
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
                    }
                    isWithinOrientationRange(orientation, 90) -> {
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                    }
                }
            }
        }
        _orientationEventListener?.enable()

        val layoutParams = ConstraintLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        playerContainer.layoutParams = layoutParams
        playerContainer.setBackgroundColor(Color.BLACK)
        if (playerView != null) playerContainer.addView(playerView)

        if (_shelfView != null) { // only needed for Shorts shelf
            _closeButton = ImageButton(playerContainer.context)
            _closeButton?.setBackgroundColor(Color.parseColor("#FF363636"))
            _closeButton?.elevation = 4F
            _closeButton?.adjustViewBounds = true
            _closeButton?.setImageResource(R.drawable.bb_icon_close_new)
            _closeButton?.setOnClickListener { _ -> this.onBackPressedDispatcher.onBackPressed() }
            _closeButton?.setBackgroundResource(R.drawable.bb_shorts_close_button_round)
            val closeButtonLayoutParams = LayoutParams(150, 150)
            closeButtonLayoutParams.gravity = Gravity.TOP or Gravity.RIGHT
            val margin = 20
            val padding = 55
            closeButtonLayoutParams.setMargins(margin, margin, margin, margin)
            _closeButton?.setPadding(padding,padding,padding,padding)
            _closeButton?.cropToPadding = true

            _closeButton?.layoutParams = closeButtonLayoutParams
            playerContainer.addView(_closeButton)
        }

        // back arrow
        val showBackArrow = intent.getBooleanExtra("showBackArrow", false)
        if (showBackArrow) {
            _backArrow = ImageButton(playerContainer.context)
            _backArrow?.setImageResource(R.drawable.bb_icon_close_arrow)
            _backArrow?.setBackgroundColor(Color.TRANSPARENT)
            _backArrow?.setPadding(30, 30, 30, 30)
            _backArrow?.setOnClickListener { _ -> this.onBackPressedDispatcher.onBackPressed() }
            val backArrowLayoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            backArrowLayoutParams.gravity = Gravity.TOP or Gravity.LEFT
            backArrowLayoutParams.setMargins(20, 20, 20, 20)
            _backArrow?.layoutParams = backArrowLayoutParams
            playerContainer.addView(_backArrow)
            _playerView?.backArrow = _backArrow
        }

        // hide top bar
        supportActionBar?.hide()

        // hide all other ui elements
        val decorView: View = this.window.decorView
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)

            window.insetsController?.let {
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsets.Type.systemBars())
            }

        } else {

            val uiOptions = decorView.systemUiVisibility
            var newUiOptions = uiOptions
            newUiOptions = newUiOptions or View.SYSTEM_UI_FLAG_LOW_PROFILE
            newUiOptions = newUiOptions or View.SYSTEM_UI_FLAG_FULLSCREEN
            newUiOptions = newUiOptions or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            newUiOptions = newUiOptions or View.SYSTEM_UI_FLAG_IMMERSIVE
            newUiOptions = newUiOptions or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            decorView.systemUiVisibility = newUiOptions
        }

        //remove fullscreen button
        if (playerView != null) {
            val fullscreenButton: ImageView? = playerView.findViewById(R.id.exo_fullscreen_icon) as ImageView?
            if (fullscreenButton != null) {
                fullscreenButton.visibility = View.GONE
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val keep = intent.getBooleanExtra("keep", false)
        if (keep) {
            _orientationEventListener?.enable()
            _playerView?.modalAppCompatActivity = this
        } else {
            this.finish()
        }
    }

    override fun onResume() {
        super.onResume()
        _orientationEventListener?.enable()
    }

    override fun onPause() {
        super.onPause()
        _orientationEventListener?.disable()
    }

    override fun onStop() {
        super.onStop()
        _orientationEventListener?.disable()
        _playerView?.modalAppCompatActivity = null

        _playerView?.update()
        _shelfView?.update()
    }

    override fun onDestroy() {
        super.onDestroy()
        _playerView?.delegate?.didCloseModalPlayer(_playerView!!)
        _playerView?.player?.pause()
        _playerView?.backArrow = null
        playerContainer.removeView(_backArrow)
        _backArrow = null
        playerContainer.removeView(_playerView)
        playerContainer.removeView(_closeButton)
        _orientationEventListener?.disable()
        _orientationEventListener = null
        _eventBus?.removeEventlistener(this)
        this._eventBus = null
        _shelfView = null
    }

    private fun isWithinOrientationRange(
        currentOrientation: Int, targetOrientation: Int, epsilon: Int = 10
    ): Boolean {
        return Math.abs((targetOrientation + epsilon)%360 - (currentOrientation + epsilon)%360) < epsilon
    }
}
