package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.enums.EventName

/**
 * @suppress
 */
class EventBus: EventBusInterface {
    override var listeners: MutableList<EventListenerInterface>
        get() = synchronized(_lock) { _listeners.toMutableList() }
        set(value) { synchronized(_lock) { _listeners = value.toMutableList() } }

    override fun trigger(eventType: EventName) {
        val snapshot: List<EventListenerInterface>
        synchronized(_lock) {
            snapshot = _listeners.toList()
        }
        snapshot.forEach { it.onEvent(eventType, null) }
    }

    override fun trigger(eventType: EventName, data: Map<String, Any?>) {
        val snapshot: List<EventListenerInterface>
        synchronized(_lock) {
            snapshot = _listeners.toList()
        }
        snapshot.forEach { it.onEvent(eventType, data) }
    }

    override fun addEventlistener(listener: EventListenerInterface) {
        synchronized(_lock) {
            _listeners.add(listener)
        }
    }

    override fun removeEventlistener(listener: EventListenerInterface) {
        synchronized(_lock) {
            _listeners.remove(listener)
        }
    }

    private val _lock = Any()
    private var _listeners: MutableList<EventListenerInterface> = mutableListOf()

    fun __destruct() {
        synchronized(_lock) {
            _listeners.clear()
        }
    }
}
