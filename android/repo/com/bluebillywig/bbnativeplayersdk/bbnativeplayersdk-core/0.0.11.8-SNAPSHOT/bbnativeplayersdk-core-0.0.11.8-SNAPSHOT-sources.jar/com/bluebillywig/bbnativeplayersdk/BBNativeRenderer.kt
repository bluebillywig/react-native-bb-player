package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import com.bluebillywig.bbnativeshared.controller.EmbedController

/**
 * BBNativeRenderer
 *   offers static factory functions for creating the views that do the actual work
 *
 */
class BBNativeRenderer {
	companion object { // this is Kotlin's way to support static class methods; don't ask...
		/**
		 * Create a Renderer view
		 * * context: the view context. Should be of type AppCompatActivity for fullscreen functionality
		 * * jsonUrl: the json embed URL (nullable)
		 * * options: the options dictionary (optional), options recognized:
		 *	* adsystem_buid: app bundle id
		 *	* adsystem_rdid: resettable device identifier
		 *	* adsystem_idtype: identifier type ("idfa" for iOS, "adid" for Android)
		 *	* adsystem_is_lat: limit ad tracking (Boolean)
		 *	* adsystem_ppid: publisher-provided id
		 *	* allowCollapseExpand: honour collapse / expand requests (Boolean or String)
		 *	* waitForCmp: wait for Consent Management, then setup (Boolean or String)
		 *	* handleConsentManagement: handle Consent Management (Boolean or String) -- needs waitForCmp
		 *	* tagForUnderAgeOfConsent: (Boolean or String)
		 *	* consent_string: default consent string (String)
		 *	* consent_gdprApplies: default GDPR applies (Int)
		 *	* consent_cmpVersion: default CMP version (Int)
		 *	* autoPlay: auto play (Boolean or String), overrides playout setting
		 *	* commercials: allow commercials (Boolean or String), overrides playout setting
		 *	* noChromeCast: no ChromeCast support (Boolean or String), overrides playout setting
		 *	* noStats: no stats logging (Boolean), overrides playout setting
		 *	* forceFullscreenLandscape: rotated the video to landscape when the video goes fullscreen
		 *	* adTagUrlParam_[key]: Custom parameters to add to ad tag URLs. Multiple parameters supported with different keys (e.g., "adTagUrlParam_userId": "12345")
		 * @param context the view context
		 * @param jsonUrl the json embed URL (nullable)
		 * @param options the options dictionary (optional)
		 * @return the Renderer view
		 */
		fun createRendererView(context: Context, jsonUrl: String?,  options: Map<String, Any?>? = null): BBNativeRendererView {
			val rendererView = BBNativeRendererView(context)
			if (jsonUrl != null) rendererView.setupWithJsonUrl(jsonUrl, options)
			return rendererView
		}

		/**
		 * Create a json embed URL
		 * * baseUrl: the base URL, e.g. "https://demo.bbvms.com"
		 * * appIndicator: the application indicator, e.g. "p" for player
		 * * appId: the application config id, e.g. the playout code
		 * @param baseUrl the base URL, e.g. "https://demo.bbvms.com"
		 * @param appIndicator the application indicator, e.g. "r" for renderer
		 * @param appId the application config id, e.g. the ad unit code
		 * @return the json embed URL
		 */
		fun createJsonEmbedUrl(baseUrl: String, appIndicator: String, appId: String, contentIndicator: String? = null, contentId: String? = null): String {
			return EmbedController.createJsonEmbedUrl(baseUrl, appIndicator, appId, contentIndicator, contentId)
		}
	}
}
