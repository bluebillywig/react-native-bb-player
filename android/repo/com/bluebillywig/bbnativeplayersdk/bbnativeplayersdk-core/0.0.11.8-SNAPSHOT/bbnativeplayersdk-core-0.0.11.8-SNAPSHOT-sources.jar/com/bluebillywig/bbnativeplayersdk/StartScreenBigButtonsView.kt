package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.controller.ProgramController

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/**
 * @suppress
 */
class StartScreenBigButtonsView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr) {

	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	private var _bigPlayButtonView = BigButtonView(this.context)

	init {
		this.setOrientation(LinearLayout.HORIZONTAL)
		this.setPadding(32, 32, 32, 32)
		this.setVerticalGravity(Gravity.CENTER_VERTICAL)
		this.setHorizontalGravity(Gravity.CENTER)

		_bigPlayButtonView.type = "PLAY"
		_bigPlayButtonView.minimumWidth = 180
		_bigPlayButtonView.minimumHeight = 180
		_bigPlayButtonView.setOnClickListener { view -> _programController?.play() }
		_bigPlayButtonView.id = View.generateViewId()
		this.addView(_bigPlayButtonView)
	}

	fun __destruct() {
		this.removeView(_bigPlayButtonView)

		_programController = null
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus = value
			_bigPlayButtonView.eventBus = _eventBus
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
		}
}
