package com.bluebillywig.bbnativeplayersdk

import com.bluebillywig.bbnativeshared.enums.ApiMethod
import com.bluebillywig.bbnativeshared.enums.ApiProperty
import com.bluebillywig.bbnativeshared.model.Playout
import com.bluebillywig.bbnativeshared.model.Project
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.MediaClipList
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.State
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.ContentItemInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface

/**
 * BBNativePlayerAPI
 *   is the convenience API, accessible via BBNativePlayerView::player.
 *   It simply wraps BBNativePlayerView::callApiMethod & BBNativePlayerView::getApiProperty
 *
 * @constructor
 *   no need to call this directly; use the playerView's player property
 *
 * @param playerView
 */
class BBNativePlayerAPI(playerView: BBNativePlayerView, eventBus: EventBus?) :
	EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				_eventBus?.trigger(EventName.bb_api_ready)
			}
			else -> {}
		}
	}

	private var _playerView: BBNativePlayerView? = playerView
	private val _eventBus: EventBus? = eventBus

	init {
		_eventBus?.addEventlistener(this)
	}

	/**
	 * Destruct, freeing all memory allocated internally
	 */
	fun __destruct (): Unit {
		_eventBus?.removeEventlistener(this)
		_playerView = null
	}

	/**
	 * Load With Clip Id
	 *
	 * @param clipId
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClipId (clipId: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("clipId" to clipId, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Clip List Id
	 *
	 * @param clipListId
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClipListId (clipListId: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("cliplistId" to clipListId, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Project Id
	 *
	 * @param projectId
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithProjectId (projectId: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("projectId" to projectId, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Clip JSON
	 *
	 * @param clipJson
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClipJson (clipJson: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("clipDataJsonString" to clipJson, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Clip List JSON
	 *
	 * @param clipListJson
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClipListJson (clipListJson: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("clipListDataJsonString" to clipListJson, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Project JSON
	 *
	 * @param projectJson
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithProjectJson (projectJson: String, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("projectDataJsonString" to projectJson, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Clip
	 *
	 * @param clip
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClip (clip: MediaClip, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("clipData" to clip, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Clip List
	 *
	 * @param clipList
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithClipList (clipList: MediaClipList, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("clipListData" to clipList, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Load With Project
	 *
	 * @param project
	 * @param initiator (optional, default: "external")
	 * @param autoPlay (optional, default: true)
	 * @param seekTo (optional, default: null)
	 * @param context (optional): Context map with keys like contextCollectionType, contextCollectionId, contextEntityType, contextEntityId
	 */
	@JvmOverloads
	fun loadWithProject (project: Project, initiator: String? = "external", autoPlay: Boolean? = true, seekTo: Number? = null, context: Map<String, Any?>? = null): Unit {
		val args = mutableMapOf<String, Any?>("projectData" to project, "initiator" to initiator, "autoPlay" to autoPlay, "seekTo" to seekTo)
		context?.forEach { (k, v) -> args.putIfAbsent(k, v) }
		_playerView?.callApiMethod(ApiMethod.load, args)
	}

	/**
	 * Update Playout With JSON
	 *
	 * @param playoutJson
	 */
	fun updatePlayoutWithJson (playoutJson: String): Unit {
		_playerView?.callApiMethod(ApiMethod.updatePlayout, mapOf("playoutDataJsonString" to playoutJson))
	}

	/**
	 * Start / Resume playback
	 */
	fun play (): Unit {
		_playerView?.callApiMethod(ApiMethod.play, null)
	}

	/**
	 * Pause playback
	 */
	fun pause (): Unit {
		_playerView?.callApiMethod(ApiMethod.pause, null)
	}

	/**
	 * Seek to time offset
	 */
	fun seek (offsetInSeconds: Number, relativeToCurrentTime: Boolean = false): Unit {
		_playerView?.callApiMethod(ApiMethod.seek, mapOf(
			"offsetInSeconds" to offsetInSeconds,
			"relativeToCurrentTime" to relativeToCurrentTime
		))
	}

	/**
	 * Cancel AutoPlayNext countdown
	 */
	fun autoPlayNextCancel (): Unit {
		_playerView?.callApiMethod(ApiMethod.autoPlayNextCancel, null)
	}

	/**
	 * Collapse
	 */
	fun collapse (): Unit {
		_playerView?.callApiMethod(ApiMethod.collapse, null)
	}

	/**
	 * Expand
	 */
	fun expand (): Unit {
		_playerView?.callApiMethod(ApiMethod.expand, null)
	}

	/**
	 * Enter fullscreen
	 */
	fun enterFullScreen (): Unit {
		_playerView?.callApiMethod(ApiMethod.enterFullScreen, null)
	}

	/**
	 * Leave fullscreen
	 */
	fun exitFullScreen (): Unit {
		_playerView?.callApiMethod(ApiMethod.exitFullScreen, null)
	}

	/**
	 * Phase (read-only)
	 *
	 * @see https://support.bluebillywig.com/player-api/events-modes-and-phases/#3-0-phases
	 */
	val phase: Phase?
		get() = _playerView?.getApiProperty(ApiProperty.phase) as Phase?

	/**
	 * State (read-only)
	 *
	 * @see https://support.bluebillywig.com/player-api/events-modes-and-phases/#4-0-states
	 */
	val state: State?
		get() = _playerView?.getApiProperty(ApiProperty.state) as State?

	/**
	 * Mode (read-only)
	 *
	 * @see https://support.bluebillywig.com/player-api/events-modes-and-phases/#2-0-modes
	 */
	val mode: String?
		get() = _playerView?.getApiProperty(ApiProperty.mode) as String?

	/**
	 * isCasting (read-only)
	 *
	 * @see https://support.bluebillywig.com/player-api/events-modes-and-phases/#2-0-modes
	 */
	val isCasting: Boolean?
		get() = _playerView?.getApiProperty(ApiProperty.isCasting) as Boolean?

	/**
	 * Playout data (read-only)
	 */
	val playoutData: Playout?
		get() = _playerView?.getApiProperty(ApiProperty.playoutData) as Playout?

	/**
	 * Project data (read-only)
	 */
	val projectData: Project?
		get() = _playerView?.getApiProperty(ApiProperty.projectData) as Project?

	/**
	 * Clip data (read-only)
	 */
	val clipData: MediaClip?
		get() = _playerView?.getApiProperty(ApiProperty.clipData) as MediaClip?

	/**
	 * Related items
	 */
	var relatedItems: List<ContentItemInterface>? = null
		set(value) {
			_playerView?.setApiProperty(ApiProperty.relatedItems, value)
		}

	/**
	 * Volume [0.0 - 1.0]
	 */
	var volume: Double?
		get() = _playerView?.getApiProperty(ApiProperty.volume) as Double?
		set(value) {
			_playerView?.setApiProperty(ApiProperty.volume, value)
		}

	/**
	 * Set Volume
	 * @param volume
	 * @param userAction (optional, default: false)
	 */
	fun setVolume(volume: Double, userAction: Boolean = false) {
		_eventBus?.trigger(EventName.bb_api_called, mapOf("method" to "setVolume", "volume" to volume, "userAction" to userAction))
		_playerView?.setApiProperty(ApiProperty.volume, volume)
	}

	/**
	 * Muted state
	 */
	var muted: Boolean?
		get() = _playerView?.getApiProperty(ApiProperty.muted) as Boolean?
		set(value) {
			_playerView?.setApiProperty(ApiProperty.muted, value)
		}

	/**
	 * Set Muted state
	 * @param muted
	 * @param userAction (optional, default: false)
	 */
	fun setMuted(muted: Boolean, userAction: Boolean = false) {
		_eventBus?.trigger(EventName.bb_api_called, mapOf("method" to "setMuted", "muted" to muted, "userAction" to userAction))
		_playerView?.setApiProperty(ApiProperty.muted, muted)
	}

	/**
	 * Controls shown
	 */
	var controls: Boolean?
		get() = _playerView?.getApiProperty(ApiProperty.controls) as Boolean?
		set(value) {
			_playerView?.setApiProperty(ApiProperty.controls, value)
		}

	/**
	 * InView override
	 */
	var inView: Boolean?
		get() = _playerView?.getApiProperty(ApiProperty.inView) as Boolean?
		set(value) {
			_playerView?.setApiProperty(ApiProperty.inView, value)
		}

	/**
	 * Media duration in seconds (read-only)
	 */
	val duration: Double?
		get() = _playerView?.getApiProperty(ApiProperty.duration) as Double?

	/**
	 * Ad media width in pixels (read-only)
	 */
	val adMediaWidth: Int?
		get() = _playerView?.getApiProperty(ApiProperty.adMediaWidth) as Int?

	/**
	 * Ad media height in pixels (read-only)
	 */
	val adMediaHeight: Int?
		get() = _playerView?.getApiProperty(ApiProperty.adMediaHeight) as Int?
}
