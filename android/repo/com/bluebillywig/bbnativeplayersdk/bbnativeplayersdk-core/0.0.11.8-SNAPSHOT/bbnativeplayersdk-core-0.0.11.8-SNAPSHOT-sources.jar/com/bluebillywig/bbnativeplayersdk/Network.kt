package com.bluebillywig.bbnativeplayersdk

import android.os.Build
import com.bluebillywig.bbnativeshared.interfaces.NetworkInterface
import io.ktor.client.*
import io.ktor.client.plugins.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.util.toMap
import kotlinx.coroutines.*

/**
 * @suppress
 */
class Network: com.bluebillywig.bbnativeshared.interfaces.NetworkInterface  {
    private var _mainScope: CoroutineScope = MainScope()
    private var _job: Job? = null
    private var _userAgentString:String? = null

    private fun getUserAgentHeader(): String {
        if (_userAgentString != null) {
            return _userAgentString ?: ""
        }
        _userAgentString = "BBNative SDK Android/ (Android; ${Build.VERSION.SDK_INT}; ${Build.MANUFACTURER} ${Build.MODEL}) "
        return _userAgentString ?: ""
    }

    override fun getJsonString(jsonUrl: String, onSuccess: (retObject: String) -> Unit, onFailure: (error: Boolean) -> Unit): Unit {
        getJsonStringAndHeaders(
            jsonUrl = jsonUrl,
            onSuccess = { retObject, _ -> onSuccess(retObject) },
            onFailure = onFailure
        )
    }

    override fun getJsonStringAndHeaders(jsonUrl: String, onSuccess: (retObject: String, responseHeaders: Map<String, List<String>>) -> Unit, onFailure: (error: Boolean) -> Unit): Unit {
        // start coroutine
        _job = _mainScope.launch(Dispatchers.Default) {
            // get http response using ktor client
            try {
                val client = HttpClient() {
                    install(UserAgent) {
                        agent = getUserAgentHeader()
                    }
                }
                val response = client.get {
                    headers {
                        append(HttpHeaders.Referrer, "in-app")
                    }
                    url(Url(jsonUrl))
                }

                if (!response.status.isSuccess()) {
                    onFailure(true)
                } else {
                    onSuccess(response.bodyAsText(), response.headers.toMap())
                }
                client.close()
            } catch (e: Exception) {
                onFailure(true)
            }
        }
    }

    override fun logStats(url: String, onSuccess: () -> Unit, onFailure: (error: Boolean) -> Unit): Unit {
        // start coroutine
        var job: Job = _mainScope.launch(Dispatchers.Default) {
            // get http response using ktor client
            try {
                val client = HttpClient() {
                    install(UserAgent) {
                        agent = getUserAgentHeader()
                    }                }
                val response = client.get {
                    headers {
                        append(HttpHeaders.Referrer, "in-app")
                    }
                    url(Url(url))
                }
                if (!response.status.isSuccess()) {
                    onFailure(true)
                } else {
                    onSuccess()
                }
                client.close()
            } catch (e: Exception) {
                onFailure(true)
            }
        }
    }

    override public fun __destruct() {
        if ( _job?.isActive == true  ){
            _job?.cancel()
        }
        _job = null
    }
}
