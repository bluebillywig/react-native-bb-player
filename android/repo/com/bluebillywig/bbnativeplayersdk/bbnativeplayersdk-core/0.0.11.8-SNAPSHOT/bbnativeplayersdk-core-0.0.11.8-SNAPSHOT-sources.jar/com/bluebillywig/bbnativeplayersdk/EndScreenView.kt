package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.data.Languages
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import java.util.*

//	big replay button
//  related items (TODO;)
/**
* @suppress
*/
class EndScreenView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): ConstraintLayout(context, attrs, defStyleAttr), EventListenerInterface {
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_embed_loaded -> {
				if (data != null && data["embedObject"] != null) _ingestOpts(data["embedObject"] as EmbedObject?)
			}
			EventName.bb_playout_changed -> { _onPlayoutChanged(data) }
			EventName.bb_project_loaded -> {
				val projectData = if (data != null && data["projectData"] is Project) data["projectData"] as Project else null
				if (projectData != null) {
					_titleView.text = projectData.title ?: ""
					_copyright = projectData.copyright ?: ""
					_authorCopyrightView.text = projectData.author ?: ""
					_authorCopyrightView.append(if (_copyright != "") " | " + _copyright else "")
				}
				_updateTitleAuthor()
			}
			EventName.bb_mediaclip_loaded -> {
				val clipData = if (data != null && data["clipData"] is MediaClip) data["clipData"] as MediaClip else null
				if (clipData != null ) {
					_titleView.text = clipData.title ?: ""
					_copyright = clipData.copyright ?: ""
					_authorCopyrightView.text = clipData.author ?: ""
					_authorCopyrightView.append(if (_copyright != "") " | " + _copyright else "")
				}
				_updateTitleAuthor()
			}
			EventName.ended -> {
				if (_showRelatedItems) {
					_showRelatedItems()
				} else {
					_hideRelatedItems()
				}
			}
			EventName.bb_autoplaynexttimer_started -> {
				_apntState = "running"
				if (_autoPlayNext) {
					_bigButtonsView.visibility = View.GONE
					// _infoView.visibility = View.INVISIBLE
					if (_showRelatedItems) {
						_relatedItemsButton.visibility = View.VISIBLE
					} else {
						_relatedItemsButton.visibility = View.GONE
					}
					_relatedItemsView.visibility = View.GONE
					_autoPlayNextView.visibility = View.VISIBLE
				}
			}
			EventName.bb_autoplaynexttimer_paused -> {
				_apntState = "paused"
			}
			EventName.bb_autoplaynexttimer_resumed -> {
				_apntState = "running"
			}
			EventName.bb_autoplaynexttimer_cancelled,
			EventName.bb_autoplaynexttimer_finished -> {
				_apntState = "idle"
				if (_showBigReplayButton) {
					_bigButtonsView.visibility = View.VISIBLE
				} else {
					_bigButtonsView.visibility = View.GONE
				}
				_autoPlayNextView.visibility = View.GONE
			}
			else -> {}
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	private var _bigButtonsView = EndScreenBigButtonsView(this.context)
	private var _backDropView = LinearLayout(this.context)
	private var _relatedItemsView = RelatedItemsView(this.context)
	private var _relatedItemsCloseButton: ShadowImageButton = ShadowImageButton(this.context)
	private var _relatedItemsButton: ShadowImageButton = ShadowImageButton(this.context)
	private var _autoPlayNextView = AutoPlayNextView(this.context)
	internal var _shareButton: ImageView? = null
	private var _titleView: TextView = TextView(this.context)
	private var _authorCopyrightView: TextView = TextView(this.context)
	private var _relatedItemsLabelView: TextView = TextView(this.context)

	// layout
	private var _titleIndentPx: Int = 0

	// settings
	private var _showBigReplayButton = true
	private var _showRelatedItems = false // default true?
	private var _showShareButton = true
	private var _mobileMediaAssetPath = ""
	private var _useDeeplinkForRelatedItems = false
	private var _autoPlayNext = false
	private var _showTitle = false
	private var _showAuthor = false

	// data
	private var _copyright: String = ""

	// state
	private var _apntState = "idle"

	init {
		this.setBackgroundColor(Color.parseColor("#ff2121ff"))
		val layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
		this.layoutParams = layoutParams
		this.setBackgroundColor(Color.parseColor("#00212121")) // NB leave it like this, otherwise weird things happen;(

		// Set elevation to ensure this view renders above player control gradients
		this.elevation = 10f

		// Set solid transparent background rgba(33, 33, 33, 0.7) - Max verified
		this._backDropView.setBackgroundColor(Color.parseColor("#B3212121"))
		this._backDropView.id = View.generateViewId()
		this.addView(this._backDropView)

		_bigButtonsView.visibility = View.GONE
		_bigButtonsView.id = View.generateViewId()
		this.addView(_bigButtonsView)

		_relatedItemsView.visibility = View.GONE
		_relatedItemsView.id = View.generateViewId()
		this.addView(_relatedItemsView)

		_relatedItemsCloseButton.visibility = View.GONE
		_relatedItemsCloseButton.setImageResource(R.drawable.bb_icon_close_new);
		_relatedItemsCloseButton.setOnClickListener { view -> _onCloseRelatedItemsButtonClicked()  }
		_relatedItemsCloseButton.id = View.generateViewId()
		this.addView(_relatedItemsCloseButton)

		_relatedItemsButton.setImageResource(R.drawable.bb_icon_related_items)
		_relatedItemsButton.setOnClickListener { view -> _onRelatedItemsButtonClicked() }
		_relatedItemsButton.id = View.generateViewId()
		this.addView(_relatedItemsButton)

		_autoPlayNextView.visibility = View.GONE
		_autoPlayNextView.id = View.generateViewId()
		this.addView(_autoPlayNextView)

		// Initialize title and author views
		var typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato_black)

		_titleView.textSize = 17F
		_titleView.setTypeface(typeface)
		_titleView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_titleView.id = View.generateViewId()
		_titleView.visibility = View.GONE
		this.addView(_titleView)

		typeface = ResourcesCompat.getFont(context, R.font.lato_bold)

		_authorCopyrightView.setTypeface(typeface)
		_authorCopyrightView.textSize = 12F
		_authorCopyrightView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_authorCopyrightView.id = View.generateViewId()
		_authorCopyrightView.visibility = View.GONE
		this.addView(_authorCopyrightView)

		// Initialize related items label view
		typeface = ResourcesCompat.getFont(context, R.font.lato_black)
		_relatedItemsLabelView.text = "Related Videos"
		_relatedItemsLabelView.textSize = 15F
		_relatedItemsLabelView.setTypeface(typeface)
		_relatedItemsLabelView.setTextColor(Color.parseColor("#ffffff"))
		_relatedItemsLabelView.setShadowLayer(2F, 2F, 2F, 0xFF000000.toInt())
		_relatedItemsLabelView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_relatedItemsLabelView.id = View.generateViewId()
		_relatedItemsLabelView.visibility = View.GONE
		this.addView(_relatedItemsLabelView)

		// Set up constraints once
		post {
			_setupConstraints()
		}
	}

	private fun _setupConstraints() {
		val constraintSet = ConstraintSet()
		constraintSet.clone(this)

		// Position backdrop view (match parent)
		constraintSet.constrainWidth(_backDropView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.constrainHeight(_backDropView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.connect(_backDropView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_backDropView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
		constraintSet.connect(_backDropView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_backDropView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)

		// Position big buttons view (centered)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_bigButtonsView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)

		// Position autoplay next view (centered)
		constraintSet.connect(_autoPlayNextView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
		constraintSet.connect(_autoPlayNextView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
		constraintSet.connect(_autoPlayNextView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
		constraintSet.connect(_autoPlayNextView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)

		// Position related items view above control bar with larger margin
		constraintSet.constrainWidth(_relatedItemsView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.constrainHeight(_relatedItemsView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_relatedItemsView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, 10)
		constraintSet.connect(_relatedItemsView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 10)
		constraintSet.connect(_relatedItemsView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 180)

		// Position title view (top left)
		constraintSet.constrainWidth(_titleView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.constrainHeight(_titleView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_titleView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, 24 + _titleIndentPx)
		constraintSet.connect(_titleView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 128)
		constraintSet.connect(_titleView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 16)

		// Position author view (below title)
		constraintSet.constrainWidth(_authorCopyrightView.id, ConstraintSet.MATCH_CONSTRAINT)
		constraintSet.constrainHeight(_authorCopyrightView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_authorCopyrightView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START, 24 + _titleIndentPx)
		constraintSet.connect(_authorCopyrightView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END, 128)
		constraintSet.connect(_authorCopyrightView.id, ConstraintSet.TOP, _titleView.id, ConstraintSet.BOTTOM, 16)

		// Position related items label view (above related items)
		constraintSet.constrainWidth(_relatedItemsLabelView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.constrainHeight(_relatedItemsLabelView.id, ConstraintSet.WRAP_CONTENT)
		constraintSet.connect(_relatedItemsLabelView.id, ConstraintSet.START, _relatedItemsView.id, ConstraintSet.START, 10)
		constraintSet.connect(_relatedItemsLabelView.id, ConstraintSet.BOTTOM, _relatedItemsView.id, ConstraintSet.TOP, 16)

		constraintSet.applyTo(this)
	}

	override fun onDraw(canvas: Canvas) {
		_relatedItemsCloseButton.setBackgroundColor(Color.parseColor("#00000000"))

		val layoutParamsRelatedItemsCloseButton: ConstraintLayout.LayoutParams = ConstraintLayout.LayoutParams(56, 56)
		layoutParamsRelatedItemsCloseButton.bottomToBottom = _relatedItemsLabelView.id
		layoutParamsRelatedItemsCloseButton.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
		layoutParamsRelatedItemsCloseButton.setMargins(10,10,36,0)
		_relatedItemsCloseButton.setPadding(11, 11, 11, 11)
		_relatedItemsCloseButton.setLayoutParams(layoutParamsRelatedItemsCloseButton)

		val layoutParamsRelatedItemsButton: ConstraintLayout.LayoutParams = ConstraintLayout.LayoutParams(120, 120)
		layoutParamsRelatedItemsButton.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
		layoutParamsRelatedItemsButton.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
		layoutParamsRelatedItemsButton.setMargins(10,10,36,180)

		// Set circular black transparent background
		val circularBackground = GradientDrawable()
		circularBackground.shape = GradientDrawable.OVAL
		circularBackground.setColor(Color.parseColor("#80000000"))
		_relatedItemsButton.background = circularBackground

		// Scale down the icon drawable to make it smaller
		_relatedItemsButton.scaleType = ImageView.ScaleType.FIT_CENTER
		_relatedItemsButton.setPadding(40, 40, 40, 40)

		_relatedItemsButton.setLayoutParams(layoutParamsRelatedItemsButton)

		super.onDraw(canvas)
	}

	private fun _onRelatedItemsButtonClicked() {
		if (_relatedItemsView?.visibility == View.VISIBLE) {
			_onCloseRelatedItemsButtonClicked()
		} else {
			_showRelatedItems()
			if (_apntState == "running") {
				_programController?.autoPlayNextPause()
				_autoPlayNextView.visibility = View.GONE
			}
			_bigButtonsView.visibility = View.GONE
		}
	}

	private fun _onCloseRelatedItemsButtonClicked() {
		_hideRelatedItems()
		if (_apntState == "paused") {
			_programController?.autoPlayNextResume()
			_autoPlayNextView.visibility = View.VISIBLE
		}
		if (_apntState == "idle") {
			if (_showBigReplayButton) {
				_bigButtonsView.visibility = View.VISIBLE
			} else {
				_bigButtonsView.visibility = View.GONE
			}
		}
	}

	private fun _showRelatedItems() {
		_relatedItemsCloseButton.visibility = View.VISIBLE
		_relatedItemsView.visibility = View.VISIBLE
		_relatedItemsLabelView.visibility = View.VISIBLE
		_relatedItemsButton.visibility = View.GONE
		_bigButtonsView.visibility = View.GONE
		_shareButton?.visibility = View.GONE
		_titleView.visibility = View.GONE
		_authorCopyrightView.visibility = View.GONE
	}
	private fun _hideRelatedItems() {
		_relatedItemsCloseButton.visibility = View.GONE
		_relatedItemsView.visibility = View.GONE
		_relatedItemsLabelView.visibility = View.GONE
		if (_showRelatedItems) {
			_relatedItemsButton.visibility = View.VISIBLE
		} else {
			_relatedItemsButton.visibility = View.GONE
		}
		if (_showBigReplayButton) {
			_bigButtonsView.visibility = View.VISIBLE
		} else {
			_bigButtonsView.visibility = View.GONE
		}
		if (_showShareButton) {
			_shareButton?.visibility = View.VISIBLE
		}
		_updateTitleAuthor()
	}

	private fun _updateTitleAuthor() {
		_titleView.setTextColor(Color.parseColor("#ffffff"))
		_titleView.setShadowLayer(2F, 2F, 2F, 0xFF000000.toInt())
		if (_showTitle && _titleView.text != "") {
			_titleView.visibility = View.VISIBLE
		} else {
			_titleView.visibility = View.GONE
		}

		_authorCopyrightView.setTextColor(Color.parseColor("#ffffff"))
		_authorCopyrightView.setShadowLayer(2F, 2F, 2F, 0xFF000000.toInt())
		if (_showAuthor && _authorCopyrightView.text != "") {
			_authorCopyrightView.visibility = View.VISIBLE
		} else {
			_authorCopyrightView.visibility = View.GONE
		}
	}

	private fun _updateBackdropVisibility() {
		// Hide backdrop only when both related items and big replay button are hidden
		if (!_showRelatedItems && !_showBigReplayButton) {
			_backDropView.visibility = View.GONE
		} else {
			_backDropView.visibility = View.VISIBLE
		}
	}

	fun setTitleIndent(px: Int) {
		_titleIndentPx = px
		post { _setupConstraints() }
	}

	fun __destruct() {
		this.removeView(_autoPlayNextView)
		this.removeView(_relatedItemsView)
		this.removeView(_bigButtonsView)
		this.removeView(_titleView)
		this.removeView(_authorCopyrightView)
		this.removeView(_relatedItemsLabelView)
		_programController = null
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!

			_bigButtonsView.eventBus = _eventBus
			_relatedItemsView.eventBus = _eventBus
			_autoPlayNextView.eventBus = _eventBus
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
			_bigButtonsView.programController = _programController
			_relatedItemsView.programController = _programController
			_autoPlayNextView.programController = _programController
		}

	private fun _update() {
		_relatedItemsView.updateSettings(mapOf(
			"useDeeplink" to _useDeeplinkForRelatedItems,
			"avoidAssets" to _mobileMediaAssetPath.isNotEmpty()
		))
		if (_showRelatedItems) {
			_showRelatedItems()
		} else {
			_hideRelatedItems()
		}
		_updateTitleAuthor()
		_updateBackdropVisibility()
	}

	private fun _onPlayoutChanged(payload: Map<String, Any?>?) {
		val playoutData = payload?.get("playoutData") as? Playout
		if (playoutData != null) {
			_ingestPlayoutData(playoutData)
		}
		_update()
	}

	private fun _ingestPlayoutData(playout: Playout) {
		if (playout.showBigReplayButton != null) _showBigReplayButton = playout.showBigReplayButton == "true"
		if (playout.relatedItems != null) _showRelatedItems = playout.relatedItems == "Show"
		if (playout.shareButtonEnd != null) _showShareButton = playout.shareButtonEnd == "Show"
		if (playout.useDeeplinkForRelatedItems != null) _useDeeplinkForRelatedItems = playout.useDeeplinkForRelatedItems == "true"
		if (playout.autoPlayNext != null) _autoPlayNext = playout.autoPlayNext == "true"
		if (playout.titleEnd != null) _showTitle = playout.titleEnd == "Show"
		if (playout.authorCopyrightEnd != null) _showAuthor = playout.authorCopyrightEnd == "Show"
	}

	private fun _ingestOpts(opts: EmbedObject?) {
		if (opts != null) {
			// publication settings
			if (opts.publicationData is Publication) {
				val publication = opts.publicationData as Publication // Smart cast is impossible...
				if (publication.mobileMediaAssetPath != null) _mobileMediaAssetPath = publication.mobileMediaAssetPath ?: ""
			}

			// playout settings
			if (opts.playoutData is Playout) {
				_ingestPlayoutData(opts.playoutData as Playout)
			}
			_update()
		}
	}
}
