package com.bluebillywig.bbnativeplayersdk

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.bluebillywig.bbnativeshared.controller.ProgramController
import com.bluebillywig.bbnativeshared.data.Languages
import com.bluebillywig.bbnativeshared.enums.EventName
import com.bluebillywig.bbnativeshared.interfaces.EventBusInterface
import com.bluebillywig.bbnativeshared.interfaces.EventListenerInterface
import com.bluebillywig.bbnativeshared.model.*
import java.util.*

/**
 * @suppress
 */
class AutoPlayNextView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): LinearLayout(context, attrs, defStyleAttr), EventListenerInterface {
	@SuppressLint("SetTextI18n")
	override fun onEvent(eventType: EventName, data: Map<String, Any?>?) {
		when (eventType) {
			EventName.bb_autoplaynexttimer_tick -> {
				_onTimerTick(data)
			}
			EventName.bb_autoplaynexttimer_started,
			EventName.bb_autoplaynexttimer_cancelled,
			EventName.bb_autoplaynexttimer_finished -> {
				_timeView.text = "${_upNextIn} 8" // avoid flashing previous end time
			}
			EventName.bb_autoplaynext_item -> {
				_onAutoPlayNextItem(data)
			}
			else -> {}
		}
	}

	private var _eventBus: EventBusInterface? = null
	private var _programController: ProgramController? = null
	private var _timeView: TextView
	private var _titleView: TextView
	private var _playView: ImageButton? = null
	private var _cancelView: LinearLayout? = null
	private var _upNextIn: String = "Up next in"


	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0xFF000000.toInt()

	// state
	private var _autoPlayNextTime: Long = 8L

	init {
		val inflater = LayoutInflater.from(getContext())
		inflater.inflate(R.layout.autoplay_next_view, this)
		this.setBackgroundColor(Color.parseColor("#99000000")) // acc. Deniz

		_timeView = findViewById(R.id.tv_autoplaynext_upnext)
		_titleView = findViewById(R.id.tv_autoplaynext_clip_title)

		_cancelView = findViewById(R.id.tv_autoplaynext_cancel)
		_cancelView?.setOnClickListener { view -> _cancel() }

		_playView = findViewById(R.id.tv_autoplaynext_play)
		_playView?.setOnClickListener { view -> _play() }

		_upNextIn = Languages.translate(Locale.getDefault().getLanguage(), _upNextIn)

		_update()
	}

	private fun _cancel() {
		_programController?.autoPlayNextCancel()
	}

	private fun _play() {
		_programController?.autoPlayNextProceed()
	}

	private fun _replay() {
		_programController?.autoPlayNextCancel()
		_programController?.seek(0)
		_programController?.play()
	}

	private fun _showRelatedItems() {
		_timeView?.visibility = View.INVISIBLE
		_titleView?.visibility = View.INVISIBLE
		_cancelView?.visibility = View.INVISIBLE
		_playView?.visibility = View.INVISIBLE
	}

	private fun _hideRelatedItems() {
		_timeView?.visibility = View.VISIBLE
		_titleView?.visibility = View.VISIBLE
		_cancelView?.visibility = View.VISIBLE
		_playView?.visibility = View.VISIBLE
	}


	fun __destruct() {
		this.removeView(_cancelView)
		this.removeView(_playView)
		this.removeView(_timeView)
		_eventBus?.removeEventlistener(this)
		_eventBus = null
	}

	var eventBus: EventBusInterface?
		get() = _eventBus
		set(value) {
			_eventBus?.removeEventlistener(this)
			_eventBus = value
			_eventBus?.addEventlistener(this) // NB after constructing eventBus-dependent resources!
		}

	var programController: ProgramController?
		get() = _programController
		set(value) {
			_programController = value
		}

	@SuppressLint("SetTextI18n")
	private fun _onTimerTick(data: Map<String, Any?>?) {
		// data: { ticks: _ticks, remainingTime: _remainingTime }
		if (data != null && data["remainingTime"] is Double) {
			_autoPlayNextTime = Math.round(data["remainingTime"] as Double)
			// Logger.d("AutoPlayNextView", "_onTimerTick time: ${_autoPlayNextTime}")
			_timeView.text = "${_upNextIn} ${_autoPlayNextTime}"
		}
	}

	private fun _onAutoPlayNextItem(data: Map<String, Any?>?) {
		val projectData = if (data != null && data["item"] is Project) data["item"] as Project else null
		if (projectData != null) {
			_titleView.text = projectData.title ?: ""
		}
		val clipListData = if (data != null && data["item"] is MediaClipList) data["item"] as MediaClipList else null
		if (clipListData != null) {
			_titleView.text = clipListData.title ?: ""
		}
		val clipData = if (data != null && data["item"] is MediaClip) data["item"] as MediaClip else null
		if (clipData != null) {
			_titleView.text = clipData.title ?: ""
		}
		_update()
	}

	private fun _update() {
		val fr: Int = Color.red(_foregroundColor)
		val fg: Int = Color.green(_foregroundColor)
		val fb: Int = Color.blue(_foregroundColor)
		val shadowColor = if (fr + fg + fb < 384) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
		val shadowD = if (fr + fg + fb < 384) -2F else 2F

		_timeView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
		_titleView.setShadowLayer(2F, shadowD, shadowD, shadowColor)
	}
}
