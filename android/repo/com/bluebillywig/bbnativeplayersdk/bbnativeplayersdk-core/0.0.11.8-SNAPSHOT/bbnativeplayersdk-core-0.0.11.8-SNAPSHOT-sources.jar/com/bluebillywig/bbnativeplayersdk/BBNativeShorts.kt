package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import com.bluebillywig.bbnativeshared.controller.EmbedController

/**
 * BBNativeShorts
 *   offers static factory functions for creating the views that do the actual work
 *
 */
class BBNativeShorts {
	companion object { // this is Kotlin's way to support static class methods; don't ask...
		/**
		 * Create a Shorts view
		 * * context: the view context. Should be of type AppCompatActivity for fullscreen functionality
		 * * jsonUrl: the json embed URL (nullable)
		 * * options: the options dictionary (optional), options recognized:
		 *	* displayFormat:  full | list | player
		 *	* shelfStartSpacing: Int - spacing at the start of the shorts list
		 *	* shelfEndSpacing: Int - spacing at the end of the shorts list
		 * @param context the view context
		 * @param jsonUrl the json embed URL (nullable)
		 * @param options the options dictionary (optional)
		 * @return the Shorts view
		 */
		fun createShortsView(context: Context, jsonUrl: String?,  options: Map<String, Any?>? = null): BBNativeShortsView {
			val shortsView = BBNativeShortsView(context)
			if (jsonUrl != null) shortsView.setupWithJsonUrl(jsonUrl, options)
			return shortsView
		}

		/**
		 * Create a json embed URL
		 * * baseUrl: the base URL, e.g. "https://demo.bbvms.com"
		 * * appIndicator: the application indicator, e.g. "p" for player
		 * * appId: the application config id, e.g. the playout code
		 * * contentIndicator: the content indicator (optional), e.g. "c" for clip
		 * * contentId: the content id, e.g. "7654321"
		 * @param baseUrl the base URL, e.g. "https://demo.bbvms.com"
		 * @param appIndicator the application indicator, e.g. "sh" for shorts experience
		 * @param appId the application config id, e.g. the shorts experience id
		 * @param contentIndicator the content indicator (optional), e.g. "l" for list
		 * @param contentId the content id, e.g. "7654321"
		 * @return the json embed URL
		 */
		fun createJsonEmbedUrl(baseUrl: String, appIndicator: String, appId: String, contentIndicator: String? = null, contentId: String? = null): String {
			return EmbedController.createJsonEmbedUrl(baseUrl, appIndicator, appId, contentIndicator, contentId)
		}
	}
}
