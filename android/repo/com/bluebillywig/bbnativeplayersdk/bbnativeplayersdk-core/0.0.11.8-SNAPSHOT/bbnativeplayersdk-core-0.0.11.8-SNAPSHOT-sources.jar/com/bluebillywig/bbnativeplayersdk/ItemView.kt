package com.bluebillywig.bbnativeplayersdk

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import coil3.load
import coil3.request.crossfade
import coil3.request.transformations

/**
 * @suppress
 */
class ItemView @JvmOverloads constructor(
	context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
): FrameLayout(context, attrs, defStyleAttr) {
	private var _backDropView = LinearLayout(this.context)
	private var _blurredBackgroundView = ImageView(this.context)
	private var _blackOverlayView = View(this.context)
	private var _imageView = ImageView(this.context)
	private var _titleView: TextView = TextView(this.context)
	private var _durationView: TextView = TextView(this.context)

	// settings
	private var _foregroundColor = 0xFFFFFFFF.toInt()
	private var _backgroundColor = 0x33000000.toInt()

	init {
		this.setPadding(0, 0, 0, 0)

		// Apply background color with rounded corners
		val backgroundDrawable = GradientDrawable()
		backgroundDrawable.setColor(_backgroundColor)
		backgroundDrawable.cornerRadius = 8f * resources.displayMetrics.density
		this.background = backgroundDrawable

		// Apply rounded corners to the entire ItemView
		this.clipToOutline = true
		this.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND

		_titleView.setGravity(Gravity.TOP)
		_durationView.setGravity(Gravity.BOTTOM)
		_durationView.setTextDirection(TEXT_DIRECTION_RTL)
		_titleView.setPadding(20, 20, 20, 0)
		_titleView.textSize = 12F
		_durationView.textSize = 10F
		// see: https://stackoverflow.com/questions/17410195/setshadowlayer-android-api-differences
		_titleView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
		_durationView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

		val layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
		layoutParams.gravity = Gravity.BOTTOM or Gravity.RIGHT
		layoutParams.setMargins(0, 0, 20, 20)
		_durationView.layoutParams = layoutParams

		_durationView.setBackgroundResource(R.drawable.duration_rounded_corners)

		// Setup blurred background image (hidden by default, shown for vertical videos)
		_blurredBackgroundView.scaleType = ImageView.ScaleType.CENTER_CROP
		_blurredBackgroundView.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		_blurredBackgroundView.setBackgroundResource(R.drawable.rounded_thumbnail)
		_blurredBackgroundView.clipToOutline = true
		_blurredBackgroundView.visibility = View.GONE
		_blurredBackgroundView.id = View.generateViewId()
		this.addView(_blurredBackgroundView)

		// Setup black overlay (30% opacity, hidden by default, shown for vertical videos)
		_blackOverlayView.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		_blackOverlayView.setBackgroundColor(0x4D000000.toInt()) // 30% opacity black (4D = 77/255 ≈ 30%)
		_blackOverlayView.visibility = View.GONE
		_blackOverlayView.id = View.generateViewId()
		this.addView(_blackOverlayView)

		_imageView.scaleType = ImageView.ScaleType.CENTER_CROP
		_imageView.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		_imageView.setBackgroundResource(R.drawable.rounded_thumbnail)
		_imageView.clipToOutline = true

		val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.lato_black)
		_titleView.setTypeface(typeface)
		_durationView.setTypeface(typeface)

		_imageView.id = View.generateViewId()
		this.addView(_imageView)

		// Create gradient drawable for backdrop (top to bottom)
		val gradientDrawable = GradientDrawable(
			GradientDrawable.Orientation.TOP_BOTTOM,
			intArrayOf(
				Color.parseColor("#80000000"), // Top color (semi-transparent black)
				Color.parseColor("#20000000"), // Middle (in between top and bottom)
				Color.parseColor("#00000000")  // Bottom color (transparent)
			)
		)
		gradientDrawable.gradientType = GradientDrawable.LINEAR_GRADIENT
		gradientDrawable.cornerRadius = 8 * resources.displayMetrics.density
		_backDropView.background = gradientDrawable

		_backDropView.post {
			val drawable = _backDropView.background as? GradientDrawable
			drawable?.setGradientCenter(0.5f, 0.3f)
		}

		val backDropLayoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
		_backDropView.layoutParams = backDropLayoutParams
		this.addView(_backDropView)

		_titleView.id = View.generateViewId()
		this.addView(_titleView)
		_durationView.id = View.generateViewId()
		this.addView(_durationView)

		_update()
	}

	fun __destruct() {
		this.removeAllViews()
	}

	fun updateSettings(settings: Map<String, Any?>) {
		if (settings["foregroundColor"] is Int) _foregroundColor = settings["foregroundColor"] as Int
		_update()
	}

	fun updateContent(content: Map<String, Any?>) {
		var isVertical = false
		if (content["isVertical"] is Boolean) isVertical = content["isVertical"] as Boolean

		if (content["thumbnailUrl"] is String) {
			val thumbnailUrl = content["thumbnailUrl"] as String

			if (isVertical) {
				// For vertical videos, show blurred background, black overlay, and fit the main image
				_blurredBackgroundView.visibility = View.VISIBLE
				_blackOverlayView.visibility = View.VISIBLE
				_imageView.scaleType = ImageView.ScaleType.FIT_CENTER

				// Load main image
				_imageView.load(thumbnailUrl) {
					crossfade(true)
				}

				// Load blurred background
				_blurredBackgroundView.load(thumbnailUrl) {
					transformations(BlurTransformation(radius = 5f, sampling = 1f))
					crossfade(true)
				}
			} else {
				// For horizontal videos, hide blurred background, black overlay, and use center crop
				_blurredBackgroundView.visibility = View.GONE
				_blackOverlayView.visibility = View.GONE
				_imageView.scaleType = ImageView.ScaleType.CENTER_CROP

				// Load main image
				_imageView.load(thumbnailUrl) {
					crossfade(true)
				}
			}
		}

		if (content["title"] is String) _titleView.text = content["title"] as String
		if (content["description"] is String) _titleView.hint = content["description"] as String
		if (content["duration"] is String) _durationView.text = content["duration"] as String

		_update() // OBSOLETE?!?
	}

	private fun _update() {
		val r: Int = Color.red(_foregroundColor)
		val g: Int = Color.green(_foregroundColor)
		val b: Int = Color.blue(_foregroundColor)
		val shadowColor = if (r + g + b < 384) 0x80FFFFFF.toInt() else 0x80000000.toInt()
		val shadowD = if (r + g + b < 384) -2F else 2F

		_titleView.setTextColor(_foregroundColor)
		_titleView.setShadowLayer(2F, 0F, shadowD, shadowColor)

		_durationView.setTextColor(_foregroundColor)
		_durationView.setShadowLayer(2F, 0F, shadowD, shadowColor)
	}
}

