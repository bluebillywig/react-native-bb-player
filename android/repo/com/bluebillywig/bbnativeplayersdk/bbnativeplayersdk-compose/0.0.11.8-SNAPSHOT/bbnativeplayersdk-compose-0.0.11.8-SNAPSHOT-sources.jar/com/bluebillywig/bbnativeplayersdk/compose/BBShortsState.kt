package com.bluebillywig.bbnativeplayersdk.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.bluebillywig.bbnativeplayersdk.BBNativeShortsView
import com.bluebillywig.bbnativeplayersdk.BBNativeShortsViewDelegate

/**
 * Reactive state holder for [BBNativeShorts].
 *
 * Bridges [BBNativeShortsViewDelegate] callbacks to Compose state.
 * Create with [rememberBBShortsState].
 */
@Stable
class BBShortsState {
    // --- Setup state ---
    var isReady: Boolean by mutableStateOf(false)
        internal set
    var jsonUrl: String? by mutableStateOf(null)
        internal set

    // --- Error state ---
    var error: String? by mutableStateOf(null)
        internal set

    // Internal reference to the underlying shorts view
    internal var shortsView: BBNativeShortsView? = null

    // --- Internal delegate bridge ---

    internal val delegate = object : BBNativeShortsViewDelegate {
        override fun didSetupWithJsonUrl(shortsView: BBNativeShortsView, url: String?) {
            jsonUrl = url
            isReady = true
        }

        override fun didFailWithError(shortsView: BBNativeShortsView, error: String?) {
            this@BBShortsState.error = error
        }
    }
}

/**
 * Remember a [BBShortsState] instance scoped to the current composition.
 */
@Composable
fun rememberBBShortsState(): BBShortsState {
    return remember { BBShortsState() }
}
