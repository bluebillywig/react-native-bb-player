package com.bluebillywig.bbnativeplayersdk.compose

/**
 * Type-safe configuration options for [BBNativeShorts].
 *
 * @param displayFormat The display format: "full", "list", or "player".
 * @param shelfStartSpacing Spacing at the start of the shorts list (pixels).
 * @param shelfEndSpacing Spacing at the end of the shorts list (pixels).
 * @param custom Escape hatch for custom or undocumented options.
 *
 * @see BBNativeShorts
 */
data class BBShortsOptions(
    val displayFormat: String? = null,
    val shelfStartSpacing: Int? = null,
    val shelfEndSpacing: Int? = null,
    /** Escape hatch for custom or undocumented options. */
    val custom: Map<String, Any?>? = null,
) {
    internal fun toMap(): Map<String, Any?> = buildMap {
        // Apply custom first so typed properties take precedence
        custom?.let { putAll(it) }
        displayFormat?.let { put("displayFormat", it) }
        shelfStartSpacing?.let { put("shelfStartSpacing", it) }
        shelfEndSpacing?.let { put("shelfEndSpacing", it) }
    }
}
