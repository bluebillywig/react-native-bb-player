package com.bluebillywig.bbnativeplayersdk.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.bluebillywig.bbnativeplayersdk.BBNativePlayerView
import com.bluebillywig.bbnativeplayersdk.BBNativePlayerViewDelegate
import com.bluebillywig.bbnativeshared.enums.Phase
import com.bluebillywig.bbnativeshared.enums.State
import com.bluebillywig.bbnativeshared.model.MediaClip
import com.bluebillywig.bbnativeshared.model.Project

/**
 * Reactive state holder that bridges [BBNativePlayerViewDelegate] callbacks to Compose state.
 *
 * Observe any property directly in a composable to trigger recomposition when it changes.
 * Use the imperative control methods ([play], [pause], [seek], etc.) to control the player.
 *
 * Create with [rememberBBPlayerState].
 */
@Stable
class BBPlayerState {
    // --- Playback state ---
    var phase: Phase? by mutableStateOf(null)
        internal set
    var state: State? by mutableStateOf(null)
        internal set
    var isPlaying: Boolean by mutableStateOf(false)
        internal set
    var duration: Double by mutableStateOf(0.0)
        internal set
    var volume: Double by mutableStateOf(1.0)
        internal set
    var isFullscreen: Boolean by mutableStateOf(false)
        internal set
    var mode: String? by mutableStateOf(null)
        internal set

    // --- Content metadata ---
    var clipData: MediaClip? by mutableStateOf(null)
        internal set
    var projectData: Project? by mutableStateOf(null)
        internal set

    // --- Setup state ---
    var isReady: Boolean by mutableStateOf(false)
        internal set
    var jsonUrl: String? by mutableStateOf(null)
        internal set

    // --- Error state ---
    var error: String? by mutableStateOf(null)
        internal set

    // --- Ad state ---
    var isAdPlaying: Boolean by mutableStateOf(false)
        internal set

    // Internal reference to the underlying player view
    internal var playerView: BBNativePlayerView? = null

    // --- Current time tracking (same pattern as RN wrapper) ---
    private var lastKnownTime: Double = 0.0
    private var playbackStartTimestamp: Long = 0L

    /** Estimated current playback position in seconds. */
    val currentTime: Double
        get() = if (isPlaying && playbackStartTimestamp > 0) {
            val elapsedSeconds = (System.currentTimeMillis() - playbackStartTimestamp) / 1000.0
            kotlin.math.min(lastKnownTime + elapsedSeconds, duration)
        } else {
            lastKnownTime
        }

    // --- Imperative controls ---

    /** Start or resume playback. */
    fun play() { playerView?.player?.play() }

    /** Pause playback. */
    fun pause() { playerView?.player?.pause() }

    /** Seek to the given absolute position in seconds. */
    fun seek(seconds: Double) { playerView?.player?.seek(seconds) }

    /** Seek relative to the current position (e.g. +10.0 or -10.0 seconds). */
    fun seekRelative(offsetInSeconds: Double) {
        playerView?.player?.seek(offsetInSeconds, relativeToCurrentTime = true)
    }

    /** Set the playback volume (0.0 to 1.0). */
    fun setVolume(volume: Double) { playerView?.player?.setVolume(volume) }

    /** Set the muted state. */
    fun setMuted(muted: Boolean) { playerView?.player?.setMuted(muted) }

    /** Enter fullscreen mode. Requires the hosting Activity to extend AppCompatActivity. */
    fun enterFullScreen() { playerView?.player?.enterFullScreen() }

    /** Exit fullscreen mode. */
    fun exitFullScreen() { playerView?.player?.exitFullScreen() }

    /** Load a clip by ID. */
    fun loadClip(clipId: String, autoPlay: Boolean = true, seekTo: Number? = null) {
        playerView?.player?.loadWithClipId(clipId, autoPlay = autoPlay, seekTo = seekTo)
    }

    /** Load a project by ID. */
    fun loadProject(projectId: String, autoPlay: Boolean = true) {
        playerView?.player?.loadWithProjectId(projectId, autoPlay = autoPlay)
    }

    /** Load a clip list by ID. */
    fun loadClipList(clipListId: String, autoPlay: Boolean = true) {
        playerView?.player?.loadWithClipListId(clipListId, autoPlay = autoPlay)
    }

    /** Destroy the player and release resources. */
    fun destroy() { playerView?.destroy() }

    /** Get the muted state. */
    fun isMuted(): Boolean = volume == 0.0

    /** Show the Chromecast device picker by programmatically clicking the cast button in the player UI. */
    fun showCastPicker() {
        val view = playerView ?: return
        // Find cast button by resource ID (exo_cast_button) in the player view hierarchy
        val castButtonId = view.resources.getIdentifier("exo_cast_button", "id", view.context.packageName)
        if (castButtonId != 0) {
            view.findViewById<android.view.View>(castButtonId)?.performClick()
        }
    }

    // --- Internal delegate bridge ---

    internal val delegate = object : BBNativePlayerViewDelegate {
        override fun didSetupWithJsonUrl(playerView: BBNativePlayerView, url: String?) {
            jsonUrl = url
            isReady = true
        }

        override fun didFailWithError(playerView: BBNativePlayerView, error: String?) {
            this@BBPlayerState.error = error
        }

        override fun didTriggerApiReady(playerView: BBNativePlayerView) {
            // API ready — isReady already set via didSetupWithJsonUrl
        }

        override fun didTriggerPlaying(playerView: BBNativePlayerView) {
            playbackStartTimestamp = System.currentTimeMillis()
            isPlaying = true
        }

        override fun didTriggerPause(playerView: BBNativePlayerView) {
            lastKnownTime = currentTime
            playbackStartTimestamp = 0L
            isPlaying = false
        }

        override fun didTriggerPlay(playerView: BBNativePlayerView) {
            // Play command issued (not yet actually playing — didTriggerPlaying fires when buffered)
        }

        override fun didTriggerEnded(playerView: BBNativePlayerView) {
            lastKnownTime = duration
            playbackStartTimestamp = 0L
            isPlaying = false
        }

        override fun didTriggerSeeking(playerView: BBNativePlayerView) {
            // Seeking started
        }

        override fun didTriggerSeeked(playerView: BBNativePlayerView, seekOffset: Double?) {
            lastKnownTime = seekOffset ?: 0.0
            playbackStartTimestamp = if (isPlaying) System.currentTimeMillis() else 0L
        }

        override fun didTriggerPhaseChange(playerView: BBNativePlayerView, phase: Phase?) {
            this@BBPlayerState.phase = phase
        }

        override fun didTriggerStateChange(playerView: BBNativePlayerView, state: State?) {
            this@BBPlayerState.state = state
        }

        override fun didTriggerDurationChange(playerView: BBNativePlayerView, duration: Double?) {
            this@BBPlayerState.duration = duration ?: 0.0
        }

        override fun didTriggerVolumeChange(playerView: BBNativePlayerView, volume: Double?) {
            this@BBPlayerState.volume = volume ?: 1.0
        }

        override fun didTriggerFullscreen(playerView: BBNativePlayerView) {
            isFullscreen = true
        }

        override fun didTriggerRetractFullscreen(playerView: BBNativePlayerView) {
            isFullscreen = false
        }

        override fun didTriggerMediaClipLoaded(playerView: BBNativePlayerView, clipData: MediaClip?) {
            lastKnownTime = 0.0
            playbackStartTimestamp = 0L
            this@BBPlayerState.clipData = clipData
        }

        override fun didTriggerProjectLoaded(playerView: BBNativePlayerView, projectData: Project?) {
            this@BBPlayerState.projectData = projectData
        }

        override fun didTriggerModeChange(playerView: BBNativePlayerView, mode: String?) {
            this@BBPlayerState.mode = mode
        }

        override fun didTriggerAdStarted(playerView: BBNativePlayerView) {
            isAdPlaying = true
        }

        override fun didTriggerAdFinished(playerView: BBNativePlayerView) {
            isAdPlaying = false
        }

        override fun didTriggerAllAdsCompleted(playerView: BBNativePlayerView) {
            isAdPlaying = false
        }
    }
}

/**
 * Remember a [BBPlayerState] instance scoped to the current composition.
 */
@Composable
fun rememberBBPlayerState(): BBPlayerState {
    return remember { BBPlayerState() }
}
