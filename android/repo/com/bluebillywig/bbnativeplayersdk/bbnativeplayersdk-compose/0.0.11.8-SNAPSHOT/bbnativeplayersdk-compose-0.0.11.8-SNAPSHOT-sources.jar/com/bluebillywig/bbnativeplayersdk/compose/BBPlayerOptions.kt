package com.bluebillywig.bbnativeplayersdk.compose

/**
 * Type-safe configuration options for [BBNativePlayer].
 *
 * Replaces the untyped `Map<String, Any?>` options parameter with compile-time checked properties.
 * Use [custom] as an escape hatch for any options not yet covered by typed properties.
 *
 * @see BBNativePlayer
 */
data class BBPlayerOptions(
    val autoPlay: Boolean? = null,
    val muted: Boolean? = null,
    val noChromeCast: Boolean? = null,
    val noStats: Boolean? = null,
    val commercials: Boolean? = null,
    val forceFullscreenLandscape: Boolean? = null,
    val allowCollapseExpand: Boolean? = null,
    val showChromeCastMiniControlsInPlayer: Boolean? = null,
    val showDescription: Boolean? = null,
    val waitForCmp: Boolean? = null,
    val handleConsentManagement: Boolean? = null,
    val tagForUnderAgeOfConsent: Boolean? = null,
    val consentString: String? = null,
    val consentGdprApplies: Int? = null,
    val consentCmpVersion: Int? = null,
    val adsystemPpid: String? = null,
    val adsystemBuid: String? = null,
    /** Custom parameters to add to ad tag URLs. Keys should NOT include the "adTagUrlParam_" prefix. */
    val adTagUrlParams: Map<String, String>? = null,
    /** Escape hatch for custom or undocumented options. */
    val custom: Map<String, Any?>? = null,
) {
    internal fun toMap(): Map<String, Any?> = buildMap {
        // Apply custom first so typed properties take precedence
        custom?.let { putAll(it) }
        autoPlay?.let { put("autoPlay", it) }
        muted?.let { put("muted", it) }
        noChromeCast?.let { put("noChromeCast", it) }
        noStats?.let { put("noStats", it) }
        commercials?.let { put("commercials", it) }
        forceFullscreenLandscape?.let { put("forceFullscreenLandscape", it) }
        allowCollapseExpand?.let { put("allowCollapseExpand", it) }
        showChromeCastMiniControlsInPlayer?.let { put("showChromeCastMiniControlsInPlayer", it) }
        showDescription?.let { put("showDescription", it) }
        waitForCmp?.let { put("waitForCmp", it) }
        handleConsentManagement?.let { put("handleConsentManagement", it) }
        tagForUnderAgeOfConsent?.let { put("tagForUnderAgeOfConsent", it) }
        consentString?.let { put("consent_string", it) }
        consentGdprApplies?.let { put("consent_gdprApplies", it) }
        consentCmpVersion?.let { put("consent_cmpVersion", it) }
        adsystemPpid?.let { put("adsystem_ppid", it) }
        adsystemBuid?.let { put("adsystem_buid", it) }
        adTagUrlParams?.forEach { (k, v) -> put("adTagUrlParam_$k", v) }
    }
}
