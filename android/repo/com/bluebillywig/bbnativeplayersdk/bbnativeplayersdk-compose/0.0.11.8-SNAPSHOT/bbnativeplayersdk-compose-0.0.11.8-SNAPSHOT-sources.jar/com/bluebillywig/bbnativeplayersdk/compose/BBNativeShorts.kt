package com.bluebillywig.bbnativeplayersdk.compose

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.bluebillywig.bbnativeplayersdk.BBNativeShorts as BBNativeShortsFactory

/**
 * A Jetpack Compose wrapper for [BBNativeShortsView][com.bluebillywig.bbnativeplayersdk.BBNativeShortsView].
 *
 * Embeds the Blue Billywig Shorts experience in a Compose layout using [AndroidView].
 *
 * ## Example
 * ```kotlin
 * @Composable
 * fun ShortsScreen(shortsUrl: String) {
 *     val shortsState = rememberBBShortsState()
 *
 *     BBNativeShorts(
 *         jsonUrl = shortsUrl,
 *         modifier = Modifier.fillMaxSize(),
 *         state = shortsState,
 *         options = BBShortsOptions(displayFormat = "full"),
 *     )
 * }
 * ```
 *
 * @param jsonUrl The JSON embed URL for the shorts configuration.
 * @param modifier Modifier for sizing and layout.
 * @param options Type-safe shorts options. Defaults to empty (uses defaults).
 * @param state Reactive state holder. Create with [rememberBBShortsState].
 * @param onReady Called when the shorts view has finished setup.
 * @param onError Called when the shorts view encounters an error.
 */
@Composable
fun BBNativeShorts(
    jsonUrl: String,
    modifier: Modifier = Modifier,
    options: BBShortsOptions = BBShortsOptions(),
    state: BBShortsState = rememberBBShortsState(),
    onReady: (() -> Unit)? = null,
    onError: ((String?) -> Unit)? = null,
) {
    val activityContext = LocalContext.current.findActivity()

    AndroidView(
        modifier = modifier,
        factory = { _ ->
            BBNativeShortsFactory.createShortsView(activityContext, jsonUrl, options.toMap()).also { view ->
                state.shortsView = view
                view.delegate = state.delegate
            }
        },
        onRelease = { view ->
            state.shortsView = null
            view.__destruct()
        },
    )

    // Forward optional callbacks from state changes
    if (onReady != null) {
        LaunchedEffect(state.isReady) {
            if (state.isReady) onReady()
        }
    }
    if (onError != null) {
        LaunchedEffect(state.error) {
            state.error?.let { onError(it) }
        }
    }
}

private fun Context.findActivity(): Activity {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    throw IllegalStateException("No Activity found in context chain")
}
