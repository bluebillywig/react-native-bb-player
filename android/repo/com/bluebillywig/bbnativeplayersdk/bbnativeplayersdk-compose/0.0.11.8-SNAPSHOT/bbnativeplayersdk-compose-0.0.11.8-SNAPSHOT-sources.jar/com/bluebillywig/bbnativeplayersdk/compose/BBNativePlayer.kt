package com.bluebillywig.bbnativeplayersdk.compose

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.bluebillywig.bbnativeplayersdk.BBNativePlayer as BBNativePlayerFactory

/**
 * A Jetpack Compose wrapper for [BBNativePlayerView][com.bluebillywig.bbnativeplayersdk.BBNativePlayerView].
 *
 * Embeds the Blue Billywig native video player in a Compose layout using [AndroidView].
 * Observe the player's reactive state via [state] and control it with [BBPlayerState] methods.
 *
 * ## Example
 * ```kotlin
 * @Composable
 * fun VideoScreen(clipUrl: String) {
 *     val playerState = rememberBBPlayerState()
 *
 *     BBNativePlayer(
 *         jsonUrl = clipUrl,
 *         modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
 *         state = playerState,
 *         options = BBPlayerOptions(autoPlay = false, noChromeCast = true),
 *     )
 *
 *     Button(onClick = {
 *         if (playerState.isPlaying) playerState.pause() else playerState.play()
 *     }) {
 *         Text(if (playerState.isPlaying) "Pause" else "Play")
 *     }
 * }
 * ```
 *
 * @param jsonUrl The JSON embed URL for the player configuration.
 * @param modifier Modifier for sizing and layout.
 * @param options Type-safe player options. Defaults to empty (uses playout defaults).
 * @param state Reactive state holder. Create with [rememberBBPlayerState].
 * @param onReady Called when the player has finished setup.
 * @param onError Called when the player encounters an error.
 * @param onEnded Called when playback ends.
 */
@Composable
fun BBNativePlayer(
    jsonUrl: String,
    modifier: Modifier = Modifier,
    options: BBPlayerOptions = BBPlayerOptions(),
    state: BBPlayerState = rememberBBPlayerState(),
    onReady: (() -> Unit)? = null,
    onError: ((String?) -> Unit)? = null,
    onEnded: (() -> Unit)? = null,
) {
    val activityContext = LocalContext.current.findActivity()

    AndroidView(
        modifier = modifier,
        factory = { _ ->
            BBNativePlayerFactory.createPlayerView(activityContext, jsonUrl, options.toMap()).also { view ->
                state.playerView = view
                view.delegate = state.delegate
            }
        },
        onRelease = { view ->
            state.playerView = null
            view.destroy()
        },
    )

    // Forward optional callbacks from state changes
    if (onReady != null) {
        LaunchedEffect(state.isReady) {
            if (state.isReady) onReady()
        }
    }
    if (onError != null) {
        LaunchedEffect(state.error) {
            state.error?.let { onError(it) }
        }
    }
    if (onEnded != null) {
        LaunchedEffect(state.isPlaying, state.phase) {
            if (!state.isPlaying && state.phase == com.bluebillywig.bbnativeshared.enums.Phase.EXIT) {
                onEnded()
            }
        }
    }
}

private fun Context.findActivity(): Activity {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    throw IllegalStateException("No Activity found in context chain")
}
